// Ubica · Número de versión. GitHub lo reescribe en cada compilación (ver compilar-apk.yml);
// en el repositorio se queda así.
window.APP_VERSION = { numero: '', fecha: '', commit: '' };
