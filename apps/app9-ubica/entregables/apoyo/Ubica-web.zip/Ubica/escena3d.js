// Ubica · Escena 3D: el mismo lugar que dibuja escena.js, en tres dimensiones reales (Three.js).
//
// Este archivo es un "módulo" que la app carga SOLO cuando se abre la vista 3D (ver vistas.js):
// así quien usa listas o 2.5D no descarga el motor 3D (~690 KB).
//
// Reglas de la arquitectura:
//   - No guarda nada. Lee lo mismo que la escena 2.5D (opciones.estado()) y avisa de lo que hace
//     la persona con opciones.alTocar() y opciones.alArrastrarMueble(); quien valida y guarda es
//     nucleo.js a través de la app. Por eso un mueble movido aquí aparece movido en 2.5D.
//   - Los muebles se arman con el catálogo de piezas de nucleo.js (piezasMueble): tablero,
//     patas, repisas, puertas… con las medidas y el giro guardados en los datos.
//   - Coordenadas: la casilla (x, y) del lugar es el punto (x, z) del mundo 3D; la altura es Y.
//   - Se dibuja solo cuando algo cambia (no 60 veces por segundo) para cuidar la batería.
import * as THREE from './vendor/three.module.min.js';

const N = window.Nucleo;
const ALTO_PISO = 1.15;          // cuánto mide en el mundo un "piso" de altura del catálogo
const POLAR_MINIMO = 0.12;       // la cámara casi desde arriba…
const POLAR_MAXIMO = 1.42;       // …y nunca por debajo del piso
const UMBRAL_TOQUE = 8;

export function crear(contenedor, opciones) {
  const temaOscuro = window.matchMedia('(prefers-color-scheme: dark)');
  const renderizador = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'low-power' });
  renderizador.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderizador.shadowMap.enabled = true;
  renderizador.shadowMap.type = THREE.PCFSoftShadowMap;
  renderizador.outputColorSpace = THREE.SRGBColorSpace;
  const lienzo = renderizador.domElement;
  lienzo.setAttribute('role', 'img');
  lienzo.setAttribute('aria-label', 'Vista 3D del lugar');
  lienzo.style.touchAction = 'none';
  contenedor.appendChild(lienzo);

  const escena = new THREE.Scene();
  const camara = new THREE.PerspectiveCamera(42, 1, 0.1, 400);
  const luzAmbiente = new THREE.HemisphereLight(0xffffff, 0x8892a6, 1.15);
  const sol = new THREE.DirectionalLight(0xffffff, 2.1);
  sol.castShadow = true;
  sol.shadow.mapSize.set(1024, 1024);
  sol.shadow.bias = -0.0005;
  sol.shadow.normalBias = 0.03;
  escena.add(luzAmbiente, sol, sol.target);

  const grupoSala = new THREE.Group();     // piso y paredes
  const grupoMuebles = new THREE.Group();  // un grupo por mueble
  const grupoMarcas = new THREE.Group();   // selección y vista previa al arrastrar
  escena.add(grupoSala, grupoMuebles, grupoMarcas);

  const cubo = new THREE.BoxGeometry(1, 1, 1); // todas las piezas son este cubo, estirado
  const materiales = new Map();
  const texturasEtiqueta = new Map();
  const muebles3d = new Map();              // id → { grupo, firma, etiqueta }
  let paredes = [];
  let sala = null;
  let claveSala = '';
  let ancho = 0;
  let alto = 0;
  let destruida = false;
  let cuadroPedido = false;
  let sombrasRevisadas = 0;

  // ---------- Cámara: gira alrededor de un punto del piso ----------
  // actual → lo que se ve; meta → a dónde va. Cada cuadro se acerca un poco (movimiento suave).
  const actual = { azimut: Math.PI / 4, polar: 0.95, distancia: 14, x: 0, z: 0 };
  const meta = Object.assign({}, actual);
  let ultimaInteraccion = 0;

  function limitarMeta() {
    meta.polar = Math.max(POLAR_MINIMO, Math.min(POLAR_MAXIMO, meta.polar));
    if (!sala) return;
    const radio = Math.hypot(sala.ancho, sala.fondo) / 2;
    meta.distancia = Math.max(2.5, Math.min(radio * 5 + 6, meta.distancia));
    meta.x = Math.max(-1, Math.min(sala.ancho + 1, meta.x));   // el punto de mira no sale del lugar:
    meta.z = Math.max(-1, Math.min(sala.fondo + 1, meta.z));   // así la cámara nunca se pierde
  }

  function distanciaGeneral() {
    const radio = Math.hypot(sala.ancho, sala.fondo) / 2 + 0.8;
    const medioAngulo = THREE.MathUtils.degToRad(camara.fov / 2);
    const aspecto = ancho && alto ? ancho / alto : 1;
    return (radio / Math.sin(medioAngulo)) * (aspecto < 1 ? Math.min(1.9, 0.8 / aspecto) : 0.74);
  }

  function vistaGeneral(inmediata) {
    if (!sala) return;
    Object.assign(meta, { azimut: Math.PI / 4, polar: 0.95, distancia: distanciaGeneral(), x: sala.ancho / 2, z: sala.fondo / 2 });
    if (inmediata) Object.assign(actual, meta);
    pedirCuadro();
  }

  function colocarCamara() {
    const s = Math.sin(actual.polar);
    camara.position.set(
      actual.x + actual.distancia * s * Math.sin(actual.azimut),
      actual.distancia * Math.cos(actual.polar),
      actual.z + actual.distancia * s * Math.cos(actual.azimut));
    camara.lookAt(actual.x, 0.6, actual.z);
    // Casa de muñecas: se ocultan las paredes que quedarían entre la cámara y el interior
    if (sala && paredes.length) {
      paredes[0].visible = camara.position.x > 0;            // pared en x = 0
      paredes[1].visible = camara.position.x < sala.ancho;   // pared en x = ancho
      paredes[2].visible = camara.position.z > 0;            // pared en z = 0
      paredes[3].visible = camara.position.z < sala.fondo;   // pared en z = fondo
    }
  }

  // ---------- Colores y materiales ----------
  const variableCss = (nombre) => getComputedStyle(contenedor).getPropertyValue(nombre).trim();

  function material(clave, crearMaterial) {
    if (!materiales.has(clave)) materiales.set(clave, crearMaterial());
    return materiales.get(clave);
  }

  function materialDePieza(tipoClave, mat) {
    return material(tipoClave + '|' + mat + '|' + temaOscuro.matches, () => {
      const [tono, saturacion, luzBase] = (N.TIPOS_MUEBLE[tipoClave] || N.TIPOS_MUEBLE.caja).color;
      const luz = luzBase - (temaOscuro.matches ? 5 : 0);
      const hsl = (t, s, l) => new THREE.Color().setHSL(t / 360, s / 100, Math.max(6, Math.min(92, l)) / 100, THREE.SRGBColorSpace);
      if (mat === 'vidrio') {
        return new THREE.MeshStandardMaterial({ color: 0xbfe9f2, transparent: true, opacity: 0.3, roughness: 0.08, metalness: 0.1, depthWrite: false });
      }
      if (mat === 'metal') return new THREE.MeshStandardMaterial({ color: 0x9aa1ad, roughness: 0.35, metalness: 0.75 });
      if (mat === 'madera') return new THREE.MeshStandardMaterial({ color: hsl(30, 48, 60), roughness: 0.7 });
      const luces = { cuerpo: luz, oscuro: luz - 14, claro: luz + 13 };
      return new THREE.MeshStandardMaterial({ color: hsl(tono, saturacion, luces[mat] == null ? luz : luces[mat]), roughness: 0.78 });
    });
  }

  // ---------- Sala: piso con cuadrícula y cuatro paredes bajas ----------
  function construirSala() {
    grupoSala.children.slice().forEach((hijo) => {
      grupoSala.remove(hijo);
      if (hijo.material.map) hijo.material.map.dispose();
      hijo.material.dispose();
      if (hijo.geometry !== cubo) hijo.geometry.dispose();
    });
    const tono = N.TIPOS_LUGAR[sala.tipo].tono;
    const oscuro = temaOscuro.matches;
    // El piso es una imagen con las casillas (una por metro), igual que en 2.5D
    const px = 48;
    const imagen = document.createElement('canvas');
    imagen.width = sala.ancho * px;
    imagen.height = sala.fondo * px;
    const ctx = imagen.getContext('2d');
    for (let x = 0; x < sala.ancho; x++) {
      for (let y = 0; y < sala.fondo; y++) {
        ctx.fillStyle = 'hsl(' + tono + ' 18% ' + ((x + y) % 2 ? (oscuro ? 22 : 93) : (oscuro ? 19 : 89)) + '%)';
        ctx.fillRect(x * px, y * px, px, px);
        ctx.strokeStyle = oscuro ? 'rgba(255,255,255,0.07)' : 'rgba(30,40,70,0.10)';
        ctx.strokeRect(x * px + 0.5, y * px + 0.5, px - 1, px - 1);
      }
    }
    const textura = new THREE.CanvasTexture(imagen);
    textura.colorSpace = THREE.SRGBColorSpace;
    textura.anisotropy = Math.min(8, renderizador.capabilities.getMaxAnisotropy());
    const piso = new THREE.Mesh(new THREE.PlaneGeometry(sala.ancho, sala.fondo), new THREE.MeshStandardMaterial({ map: textura, roughness: 0.95 }));
    piso.rotation.x = -Math.PI / 2;
    piso.position.set(sala.ancho / 2, 0, sala.fondo / 2);
    piso.receiveShadow = true;
    piso.userData.piso = true;
    grupoSala.add(piso);

    const altoPared = N.ALTO_PARED * ALTO_PISO;
    const grosor = 0.12;
    const colorPared = new THREE.Color().setHSL(tono / 360, 0.14, oscuro ? 0.27 : 0.86, THREE.SRGBColorSpace);
    const pared = (x, z, w, d) => {
      const malla = new THREE.Mesh(cubo, new THREE.MeshStandardMaterial({ color: colorPared, roughness: 0.95 }));
      malla.scale.set(w, altoPared, d);
      malla.position.set(x, altoPared / 2, z);
      malla.receiveShadow = true;
      grupoSala.add(malla);
      return malla;
    };
    paredes = [
      pared(-grosor / 2, sala.fondo / 2, grosor, sala.fondo + 2 * grosor),
      pared(sala.ancho + grosor / 2, sala.fondo / 2, grosor, sala.fondo + 2 * grosor),
      pared(sala.ancho / 2, -grosor / 2, sala.ancho, grosor),
      pared(sala.ancho / 2, sala.fondo + grosor / 2, sala.ancho, grosor)
    ];
    // Luces según el tamaño del lugar (las sombras deben cubrirlo completo)
    const radio = Math.hypot(sala.ancho, sala.fondo) / 2 + 1;
    sol.position.set(sala.ancho / 2 + radio * 0.6, radio * 1.8 + 4, sala.fondo / 2 + radio * 0.9);
    sol.target.position.set(sala.ancho / 2, 0, sala.fondo / 2);
    Object.assign(sol.shadow.camera, { left: -radio, right: radio, top: radio, bottom: -radio, near: 0.5, far: radio * 5 + 10 });
    sol.shadow.camera.updateProjectionMatrix();
    luzAmbiente.intensity = oscuro ? 0.75 : 1.15;
    sol.intensity = oscuro ? 1.5 : 2.1;
  }

  // ---------- Muebles ----------
  function construirMueble(mueble) {
    const grupo = new THREE.Group();
    const medidas = N.medidasSinGiro(mueble);
    N.piezasMueble(mueble.tipo, medidas.ancho, medidas.fondo).forEach((pieza) => {
      const malla = new THREE.Mesh(cubo, materialDePieza(mueble.tipo, pieza.mat));
      malla.scale.set(pieza.w, pieza.h * ALTO_PISO, pieza.d);
      // El modelo se arma centrado en su huella, con el frente hacia +z
      malla.position.set(pieza.x + pieza.w / 2 - medidas.ancho / 2, (pieza.z + pieza.h / 2) * ALTO_PISO, pieza.y + pieza.d / 2 - medidas.fondo / 2);
      malla.castShadow = pieza.mat !== 'vidrio';
      malla.receiveShadow = true;
      grupo.add(malla);
    });
    grupo.rotation.y = -(mueble.giro || 0) * Math.PI / 2; // la orientación guardada en los datos
    grupo.position.set(mueble.x + mueble.ancho / 2, 0, mueble.y + mueble.fondo / 2);
    grupo.userData.muebleId = mueble.id;
    return grupo;
  }

  function texturaEtiqueta(texto) {
    if (!texturasEtiqueta.has(texto)) {
      const imagen = document.createElement('canvas');
      imagen.width = 128;
      imagen.height = 64;
      const ctx = imagen.getContext('2d');
      ctx.fillStyle = temaOscuro.matches ? '#eceef4' : '#ffffff';
      ctx.strokeStyle = 'rgba(20,24,40,0.35)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(32, 6);
      ctx.arcTo(122, 6, 122, 58, 26);
      ctx.arcTo(122, 58, 6, 58, 26);
      ctx.arcTo(6, 58, 6, 6, 26);
      ctx.arcTo(6, 6, 122, 6, 26);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#171a26';
      ctx.font = '700 34px Inter, system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(texto, 64, 34);
      const textura = new THREE.CanvasTexture(imagen);
      textura.colorSpace = THREE.SRGBColorSpace;
      texturasEtiqueta.set(texto, textura);
    }
    return texturasEtiqueta.get(texto);
  }

  function ponerEtiqueta(registro, mueble, piezas) {
    if (registro.etiqueta) {
      registro.grupo.remove(registro.etiqueta);
      registro.etiqueta.material.dispose();
      registro.etiqueta = null;
    }
    if (!piezas) return;
    const etiqueta = new THREE.Sprite(new THREE.SpriteMaterial({ map: texturaEtiqueta(String(piezas)), depthTest: false, sizeAttenuation: false }));
    const altoEtiqueta = 0.03 * Math.min(1.4, 620 / (alto || 620)); // tamaño parecido en celular y en pantalla grande
    etiqueta.scale.set(altoEtiqueta * 2, altoEtiqueta, 1);
    etiqueta.position.set(0, N.altoDe(mueble) * ALTO_PISO + 0.28, 0);
    etiqueta.renderOrder = 10;
    registro.grupo.add(etiqueta);
    registro.etiqueta = etiqueta;
  }

  function quitarMueble(id) {
    const registro = muebles3d.get(id);
    if (!registro) return;
    if (registro.etiqueta) registro.etiqueta.material.dispose();
    grupoMuebles.remove(registro.grupo);
    muebles3d.delete(id);
  }

  // Pone la escena al día con los datos: solo se rehacen los muebles que cambiaron
  function sincronizar(estado) {
    const nuevaClave = estado.espacio.id + '|' + estado.espacio.ancho + '×' + estado.espacio.fondo + '|' + estado.espacio.tipo + '|' + temaOscuro.matches;
    const cambioDeLugar = !sala || sala.id !== estado.espacio.id;
    sala = estado.espacio;
    if (nuevaClave !== claveSala) {
      claveSala = nuevaClave;
      Array.from(muebles3d.keys()).forEach(quitarMueble);
      construirSala();
      if (cambioDeLugar) vistaGeneral(true);
    }
    const vivos = new Set();
    estado.muebles.forEach((mueble) => {
      vivos.add(mueble.id);
      const piezas = estado.piezas(mueble.id);
      const firma = [mueble.tipo, mueble.x, mueble.y, mueble.ancho, mueble.fondo, mueble.giro || 0].join(',');
      let registro = muebles3d.get(mueble.id);
      if (!registro || registro.firma !== firma) {
        quitarMueble(mueble.id);
        registro = { grupo: construirMueble(mueble), firma: firma, etiqueta: null, piezas: -1 };
        grupoMuebles.add(registro.grupo);
        muebles3d.set(mueble.id, registro);
      }
      if (registro.piezas !== piezas) {
        registro.piezas = piezas;
        ponerEtiqueta(registro, mueble, piezas);
      }
    });
    Array.from(muebles3d.keys()).filter((id) => !vivos.has(id)).forEach(quitarMueble);
    marcarSeleccion(estado);
  }

  // ---------- Selección y vista previa del arrastre ----------
  function limpiarMarcas() {
    grupoMarcas.children.slice().forEach((hijo) => {
      grupoMarcas.remove(hijo);
      hijo.geometry.dispose();
      hijo.material.dispose();
    });
  }

  function marco(rect, alturaMueble, color, opacidadPiso) {
    const altura = alturaMueble * ALTO_PISO + 0.06;
    const caja = new THREE.BoxGeometry(rect.ancho + 0.04, altura, rect.fondo + 0.04);
    const lineas = new THREE.LineSegments(new THREE.EdgesGeometry(caja), new THREE.LineBasicMaterial({ color: color, depthTest: false, transparent: true }));
    caja.dispose();
    lineas.position.set(rect.x + rect.ancho / 2, altura / 2, rect.y + rect.fondo / 2);
    lineas.renderOrder = 8;
    const huella = new THREE.Mesh(new THREE.PlaneGeometry(rect.ancho, rect.fondo),
      new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: opacidadPiso, depthWrite: false }));
    huella.rotation.x = -Math.PI / 2;
    huella.position.set(rect.x + rect.ancho / 2, 0.012, rect.y + rect.fondo / 2);
    grupoMarcas.add(lineas, huella);
  }

  function marcarSeleccion(estado) {
    limpiarMarcas();
    const acento = new THREE.Color(variableCss('--acento') || '#3552e0');
    const idMarcado = estado.modo && estado.modo.tipo === 'mover' ? estado.modo.muebleId : estado.seleccionadoId;
    const mueble = idMarcado ? estado.muebles.find((m) => m.id === idMarcado) : null;
    if (mueble && !(arrastre && arrastre.activo)) marco(mueble, N.altoDe(mueble), acento, 0.28);
    if (arrastre && arrastre.activo && arrastre.rect) {
      marco(arrastre.rect, N.altoDe(arrastre.mueble), new THREE.Color(arrastre.valido ? '#19a974' : '#e0434f'), 0.4);
    }
  }

  // ---------- Dibujar ----------
  function pedirCuadro() {
    if (cuadroPedido || destruida) return;
    cuadroPedido = true;
    requestAnimationFrame(cuadro);
  }

  function cuadro(ahora) {
    cuadroPedido = false;
    if (destruida || !sala || !ancho || contenedor.hidden) return;
    const estado = opciones.estado();
    // En modo presentación la cámara gira despacio mientras nadie la toca
    if (estado.presentacion && ahora - ultimaInteraccion > 3500) meta.azimut += 0.0022;
    let enMovimiento = estado.presentacion;
    ['azimut', 'polar', 'distancia', 'x', 'z'].forEach((clave) => {
      const falta = meta[clave] - actual[clave];
      if (Math.abs(falta) > 0.0008) {
        actual[clave] += falta * 0.2;
        enMovimiento = true;
      } else actual[clave] = meta[clave];
    });
    colocarCamara();
    const inicio = performance.now();
    renderizador.render(escena, camara);
    // Si el dispositivo va lento con sombras, se apagan (prioridad: que se pueda usar)
    if (renderizador.shadowMap.enabled && sombrasRevisadas < 12) {
      sombrasRevisadas++;
      if (sombrasRevisadas > 4 && performance.now() - inicio > 45) {
        renderizador.shadowMap.enabled = false;
        sol.castShadow = false;
        materiales.forEach((m) => { m.needsUpdate = true; });
        enMovimiento = true;
      }
    }
    if (enMovimiento) pedirCuadro();
  }

  function pedirDibujo() {
    if (destruida) return;
    const estado = opciones.estado();
    if (!estado.espacio || contenedor.hidden) return;
    if (!ancho) ajustarTamano();
    sincronizar(estado);
    pedirCuadro();
  }

  function ajustarTamano() {
    const caja = contenedor.getBoundingClientRect();
    if (!caja.width || !caja.height) return;
    const primera = !ancho;
    ancho = caja.width;
    alto = caja.height;
    renderizador.setSize(ancho, alto, false);
    lienzo.style.width = '100%';
    lienzo.style.height = '100%';
    camara.aspect = ancho / alto;
    camara.updateProjectionMatrix();
    if (primera && sala) vistaGeneral(true);
    pedirCuadro();
  }

  // ---------- Qué hay bajo el dedo ----------
  const rayo = new THREE.Raycaster();
  const planoPiso = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

  function apuntar(p) {
    rayo.setFromCamera(new THREE.Vector2((p.x / ancho) * 2 - 1, -(p.y / alto) * 2 + 1), camara);
  }

  function muebleEn(p) {
    apuntar(p);
    const toques = rayo.intersectObjects(grupoMuebles.children, true).filter((t) => !t.object.isSprite);
    if (!toques.length) return null;
    let objeto = toques[0].object;
    while (objeto && !objeto.userData.muebleId) objeto = objeto.parent;
    if (!objeto) return null;
    return opciones.estado().muebles.find((m) => m.id === objeto.userData.muebleId) || null;
  }

  function puntoDelPiso(p) {
    apuntar(p);
    return rayo.ray.intersectPlane(planoPiso, new THREE.Vector3());
  }

  function casillaEn(p) {
    const punto = puntoDelPiso(p);
    if (!punto || !sala) return null;
    const casilla = { x: Math.floor(punto.x), y: Math.floor(punto.z) };
    if (casilla.x < 0 || casilla.y < 0 || casilla.x >= sala.ancho || casilla.y >= sala.fondo) return null;
    return casilla;
  }

  // ---------- Gestos: orbitar, desplazar, acercar, tocar y arrastrar un mueble ----------
  const dedos = new Map();
  let gesto = null;     // { tipo: 'orbita' | 'desplazar' | 'arrastre', inicio, movido }
  let arrastre = null;  // { mueble, pisoInicio, rect, valido, activo }
  let pellizco = null;

  const posicion = (evento) => {
    const caja = lienzo.getBoundingClientRect();
    return { x: evento.clientX - caja.left, y: evento.clientY - caja.top };
  };

  function desplazar(dx, dy) {
    // Mueve el punto de mira sobre el piso, en la dirección en que se arrastra la pantalla
    const paso = actual.distancia * 0.0016;
    const cos = Math.cos(actual.azimut);
    const sen = Math.sin(actual.azimut);
    meta.x += (-dx * cos - dy * sen) * paso;
    meta.z += (dx * sen - dy * cos) * paso;
  }

  lienzo.addEventListener('pointerdown', (evento) => {
    try {
      lienzo.setPointerCapture(evento.pointerId);
    } catch (error) {
      // Sin captura el gesto funciona igual mientras el dedo siga sobre el lienzo
    }
    const p = posicion(evento);
    dedos.set(evento.pointerId, p);
    ultimaInteraccion = performance.now();
    if (dedos.size === 2) {
      // Segundo dedo: pellizco. Se cancela cualquier arrastre de mueble.
      if (arrastre) soltarArrastre(true);
      const [a, b] = Array.from(dedos.values());
      pellizco = { separacion: Math.hypot(a.x - b.x, a.y - b.y), cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2 };
      gesto = { tipo: 'pellizco', movido: true };
      return;
    }
    const estado = opciones.estado();
    const mueble = muebleEn(p);
    const puedeArrastrar = opciones.alArrastrarMueble && mueble && mueble.id === estado.seleccionadoId && !estado.modo && !estado.presentacion;
    if (puedeArrastrar) {
      arrastre = { mueble: mueble, pisoInicio: puntoDelPiso(p), rect: null, valido: false, activo: false };
      gesto = { tipo: 'arrastre', inicio: p, movido: false };
    } else {
      const desplazando = evento.button === 2 || evento.button === 1 || evento.shiftKey;
      gesto = { tipo: desplazando ? 'desplazar' : 'orbita', inicio: p, movido: false, mueble: mueble };
    }
  });

  lienzo.addEventListener('pointermove', (evento) => {
    if (!dedos.has(evento.pointerId) || !gesto) return;
    const antes = dedos.get(evento.pointerId);
    const p = posicion(evento);
    dedos.set(evento.pointerId, p);
    ultimaInteraccion = performance.now();
    if (gesto.tipo === 'pellizco' && dedos.size >= 2) {
      const [a, b] = Array.from(dedos.values());
      const separacion = Math.hypot(a.x - b.x, a.y - b.y);
      const cx = (a.x + b.x) / 2;
      const cy = (a.y + b.y) / 2;
      if (pellizco.separacion > 0 && separacion > 0) meta.distancia *= pellizco.separacion / separacion;
      desplazar(cx - pellizco.cx, cy - pellizco.cy);
      pellizco = { separacion: separacion, cx: cx, cy: cy };
      limitarMeta();
      pedirCuadro();
      return;
    }
    if (!gesto.movido && Math.hypot(p.x - gesto.inicio.x, p.y - gesto.inicio.y) < UMBRAL_TOQUE) return;
    gesto.movido = true;
    if (gesto.tipo === 'arrastre') {
      moverArrastre(p);
      return;
    }
    const dx = p.x - antes.x;
    const dy = p.y - antes.y;
    if (gesto.tipo === 'orbita') {
      meta.azimut -= dx * 0.008;
      meta.polar -= dy * 0.006;
    } else desplazar(dx, dy);
    limitarMeta();
    pedirCuadro();
  });

  function moverArrastre(p) {
    const punto = puntoDelPiso(p);
    if (!punto || !arrastre.pisoInicio) return;
    const m = arrastre.mueble;
    const limitar = (valor, maximo) => Math.max(0, Math.min(maximo, valor));
    arrastre.activo = true;
    arrastre.rect = {
      x: limitar(m.x + Math.round(punto.x - arrastre.pisoInicio.x), sala.ancho - m.ancho),
      y: limitar(m.y + Math.round(punto.z - arrastre.pisoInicio.z), sala.fondo - m.fondo),
      ancho: m.ancho, fondo: m.fondo
    };
    const estado = opciones.estado();
    arrastre.valido = N.cabe(arrastre.rect, sala, estado.muebles, m.id);
    const registro = muebles3d.get(m.id);
    if (registro) registro.grupo.position.set(arrastre.rect.x + m.ancho / 2, 0.05, arrastre.rect.y + m.fondo / 2);
    lienzo.style.cursor = 'grabbing';
    marcarSeleccion(estado);
    pedirCuadro();
  }

  function soltarArrastre(cancelado) {
    const fin = arrastre;
    arrastre = null;
    lienzo.style.cursor = '';
    const registro = muebles3d.get(fin.mueble.id);
    if (registro) registro.grupo.position.set(fin.mueble.x + fin.mueble.ancho / 2, 0, fin.mueble.y + fin.mueble.fondo / 2);
    marcarSeleccion(opciones.estado());
    pedirCuadro();
    if (!cancelado && fin.activo && fin.valido && fin.rect) opciones.alArrastrarMueble(fin.mueble.id, fin.rect);
  }

  function terminarGesto(evento, cancelado) {
    if (!dedos.has(evento.pointerId)) return;
    const p = posicion(evento);
    dedos.delete(evento.pointerId);
    const fin = gesto;
    if (dedos.size === 0) gesto = null;
    if (!fin) return;
    if (fin.tipo === 'arrastre' && arrastre) {
      const fueToque = !fin.movido;
      const mueble = arrastre.mueble;
      soltarArrastre(cancelado);
      if (fueToque && !cancelado) opciones.alTocar({ casilla: casillaEn(p), mueble: mueble });
      return;
    }
    if (!cancelado && !fin.movido && fin.tipo !== 'pellizco') opciones.alTocar({ casilla: casillaEn(p), mueble: muebleEn(p) });
  }
  lienzo.addEventListener('pointerup', (evento) => terminarGesto(evento, false));
  lienzo.addEventListener('pointercancel', (evento) => terminarGesto(evento, true));
  lienzo.addEventListener('contextmenu', (evento) => evento.preventDefault());
  lienzo.addEventListener('wheel', (evento) => {
    evento.preventDefault();
    ultimaInteraccion = performance.now();
    meta.distancia *= Math.exp(evento.deltaY * 0.0012);
    limitarMeta();
    pedirCuadro();
  }, { passive: false });

  lienzo.addEventListener('webglcontextlost', (evento) => {
    evento.preventDefault();
    console.warn('El dispositivo liberó la memoria gráfica de la vista 3D.');
  });
  lienzo.addEventListener('webglcontextrestored', () => {
    claveSala = '';
    pedirDibujo();
  });

  const observador = window.ResizeObserver ? new ResizeObserver(ajustarTamano) : null;
  if (observador) observador.observe(contenedor);
  const alCambiarTema = () => {
    materiales.forEach((m) => m.dispose());
    materiales.clear();
    texturasEtiqueta.forEach((t) => t.dispose());
    texturasEtiqueta.clear();
    claveSala = '';
    pedirDibujo();
  };
  temaOscuro.addEventListener('change', alCambiarTema);

  // Punto de la pantalla (relativo al lienzo) de un punto del mundo: lo usan las pruebas
  function aPantalla(x, y, z) {
    colocarCamara();
    camara.updateMatrixWorld();
    const v = new THREE.Vector3(x, y, z).project(camara);
    return { x: (v.x + 1) / 2 * ancho, y: (1 - v.y) / 2 * alto };
  }

  // ---------- Lo que la app puede pedirle a la escena (mismo contrato que escena.js) ----------
  return {
    pedirDibujo: pedirDibujo,
    ajustarTamano: ajustarTamano,
    rotacion: () => 0, // aquí las casillas ya vienen en coordenadas del lugar
    zoom: () => (sala ? distanciaGeneral() / actual.distancia : 1),
    girar() {
      meta.azimut += Math.PI / 2;
      pedirCuadro();
    },
    acercar(factor) {
      meta.distancia /= factor;
      limitarMeta();
      pedirCuadro();
    },
    centrar: () => vistaGeneral(false),
    reiniciar() {
      sala = null;
      claveSala = '';
    },
    // Lleva la cámara a un mueble (al seleccionarlo desde la lista o al cambiar de vista)
    enfocar(mueble) {
      if (!sala) return;
      meta.x = mueble.x + mueble.ancho / 2;
      meta.z = mueble.y + mueble.fondo / 2;
      meta.distancia = Math.min(meta.distancia, Math.max(6, distanciaGeneral() * 0.55));
      limitarMeta();
      pedirCuadro();
    },
    puntoDeMueble(muebleId) {
      const m = opciones.estado().muebles.find((mueble) => mueble.id === muebleId);
      return m ? aPantalla(m.x + m.ancho / 2, N.altoDe(m) * ALTO_PISO * 0.6, m.y + m.fondo / 2) : null;
    },
    puntoDeCasilla: (x, y) => aPantalla(x + 0.5, 0, y + 0.5),
    // Datos para las pruebas automáticas: qué hay construido y dónde
    info() {
      const posiciones = {};
      muebles3d.forEach((registro, id) => {
        posiciones[id] = { x: registro.grupo.position.x, z: registro.grupo.position.z, giro: registro.grupo.rotation.y, mallas: registro.grupo.children.length };
      });
      return {
        muebles: muebles3d.size, posiciones: posiciones, sombras: renderizador.shadowMap.enabled,
        camara: Object.assign({}, actual), memoria: Object.assign({}, renderizador.info.memory), dibujos: renderizador.info.render.calls
      };
    },
    // Libera la memoria gráfica (al salir del lugar): geometrías, materiales, texturas y el lienzo
    destruir() {
      destruida = true;
      if (observador) observador.disconnect();
      temaOscuro.removeEventListener('change', alCambiarTema);
      Array.from(muebles3d.keys()).forEach(quitarMueble);
      limpiarMarcas();
      grupoSala.children.forEach((hijo) => {
        if (hijo.material.map) hijo.material.map.dispose();
        hijo.material.dispose();
        if (hijo.geometry !== cubo) hijo.geometry.dispose();
      });
      materiales.forEach((m) => m.dispose());
      texturasEtiqueta.forEach((t) => t.dispose());
      cubo.dispose();
      sol.shadow.map && sol.shadow.map.dispose();
      renderizador.dispose();
      renderizador.forceContextLoss();
      lienzo.remove();
    }
  };
}
