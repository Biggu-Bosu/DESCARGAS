// Ubica · Novedades: qué cambió en cada versión. Se ven en el menú ⋯ → «Novedades».
// Cómo añadir cambios (en cada subida que se note al usar la app):
//   - Si ya hay una entrada con la fecha de hoy, suma el cambio a su lista.
//   - Si no, crea una entrada NUEVA ARRIBA DEL TODO con fecha 'AAAA-MM-DD'.
//   - Frases cortas pensadas para quien usa la app, no técnicas.
// Las entradas viejas no se borran: así queda el historial de todas las versiones.
window.NOVEDADES = [
  {
    fecha: '2026-11-11',
    cambios: [
      'Ubica estrena interfaz: cuatro secciones (Inventario, Lugares, Préstamos y Más), letra más clara y botones más cómodos.',
      'Inventario como tabla: busca por nombre, número de inventario o serie; filtra por estado, categoría y lugar; ordena por la columna que quieras.',
      'Cada lugar se puede ver de tres formas con los mismos datos: Lista, 2.5D y 3D. Cambias cuando quieras y la selección se conserva.',
      'Nueva vista 3D: muebles con forma reconocible, luz y sombras. Gira con un dedo, acerca con dos, y toca un mueble para ver qué guarda.',
      'En 2.5D y en 3D puedes arrastrar el mueble seleccionado para moverlo; lo que muevas en una vista aparece igual en la otra.',
      '«Localizar» en la ficha de un artículo te lleva a su lugar y resalta el mueble donde está.',
      'Los muebles ahora pueden cambiar de medidas (de 1 a 6 casillas) además de moverse y girar.',
      'Devoluciones parciales: regresa solo algunas piezas de un préstamo y marca cuántas llegaron dañadas.',
      'Números de serie opcionales por artículo, que también se pueden buscar.',
      'Historial general de movimientos en «Más».',
      'En computadora: menú a la izquierda, panel a la derecha que no tapa la lista ni el plano, y atajos de teclado (/ buscar, N nuevo, 1-2-3 vistas, flechas mover, R girar, Ctrl+Z deshacer).',
      'Modo presentación para proyector o pantalla grande: solo el lugar, a pantalla completa.',
      'Ejemplo nuevo con un almacén en 3D, un laboratorio en 2.5D, un lugar solo con lista, artículos sin ubicación y préstamos. En «Más» puedes vaciar todo y empezar de cero.',
      'Si tu dispositivo no puede mostrar 3D, Ubica te avisa y sigues usando la vista 2.5D.'
    ]
  },
  {
    fecha: '2026-11-10',
    cambios: [
      'Ubica ya sirve como inventario de listas: puedes agregar artículos sin crear lugares ni planos.',
      '«Espacios» ahora se llaman «Lugares», y el plano es opcional: un lugar puede ser solo un nombre.',
      'Un artículo puede estar dentro de un mueble, directo en un lugar o «Sin ubicación».',
      'Categorías (Laboratorio, Cómputo, Herramientas, Limpieza, Seguridad…) que puedes crear, cambiar y borrar sin perder artículos.',
      'Cada artículo cuenta sus piezas en buen estado, en reparación y dañadas. Solo se prestan las de buen estado.',
      'Al devolver un préstamo puedes marcar cuántas piezas regresaron dañadas.',
      'Entrada de piezas, cambio de estado y baja (con motivo) desde la ficha del artículo.',
      'Historial: cada artículo muestra sus altas, cambios, préstamos y devoluciones.',
      'Borrar un mueble ya no borra lo que guarda: pasa al lugar. Borrar un lugar dice antes qué se afecta y ofrece llevar todo a otro lugar.',
      'Quitar el plano de un lugar no borra sus muebles; si lo vuelves a crear, todo regresa a su casilla.',
      'Tus datos anteriores se actualizan solos (antes se guarda una copia). Si algo no cuadra, Ubica te lo muestra y te pregunta.',
      'Copias de seguridad automáticas: Ubica guarda sola hasta 6 copias (una al día si hubo cambios). Están en el menú ⋯.',
      'Restaurar un respaldo ya no es un salto al vacío: antes se guarda una copia de lo que había y puedes recuperarla.',
      'Corregido: tocar dos veces muy rápido podía crear dos muebles en la misma casilla o guardar dos veces el mismo equipo.',
      'Al abrir, Ubica revisa sus datos; si encuentra muebles encimados los separa sin borrar su equipo (y antes guarda una copia).',
      'Mucho más rápida con inventarios grandes: el plano, la búsqueda y la Lista (ahora se muestra por partes con «Mostrar más»).',
      'En la versión web, el botón o gesto Atrás cierra la ficha abierta en lugar de salir de la app.',
      'El plano se dibuja también en celulares con navegador antiguo.',
      'El menú dice cuándo fue tu último respaldo en archivo y te lo recuerda si pasan 14 días.',
      'En iPhone, aviso para añadir Ubica a la pantalla de inicio y no perder datos.'
    ]
  },
  {
    fecha: '2026-11-09',
    cambios: [
      'Primera versión de Ubica: el inventario que también dice dónde está cada cosa.',
      'Crea tus espacios (laboratorio, salón, bodega…) y míralos en vista isométrica.',
      'Coloca muebles con un toque y guarda en cada uno el equipo que tiene dentro.',
      'Zoom con dos dedos, mover la vista arrastrando y girar la sala.',
      'Los muebles que tapan al que buscas se vuelven transparentes.',
      'Préstamos: quién se llevó qué, cuándo regresa y avisos de vencidos.',
      'Vista de Lista con todo el inventario en texto (funciona con lector de pantalla).',
      'Respaldo para guardar o pasar tus datos, y lista para Excel.',
      'Base de datos IndexedDB en tu celular: funciona sin internet. Puedes ver sus tablas.'
    ]
  }
];
