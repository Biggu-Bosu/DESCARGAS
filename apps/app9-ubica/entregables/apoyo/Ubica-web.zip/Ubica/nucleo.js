// Ubica · Núcleo: toda la lógica que NO dibuja ni toca la pantalla.
// Por eso se puede probar con node (carpeta Pruebas/) sin abrir un navegador.
//
// Contenido:
//   1. Catálogos (tipos de lugar y de mueble, categorías, estados) y límites
//   2. Utilidades de texto y fechas
//   3. Geometría isométrica: proyección, giro de la vista, choques y orden de dibujo
//   4. Cámara (zoom y desplazamiento) y gestos táctiles
//   5. Consultas: dónde está cada artículo, existencias, búsqueda, préstamos y resumen
//   6. Validación de formularios
//   7. Operaciones: cada una devuelve una lista de "cambios" para la base de datos
//   8. Historial (movimientos)
//   9. Respaldo: formato 2, conversión del formato 1, revisión y reparación segura
//  10. Migración de la base de datos a la versión 3
//  11. Copias de seguridad, CSV y datos de ejemplo
//
// El modelo (Etapa 1A):
//   - Un LUGAR puede tener plano (medidas) o no. Sin plano sirve para listas.
//   - Un MUEBLE pertenece a un lugar; puede estar colocado en el plano (x, y) o sin colocar.
//   - Un ARTÍCULO está en UNO solo de estos sitios: en un mueble, directo en un lugar o sin ubicación.
//   - Las existencias de un artículo se cuentan por estado: buen estado, en reparación y dañado.
//     El total se calcula (nunca se guarda) y las prestadas salen de los préstamos activos.
(function (raiz) {
  'use strict';

  // =====================================================================
  // 1. CATÁLOGOS Y LÍMITES
  // =====================================================================

  const LIMITES = {
    nombre: 40,
    persona: 60,
    grupo: 40,
    codigo: 30,
    notas: 200,
    motivo: 120,
    cantidad: 9999,
    ladoMinimo: 3,
    ladoMaximo: 20,
    lugares: 100,
    categorias: 40,
    diasPrestamo: 365
  };

  // tono: el color (de 0 a 360 en el círculo de colores) con que se tiñe el piso del plano
  const TIPOS_LUGAR = {
    laboratorio: { nombre: 'Laboratorio', tono: 195 },
    salon: { nombre: 'Salón', tono: 40 },
    computo: { nombre: 'Sala de cómputo', tono: 250 },
    bodega: { nombre: 'Bodega', tono: 80 },
    biblioteca: { nombre: 'Biblioteca', tono: 320 },
    taller: { nombre: 'Taller', tono: 15 },
    oficina: { nombre: 'Oficina', tono: 160 },
    otro: { nombre: 'Otro', tono: 220 }
  };

  // ancho y fondo: casillas que ocupa (1 casilla ≈ 1 metro). alto: altura en "pisos".
  // color: [tono, saturación %, luz %]. detalle: dibujo extra en sus caras.
  const TIPOS_MUEBLE = {
    mesa: { nombre: 'Mesa', ancho: 2, fondo: 1, alto: 0.45, color: [28, 45, 52], detalle: null },
    escritorio: {
      nombre: 'Escritorio', ancho: 2, fondo: 1, alto: 0.5, color: [20, 30, 42], detalle: 'cajones'
    },
    estante: {
      nombre: 'Estante', ancho: 1, fondo: 1, alto: 1.6, color: [215, 35, 50], detalle: 'repisas'
    },
    gabinete: {
      nombre: 'Gabinete', ancho: 1, fondo: 1, alto: 1.0, color: [150, 30, 42], detalle: 'puertas'
    },
    vitrina: {
      nombre: 'Vitrina', ancho: 2, fondo: 1, alto: 1.3, color: [190, 45, 58], detalle: 'vidrio'
    },
    casillero: {
      nombre: 'Casillero', ancho: 1, fondo: 1, alto: 1.5, color: [5, 45, 52], detalle: 'puertas'
    },
    caja: { nombre: 'Caja', ancho: 1, fondo: 1, alto: 0.45, color: [38, 55, 55], detalle: 'cinta' },
    banco: { nombre: 'Banco', ancho: 1, fondo: 1, alto: 0.3, color: [0, 0, 50], detalle: null }
  };

  // Categorías con las que empieza toda base de datos. «Otros» es fija: no se puede borrar,
  // porque es a donde pasan los artículos cuando se borra su categoría.
  const ID_OTROS = 'cat-otros';
  const CATEGORIAS_INICIALES = [
    ['cat-laboratorio', 'Laboratorio', '#2f80ed'],
    ['cat-computo', 'Cómputo', '#6c5ce7'],
    ['cat-audiovisual', 'Audiovisual', '#d63384'],
    ['cat-deportes', 'Deportes', '#14966b'],
    ['cat-mobiliario', 'Mobiliario', '#9a5b2e'],
    ['cat-papeleria', 'Papelería', '#c99a06'],
    ['cat-herramientas', 'Herramientas', '#5f6b76'],
    ['cat-limpieza', 'Limpieza', '#0f9fa8'],
    ['cat-seguridad', 'Seguridad', '#d63031'],
    ['cat-consumibles', 'Consumibles', '#e0662f'],
    ['cat-refacciones', 'Refacciones', '#2563a8'],
    [ID_OTROS, 'Otros', '#7b8794']
  ];
  const COLORES_CATEGORIA = CATEGORIAS_INICIALES.map((categoria) => categoria[2]);

  function categoriasIniciales() {
    return CATEGORIAS_INICIALES.map(([id, nombre, color], orden) =>
      ({ id: id, nombre: nombre, color: color, orden: orden, fija: id === ID_OTROS }));
  }

  // Estados de las existencias de un artículo (las prestadas NO son un estado: salen de los préstamos)
  const ESTADOS = [
    { clave: 'bueno', nombre: 'Buen estado' },
    { clave: 'reparacion', nombre: 'En reparación' },
    { clave: 'danado', nombre: 'Dañado' }
  ];
  const CLAVES_ESTADO = ESTADOS.map((estado) => estado.clave);

  const TIPOS_MOVIMIENTO = {
    alta: 'Alta',
    edicion: 'Edición',
    'cambio-ubicacion': 'Cambio de ubicación',
    entrada: 'Entrada de existencias',
    'cambio-estado': 'Cambio de estado',
    baja: 'Baja',
    prestamo: 'Préstamo',
    devolucion: 'Devolución',
    colocar: 'Colocado en el plano',
    mover: 'Movido en el plano',
    girar: 'Girado',
    borrado: 'Borrado',
    deshacer: 'Deshacer',
    restauracion: 'Restauración de respaldo',
    migracion: 'Actualización de los datos',
    'reparacion-datos': 'Reparación de datos'
  };

  // Tablas (almacenes) de la base de datos, versión 3:
  //   lugares ← muebles (lugarId) ← articulos (muebleId o lugarId) ← prestamos (articuloId)
  //   categorias ← articulos (categoriaId) · movimientos: historial de todo lo anterior
  const VISTAS_LUGAR = ['lista', '2.5d', '3d'];
  const TABLAS = ['lugares', 'muebles', 'articulos', 'prestamos', 'categorias', 'movimientos'];
  const TABLA_COPIAS = 'copias'; // copias de seguridad automáticas (no forma parte del respaldo)
  const INDICES = {
    lugares: [],
    muebles: ['lugarId'],
    articulos: ['muebleId', 'lugarId', 'categoriaId'],
    prestamos: ['articuloId'],
    categorias: [],
    movimientos: ['entidadId', 'momento']
  };
  // Tablas de las versiones 1 y 2 de la base de datos (para migrar)
  const TABLAS_ANTIGUAS = ['espacios', 'muebles', 'equipo', 'prestamos'];

  // =====================================================================
  // 2. UTILIDADES DE TEXTO Y FECHAS
  // =====================================================================

  // Quita acentos y mayúsculas para que "matraz erlenmeyer" encuentre "Matraz Erlenmeyer".
  function normalizar(texto) {
    return String(texto == null ? '' : texto)
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Evita que un texto escrito por el usuario se convierta en HTML (por ejemplo <script>).
  function escaparHTML(texto) {
    return String(texto == null ? '' : texto)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Identificador único, por ejemplo "mue-lz3k9a-4f2c"
  function nuevoId(prefijo) {
    const azar = Math.random().toString(36).slice(2, 6);
    return (prefijo || 'id') + '-' + Date.now().toString(36) + '-' + azar;
  }

  function dosDigitos(numero) {
    return (numero < 10 ? '0' : '') + numero;
  }

  // Fecha local como texto 'AAAA-MM-DD' (así la guarda la base de datos)
  function fechaISO(fecha) {
    const dia = fecha || new Date();
    return dia.getFullYear() + '-' + dosDigitos(dia.getMonth() + 1) + '-' + dosDigitos(dia.getDate());
  }

  function leerFechaISO(texto) {
    const partes = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(texto || ''));
    if (!partes) return null;
    const fecha = new Date(Number(partes[1]), Number(partes[2]) - 1, Number(partes[3]));
    // new Date(2026, 1, 31) se convierte en 3 de marzo: así detectamos fechas que no existen
    if (fechaISO(fecha) !== texto) return null;
    return fecha;
  }

  function sumarDias(textoISO, dias) {
    const fecha = leerFechaISO(textoISO);
    fecha.setDate(fecha.getDate() + dias);
    return fechaISO(fecha);
  }

  // Días de "desde" a "hasta" (negativo si "hasta" ya pasó)
  function diasEntre(desdeISO, hastaISO) {
    const desde = leerFechaISO(desdeISO);
    const hasta = leerFechaISO(hastaISO);
    return Math.round((hasta - desde) / 86400000);
  }

  const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];

  // "16 nov" (o "16 nov 2027" si no es de este año)
  function fechaCorta(textoISO, hoyISO) {
    const fecha = leerFechaISO(textoISO);
    if (!fecha) return '';
    let texto = fecha.getDate() + ' ' + MESES[fecha.getMonth()];
    if (hoyISO && textoISO.slice(0, 4) !== hoyISO.slice(0, 4)) texto += ' ' + fecha.getFullYear();
    return texto;
  }

  function plural(cantidad, singular, varios) {
    return cantidad + ' ' + (cantidad === 1 ? singular : varios || singular + 's');
  }

  // =====================================================================
  // 3. GEOMETRÍA ISOMÉTRICA
  // =====================================================================
  //
  // El piso es una cuadrícula. Una casilla (x, y) del piso se dibuja como un rombo:
  //   pantallaX = origenX + (x - y) * medioAncho
  //   pantallaY = origenY + (x + y) * medioAlto - altura * altoPiso
  // Moverse +1 en x baja a la derecha; +1 en y baja a la izquierda; la altura sube.
  // Ese es todo el "3D": geometría de secundaria, sin librerías.

  // Proporciones respecto a medioAncho: el rombo mide el doble de ancho que de alto
  const PROPORCION = { medioAlto: 0.5, altoPiso: 1.2 };
  const ALTO_PARED = 1.8;

  function proyectar(x, y, z, escala) {
    return {
      x: escala.origenX + (x - y) * escala.medioAncho,
      y: escala.origenY + (x + y) * escala.medioAlto - z * escala.altoPiso
    };
  }

  // Lo contrario de proyectar() con altura 0: ¿qué casilla del piso está en este punto?
  // Despejando las dos fórmulas: a = x - y, b = x + y  →  x = (a + b) / 2, y = (b - a) / 2
  function casillaEnPantalla(px, py, escala) {
    const a = (px - escala.origenX) / escala.medioAncho;
    const b = (py - escala.origenY) / escala.medioAlto;
    return { x: Math.floor((a + b) / 2), y: Math.floor((b - a) / 2) };
  }

  // Calcula el tamaño de las casillas para que la sala completa quepa en el lienzo.
  function escalaParaSala(anchoVista, fondoVista, anchoLienzo, altoLienzo) {
    // De izquierda a derecha la sala ocupa (ancho + fondo) "medios anchos"
    const unidades = anchoVista + fondoVista;
    const porAncho = (anchoLienzo * 0.92) / unidades;
    const porAlto = (altoLienzo * 0.86) / (unidades * PROPORCION.medioAlto + ALTO_PARED * PROPORCION.altoPiso);
    const medioAncho = Math.max(8, Math.min(porAncho, porAlto, 56));
    const escala = {
      medioAncho: medioAncho,
      medioAlto: medioAncho * PROPORCION.medioAlto,
      altoPiso: medioAncho * PROPORCION.altoPiso
    };
    const altoTotal = unidades * escala.medioAlto + ALTO_PARED * escala.altoPiso;
    // El rombo del piso está centrado si su punta izquierda y derecha quedan a la misma distancia
    escala.origenX = anchoLienzo / 2 - ((anchoVista - fondoVista) * medioAncho) / 2;
    escala.origenY = (altoLienzo - altoTotal) / 2 + ALTO_PARED * escala.altoPiso;
    return escala;
  }

  // ---------- Girar la vista ----------
  // Los muebles se guardan siempre en "coordenadas del mundo". Para ver la sala desde otro
  // lado no se cambia nada guardado: solo se giran los rectángulos antes de dibujarlos.
  // Un cuarto de vuelta convierte la sala de ancho × fondo en una de fondo × ancho.
  function girarUnCuarto(rect, anchoSala, fondoSala) {
    return {
      rect: { x: fondoSala - (rect.y + rect.fondo), y: rect.x, ancho: rect.fondo, fondo: rect.ancho },
      anchoSala: fondoSala,
      fondoSala: anchoSala
    };
  }

  function girar(rect, anchoSala, fondoSala, cuartos) {
    let actual = { rect: rect, anchoSala: anchoSala, fondoSala: fondoSala };
    const vueltas = ((cuartos % 4) + 4) % 4;
    for (let i = 0; i < vueltas; i++) {
      actual = girarUnCuarto(actual.rect, actual.anchoSala, actual.fondoSala);
    }
    return actual;
  }

  // Medidas de la sala tal como se ve (con un cuarto de vuelta, ancho y fondo se intercambian)
  function medidasVista(sala, rotacion) {
    return rotacion % 2 ? { ancho: sala.fondo, fondo: sala.ancho } : { ancho: sala.ancho, fondo: sala.fondo };
  }

  function aVista(rect, sala, rotacion) {
    return girar(rect, sala.ancho, sala.fondo, rotacion).rect;
  }

  function aMundo(rectVista, sala, rotacion) {
    const vista = medidasVista(sala, rotacion);
    return girar(rectVista, vista.ancho, vista.fondo, 4 - rotacion).rect;
  }

  // Rectángulo (en el mundo) que ocupa un mueble si su primera casilla queda donde tocaste.
  // Corrige un error del prototipo: allá se convertía solo la casilla y el mueble crecía
  // hacia el lado contrario cuando la vista estaba girada media vuelta o tres cuartos.
  function rectAlTocar(casillaVista, medidas, sala, rotacion) {
    const enVista = rotacion % 2
      ? { ancho: medidas.fondo, fondo: medidas.ancho }
      : { ancho: medidas.ancho, fondo: medidas.fondo };
    return aMundo(
      { x: casillaVista.x, y: casillaVista.y, ancho: enVista.ancho, fondo: enVista.fondo },
      sala,
      rotacion
    );
  }

  // ---------- Choques ----------
  function seEnciman(a, b) {
    return a.x < b.x + b.ancho && b.x < a.x + a.ancho && a.y < b.y + b.fondo && b.y < a.y + a.fondo;
  }

  // Un mueble está colocado si tiene casilla (x, y). Sin casilla está «sin colocar».
  function estaColocado(mueble) {
    return Number.isInteger(mueble.x) && Number.isInteger(mueble.y);
  }

  // ¿Cabe el rectángulo en la sala sin encimarse con otro mueble colocado? (ignorarId: el que se mueve)
  function cabe(rect, sala, muebles, ignorarId) {
    if (rect.x < 0 || rect.y < 0) return false;
    if (rect.x + rect.ancho > sala.ancho || rect.y + rect.fondo > sala.fondo) return false;
    return !muebles.some((otro) => otro.id !== ignorarId && estaColocado(otro) && seEnciman(rect, otro));
  }

  // ---------- Orden de dibujo ("algoritmo del pintor") ----------
  // Se dibuja primero lo de atrás y al final lo de adelante, que lo tapa.
  // ¿El rectángulo a queda completamente detrás de b? (más arriba en la pantalla)
  function estaDetras(a, b) {
    return a.x + a.ancho <= b.x || a.y + a.fondo <= b.y;
  }

  // lista: objetos con la propiedad "vista" (su rectángulo ya girado).
  // Primero se anota, para cada par, quién debe dibujarse antes; luego se van tomando los que
  // ya no esperan a nadie. Cuesta n × n comparaciones (antes eran n × n × n: lento con 200 muebles).
  function ordenarDeAtrasHaciaAdelante(lista) {
    const total = lista.length;
    const esperaA = new Array(total).fill(0);      // cuántos muebles deben dibujarse antes que este
    const vanDespues = lista.map(() => []);        // a quiénes libera este mueble al dibujarse
    for (let i = 0; i < total; i++) {
      for (let j = i + 1; j < total; j++) {
        const iDetras = estaDetras(lista[i].vista, lista[j].vista);
        const jDetras = estaDetras(lista[j].vista, lista[i].vista);
        if (iDetras && !jDetras) {
          vanDespues[i].push(j);
          esperaA[j]++;
        } else if (jDetras && !iDetras) {
          vanDespues[j].push(i);
          esperaA[i]++;
        }
      }
    }
    const usado = new Array(total).fill(false);
    const ordenados = [];
    for (let paso = 0; paso < total; paso++) {
      let elegido = -1;
      for (let i = 0; i < total; i++) {
        if (usado[i]) continue;
        if (esperaA[i] === 0) {
          elegido = i;
          break;
        }
        if (elegido === -1) elegido = i; // si hubiera un ciclo, se toma el primero que quede
      }
      if (esperaA[elegido] !== 0) elegido = usado.indexOf(false);
      usado[elegido] = true;
      ordenados.push(lista[elegido]);
      vanDespues[elegido].forEach((j) => {
        esperaA[j]--;
      });
    }
    return ordenados;
  }

  // Rectángulo que ocupa un mueble en la pantalla, en unidades de medioAncho (horizontal)
  // y medioAlto (vertical). Sirve para saber si uno tapa a otro sin dibujar nada.
  function siluetaEnPantalla(vista, alto) {
    const subePorPiso = PROPORCION.altoPiso / PROPORCION.medioAlto;
    return {
      izquierda: vista.x - (vista.y + vista.fondo),
      derecha: vista.x + vista.ancho - vista.y,
      arriba: vista.x + vista.y - alto * subePorPiso,
      abajo: vista.x + vista.ancho + vista.y + vista.fondo
    };
  }

  function siluetasSeEnciman(a, b) {
    const margen = 0.05;
    return a.izquierda + margen < b.derecha && b.izquierda + margen < a.derecha &&
      a.arriba + margen < b.abajo && b.arriba + margen < a.abajo;
  }

  // ordenados: lista ya en orden de dibujo, cada uno { mueble, vista }.
  // Devuelve los id de los muebles que están ADELANTE de algún objetivo y lo tapan:
  // esos se dibujan semitransparentes para que el objetivo se vea.
  function mueblesQueTapan(ordenados, idsObjetivo) {
    const objetivos = new Set(idsObjetivo);
    const tapan = new Set();
    ordenados.forEach((objetivo, posicion) => {
      if (!objetivos.has(objetivo.mueble.id)) return;
      const siluetaObjetivo = siluetaEnPantalla(objetivo.vista, altoDe(objetivo.mueble));
      for (let i = posicion + 1; i < ordenados.length; i++) {
        const delante = ordenados[i];
        if (objetivos.has(delante.mueble.id)) continue;
        const silueta = siluetaEnPantalla(delante.vista, altoDe(delante.mueble));
        if (siluetasSeEnciman(silueta, siluetaObjetivo)) tapan.add(delante.mueble.id);
      }
    });
    return tapan;
  }

  function altoDe(mueble) {
    const tipo = TIPOS_MUEBLE[mueble.tipo];
    return tipo ? tipo.alto : 1;
  }

  // =====================================================================
  // 4. CÁMARA Y GESTOS
  // =====================================================================
  //
  // La cámara dice cómo se ve el dibujo ya acomodado: punto en pantalla =
  //   desplazamiento + zoom × punto del dibujo.
  // zoom 1 = la sala completa cabe en el lienzo.

  const ZOOM_MINIMO = 0.6;
  const ZOOM_MAXIMO = 4;

  function camaraInicial() {
    return { zoom: 1, x: 0, y: 0 };
  }

  function limitarCamara(camara, anchoLienzo, altoLienzo) {
    const zoom = Math.min(ZOOM_MAXIMO, Math.max(ZOOM_MINIMO, camara.zoom));
    // El centro del dibujo nunca sale del lienzo: así no se "pierde" la sala
    const limitar = (valor, minimo, maximo) => Math.min(maximo, Math.max(minimo, valor));
    return {
      zoom: zoom,
      x: limitar(camara.x, -zoom * anchoLienzo / 2, anchoLienzo - zoom * anchoLienzo / 2),
      y: limitar(camara.y, -zoom * altoLienzo / 2, altoLienzo - zoom * altoLienzo / 2)
    };
  }

  // Acerca o aleja manteniendo fijo el punto (fx, fy) de la pantalla, por ejemplo
  // el punto medio entre los dos dedos: lo que está bajo tus dedos se queda bajo tus dedos.
  function zoomEn(camara, factor, fx, fy) {
    const zoom = Math.min(ZOOM_MAXIMO, Math.max(ZOOM_MINIMO, camara.zoom * factor));
    const dibujoX = (fx - camara.x) / camara.zoom;
    const dibujoY = (fy - camara.y) / camara.zoom;
    return { zoom: zoom, x: fx - dibujoX * zoom, y: fy - dibujoY * zoom };
  }

  // Convierte un punto de la pantalla al dibujo (lo contrario de la cámara)
  function pantallaADibujo(camara, px, py) {
    return { x: (px - camara.x) / camara.zoom, y: (py - camara.y) / camara.zoom };
  }

  // ---------- Gestos táctiles ----------
  // Recibe los eventos de cada dedo (pointerdown, pointermove, pointerup) y decide qué
  // significan. Devuelve una lista de acciones:
  //   { tipo: 'toque', x, y }          un dedo, sin moverse: colocar o abrir
  //   { tipo: 'desplazar', dx, dy }    mover la vista (1 dedo arrastrando o 2 dedos)
  //   { tipo: 'zoom', factor, x, y }   pellizco con 2 dedos
  // Regla clave: si el dedo se movió más de UMBRAL px, o si en algún momento hubo dos
  // dedos, ya NO es un toque. Así un pellizco nunca coloca un mueble por accidente.
  const UMBRAL_TOQUE = 10;

  function crearGestos() {
    const dedos = new Map(); // id del dedo → { x, y } última posición
    let inicio = null;       // dónde bajó el primer dedo
    let arrastrando = false;
    let huboVariosDedos = false;

    function centroYDistancia() {
      const [a, b] = Array.from(dedos.values());
      return {
        x: (a.x + b.x) / 2,
        y: (a.y + b.y) / 2,
        distancia: Math.hypot(a.x - b.x, a.y - b.y)
      };
    }

    function reiniciarSiNoHayDedos() {
      if (dedos.size) return;
      inicio = null;
      arrastrando = false;
      huboVariosDedos = false;
    }

    return {
      bajar(id, x, y) {
        if (dedos.size === 0) inicio = { x: x, y: y };
        dedos.set(id, { x: x, y: y });
        if (dedos.size > 1) huboVariosDedos = true;
        return [];
      },

      mover(id, x, y) {
        const anterior = dedos.get(id);
        if (!anterior) return [];
        const acciones = [];
        if (dedos.size === 1) {
          if (!arrastrando && Math.hypot(x - inicio.x, y - inicio.y) > UMBRAL_TOQUE) arrastrando = true;
          if (arrastrando && !huboVariosDedos) {
            acciones.push({ tipo: 'desplazar', dx: x - anterior.x, dy: y - anterior.y });
          }
          dedos.set(id, { x: x, y: y });
        } else if (dedos.size === 2) {
          const antes = centroYDistancia();
          dedos.set(id, { x: x, y: y });
          const despues = centroYDistancia();
          if (antes.distancia > 0 && despues.distancia > 0) {
            acciones.push({
              tipo: 'zoom', factor: despues.distancia / antes.distancia, x: despues.x, y: despues.y
            });
          }
          acciones.push({ tipo: 'desplazar', dx: despues.x - antes.x, dy: despues.y - antes.y });
        } else {
          dedos.set(id, { x: x, y: y });
        }
        return acciones;
      },

      subir(id, x, y) {
        if (!dedos.has(id)) return [];
        dedos.delete(id);
        const acciones = [];
        if (dedos.size === 0 && !arrastrando && !huboVariosDedos) {
          acciones.push({ tipo: 'toque', x: x, y: y });
        }
        reiniciarSiNoHayDedos();
        return acciones;
      },

      // El sistema canceló el gesto (por ejemplo, llegó una llamada): nunca cuenta como toque
      cancelar(id) {
        dedos.delete(id);
        huboVariosDedos = huboVariosDedos || dedos.size > 0;
        reiniciarSiNoHayDedos();
        return [];
      },

      dedosEnPantalla() {
        return dedos.size;
      }
    };
  }

  // =====================================================================
  // 5. CONSULTAS
  // =====================================================================
  // "datos" tiene la misma forma que la base de datos: una lista por tabla.
  //   { lugares: [], muebles: [], articulos: [], prestamos: [], categorias: [], movimientos: [] }

  function datosVacios() {
    const datos = {};
    TABLAS.forEach((tabla) => {
      datos[tabla] = [];
    });
    return datos;
  }

  function buscarPorId(lista, id) {
    return lista.find((registro) => registro.id === id) || null;
  }

  // Copia profunda de un registro (los estados son un objeto dentro del artículo)
  function clonar(valor) {
    return valor == null ? valor : JSON.parse(JSON.stringify(valor));
  }

  // ---------- Índices en memoria ----------
  // Preguntar "¿qué hay en este mueble?" recorriendo TODOS los artículos es lento cuando hay
  // miles (y el plano lo pregunta por cada mueble en cada dibujo). Un índice es como el índice
  // de un libro: se arma una vez y luego se consulta al instante. Se guarda aparte (WeakMap)
  // para no ensuciar los datos, y se vuelve a armar cuando los datos cambian.
  const indices = new WeakMap();
  const textos = new WeakMap(); // registro → su nombre y código ya sin acentos (para buscar)

  function textoDe(registro) {
    let texto = textos.get(registro);
    if (!texto) {
      texto = { nombre: normalizar(registro.nombre), codigo: normalizar(registro.codigo),
        series: normalizar((registro.series || []).join(' ')) };
      textos.set(registro, texto);
    }
    return texto;
  }

  function firmaDe(datos) {
    return TABLAS.map((tabla) => (datos[tabla] || []).length).join('/');
  }

  function agrupar(lista, campo) {
    const grupos = new Map();
    lista.forEach((registro) => {
      const clave = registro[campo];
      if (clave == null) return;
      if (!grupos.has(clave)) grupos.set(clave, []);
      grupos.get(clave).push(registro);
    });
    return grupos;
  }

  const porNombre = (a, b) => textoDe(a).nombre.localeCompare(textoDe(b).nombre, 'es', { numeric: true });

  function indiceDe(datos) {
    const firma = firmaDe(datos);
    let indice = indices.get(datos);
    if (indice && indice.firma === firma) return indice;
    indice = {
      firma: firma,
      muebles: agrupar(datos.muebles, 'lugarId'),
      enMueble: agrupar(datos.articulos, 'muebleId'),
      enLugar: agrupar(datos.articulos.filter((a) => !a.muebleId), 'lugarId'),
      sinUbicacion: datos.articulos.filter((a) => !a.muebleId && !a.lugarId).sort(porNombre),
      activos: agrupar(datos.prestamos.filter((prestamo) => !prestamo.devuelto), 'articuloId'),
      piezas: new Map(),
      movimientos: null // se arma solo si alguien lo pide (el historial puede ser grande)
    };
    indice.enMueble.forEach((lista, muebleId) => {
      lista.sort(porNombre);
      indice.piezas.set(muebleId, lista.reduce((suma, articulo) => suma + totalDe(articulo), 0));
    });
    indice.enLugar.forEach((lista) => lista.sort(porNombre));
    indices.set(datos, indice);
    return indice;
  }

  const VACIA = Object.freeze([]);

  // Las listas que devuelven estas funciones son del índice: se leen, no se modifican.
  function mueblesDe(datos, lugarId) {
    return indiceDe(datos).muebles.get(lugarId) || VACIA;
  }

  function mueblesColocados(datos, lugarId) {
    const lugar = buscarPorId(datos.lugares, lugarId);
    if (!lugar || !lugar.plano) return VACIA;
    return mueblesDe(datos, lugarId).filter(estaColocado);
  }

  function articulosDe(datos, muebleId) {
    return indiceDe(datos).enMueble.get(muebleId) || VACIA;
  }

  // Artículos que están directo en el lugar (sin mueble)
  function articulosEnLugar(datos, lugarId) {
    return indiceDe(datos).enLugar.get(lugarId) || VACIA;
  }

  function articulosSinUbicacion(datos) {
    return indiceDe(datos).sinUbicacion;
  }

  // Existencias: total = buen estado + en reparación + dañado (se calcula, nunca se guarda)
  function totalDe(articulo) {
    const estados = articulo.estados || {};
    return (estados.bueno || 0) + (estados.reparacion || 0) + (estados.danado || 0);
  }

  function piezasEnMueble(datos, muebleId) {
    return indiceDe(datos).piezas.get(muebleId) || 0;
  }

  function piezasEnLugar(datos, lugarId) {
    return mueblesDe(datos, lugarId).reduce((suma, mueble) => suma + piezasEnMueble(datos, mueble.id), 0) +
      articulosEnLugar(datos, lugarId).reduce((suma, articulo) => suma + totalDe(articulo), 0);
  }

  function prestamosActivosDe(datos, articuloId) {
    return indiceDe(datos).activos.get(articuloId) || VACIA;
  }

  function prestadas(datos, articuloId) {
    return prestamosActivosDe(datos, articuloId).reduce((suma, prestamo) => suma + prestamo.cantidad, 0);
  }

  // Disponibles para prestar = en buen estado − prestadas (las prestadas salen de las de buen estado)
  function disponibles(datos, articulo) {
    return articulo.estados.bueno - prestadas(datos, articulo.id);
  }

  // Dónde está un artículo: { articulo, mueble, lugar } (mueble y lugar pueden ser null)
  function ubicacion(datos, articuloId) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    const mueble = articulo && articulo.muebleId ? buscarPorId(datos.muebles, articulo.muebleId) : null;
    const lugarId = mueble ? mueble.lugarId : articulo ? articulo.lugarId : null;
    const lugar = lugarId ? buscarPorId(datos.lugares, lugarId) : null;
    return { articulo: articulo, mueble: mueble, lugar: lugar };
  }

  // "Laboratorio › Estante A", "Bodega" o "Sin ubicación"
  function textoUbicacion(lugar, mueble) {
    if (lugar && mueble) return lugar.nombre + ' › ' + mueble.nombre;
    if (lugar) return lugar.nombre;
    return 'Sin ubicación';
  }

  function categoriaDe(datos, articulo) {
    return buscarPorId(datos.categorias, articulo.categoriaId) || buscarPorId(datos.categorias, ID_OTROS);
  }

  function categoriasOrdenadas(datos) {
    return datos.categorias.slice().sort((a, b) => (a.orden - b.orden) || a.nombre.localeCompare(b.nombre, 'es'));
  }

  function articulosDeCategoria(datos, categoriaId) {
    return datos.articulos.filter((articulo) => articulo.categoriaId === categoriaId);
  }

  // Historial de un registro, el más reciente primero. Para un artículo incluye también los
  // movimientos de sus préstamos (préstamo y devolución), que se guardan a nombre del préstamo.
  function movimientosDe(datos, entidadId) {
    const indice = indiceDe(datos);
    if (!indice.movimientos) {
      const grupos = new Map();
      const sumar = (clave, movimiento) => {
        if (!clave) return;
        if (!grupos.has(clave)) grupos.set(clave, []);
        grupos.get(clave).push(movimiento);
      };
      datos.movimientos.forEach((movimiento) => {
        sumar(movimiento.entidadId, movimiento);
        if (movimiento.entidad === 'prestamo') {
          const prestamo = movimiento.despues || movimiento.antes || {};
          if (prestamo.articuloId !== movimiento.entidadId) sumar(prestamo.articuloId, movimiento);
        }
      });
      // Una sola línea por operación (una devolución con dañadas cambia el préstamo Y el artículo)
      grupos.forEach((lista, clave) => {
        const vistas = new Set();
        const unica = lista.filter((movimiento) => {
          if (vistas.has(movimiento.operacionId)) return false;
          vistas.add(movimiento.operacionId);
          return true;
        });
        unica.sort((a, b) => (a.momento < b.momento ? 1 : a.momento > b.momento ? -1 : 0));
        grupos.set(clave, unica);
      });
      indice.movimientos = grupos;
    }
    return indice.movimientos.get(entidadId) || VACIA;
  }

  // 'devuelto', 'vencido' (ya pasó la fecha límite) o 'activo'
  function estadoPrestamo(prestamo, hoyISO) {
    if (prestamo.devuelto) return 'devuelto';
    return diasEntre(hoyISO, prestamo.fechaLimite) < 0 ? 'vencido' : 'activo';
  }

  // Activos con los vencidos primero; dentro de cada grupo, el que vence antes va primero
  function prestamosActivos(datos, hoyISO) {
    return datos.prestamos
      .filter((prestamo) => !prestamo.devuelto)
      .sort((a, b) => {
        const vencidoA = estadoPrestamo(a, hoyISO) === 'vencido' ? 0 : 1;
        const vencidoB = estadoPrestamo(b, hoyISO) === 'vencido' ? 0 : 1;
        if (vencidoA !== vencidoB) return vencidoA - vencidoB;
        return a.fechaLimite < b.fechaLimite ? -1 : a.fechaLimite > b.fechaLimite ? 1 : 0;
      });
  }

  // Devueltos, el más reciente primero
  function historialPrestamos(datos) {
    return datos.prestamos
      .filter((prestamo) => prestamo.devuelto)
      .sort((a, b) => (a.devuelto < b.devuelto ? 1 : a.devuelto > b.devuelto ? -1 : 0));
  }

  // "Vence hoy", "Regresa el 16 nov", "Vencido hace 2 días"
  function textoVencimiento(prestamo, hoyISO) {
    const dias = diasEntre(hoyISO, prestamo.fechaLimite);
    if (dias < 0) return 'Vencido hace ' + plural(-dias, 'día');
    if (dias === 0) return 'Vence hoy';
    if (dias === 1) return 'Vence mañana';
    return 'Regresa el ' + fechaCorta(prestamo.fechaLimite, hoyISO);
  }

  // Búsqueda en todo el inventario, sin importar acentos ni mayúsculas.
  // Encuentra artículos por nombre o número de inventario (estén donde estén, también sin
  // ubicación) y muebles por su nombre. Cada resultado: { lugar, mueble, articulo } (pueden ser null).
  function buscar(datos, consulta) {
    const texto = normalizar(consulta);
    if (!texto) return [];
    const coincide = (articulo) => {
      const t = textoDe(articulo);
      return t.nombre.includes(texto) || t.codigo.includes(texto) || t.series.includes(texto);
    };
    const resultados = [];
    datos.lugares.forEach((lugar) => {
      mueblesDe(datos, lugar.id).forEach((mueble) => {
        const encontrados = articulosDe(datos, mueble.id).filter(coincide);
        encontrados.forEach((articulo) => resultados.push({ lugar: lugar, mueble: mueble, articulo: articulo }));
        if (!encontrados.length && textoDe(mueble).nombre.includes(texto)) {
          resultados.push({ lugar: lugar, mueble: mueble, articulo: null });
        }
      });
      articulosEnLugar(datos, lugar.id).filter(coincide)
        .forEach((articulo) => resultados.push({ lugar: lugar, mueble: null, articulo: articulo }));
    });
    articulosSinUbicacion(datos).filter(coincide)
      .forEach((articulo) => resultados.push({ lugar: null, mueble: null, articulo: articulo }));
    return resultados;
  }

  // Ids de los muebles de un lugar que coinciden con la búsqueda (para resaltarlos en el plano)
  function mueblesQueCoinciden(datos, consulta, lugarId) {
    return new Set(
      buscar(datos, consulta)
        .filter((resultado) => resultado.lugar && resultado.lugar.id === lugarId && resultado.mueble)
        .map((resultado) => resultado.mueble.id)
    );
  }

  function resumen(datos, hoyISO) {
    const activos = prestamosActivos(datos, hoyISO);
    const suma = (clave) => datos.articulos.reduce((total, articulo) => total + (articulo.estados[clave] || 0), 0);
    return {
      lugares: datos.lugares.length,
      muebles: datos.muebles.length,
      articulos: datos.articulos.length,
      piezas: datos.articulos.reduce((total, articulo) => total + totalDe(articulo), 0),
      enReparacion: suma('reparacion'),
      danadas: suma('danado'),
      sinUbicacion: articulosSinUbicacion(datos).length,
      piezasPrestadas: activos.reduce((total, prestamo) => total + prestamo.cantidad, 0),
      prestamosActivos: activos.length,
      vencidos: activos.filter((prestamo) => estadoPrestamo(prestamo, hoyISO) === 'vencido').length
    };
  }

  // Inventario completo como filas listas para una tabla, con filtros combinables y orden.
  // filtros: { texto, categoriaId, estado, lugar }   (todos opcionales)
  //   estado: 'disponible' | 'prestado' | 'reparacion' | 'danado' | 'agotado'
  //   lugar: id de un lugar | 'sin' (sin ubicación)
  // orden: 'nombre' | 'total' | 'disponibles' | 'categoria' | 'ubicacion'; descendente: true/false
  function consultarArticulos(datos, filtros, orden, descendente) {
    const f = filtros || {};
    const texto = normalizar(f.texto);
    const filas = [];
    datos.articulos.forEach((articulo) => {
      const t = textoDe(articulo);
      if (texto && !(t.nombre.includes(texto) || t.codigo.includes(texto) || t.series.includes(texto))) return;
      if (f.categoriaId && (categoriaDe(datos, articulo).id !== f.categoriaId)) return;
      const mueble = articulo.muebleId ? buscarPorId(datos.muebles, articulo.muebleId) : null;
      const lugarId = mueble ? mueble.lugarId : articulo.lugarId;
      if (f.lugar === 'sin' ? Boolean(lugarId) : f.lugar && lugarId !== f.lugar) return;
      const fila = {
        articulo: articulo, mueble: mueble, lugar: lugarId ? buscarPorId(datos.lugares, lugarId) : null,
        categoria: categoriaDe(datos, articulo), total: totalDe(articulo), prestadas: prestadas(datos, articulo.id)
      };
      fila.disponibles = articulo.estados.bueno - fila.prestadas;
      if (f.estado === 'disponible' && fila.disponibles < 1) return;
      if (f.estado === 'prestado' && fila.prestadas < 1) return;
      if (f.estado === 'reparacion' && articulo.estados.reparacion < 1) return;
      if (f.estado === 'danado' && articulo.estados.danado < 1) return;
      if (f.estado === 'agotado' && fila.total > 0) return;
      fila.ubicacion = textoUbicacion(fila.lugar, mueble);
      filas.push(fila);
    });
    const comparar = {
      nombre: (a, b) => porNombre(a.articulo, b.articulo),
      total: (a, b) => a.total - b.total,
      disponibles: (a, b) => a.disponibles - b.disponibles,
      categoria: (a, b) => a.categoria.nombre.localeCompare(b.categoria.nombre, 'es'),
      ubicacion: (a, b) => a.ubicacion.localeCompare(b.ubicacion, 'es', { numeric: true })
    }[orden] || ((a, b) => porNombre(a.articulo, b.articulo));
    filas.sort((a, b) => (comparar(a, b) || porNombre(a.articulo, b.articulo)) * (descendente ? -1 : 1));
    return filas;
  }

  // Los movimientos más recientes de todo el inventario (una línea por operación)
  function movimientosRecientes(datos, limite) {
    const vistas = new Set();
    return datos.movimientos.slice()
      .sort((a, b) => (a.momento < b.momento ? 1 : a.momento > b.momento ? -1 : 0))
      .filter((movimiento) => {
        if (vistas.has(movimiento.operacionId)) return false;
        vistas.add(movimiento.operacionId);
        return true;
      })
      .slice(0, limite || 50);
  }

  // =====================================================================
  // 5b. CATÁLOGO DE PIEZAS (para el 3D)
  // =====================================================================
  // Cada tipo de mueble se arma con cajas: tablero, patas, repisas, puertas… Es solo geometría
  // (sin dibujo), así sirve a cualquier vista. Medidas en casillas; la altura (z) en "pisos".
  //   ancho, fondo: medidas del mueble SIN girar (su frente mira hacia +y).
  //   Devuelve cajas { x, y, z, w, d, h, mat } con origen en una esquina del mueble.
  //   mat: 'cuerpo' | 'oscuro' | 'claro' | 'madera' | 'metal' | 'vidrio'
  function piezasMueble(tipoClave, ancho, fondo) {
    const tipo = TIPOS_MUEBLE[tipoClave] || TIPOS_MUEBLE.caja;
    const alto = tipo.alto;
    const m = 0.06; // margen para que dos muebles juntos no se vean pegados
    const w = ancho - 2 * m;
    const d = fondo - 2 * m;
    const cajas = [];
    const caja = (x, y, z, cw, cd, ch, mat) => cajas.push({ x: m + x, y: m + y, z: z, w: cw, d: cd, h: ch, mat: mat });
    const patas = (grosor, altura, mat) => {
      [[0, 0], [w - grosor, 0], [0, d - grosor], [w - grosor, d - grosor]].forEach(([x, y]) => caja(x, y, 0, grosor, grosor, altura, mat));
    };
    if (tipoClave === 'mesa') {
      patas(0.08, alto - 0.06, 'metal');
      caja(0, 0, alto - 0.06, w, d, 0.06, 'madera');
    } else if (tipoClave === 'banco') {
      patas(0.07, alto - 0.05, 'metal');
      caja(0.04, 0.04, alto - 0.05, w - 0.08, d - 0.08, 0.05, 'cuerpo');
    } else if (tipoClave === 'escritorio') {
      caja(0, 0, alto - 0.05, w, d, 0.05, 'madera');
      caja(0, 0.05, 0, Math.min(0.55, w * 0.35), d - 0.05, alto - 0.05, 'cuerpo'); // cajonera
      const cw = Math.min(0.55, w * 0.35);
      [0.25, 0.55, 0.85].forEach((f) => caja(0.06, d - 0.01, (alto - 0.05) * f - 0.02, cw - 0.12, 0.02, 0.03, 'metal')); // jaladeras
      caja(w - 0.05, 0.05, 0, 0.05, d - 0.05, alto - 0.05, 'oscuro'); // costado
      caja(cw, 0.02, alto * 0.35, w - cw - 0.05, 0.03, alto * 0.55, 'oscuro'); // faldón trasero
    } else if (tipoClave === 'estante') {
      caja(0, 0, 0, 0.05, d, alto, 'cuerpo');
      caja(w - 0.05, 0, 0, 0.05, d, alto, 'cuerpo');
      caja(0.05, 0, 0, w - 0.1, 0.03, alto, 'oscuro');
      const niveles = 5;
      for (let n = 0; n < niveles; n++) caja(0.05, 0.03, 0.08 + n * ((alto - 0.12) / (niveles - 1)), w - 0.1, d - 0.03, 0.04, 'claro');
    } else if (tipoClave === 'gabinete' || tipoClave === 'casillero') {
      caja(0, 0, 0, w, d - 0.03, alto, 'cuerpo');
      const columnas = Math.max(1, Math.round(w / 0.5));
      const filas = tipoClave === 'casillero' ? 2 : 1;
      const pw = (w - 0.04) / columnas;
      const ph = (alto - 0.06) / filas;
      for (let c = 0; c < columnas; c++) {
        for (let f = 0; f < filas; f++) {
          caja(0.02 + c * pw + 0.015, d - 0.03, 0.03 + f * ph + 0.015, pw - 0.03, 0.03, ph - 0.03, 'claro'); // puerta
          caja(0.02 + c * pw + pw - 0.09, d, 0.03 + f * ph + ph * 0.5, 0.03, 0.02, 0.1, 'metal'); // jaladera
          if (tipoClave === 'casillero') caja(0.02 + c * pw + pw * 0.3, d, 0.03 + f * ph + ph * 0.8, pw * 0.4, 0.005, 0.03, 'oscuro'); // rejilla
        }
      }
    } else if (tipoClave === 'vitrina') {
      caja(0, 0, 0, w, d, alto * 0.3, 'cuerpo');
      caja(0, 0, alto - 0.05, w, d, 0.05, 'cuerpo');
      [[0, 0], [w - 0.04, 0], [0, d - 0.04], [w - 0.04, d - 0.04]].forEach(([x, y]) => caja(x, y, alto * 0.3, 0.04, 0.04, alto * 0.7 - 0.05, 'oscuro'));
      caja(0.04, 0.04, alto * 0.62, w - 0.08, d - 0.08, 0.02, 'claro'); // repisa interior
      caja(0.02, 0.02, alto * 0.3, w - 0.04, d - 0.04, alto * 0.7 - 0.05, 'vidrio');
    } else { // caja
      caja(0.12, 0.12, 0, w - 0.24, d - 0.24, alto, 'cuerpo');
      caja(0.12, d / 2 - 0.05, alto, w - 0.24, 0.1, 0.004, 'claro'); // cinta
    }
    return cajas;
  }

  // Medidas del mueble sin girar: lo que mide "de fábrica" su frente y su fondo
  function medidasSinGiro(mueble) {
    return (mueble.giro || 0) % 2 ? { ancho: mueble.fondo, fondo: mueble.ancho } : { ancho: mueble.ancho, fondo: mueble.fondo };
  }

  // =====================================================================
  // 6. VALIDACIÓN
  // =====================================================================
  // Cada función devuelve { ok: true, valor } o { ok: false, error: 'mensaje para el usuario' }.

  // Junta espacios repetidos y quita caracteres de control (invisibles)
  function limpiarTexto(valor) {
    return String(valor == null ? '' : valor)
      .replace(/[\u0000-\u001f\u007f]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function validarTexto(valor, opciones) {
    const texto = limpiarTexto(valor);
    const campo = opciones.campo;
    const minimo = opciones.minimo == null ? 1 : opciones.minimo;
    if (!texto && minimo > 0) return { ok: false, error: 'Escribe ' + campo + '.' };
    if (texto.length < minimo) return { ok: false, error: campo + ': al menos ' + minimo + ' letras.' };
    if (texto.length > opciones.maximo) {
      return { ok: false, error: campo + ': máximo ' + opciones.maximo + ' caracteres.' };
    }
    return { ok: true, valor: texto };
  }

  function validarEntero(valor, opciones) {
    const texto = String(valor == null ? '' : valor).trim();
    const numero = Number(texto);
    if (texto === '' || !Number.isInteger(numero)) {
      return { ok: false, error: opciones.campo + ': escribe un número entero.' };
    }
    if (numero < opciones.minimo || numero > opciones.maximo) {
      return { ok: false, error: opciones.campo + ': de ' + opciones.minimo + ' a ' + opciones.maximo + '.' };
    }
    return { ok: true, valor: numero };
  }

  // Un plano válido: { ancho, fondo } con enteros de 3 a 20
  function planoValido(plano) {
    return Boolean(plano) && [plano.ancho, plano.fondo].every((lado) =>
      Number.isInteger(lado) && lado >= LIMITES.ladoMinimo && lado <= LIMITES.ladoMaximo);
  }

  // entrada: { nombre, tipo, conPlano, ancho, fondo }. conPlano puede venir como 'si'/'on'/true.
  function validarLugar(entrada) {
    const nombre = validarTexto(entrada.nombre, { campo: 'el nombre', maximo: LIMITES.nombre });
    if (!nombre.ok) return nombre;
    if (!TIPOS_LUGAR[entrada.tipo]) return { ok: false, error: 'Elige el tipo de lugar.' };
    const conPlano = entrada.conPlano === true || entrada.conPlano === 'si' || entrada.conPlano === 'on';
    let plano = null;
    if (conPlano) {
      const lado = { minimo: LIMITES.ladoMinimo, maximo: LIMITES.ladoMaximo };
      const ancho = validarEntero(entrada.ancho, Object.assign({ campo: 'Ancho' }, lado));
      if (!ancho.ok) return ancho;
      const fondo = validarEntero(entrada.fondo, Object.assign({ campo: 'Fondo' }, lado));
      if (!fondo.ok) return fondo;
      plano = { ancho: ancho.valor, fondo: fondo.valor };
    }
    return { ok: true, valor: { nombre: nombre.valor, tipo: entrada.tipo, plano: plano } };
  }

  // Datos descriptivos de un artículo (las existencias se cambian con sus propias operaciones)
  function validarDatosArticulo(datos, entrada) {
    const nombre = validarTexto(entrada.nombre, { campo: 'el nombre del artículo', maximo: LIMITES.nombre });
    if (!nombre.ok) return nombre;
    const categoriaId = entrada.categoriaId || ID_OTROS;
    if (!buscarPorId(datos.categorias, categoriaId)) return { ok: false, error: 'Elige una categoría.' };
    const codigo = validarTexto(entrada.codigo, { campo: 'N.º de inventario', minimo: 0, maximo: LIMITES.codigo });
    if (!codigo.ok) return codigo;
    const notas = validarTexto(entrada.notas, { campo: 'Notas', minimo: 0, maximo: LIMITES.notas });
    if (!notas.ok) return notas;
    return { ok: true, valor: { nombre: nombre.valor, categoriaId: categoriaId, codigo: codigo.valor, notas: notas.valor } };
  }

  function validarPrestamo(entrada, maximoCantidad, hoyISO) {
    const persona = validarTexto(entrada.persona, { campo: 'quién se lo lleva', minimo: 2, maximo: LIMITES.persona });
    if (!persona.ok) return persona;
    const grupo = validarTexto(entrada.grupo, { campo: 'Grupo o área', minimo: 0, maximo: LIMITES.grupo });
    if (!grupo.ok) return grupo;
    if (maximoCantidad < 1) return { ok: false, error: 'No hay piezas disponibles para prestar.' };
    const cantidad = validarEntero(entrada.cantidad, { campo: 'Cantidad', minimo: 1, maximo: maximoCantidad });
    if (!cantidad.ok) return cantidad;
    if (!leerFechaISO(entrada.fechaLimite)) return { ok: false, error: 'Elige la fecha en que regresa.' };
    const dias = diasEntre(hoyISO, entrada.fechaLimite);
    if (dias < 0) return { ok: false, error: 'La fecha de regreso no puede ser antes de hoy.' };
    if (dias > LIMITES.diasPrestamo) return { ok: false, error: 'El préstamo puede durar máximo un año.' };
    const nota = validarTexto(entrada.nota, { campo: 'Nota', minimo: 0, maximo: LIMITES.notas });
    if (!nota.ok) return nota;
    return {
      ok: true,
      valor: { persona: persona.valor, grupo: grupo.valor, cantidad: cantidad.valor, fechaLimite: entrada.fechaLimite, nota: nota.valor }
    };
  }

  function colorValido(color) {
    return typeof color === 'string' && /^#[0-9a-f]{6}$/i.test(color);
  }

  // =====================================================================
  // 7. OPERACIONES
  // =====================================================================
  // Ninguna operación cambia "datos" directamente. Devuelven:
  //   { ok: true, tipo, cambios: [...], ... }  o  { ok: false, error }
  // donde cada cambio es { tabla, poner: registro } o { tabla, borrar: id }, y "tipo" es el tipo de
  // movimiento para el historial. La app guarda los cambios (y su historial) en UNA transacción,
  // los aplica en memoria (aplicarCambios) y con invertirCambios() obtiene el «Deshacer».

  function fallo(error) {
    return { ok: false, error: error };
  }

  function exito(tipo, cambios, extra) {
    return Object.assign({ ok: true, tipo: tipo, cambios: cambios }, extra || {});
  }

  function aplicarCambios(datos, cambios) {
    indices.delete(datos); // los datos cambian: el índice se arma de nuevo en la próxima consulta
    cambios.forEach((cambio) => {
      const lista = datos[cambio.tabla];
      const id = cambio.poner ? cambio.poner.id : cambio.borrar;
      const posicion = lista.findIndex((registro) => registro.id === id);
      if (cambio.poner) {
        const copia = clonar(cambio.poner);
        if (posicion === -1) lista.push(copia);
        else lista[posicion] = copia;
      } else if (posicion !== -1) {
        lista.splice(posicion, 1);
      }
    });
    return datos;
  }

  // Los cambios que regresan "datos" a como estaba ANTES de aplicar "cambios".
  // El historial (movimientos) nunca se deshace: deshacer agrega su propio movimiento.
  function invertirCambios(datos, cambios) {
    const inverso = [];
    cambios.filter((cambio) => cambio.tabla !== 'movimientos').forEach((cambio) => {
      const id = cambio.poner ? cambio.poner.id : cambio.borrar;
      const anterior = buscarPorId(datos[cambio.tabla], id);
      if (anterior) inverso.unshift({ tabla: cambio.tabla, poner: clonar(anterior) });
      else inverso.unshift({ tabla: cambio.tabla, borrar: id });
    });
    return inverso;
  }

  function nombreRepetido(lista, nombre, ignorarId) {
    const buscado = normalizar(nombre);
    return lista.some((registro) => registro.id !== ignorarId && normalizar(registro.nombre) === buscado);
  }

  // "Estante", y si ya existe, "Estante 2", "Estante 3"…
  function nombreLibre(lista, base) {
    if (!nombreRepetido(lista, base)) return base;
    let numero = 2;
    while (nombreRepetido(lista, base + ' ' + numero)) numero++;
    return base + ' ' + numero;
  }

  // ---------- Lugares ----------
  function crearLugar(datos, entrada, id) {
    if (datos.lugares.length >= LIMITES.lugares) return fallo('Llegaste al máximo de ' + LIMITES.lugares + ' lugares.');
    const revision = validarLugar(entrada);
    if (!revision.ok) return revision;
    if (nombreRepetido(datos.lugares, revision.valor.nombre)) return fallo('Ya hay un lugar con ese nombre.');
    const lugar = Object.assign({ id: id || nuevoId('lug') }, revision.valor);
    return exito('alta', [{ tabla: 'lugares', poner: lugar }], { lugar: lugar });
  }

  // Editar nombre, tipo y plano.
  //   - Quitar el plano: los muebles conservan sus casillas como dato inactivo y el lugar recuerda
  //     sus medidas (planoAnterior). Nada se borra.
  //   - Volver a ponerle plano: los muebles cuya casilla guardada cabe vuelven a su lugar; los que
  //     no caben quedan «sin colocar» (se avisa cuáles) para acomodarlos después.
  //   - Achicar un plano que ya existe: si algún mueble colocado quedaría fuera, no se permite.
  function editarLugar(datos, lugarId, entrada) {
    const actual = buscarPorId(datos.lugares, lugarId);
    if (!actual) return fallo('Ese lugar ya no existe.');
    const revision = validarLugar(entrada);
    if (!revision.ok) return revision;
    if (nombreRepetido(datos.lugares, revision.valor.nombre, lugarId)) return fallo('Ya hay un lugar con ese nombre.');
    const plano = revision.valor.plano;
    const lugar = Object.assign({}, actual, revision.valor);
    const cambios = [];
    const sinColocar = [];
    let detalle = null;
    if (actual.plano && !plano) {
      lugar.planoAnterior = clonar(actual.plano);
      detalle = { plano: 'quitado' };
    } else if (actual.plano && plano) {
      const fuera = mueblesDe(datos, lugarId).filter((mueble) =>
        estaColocado(mueble) && (mueble.x + mueble.ancho > plano.ancho || mueble.y + mueble.fondo > plano.fondo));
      if (fuera.length) {
        return fallo('Con esas medidas quedarían fuera: ' + fuera.map((m) => m.nombre).join(', ') + '. Muévelos primero.');
      }
    } else if (!actual.plano && plano) {
      // Se vuelve a usar el plano: se revisa cada casilla guardada, los muebles con más artículos primero
      delete lugar.planoAnterior;
      detalle = { plano: 'puesto' };
      const colocados = [];
      mueblesDe(datos, lugarId).slice()
        .sort((a, b) => piezasEnMueble(datos, b.id) - piezasEnMueble(datos, a.id))
        .forEach((mueble) => {
          if (!estaColocado(mueble)) return;
          if (cabe(mueble, plano, colocados)) {
            colocados.push(mueble);
            return;
          }
          sinColocar.push(mueble.nombre);
          cambios.push({ tabla: 'muebles', poner: Object.assign({}, mueble, { x: null, y: null }) });
        });
    }
    cambios.unshift({ tabla: 'lugares', poner: lugar });
    return exito('edicion', cambios, { lugar: lugar, sinColocar: sinColocar, detalle: detalle });
  }

  // Qué se vería afectado si se borra un lugar (para mostrarlo antes de confirmar)
  function afectadosPorBorrarLugar(datos, lugarId) {
    const muebles = mueblesDe(datos, lugarId);
    const enMuebles = [];
    muebles.forEach((mueble) => articulosDe(datos, mueble.id).forEach((articulo) => enMuebles.push(articulo)));
    const directos = articulosEnLugar(datos, lugarId);
    const articulos = enMuebles.concat(directos);
    return {
      muebles: muebles.slice(),
      articulos: articulos,
      piezas: articulos.reduce((suma, articulo) => suma + totalDe(articulo), 0)
    };
  }

  // Borrar un lugar SIN perder artículos. Dos caminos:
  //   - destinoId: los muebles pasan a ese lugar «sin colocar» (con sus artículos dentro) y los
  //     artículos directos pasan directo a ese lugar. Nada se borra salvo el lugar.
  //   - sin destino: se borran el lugar y sus muebles; TODOS sus artículos pasan a «Sin ubicación».
  function borrarLugar(datos, lugarId, opciones) {
    const lugar = buscarPorId(datos.lugares, lugarId);
    if (!lugar) return fallo('Ese lugar ya no existe.');
    const destinoId = opciones && opciones.destinoId;
    const destino = destinoId ? buscarPorId(datos.lugares, destinoId) : null;
    if (destinoId && (!destino || destinoId === lugarId)) return fallo('Elige otro lugar como destino.');
    const afectados = afectadosPorBorrarLugar(datos, lugarId);
    const cambios = [];
    if (destino) {
      const vecinos = mueblesDe(datos, destino.id);
      afectados.muebles.forEach((mueble) => {
        const nombre = nombreRepetido(vecinos, mueble.nombre) ? nombreLibre(vecinos, mueble.nombre) : mueble.nombre;
        cambios.push({ tabla: 'muebles', poner: Object.assign({}, mueble, { lugarId: destino.id, nombre: nombre, x: null, y: null }) });
      });
      articulosEnLugar(datos, lugarId).forEach((articulo) => {
        cambios.push({ tabla: 'articulos', poner: Object.assign({}, articulo, { lugarId: destino.id }) });
      });
    } else {
      afectados.articulos.forEach((articulo) => {
        cambios.push({ tabla: 'articulos', poner: Object.assign({}, articulo, { muebleId: null, lugarId: null }) });
      });
      afectados.muebles.forEach((mueble) => cambios.push({ tabla: 'muebles', borrar: mueble.id }));
    }
    cambios.push({ tabla: 'lugares', borrar: lugarId });
    return exito('borrado', cambios, {
      muebles: afectados.muebles.length,
      articulos: afectados.articulos.length,
      piezas: afectados.piezas,
      destino: destino,
      detalle: { destino: destino ? destino.nombre : 'Sin ubicación' }
    });
  }

  // ---------- Muebles ----------
  function colocarMueble(datos, lugarId, tipo, rect, id) {
    const lugar = buscarPorId(datos.lugares, lugarId);
    if (!lugar) return fallo('Ese lugar ya no existe.');
    if (!lugar.plano) return fallo('Este lugar no tiene plano.');
    const datosTipo = TIPOS_MUEBLE[tipo];
    if (!datosTipo) return fallo('Ese tipo de mueble no existe.');
    const forma = { x: rect.x, y: rect.y, ancho: rect.ancho, fondo: rect.fondo };
    if (!cabe(forma, lugar.plano, mueblesDe(datos, lugarId))) return fallo('No cabe ahí.');
    const mueble = Object.assign(
      { id: id || nuevoId('mue'), lugarId: lugarId, tipo: tipo, nombre: nombreLibre(mueblesDe(datos, lugarId), datosTipo.nombre) },
      forma,
      { giro: forma.ancho === datosTipo.ancho ? 0 : 1 }
    );
    return exito('colocar', [{ tabla: 'muebles', poner: mueble }], { mueble: mueble });
  }

  // Mover a otra casilla (también sirve para colocar un mueble que estaba «sin colocar»)
  function moverMueble(datos, muebleId, rect) {
    const mueble = buscarPorId(datos.muebles, muebleId);
    if (!mueble) return fallo('Ese mueble ya no existe.');
    const lugar = buscarPorId(datos.lugares, mueble.lugarId);
    if (!lugar || !lugar.plano) return fallo('Este lugar no tiene plano.');
    const forma = { x: rect.x, y: rect.y, ancho: rect.ancho, fondo: rect.fondo };
    if (!cabe(forma, lugar.plano, mueblesDe(datos, lugar.id), muebleId)) return fallo('No cabe ahí.');
    const movido = Object.assign({}, mueble, forma);
    return exito(estaColocado(mueble) ? 'mover' : 'colocar', [{ tabla: 'muebles', poner: movido }], { mueble: movido });
  }

  // Gira el mueble un cuarto de vuelta sobre su primera casilla. "giro" dice hacia dónde mira
  // (0 a 3 cuartos de vuelta): el 2.5D usa sus medidas y el 3D usará también su orientación.
  function girarMueble(datos, muebleId) {
    const mueble = buscarPorId(datos.muebles, muebleId);
    if (!mueble) return fallo('Ese mueble ya no existe.');
    if (mueble.ancho === mueble.fondo) return fallo('Este mueble es cuadrado: girarlo no cambia nada.');
    const forma = { ancho: mueble.fondo, fondo: mueble.ancho, giro: ((mueble.giro || 0) + 1) % 4 };
    if (estaColocado(mueble)) {
      const lugar = buscarPorId(datos.lugares, mueble.lugarId);
      const rect = { x: mueble.x, y: mueble.y, ancho: forma.ancho, fondo: forma.fondo };
      if (lugar && lugar.plano && !cabe(rect, lugar.plano, mueblesDe(datos, lugar.id), muebleId)) {
        return fallo('No hay espacio para girarlo.');
      }
    }
    const girado = Object.assign({}, mueble, forma);
    return exito('girar', [{ tabla: 'muebles', poner: girado }], { mueble: girado });
  }

  function renombrarMueble(datos, muebleId, nombre) {
    const mueble = buscarPorId(datos.muebles, muebleId);
    if (!mueble) return fallo('Ese mueble ya no existe.');
    const revision = validarTexto(nombre, { campo: 'el nombre', maximo: LIMITES.nombre });
    if (!revision.ok) return revision;
    if (nombreRepetido(mueblesDe(datos, mueble.lugarId), revision.valor, muebleId)) {
      return fallo('Ya hay un mueble con ese nombre en este lugar.');
    }
    const renombrado = Object.assign({}, mueble, { nombre: revision.valor });
    return exito('edicion', [{ tabla: 'muebles', poner: renombrado }], { mueble: renombrado });
  }

  // Borrar un mueble. Por defecto sus artículos NO se borran: pasan directo al lugar del mueble.
  // Con { conArticulos: true } (requiere confirmación explícita en la app) se borran también,
  // salvo que alguno tenga préstamos activos.
  function borrarMueble(datos, muebleId, opciones) {
    const mueble = buscarPorId(datos.muebles, muebleId);
    if (!mueble) return fallo('Ese mueble ya no existe.');
    const articulos = articulosDe(datos, muebleId);
    const piezas = articulos.reduce((suma, articulo) => suma + totalDe(articulo), 0);
    const conArticulos = Boolean(opciones && opciones.conArticulos);
    const cambios = [];
    if (conArticulos) {
      const conPrestamo = articulos.find((articulo) => prestadas(datos, articulo.id) > 0);
      if (conPrestamo) {
        return fallo('«' + conPrestamo.nombre + '» está prestado. Regístralo como devuelto antes de borrarlo.');
      }
      articulos.forEach((articulo) => cambios.push({ tabla: 'articulos', borrar: articulo.id }));
    } else {
      const vecinos = articulosEnLugar(datos, mueble.lugarId);
      articulos.forEach((articulo) => {
        const nombre = nombreRepetido(vecinos, articulo.nombre) ? nombreLibre(vecinos, articulo.nombre) : articulo.nombre;
        cambios.push({ tabla: 'articulos', poner: Object.assign({}, articulo, { muebleId: null, lugarId: mueble.lugarId, nombre: nombre }) });
      });
    }
    cambios.push({ tabla: 'muebles', borrar: muebleId });
    return exito('borrado', cambios, { articulos: articulos.length, piezas: piezas, conArticulos: conArticulos });
  }

  // ---------- Artículos ----------
  // ubicacion: { muebleId } | { lugarId } | null. Devuelve los campos normalizados o un error.
  function revisarUbicacion(datos, destino) {
    if (destino && destino.muebleId) {
      if (!buscarPorId(datos.muebles, destino.muebleId)) return fallo('Ese mueble ya no existe.');
      return { ok: true, valor: { muebleId: destino.muebleId, lugarId: null } };
    }
    if (destino && destino.lugarId) {
      if (!buscarPorId(datos.lugares, destino.lugarId)) return fallo('Ese lugar ya no existe.');
      return { ok: true, valor: { muebleId: null, lugarId: destino.lugarId } };
    }
    return { ok: true, valor: { muebleId: null, lugarId: null } };
  }

  // Artículos que ya están en esa misma ubicación (para no repetir nombres)
  function vecinosDe(datos, sitio) {
    if (sitio.muebleId) return articulosDe(datos, sitio.muebleId);
    if (sitio.lugarId) return articulosEnLugar(datos, sitio.lugarId);
    return articulosSinUbicacion(datos);
  }

  // Alta de un artículo. entrada: { nombre, cantidad, categoriaId, codigo, notas, ubicacion }.
  // Si en esa ubicación ya hay uno con el mismo nombre, se suman las piezas (entrada de existencias).
  function crearArticulo(datos, entrada, id) {
    const sitio = revisarUbicacion(datos, entrada.ubicacion);
    if (!sitio.ok) return sitio;
    const revision = validarDatosArticulo(datos, entrada);
    if (!revision.ok) return revision;
    const cantidad = validarEntero(entrada.cantidad, { campo: 'Cantidad', minimo: 1, maximo: LIMITES.cantidad });
    if (!cantidad.ok) return cantidad;
    const existente = vecinosDe(datos, sitio.valor).find((a) => normalizar(a.nombre) === normalizar(revision.valor.nombre));
    if (existente) {
      const sumado = agregarExistencias(datos, existente.id, cantidad.valor);
      return sumado.ok ? Object.assign(sumado, { sumado: true }) : sumado;
    }
    const articulo = Object.assign({ id: id || nuevoId('art') }, revision.valor, sitio.valor, {
      estados: { bueno: cantidad.valor, reparacion: 0, danado: 0 },
      seguimiento: 'cantidad'
    });
    return exito('alta', [{ tabla: 'articulos', poner: articulo }], { articulo: articulo, sumado: false });
  }

  // Atajo usado por la ficha del mueble: agregar un artículo dentro de ese mueble
  function agregarArticulo(datos, muebleId, entrada, id) {
    return crearArticulo(datos, Object.assign({}, entrada, { ubicacion: { muebleId: muebleId } }), id);
  }

  function editarArticulo(datos, articuloId, entrada) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const revision = validarDatosArticulo(datos, Object.assign({ categoriaId: articulo.categoriaId }, entrada));
    if (!revision.ok) return revision;
    if (nombreRepetido(vecinosDe(datos, articulo), revision.valor.nombre, articuloId)) {
      return fallo('Ya hay un artículo con ese nombre en esa ubicación.');
    }
    const editado = Object.assign({}, articulo, revision.valor);
    return exito('edicion', [{ tabla: 'articulos', poner: editado }], { articulo: editado });
  }

  function conEstados(articulo, cambios) {
    return Object.assign({}, articulo, { estados: Object.assign({}, articulo.estados, cambios) });
  }

  // Entrada de existencias: llegan piezas nuevas en buen estado
  function agregarExistencias(datos, articuloId, cantidad) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const revision = validarEntero(cantidad, { campo: 'Cantidad', minimo: 1, maximo: LIMITES.cantidad });
    if (!revision.ok) return revision;
    if (totalDe(articulo) + revision.valor > LIMITES.cantidad) return fallo('Cantidad: máximo ' + LIMITES.cantidad + ' piezas.');
    const nuevo = conEstados(articulo, { bueno: articulo.estados.bueno + revision.valor });
    return exito('entrada', [{ tabla: 'articulos', poner: nuevo }], { articulo: nuevo, detalle: { cantidad: revision.valor } });
  }

  // Pasar piezas de un estado a otro (por ejemplo, 1 de buen estado a reparación).
  // Desde «buen estado» solo se pueden pasar las disponibles: lo prestado no se manda a reparar.
  function cambiarEstado(datos, articuloId, entrada) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const de = entrada.de;
    const a = entrada.a;
    if (!CLAVES_ESTADO.includes(de) || !CLAVES_ESTADO.includes(a) || de === a) return fallo('Elige dos estados distintos.');
    const maximo = de === 'bueno' ? disponibles(datos, articulo) : articulo.estados[de];
    if (maximo < 1) {
      return fallo(de === 'bueno' && articulo.estados.bueno > 0
        ? 'Las piezas en buen estado están prestadas.'
        : 'No hay piezas en «' + nombreEstado(de) + '».');
    }
    const revision = validarEntero(entrada.cantidad, { campo: 'Cantidad', minimo: 1, maximo: maximo });
    if (!revision.ok) return revision;
    const cambio = {};
    cambio[de] = articulo.estados[de] - revision.valor;
    cambio[a] = articulo.estados[a] + revision.valor;
    const nuevo = conEstados(articulo, cambio);
    return exito('cambio-estado', [{ tabla: 'articulos', poner: nuevo }], {
      articulo: nuevo, detalle: { de: de, a: a, cantidad: revision.valor }
    });
  }

  // Dar de baja: las piezas salen del inventario (rotas sin arreglo, perdidas, consumidas).
  // El artículo puede quedar en 0 (por ejemplo, un consumible agotado) sin borrarse.
  function darDeBaja(datos, articuloId, entrada) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const estado = entrada.estado;
    if (!CLAVES_ESTADO.includes(estado)) return fallo('Elige de qué estado salen las piezas.');
    const maximo = estado === 'bueno' ? disponibles(datos, articulo) : articulo.estados[estado];
    if (maximo < 1) return fallo('No hay piezas que se puedan dar de baja en «' + nombreEstado(estado) + '».');
    const revision = validarEntero(entrada.cantidad, { campo: 'Cantidad', minimo: 1, maximo: maximo });
    if (!revision.ok) return revision;
    const motivo = validarTexto(entrada.motivo, { campo: 'el motivo', minimo: 2, maximo: LIMITES.motivo });
    if (!motivo.ok) return motivo;
    const cambio = {};
    cambio[estado] = articulo.estados[estado] - revision.valor;
    const nuevo = conEstados(articulo, cambio);
    return exito('baja', [{ tabla: 'articulos', poner: nuevo }], {
      articulo: nuevo, detalle: { estado: estado, cantidad: revision.valor, motivo: motivo.valor }
    });
  }

  function nombreEstado(clave) {
    const estado = ESTADOS.find((e) => e.clave === clave);
    return estado ? estado.nombre : clave;
  }

  // Lleva el artículo a otra ubicación: un mueble, directo a un lugar o «Sin ubicación».
  // Si allá ya hay uno con el mismo nombre, se juntan (se suman las existencias por estado y sus
  // préstamos pasan al de destino).
  function moverArticulo(datos, articuloId, destino) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const sitio = revisarUbicacion(datos, destino);
    if (!sitio.ok) return sitio;
    if (sitio.valor.muebleId === (articulo.muebleId || null) && sitio.valor.lugarId === (articulo.lugarId || null)) {
      return fallo('Ya está ahí.');
    }
    const igual = vecinosDe(datos, sitio.valor).find((otro) => normalizar(otro.nombre) === normalizar(articulo.nombre));
    if (!igual) {
      const movido = Object.assign({}, articulo, sitio.valor);
      return exito('cambio-ubicacion', [{ tabla: 'articulos', poner: movido }], { articulo: movido, juntos: false });
    }
    if (totalDe(igual) + totalDe(articulo) > LIMITES.cantidad) return fallo('Juntos pasarían de ' + LIMITES.cantidad + ' piezas.');
    const juntos = conEstados(igual, {
      bueno: igual.estados.bueno + articulo.estados.bueno,
      reparacion: igual.estados.reparacion + articulo.estados.reparacion,
      danado: igual.estados.danado + articulo.estados.danado
    });
    const prestamosMovidos = datos.prestamos
      .filter((prestamo) => prestamo.articuloId === articuloId)
      .map((prestamo) => ({ tabla: 'prestamos', poner: Object.assign({}, prestamo, { articuloId: igual.id }) }));
    return exito('cambio-ubicacion', [{ tabla: 'articulos', poner: juntos }]
      .concat(prestamosMovidos)
      .concat([{ tabla: 'articulos', borrar: articuloId }]), { articulo: juntos, juntos: true });
  }

  function borrarArticulo(datos, articuloId) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    if (prestadas(datos, articuloId) > 0) return fallo('Tiene préstamos activos. Regístralos como devueltos antes de borrarlo.');
    return exito('borrado', [{ tabla: 'articulos', borrar: articuloId }]);
  }

  // ---------- Préstamos ----------
  function prestar(datos, articuloId, entrada, hoyISO, id) {
    const lugar = ubicacion(datos, articuloId);
    if (!lugar.articulo) return fallo('Ese artículo ya no existe.');
    const revision = validarPrestamo(entrada, disponibles(datos, lugar.articulo), hoyISO);
    if (!revision.ok) return revision;
    const prestamo = {
      id: id || nuevoId('pre'),
      articuloId: articuloId,
      // Copia de qué y de dónde: el historial sigue legible aunque luego se borre el artículo
      articuloNombre: lugar.articulo.nombre,
      origen: textoUbicacion(lugar.lugar, lugar.mueble),
      persona: revision.valor.persona,
      grupo: revision.valor.grupo,
      cantidad: revision.valor.cantidad,
      fechaSalida: hoyISO,
      fechaLimite: revision.valor.fechaLimite,
      devuelto: null, // fecha de devolución; vacío mientras siga prestado
      devueltasDanadas: 0,
      nota: revision.valor.nota
    };
    return exito('prestamo', [{ tabla: 'prestamos', poner: prestamo }], { prestamo: prestamo });
  }

  // Registrar la devolución.
  //   opciones.cantidad: cuántas regresan (por defecto, todas). Si regresan menos, el préstamo
  //     sigue activo por las que faltan y se crea un registro aparte, ya devuelto, por las que volvieron.
  //   opciones.danadas: cuántas de las que regresan vienen dañadas; pasan de «buen estado» a «dañado».
  function devolver(datos, prestamoId, hoyISO, opciones) {
    const ajustes = opciones || {};
    const prestamo = buscarPorId(datos.prestamos, prestamoId);
    if (!prestamo) return fallo('Ese préstamo ya no existe.');
    if (prestamo.devuelto) return fallo('Ese préstamo ya estaba devuelto.');
    const cantidad = validarEntero(ajustes.cantidad != null && ajustes.cantidad !== '' ? ajustes.cantidad : prestamo.cantidad,
      { campo: 'Cantidad que regresa', minimo: 1, maximo: prestamo.cantidad });
    if (!cantidad.ok) return cantidad;
    const danadas = validarEntero(ajustes.danadas != null && ajustes.danadas !== '' ? ajustes.danadas : 0,
      { campo: 'Dañadas', minimo: 0, maximo: cantidad.valor });
    if (!danadas.ok) return danadas;
    const parcial = cantidad.valor < prestamo.cantidad;
    const devuelto = Object.assign({}, prestamo, { cantidad: cantidad.valor, devuelto: hoyISO, devueltasDanadas: danadas.valor });
    const cambios = [];
    if (parcial) {
      devuelto.id = ajustes.id || nuevoId('pre');
      cambios.push({ tabla: 'prestamos', poner: Object.assign({}, prestamo, { cantidad: prestamo.cantidad - cantidad.valor }) });
    }
    cambios.push({ tabla: 'prestamos', poner: devuelto });
    const articulo = buscarPorId(datos.articulos, prestamo.articuloId);
    if (articulo && danadas.valor) {
      cambios.push({ tabla: 'articulos', poner: conEstados(articulo, {
        bueno: articulo.estados.bueno - danadas.valor,
        danado: articulo.estados.danado + danadas.valor
      }) });
    }
    return exito('devolucion', cambios, {
      prestamo: devuelto, parcial: parcial, faltan: prestamo.cantidad - cantidad.valor,
      detalle: { cantidad: cantidad.valor, danadas: danadas.valor, faltan: prestamo.cantidad - cantidad.valor }
    });
  }

  // ---------- Números de serie (seguimiento individual, primera parte) ----------
  // Un artículo puede llevar una lista de números de serie o etiquetas de sus piezas. Es un
  // registro para identificarlas y encontrarlas con el buscador; el estado y los préstamos se
  // siguen contando por cantidad. (El modelo deja lista la evolución a seguimiento por pieza.)
  function limpiarSeries(lista) {
    const vistas = new Set();
    const salida = [];
    lista.forEach((valor) => {
      const texto = limpiarTexto(valor).slice(0, LIMITES.codigo);
      const clave = normalizar(texto);
      if (!texto || vistas.has(clave)) return;
      vistas.add(clave);
      salida.push(texto);
    });
    return salida;
  }

  // texto: un número de serie por línea (o separados por comas)
  function guardarSeries(datos, articuloId, texto) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const series = limpiarSeries(String(texto == null ? '' : texto).split(/[\n,;]+/));
    if (series.length > totalDe(articulo)) {
      return fallo('Hay ' + series.length + ' números de serie pero solo ' + plural(totalDe(articulo), 'pieza') + '.');
    }
    const nuevo = Object.assign({}, articulo);
    if (series.length) nuevo.series = series;
    else delete nuevo.series;
    return exito('edicion', [{ tabla: 'articulos', poner: nuevo }], { articulo: nuevo, detalle: { series: series.length } });
  }

  // ---------- Medidas del mueble y vista preferida del lugar ----------
  const MEDIDA_MAXIMA_MUEBLE = 6;

  function redimensionarMueble(datos, muebleId, entrada) {
    const mueble = buscarPorId(datos.muebles, muebleId);
    if (!mueble) return fallo('Ese mueble ya no existe.');
    const limites = { minimo: 1, maximo: MEDIDA_MAXIMA_MUEBLE };
    const ancho = validarEntero(entrada.ancho, Object.assign({ campo: 'Ancho' }, limites));
    if (!ancho.ok) return ancho;
    const fondo = validarEntero(entrada.fondo, Object.assign({ campo: 'Fondo' }, limites));
    if (!fondo.ok) return fondo;
    if (estaColocado(mueble)) {
      const lugar = buscarPorId(datos.lugares, mueble.lugarId);
      const rect = { x: mueble.x, y: mueble.y, ancho: ancho.valor, fondo: fondo.valor };
      if (lugar && lugar.plano && !cabe(rect, lugar.plano, mueblesDe(datos, lugar.id), muebleId)) {
        return fallo('Con esas medidas no cabe donde está. Muévelo primero.');
      }
    }
    const nuevo = Object.assign({}, mueble, { ancho: ancho.valor, fondo: fondo.valor });
    return exito('edicion', [{ tabla: 'muebles', poner: nuevo }], { mueble: nuevo });
  }

  // Cómo se prefiere ver cada lugar: 'lista', '2.5d' o '3d'. Es una preferencia: no deja historial.
  function cambiarVistaLugar(datos, lugarId, vista) {
    const lugar = buscarPorId(datos.lugares, lugarId);
    if (!lugar) return fallo('Ese lugar ya no existe.');
    if (!VISTAS_LUGAR.includes(vista)) return fallo('Esa vista no existe.');
    if (vista !== 'lista' && !lugar.plano) return fallo('Este lugar no tiene plano.');
    return exito('edicion', [{ tabla: 'lugares', poner: Object.assign({}, lugar, { vista: vista }) }], { sinHistorial: true });
  }

  function vistaDeLugar(lugar) {
    if (!lugar || !lugar.plano) return 'lista';
    return VISTAS_LUGAR.includes(lugar.vista) ? lugar.vista : '2.5d';
  }

  // ---------- Categorías ----------
  function crearCategoria(datos, entrada, id) {
    if (datos.categorias.length >= LIMITES.categorias) return fallo('Llegaste al máximo de ' + LIMITES.categorias + ' categorías.');
    const nombre = validarTexto(entrada.nombre, { campo: 'el nombre de la categoría', maximo: LIMITES.nombre });
    if (!nombre.ok) return nombre;
    if (nombreRepetido(datos.categorias, nombre.valor)) return fallo('Ya hay una categoría con ese nombre.');
    const color = colorValido(entrada.color) ? entrada.color.toLowerCase() : COLORES_CATEGORIA[datos.categorias.length % COLORES_CATEGORIA.length];
    const orden = datos.categorias.reduce((maximo, categoria) => Math.max(maximo, categoria.orden), 0) + 1;
    const categoria = { id: id || nuevoId('cat'), nombre: nombre.valor, color: color, orden: orden, fija: false };
    return exito('alta', [{ tabla: 'categorias', poner: categoria }], { categoria: categoria });
  }

  function editarCategoria(datos, categoriaId, entrada) {
    const categoria = buscarPorId(datos.categorias, categoriaId);
    if (!categoria) return fallo('Esa categoría ya no existe.');
    const nombre = validarTexto(entrada.nombre, { campo: 'el nombre de la categoría', maximo: LIMITES.nombre });
    if (!nombre.ok) return nombre;
    if (nombreRepetido(datos.categorias, nombre.valor, categoriaId)) return fallo('Ya hay una categoría con ese nombre.');
    const editada = Object.assign({}, categoria, { nombre: nombre.valor, color: colorValido(entrada.color) ? entrada.color.toLowerCase() : categoria.color });
    return exito('edicion', [{ tabla: 'categorias', poner: editada }], { categoria: editada });
  }

  // Borrar una categoría nunca borra artículos: los suyos pasan a otra (por defecto, «Otros»).
  function borrarCategoria(datos, categoriaId, destinoId) {
    const categoria = buscarPorId(datos.categorias, categoriaId);
    if (!categoria) return fallo('Esa categoría ya no existe.');
    if (categoria.fija) return fallo('«' + categoria.nombre + '» no se puede borrar: ahí van los artículos de las categorías borradas.');
    const destino = buscarPorId(datos.categorias, destinoId || ID_OTROS);
    if (!destino || destino.id === categoriaId) return fallo('Elige otra categoría para sus artículos.');
    const articulos = articulosDeCategoria(datos, categoriaId);
    const cambios = articulos.map((articulo) => ({ tabla: 'articulos', poner: Object.assign({}, articulo, { categoriaId: destino.id }) }));
    cambios.push({ tabla: 'categorias', borrar: categoriaId });
    return exito('borrado', cambios, { articulos: articulos.length, destino: destino, detalle: { destino: destino.nombre } });
  }

  // =====================================================================
  // 8. HISTORIAL (movimientos)
  // =====================================================================
  // Cada operación trae su "tipo". Esta función agrega, por cada registro que cambia, un
  // movimiento con sus datos ANTES y DESPUÉS. La app guarda todo en la misma transacción:
  // no puede existir un cambio sin su historial. "autor" queda listo para cuando haya usuarios.
  const ENTIDADES = { lugares: 'lugar', muebles: 'mueble', articulos: 'articulo', prestamos: 'prestamo', categorias: 'categoria' };

  function conMovimientos(datos, resultado, momentoISO, operacionId) {
    const base = resultado.cambios.filter((cambio) => cambio.tabla !== 'movimientos');
    const movimientos = base.map((cambio, posicion) => {
      const id = cambio.poner ? cambio.poner.id : cambio.borrar;
      const antes = buscarPorId(datos[cambio.tabla], id);
      const despues = cambio.poner || null;
      const registro = despues || antes || {};
      return {
        tabla: 'movimientos',
        poner: {
          id: operacionId + '-' + posicion,
          momento: momentoISO,
          operacionId: operacionId,
          tipo: resultado.tipo || 'edicion',
          entidad: ENTIDADES[cambio.tabla] || cambio.tabla,
          entidadId: id,
          nombre: limpiarTexto(registro.nombre || registro.articuloNombre || ''),
          antes: clonar(antes),
          despues: clonar(despues),
          detalle: clonar(resultado.detalle) || null,
          autor: null
        }
      };
    });
    return base.concat(movimientos);
  }

  // Movimiento suelto (migración, restauración, reparación de datos)
  function movimientoGeneral(tipo, momentoISO, detalle) {
    return {
      id: 'mov-' + tipo + '-' + momentoISO, momento: momentoISO, operacionId: 'mov-' + tipo + '-' + momentoISO, tipo: tipo,
      entidad: 'inventario', entidadId: 'inventario', nombre: TIPOS_MOVIMIENTO[tipo] || tipo,
      antes: null, despues: null, detalle: clonar(detalle) || null, autor: null
    };
  }

  // Texto corto de un movimiento para el historial de la ficha
  function textoMovimiento(movimiento) {
    const tipo = TIPOS_MOVIMIENTO[movimiento.tipo] || movimiento.tipo;
    const d = movimiento.detalle || {};
    if (movimiento.tipo === 'entrada') return tipo + ': +' + d.cantidad;
    if (movimiento.tipo === 'cambio-estado') return d.cantidad + ' de «' + nombreEstado(d.de) + '» a «' + nombreEstado(d.a) + '»';
    if (movimiento.tipo === 'baja') return 'Baja de ' + d.cantidad + ' (' + d.motivo + ')';
    if (movimiento.tipo === 'devolucion' && d.danadas) return tipo + ' (' + plural(d.danadas, 'dañada') + ')';
    if (movimiento.tipo === 'cambio-ubicacion' && movimiento.despues) {
      const despues = movimiento.despues;
      return tipo + (despues.muebleId || despues.lugarId ? '' : ': a «Sin ubicación»');
    }
    return tipo;
  }

  // =====================================================================
  // 9. RESPALDO
  // =====================================================================
  // Formato 1 (hasta la Etapa 0): espacios, muebles, equipo y prestamos.
  // Formato 2 (Etapa 1A): las 6 tablas actuales. Los respaldos de formato 1 se convierten al abrirlos.
  const FORMATO_RESPALDO = 2;

  function crearRespaldo(datos, momento) {
    const respaldo = { app: 'ubica', formato: FORMATO_RESPALDO, exportado: momento || new Date().toISOString() };
    TABLAS.forEach((tabla) => {
      respaldo[tabla] = clonar(datos[tabla] || []);
    });
    return respaldo;
  }

  const esObjeto = (valor) => Boolean(valor) && typeof valor === 'object' && !Array.isArray(valor);

  // giro de un mueble antiguo: 0 si tiene las medidas de su tipo, 1 si estaba girado
  function inferirGiro(mueble) {
    const tipo = TIPOS_MUEBLE[mueble.tipo];
    if (!tipo || tipo.ancho === tipo.fondo) return 0;
    return mueble.ancho === tipo.fondo && mueble.fondo === tipo.ancho ? 1 : 0;
  }

  // Convierte un respaldo de formato 1 al 2. Solo cambia la FORMA de los datos: no valida,
  // no corrige y no borra nada (de eso se encarga prepararDatos, que avisa lo que hace).
  function convertirFormato1(objeto) {
    const lista = (tabla) => (Array.isArray(objeto[tabla]) ? objeto[tabla] : []);
    const convertir = (registro, funcion) => (esObjeto(registro) ? funcion(registro) : registro);
    return {
      app: 'ubica',
      formato: 2,
      exportado: objeto.exportado,
      lugares: lista('espacios').map((r) => convertir(r, (e) => ({
        id: e.id, nombre: e.nombre, tipo: e.tipo, plano: { ancho: e.ancho, fondo: e.fondo }
      }))),
      muebles: lista('muebles').map((r) => convertir(r, (m) => ({
        id: m.id, lugarId: m.espacioId, tipo: m.tipo, nombre: m.nombre,
        x: m.x, y: m.y, ancho: m.ancho, fondo: m.fondo, giro: inferirGiro(m)
      }))),
      articulos: lista('equipo').map((r) => convertir(r, (q) => ({
        id: q.id, nombre: q.nombre, categoriaId: ID_OTROS, codigo: q.codigo == null ? '' : q.codigo,
        notas: q.notas == null ? '' : q.notas, muebleId: q.muebleId == null ? null : q.muebleId, lugarId: null,
        estados: { bueno: q.cantidad, reparacion: 0, danado: 0 }, seguimiento: 'cantidad'
      }))),
      prestamos: lista('prestamos').map((r) => convertir(r, (p) => ({
        id: p.id, articuloId: p.equipoId, articuloNombre: p.equipoNombre, origen: p.origen, persona: p.persona,
        grupo: p.grupo, cantidad: p.cantidad, fechaSalida: p.fechaSalida, fechaLimite: p.fechaLimite,
        devuelto: p.devuelto == null ? null : p.devuelto, devueltasDanadas: 0, nota: p.nota
      }))),
      categorias: categoriasIniciales(),
      movimientos: []
    };
  }

  // ---------- Revisión y reparación segura ----------
  // prepararDatos revisa un respaldo (de archivo, de una copia, de la base vieja o de los datos
  // actuales) contra TODAS las reglas del modelo. Lo que no cumple se resuelve de la forma más
  // segura posible y QUEDA ANOTADO en "hallazgos" para mostrárselo a la persona:
  //   - Nunca se borra un lugar, mueble, artículo o préstamo para que las reglas "pasen".
  //     Un mueble encimado se mueve a una casilla libre (o queda «sin colocar»); un artículo cuyo
  //     mueble no existe pasa a «Sin ubicación»; un préstamo activo de un artículo inexistente
  //     recrea ese artículo; si lo prestado supera lo que hay en buen estado, se aumenta
  //     «buen estado» (se avisa, porque cambia una cantidad).
  //   - Solo se descarta lo que no es un registro (texto suelto, sin datos) o un registro
  //     repetido idéntico (mismo id y mismo contenido): eso también se anota.
  // Es determinista: con los mismos datos siempre da el mismo resultado (importante para la migración).
  function prepararDatos(objeto, opciones) {
    if (!esObjeto(objeto) || objeto.app !== 'ubica') return fallo('El archivo no es un respaldo de Ubica.');
    if (typeof objeto.formato !== 'number' || objeto.formato > FORMATO_RESPALDO) {
      return fallo('El respaldo es de una versión más nueva de Ubica. Actualiza la app.');
    }
    const hoyISO = (opciones && opciones.hoy) || fechaISO(new Date());
    const fuente = objeto.formato < 2 ? convertirFormato1(objeto) : objeto;
    const hallazgos = [];
    const anotar = (texto, extra) => hallazgos.push(Object.assign({ texto: texto, quita: false }, extra || {}));
    const ajustes = { piezasAgregadas: 0 };

    // Registros: solo objetos con id; repetidos idénticos se quitan, repetidos distintos reciben id nuevo
    function registros(tabla, etiqueta) {
      const vistos = new Map();
      const salida = [];
      (Array.isArray(fuente[tabla]) ? fuente[tabla] : []).forEach((registro, posicion) => {
        if (!esObjeto(registro)) {
          anotar('Se quitará un dato de «' + etiqueta + '» que no es un registro.', { quita: true });
          return;
        }
        const copia = clonar(registro);
        const valido = typeof copia.id === 'string' && copia.id.length > 0 && copia.id.length <= 80;
        if (valido && vistos.has(copia.id)) {
          if (JSON.stringify(vistos.get(copia.id)) === JSON.stringify(copia)) {
            anotar('Se quitará una copia repetida idéntica en «' + etiqueta + '» (' + copia.id + ').', { quita: true });
            return;
          }
        }
        if (!valido || vistos.has(copia.id)) {
          const anterior = copia.id;
          copia.id = 'rec-' + tabla + '-' + posicion;
          anotar('Un registro de «' + etiqueta + '» tenía un identificador ' + (valido ? 'repetido (' + anterior + ')' : 'inválido') +
            ': se le asigna uno nuevo.');
        }
        vistos.set(copia.id, registro);
        salida.push(copia);
      });
      return salida;
    }

    // Texto obligatorio: si falta se usa un nombre por defecto; si es muy largo se recorta
    function textoObligatorio(valor, maximo, porDefecto, que) {
      const texto = limpiarTexto(valor);
      if (!texto) {
        anotar(que + ' sin nombre: se llamará «' + porDefecto + '».');
        return porDefecto;
      }
      if (texto.length > maximo) {
        anotar(que + ' «' + texto.slice(0, 20) + '…»: el nombre se recorta a ' + maximo + ' caracteres.');
        return texto.slice(0, maximo).trim();
      }
      return texto;
    }

    function textoOpcional(valor, maximo, que) {
      const texto = limpiarTexto(valor);
      if (texto.length > maximo) {
        anotar(que + ': el texto se recorta a ' + maximo + ' caracteres.');
        return texto.slice(0, maximo).trim();
      }
      return texto;
    }

    // Nombre sin repetir dentro de un grupo: «Pipeta», «Pipeta (2)»…
    function sinRepetir(usados, nombre, que) {
      let final = nombre;
      let numero = 2;
      while (usados.has(normalizar(final))) {
        final = nombre.slice(0, LIMITES.nombre - 4) + ' (' + numero + ')';
        numero++;
      }
      if (final !== nombre) anotar(que + ' «' + nombre + '» estaba repetido: el segundo se llamará «' + final + '».');
      usados.add(normalizar(final));
      return final;
    }

    const limpio = datosVacios();

    // --- Categorías (primero: los artículos las necesitan) ---
    const nombresCategoria = new Set();
    registros('categorias', 'categorías').forEach((c) => {
      const nombre = sinRepetir(nombresCategoria, textoObligatorio(c.nombre, LIMITES.nombre, 'Categoría', 'Una categoría'), 'La categoría');
      limpio.categorias.push({
        id: c.id, nombre: nombre, color: colorValido(c.color) ? c.color.toLowerCase() : '#7b8794',
        orden: Number.isFinite(c.orden) ? c.orden : limpio.categorias.length, fija: c.id === ID_OTROS
      });
    });
    if (!buscarPorId(limpio.categorias, ID_OTROS)) {
      const otros = categoriasIniciales().find((c) => c.id === ID_OTROS);
      otros.nombre = sinRepetir(nombresCategoria, 'Otros', 'La categoría');
      limpio.categorias.push(otros);
      if ((fuente.categorias || []).length) anotar('Faltaba la categoría fija «Otros»: se agrega.');
    }
    const categoriaPorId = new Map(limpio.categorias.map((c) => [c.id, c]));

    // --- Lugares ---
    const nombresLugar = new Set();
    registros('lugares', 'lugares').forEach((l) => {
      const nombre = sinRepetir(nombresLugar, textoObligatorio(l.nombre, LIMITES.nombre, 'Lugar sin nombre', 'Un lugar'), 'El lugar');
      let tipo = l.tipo;
      if (!TIPOS_LUGAR[tipo]) {
        if (tipo != null && tipo !== '') anotar('El lugar «' + nombre + '» tenía un tipo desconocido: se marca como «Otro».');
        tipo = 'otro';
      }
      let plano = null;
      if (l.plano != null) {
        if (planoValido(l.plano)) plano = { ancho: l.plano.ancho, fondo: l.plano.fondo };
        else anotar('El lugar «' + nombre + '» tenía medidas no válidas: queda sin plano (sus muebles se conservan).');
      }
      const lugar = { id: l.id, nombre: nombre, tipo: tipo, plano: plano };
      if (VISTAS_LUGAR.includes(l.vista)) lugar.vista = l.vista;
      if (planoValido(l.planoAnterior) && !plano) lugar.planoAnterior = { ancho: l.planoAnterior.ancho, fondo: l.planoAnterior.fondo };
      limpio.lugares.push(lugar);
    });
    const lugarPorId = new Map(limpio.lugares.map((l) => [l.id, l]));
    let lugarRecuperado = null;
    function recuperarLugar() {
      if (!lugarRecuperado) {
        lugarRecuperado = { id: 'lugar-recuperado', nombre: sinRepetir(nombresLugar, 'Lugar recuperado', 'El lugar'), tipo: 'otro', plano: null };
        limpio.lugares.push(lugarRecuperado);
        lugarPorId.set(lugarRecuperado.id, lugarRecuperado);
      }
      return lugarRecuperado;
    }

    // --- Artículos en bruto (se necesitan para saber qué mueble tiene más cosas) ---
    const articulosCrudos = registros('articulos', 'artículos');
    const piezasCrudas = new Map();
    articulosCrudos.forEach((a) => {
      const estados = esObjeto(a.estados) ? a.estados : {};
      const total = ['bueno', 'reparacion', 'danado'].reduce((s, k) => s + (Number.isInteger(estados[k]) && estados[k] > 0 ? estados[k] : 0), 0);
      if (a.muebleId) piezasCrudas.set(a.muebleId, (piezasCrudas.get(a.muebleId) || 0) + total);
    });

    // --- Muebles ---
    const nombresMueblePorLugar = new Map();
    const crudosMuebles = registros('muebles', 'muebles');
    crudosMuebles.forEach((m, posicion) => {
      m.posicionOriginal = posicion;
    });
    const muebles = crudosMuebles.map((m) => {
      let lugar = lugarPorId.get(m.lugarId);
      const nombreBase = textoObligatorio(m.nombre, LIMITES.nombre, 'Mueble', 'Un mueble');
      if (!lugar) {
        lugar = recuperarLugar();
        anotar('El mueble «' + nombreBase + '» no tenía un lugar válido: pasa a «' + lugar.nombre + '» (sin colocar).');
        m.x = null;
        m.y = null;
      }
      if (!nombresMueblePorLugar.has(lugar.id)) nombresMueblePorLugar.set(lugar.id, new Set());
      const nombre = sinRepetir(nombresMueblePorLugar.get(lugar.id), nombreBase, 'El mueble');
      let tipo = m.tipo;
      if (!TIPOS_MUEBLE[tipo]) {
        anotar('El mueble «' + nombre + '» era de un tipo desconocido: se muestra como «Caja».');
        tipo = 'caja';
      }
      let ancho = m.ancho;
      let fondo = m.fondo;
      const medidaBien = (v) => Number.isInteger(v) && v >= 1 && v <= LIMITES.ladoMaximo;
      if (!medidaBien(ancho) || !medidaBien(fondo)) {
        anotar('El mueble «' + nombre + '» tenía medidas no válidas: toma las de su tipo.');
        ancho = TIPOS_MUEBLE[tipo].ancho;
        fondo = TIPOS_MUEBLE[tipo].fondo;
      }
      let x = m.x;
      let y = m.y;
      if (!(Number.isInteger(x) && Number.isInteger(y))) {
        if (x != null || y != null) anotar('El mueble «' + nombre + '» tenía una casilla no válida: queda sin colocar.');
        x = null;
        y = null;
      }
      const giro = [0, 1, 2, 3].includes(m.giro) ? m.giro : inferirGiro({ tipo: tipo, ancho: ancho, fondo: fondo });
      return { id: m.id, lugarId: lugar.id, tipo: tipo, nombre: nombre, x: x, y: y, ancho: ancho, fondo: fondo, giro: giro,
        orden: m.posicionOriginal };
    });
    // En cada lugar CON plano: los muebles colocados deben caber y no encimarse.
    // El que tiene más artículos conserva su casilla; los demás se mueven a una libre o quedan sin colocar.
    limpio.lugares.forEach((lugar) => {
      if (!lugar.plano) return;
      const colocados = [];
      muebles.filter((m) => m.lugarId === lugar.id && estaColocado(m))
        .sort((a, b) => ((piezasCrudas.get(b.id) || 0) - (piezasCrudas.get(a.id) || 0)) || (a.orden - b.orden))
        .forEach((m) => {
          if (cabe(m, lugar.plano, colocados)) {
            colocados.push(m);
            return;
          }
          const libre = primerLugarLibre(m, lugar.plano, colocados);
          if (libre) {
            anotar('«' + m.nombre + '» estaba encimado o fuera del plano de «' + lugar.nombre + '»: se mueve a una casilla libre.');
            m.x = libre.x;
            m.y = libre.y;
            colocados.push(m);
          } else {
            anotar('«' + m.nombre + '» estaba encimado o fuera del plano de «' + lugar.nombre + '» y no hay casilla libre: queda sin colocar.');
            m.x = null;
            m.y = null;
          }
        });
    });
    muebles.forEach((m) => {
      delete m.orden;
      limpio.muebles.push(m);
    });
    const mueblePorId = new Map(limpio.muebles.map((m) => [m.id, m]));

    // --- Artículos ---
    const nombresPorSitio = new Map();
    const articuloPorId = new Map();
    articulosCrudos.forEach((a) => {
      const nombreBase = textoObligatorio(a.nombre, LIMITES.nombre, '(sin nombre)', 'Un artículo');
      // Ubicación única
      let muebleId = a.muebleId || null;
      let lugarId = a.lugarId || null;
      if (muebleId && !mueblePorId.has(muebleId)) {
        muebleId = null;
        if (lugarId && lugarPorId.has(lugarId)) anotar('«' + nombreBase + '»: su mueble no existe; queda directo en su lugar.');
        else {
          lugarId = null;
          anotar('«' + nombreBase + '»: su mueble no existe; pasa a «Sin ubicación».');
        }
      }
      if (muebleId && lugarId) {
        anotar('«' + nombreBase + '» tenía dos ubicaciones: se conserva la del mueble.');
        lugarId = null;
      }
      if (lugarId && !lugarPorId.has(lugarId)) {
        anotar('«' + nombreBase + '»: su lugar no existe; pasa a «Sin ubicación».');
        lugarId = null;
      }
      // Categoría
      let categoriaId = a.categoriaId;
      if (!categoriaPorId.has(categoriaId)) {
        if (categoriaId) anotar('«' + nombreBase + '»: su categoría no existe; pasa a «Otros».');
        categoriaId = ID_OTROS;
      }
      // Existencias por estado
      const estadosCrudos = esObjeto(a.estados) ? a.estados : {};
      const estados = {};
      CLAVES_ESTADO.forEach((clave) => {
        const valor = estadosCrudos[clave];
        if (Number.isInteger(valor) && valor >= 0 && valor <= LIMITES.cantidad) estados[clave] = valor;
        else {
          estados[clave] = valor == null ? 0 : Math.max(0, Math.min(LIMITES.cantidad, Math.floor(Number(valor)) || 0));
          if (valor != null) anotar('«' + nombreBase + '»: la cantidad en «' + nombreEstado(clave) + '» no era válida; queda en ' + estados[clave] + '.');
        }
      });
      const sitio = muebleId ? 'm:' + muebleId : lugarId ? 'l:' + lugarId : 'sin';
      if (!nombresPorSitio.has(sitio)) nombresPorSitio.set(sitio, new Set());
      const nombre = sinRepetir(nombresPorSitio.get(sitio), nombreBase, 'El artículo');
      const articulo = {
        id: a.id, nombre: nombre, categoriaId: categoriaId,
        codigo: textoOpcional(a.codigo, LIMITES.codigo, '«' + nombre + '» (N.º de inventario)'),
        notas: textoOpcional(a.notas, LIMITES.notas, '«' + nombre + '» (notas)'),
        muebleId: muebleId, lugarId: lugarId, estados: estados, seguimiento: 'cantidad'
      };
      if (Array.isArray(a.series)) {
        const series = limpiarSeries(a.series).slice(0, LIMITES.cantidad);
        if (series.length) articulo.series = series;
      }
      limpio.articulos.push(articulo);
      articuloPorId.set(articulo.id, articulo);
    });

    // --- Préstamos ---
    const recuperados = new Map();
    registros('prestamos', 'préstamos').forEach((p) => {
      const persona = textoObligatorio(p.persona, LIMITES.persona, '(sin nombre)', 'Un préstamo con la persona');
      let cantidad = p.cantidad;
      if (!Number.isInteger(cantidad) || cantidad < 1 || cantidad > LIMITES.cantidad) {
        anotar('Un préstamo a ' + persona + ' tenía una cantidad no válida: queda en 1.');
        cantidad = 1;
      }
      let fechaSalida = leerFechaISO(p.fechaSalida) ? p.fechaSalida : null;
      let fechaLimite = leerFechaISO(p.fechaLimite) ? p.fechaLimite : null;
      if (!fechaSalida || !fechaLimite) {
        fechaSalida = fechaSalida || fechaLimite || hoyISO;
        fechaLimite = fechaLimite || fechaSalida;
        anotar('Un préstamo a ' + persona + ' tenía fechas no válidas: se usan ' + fechaSalida + ' y ' + fechaLimite + '.');
      }
      let devuelto = p.devuelto == null || p.devuelto === '' ? null : p.devuelto;
      if (devuelto && !leerFechaISO(devuelto)) {
        anotar('Un préstamo a ' + persona + ' tenía una fecha de devolución no válida: se toma la fecha límite.');
        devuelto = fechaLimite;
      }
      const articuloNombre = textoObligatorio(p.articuloNombre || (articuloPorId.get(p.articuloId) || {}).nombre,
        LIMITES.nombre, 'Artículo', 'Un préstamo de artículo');
      let articuloId = typeof p.articuloId === 'string' ? p.articuloId : '';
      if (!articuloPorId.has(articuloId) && !devuelto) {
        // Préstamo activo de algo que ya no existe: se recrea el artículo para no perder el préstamo
        if (!recuperados.has(articuloId)) {
          const nuevo = {
            id: 'rec-articulo-' + (articuloId || p.id), nombre: articuloNombre.slice(0, LIMITES.nombre - 13) + ' (recuperado)',
            categoriaId: ID_OTROS, codigo: '', notas: 'Recreado al revisar los datos: tenía un préstamo activo.',
            muebleId: null, lugarId: null, estados: { bueno: 0, reparacion: 0, danado: 0 }, seguimiento: 'cantidad'
          };
          limpio.articulos.push(nuevo);
          articuloPorId.set(nuevo.id, nuevo);
          recuperados.set(articuloId, nuevo);
          anotar('Había un préstamo activo de «' + articuloNombre + '», que ya no existía: se recrea como «' + nuevo.nombre + '» en «Sin ubicación».');
        }
        articuloId = recuperados.get(articuloId).id;
      }
      let danadas = Number.isInteger(p.devueltasDanadas) && p.devueltasDanadas >= 0 && p.devueltasDanadas <= cantidad ? p.devueltasDanadas : 0;
      if (!devuelto) danadas = 0;
      limpio.prestamos.push({
        id: p.id, articuloId: articuloId, articuloNombre: articuloNombre,
        origen: textoOpcional(p.origen, LIMITES.nombre * 2 + 3, 'Un préstamo (origen)'),
        persona: persona, grupo: textoOpcional(p.grupo, LIMITES.grupo, 'Un préstamo (grupo)'), cantidad: cantidad,
        fechaSalida: fechaSalida, fechaLimite: fechaLimite, devuelto: devuelto, devueltasDanadas: danadas,
        nota: textoOpcional(p.nota, LIMITES.notas, 'Un préstamo (nota)')
      });
    });
    // Regla de oro: lo prestado no puede superar lo que hay en buen estado
    const prestadoPor = new Map();
    limpio.prestamos.filter((p) => !p.devuelto).forEach((p) => prestadoPor.set(p.articuloId, (prestadoPor.get(p.articuloId) || 0) + p.cantidad));
    prestadoPor.forEach((prestado, articuloId) => {
      const articulo = articuloPorId.get(articuloId);
      if (!articulo || prestado <= articulo.estados.bueno) return;
      const antes = articulo.estados.bueno;
      const total = totalDe(articulo) - antes + prestado;
      if (total > LIMITES.cantidad) return; // imposible en la práctica; verificarReglas lo reportaría
      articulo.estados.bueno = prestado;
      ajustes.piezasAgregadas += prestado - antes;
      if (!recuperados.has(articuloId) && !Array.from(recuperados.values()).some((r) => r.id === articuloId)) {
        anotar('«' + articulo.nombre + '» tiene ' + prestado + ' prestadas pero solo ' + antes + ' en buen estado: «Buen estado» sube a ' +
          prestado + ' (revisa la cantidad real).', { cantidad: true });
      }
    });

    // --- Historial ---
    registros('movimientos', 'historial').forEach((m) => {
      if (typeof m.momento !== 'string' || typeof m.tipo !== 'string') {
        anotar('Se quitará un registro del historial incompleto (sin fecha o sin tipo).', { quita: true });
        return;
      }
      limpio.movimientos.push({
        id: m.id, momento: m.momento, operacionId: typeof m.operacionId === 'string' ? m.operacionId : m.id, tipo: m.tipo,
        entidad: typeof m.entidad === 'string' ? m.entidad : '', entidadId: typeof m.entidadId === 'string' ? m.entidadId : '',
        nombre: limpiarTexto(m.nombre).slice(0, 80), antes: m.antes == null ? null : m.antes, despues: m.despues == null ? null : m.despues,
        detalle: m.detalle == null ? null : m.detalle, autor: m.autor == null ? null : m.autor
      });
    });

    return {
      ok: true,
      datos: limpio,
      hallazgos: hallazgos,
      descartados: hallazgos.map((h) => h.texto), // nombre anterior, para compatibilidad
      ajustes: ajustes,
      formatoOriginal: objeto.formato
    };
  }

  // Compatibilidad: la app y las pruebas de la Etapa 0 llamaban validarRespaldo
  function validarRespaldo(objeto, opciones) {
    return prepararDatos(objeto, opciones);
  }

  // Todas las reglas del modelo. Devuelve la lista de problemas (vacía si todo está bien).
  // Se usa como comprobación final de la migración y en las pruebas.
  function verificarReglas(datos) {
    const problemas = [];
    TABLAS.forEach((tabla) => {
      const ids = new Set();
      (datos[tabla] || []).forEach((r) => {
        if (ids.has(r.id)) problemas.push('Id repetido en ' + tabla + ': ' + r.id);
        ids.add(r.id);
      });
    });
    const lugares = new Map(datos.lugares.map((l) => [l.id, l]));
    const muebles = new Map(datos.muebles.map((m) => [m.id, m]));
    const articulos = new Map(datos.articulos.map((a) => [a.id, a]));
    const categorias = new Map(datos.categorias.map((c) => [c.id, c]));
    if (!categorias.has(ID_OTROS)) problemas.push('Falta la categoría «Otros».');
    datos.lugares.forEach((l) => {
      if (!TIPOS_LUGAR[l.tipo]) problemas.push('Lugar con tipo inválido: ' + l.id);
      if (l.plano !== null && !planoValido(l.plano)) problemas.push('Lugar con plano inválido: ' + l.id);
    });
    datos.lugares.filter((l) => l.plano).forEach((l) => {
      const colocados = [];
      datos.muebles.filter((m) => m.lugarId === l.id && estaColocado(m)).forEach((m) => {
        if (!cabe(m, l.plano, colocados)) problemas.push('Mueble encimado o fuera del plano: ' + m.id);
        colocados.push(m);
      });
    });
    datos.muebles.forEach((m) => {
      if (!lugares.has(m.lugarId)) problemas.push('Mueble sin lugar: ' + m.id);
      if (!TIPOS_MUEBLE[m.tipo]) problemas.push('Mueble de tipo inválido: ' + m.id);
      if (![0, 1, 2, 3].includes(m.giro)) problemas.push('Mueble sin giro válido: ' + m.id);
    });
    const prestado = new Map();
    datos.prestamos.filter((p) => !p.devuelto).forEach((p) => {
      if (!articulos.has(p.articuloId)) problemas.push('Préstamo activo de un artículo que no existe: ' + p.id);
      prestado.set(p.articuloId, (prestado.get(p.articuloId) || 0) + p.cantidad);
    });
    datos.articulos.forEach((a) => {
      if (a.muebleId && a.lugarId) problemas.push('Artículo con dos ubicaciones: ' + a.id);
      if (a.muebleId && !muebles.has(a.muebleId)) problemas.push('Artículo en un mueble que no existe: ' + a.id);
      if (a.lugarId && !lugares.has(a.lugarId)) problemas.push('Artículo en un lugar que no existe: ' + a.id);
      if (!categorias.has(a.categoriaId)) problemas.push('Artículo con categoría inexistente: ' + a.id);
      if (!esObjeto(a.estados) || !CLAVES_ESTADO.every((k) => Number.isInteger(a.estados[k]) && a.estados[k] >= 0)) {
        problemas.push('Artículo con existencias inválidas: ' + a.id);
      } else if ((prestado.get(a.id) || 0) > a.estados.bueno) {
        problemas.push('Artículo con más prestadas que en buen estado: ' + a.id);
      }
      if (totalDe(a) > LIMITES.cantidad) problemas.push('Artículo con más de ' + LIMITES.cantidad + ' piezas: ' + a.id);
    });
    return problemas;
  }

  // Revisa los datos que ya están guardados con las mismas reglas.
  // Devuelve { datos: los datos ya corregidos, problemas: [textos] }. No cambia nada por sí sola.
  function revisarIntegridad(datos, opciones) {
    const revision = prepararDatos(crearRespaldo(datos, 'revision'), opciones);
    return { datos: revision.datos, problemas: revision.hallazgos.map((h) => h.texto), hallazgos: revision.hallazgos };
  }

  // Primera casilla (de atrás hacia adelante) donde cabe el mueble sin encimarse
  function primerLugarLibre(mueble, sala, colocados) {
    for (let y = 0; y + mueble.fondo <= sala.fondo; y++) {
      for (let x = 0; x + mueble.ancho <= sala.ancho; x++) {
        const lugar = { x: x, y: y, ancho: mueble.ancho, fondo: mueble.fondo };
        if (cabe(lugar, sala, colocados)) return lugar;
      }
    }
    return null;
  }

  // =====================================================================
  // 10. MIGRACIÓN DE LA BASE DE DATOS A LA VERSIÓN 3
  // =====================================================================
  // crudos: lo leído de la base vieja { espacios, muebles, equipo, prestamos }.
  // Devuelve el plan: los datos nuevos ya revisados, los hallazgos (que la persona debe aprobar
  // ANTES de migrar si hay alguno), la contabilidad de antes y después, y una "huella" para
  // confirmar que lo que se aplica es exactamente lo que se aprobó.
  function planDeMigracion(crudos, version, opciones) {
    const original = { app: 'ubica', formato: 1 };
    TABLAS_ANTIGUAS.forEach((tabla) => {
      original[tabla] = Array.isArray(crudos[tabla]) ? crudos[tabla] : [];
    });
    const preparado = prepararDatos(original, opciones);
    const datos = preparado.datos;
    const piezasViejas = original.equipo.reduce((suma, q) => suma + (Number.isInteger(q.cantidad) && q.cantidad > 0 ? q.cantidad : 0), 0);
    const prestadasViejas = original.prestamos.filter((p) => esObjeto(p) && !p.devuelto)
      .reduce((suma, p) => suma + (Number.isInteger(p.cantidad) ? p.cantidad : 0), 0);
    const antes = {
      lugares: original.espacios.length, muebles: original.muebles.length, articulos: original.equipo.length,
      prestamos: original.prestamos.length, piezas: piezasViejas, prestadas: prestadasViejas
    };
    const recreados = datos.articulos.filter((a) => a.id.startsWith('rec-articulo-')).length;
    const despues = {
      lugares: datos.lugares.length, muebles: datos.muebles.length, articulos: datos.articulos.length,
      prestamos: datos.prestamos.length, piezas: datos.articulos.reduce((s, a) => s + totalDe(a), 0),
      prestadas: datos.prestamos.filter((p) => !p.devuelto).reduce((s, p) => s + p.cantidad, 0)
    };
    // Comprobación: ningún registro se pierde. Solo pueden faltar los que prepararDatos anotó como
    // quitados (repetidos idénticos o datos que no son registros), y solo pueden sobrar los recuperados.
    const quitados = preparado.hallazgos.filter((h) => h.quita).length;
    const idsNuevos = new Set();
    TABLAS.forEach((tabla) => datos[tabla].forEach((r) => idsNuevos.add(tabla + ':' + r.id)));
    const perdidos = [];
    [['espacios', 'lugares'], ['muebles', 'muebles'], ['equipo', 'articulos'], ['prestamos', 'prestamos']].forEach(([vieja, nueva]) => {
      original[vieja].forEach((r) => {
        if (esObjeto(r) && typeof r.id === 'string' && !idsNuevos.has(nueva + ':' + r.id)) perdidos.push(vieja + ':' + r.id);
      });
    });
    const problemas = verificarReglas(datos);
    const cuadra = antes.piezas + preparado.ajustes.piezasAgregadas === despues.piezas;
    const comprobacion = {
      ok: perdidos.length <= quitados && problemas.length === 0 && cuadra &&
        despues.prestamos + quitados >= antes.prestamos && despues.articulos - recreados + quitados >= antes.articulos,
      perdidos: perdidos, problemas: problemas, piezasCuadran: cuadra
    };
    return {
      version: version, datos: datos, hallazgos: preparado.hallazgos, antes: antes, despues: despues,
      ajustes: preparado.ajustes, comprobacion: comprobacion,
      huella: huellaDe(datos) + '|' + preparado.hallazgos.map((h) => h.texto).join('|')
    };
  }

  // =====================================================================
  // 11. COPIAS DE SEGURIDAD, CSV Y EJEMPLO
  // =====================================================================
  // Una copia es una "foto" del inventario guardada dentro de la misma base de datos.
  // Protege de errores de uso (restaurar el archivo equivocado, borrar de más). NO protege si
  // se desinstala la app o se pierde el celular: para eso está el respaldo en archivo.
  const MAXIMO_COPIAS = 6;
  const MOTIVOS_COPIA = {
    diaria: 'Copia automática del día',
    'antes-de-restaurar': 'Antes de restaurar un respaldo',
    'antes-de-recuperar': 'Antes de recuperar otra copia',
    'antes-de-reparar': 'Antes de reparar los datos',
    'antes-de-migrar': 'Antes de actualizar los datos a la versión 3'
  };

  function estaVacio(datos) {
    return ['lugares', 'muebles', 'articulos', 'prestamos'].every((tabla) => !(datos[tabla] || []).length);
  }

  // Texto que permite saber si dos inventarios son iguales, sin importar el orden de los registros
  function huellaDe(datos) {
    return JSON.stringify(TABLAS.filter((tabla) => tabla !== 'movimientos').map((tabla) =>
      (datos[tabla] || []).map((registro) => JSON.stringify(registro, Object.keys(registro).sort())).sort()
    ));
  }

  function resumenCopia(datos) {
    return {
      lugares: datos.lugares.length,
      muebles: datos.muebles.length,
      piezas: datos.articulos.reduce((suma, articulo) => suma + totalDe(articulo), 0),
      prestamos: datos.prestamos.length
    };
  }

  // momentoISO: fecha y hora completas, por ejemplo '2026-11-10T09:30:00.000Z'
  function crearCopia(datos, motivo, momentoISO, diaISO) {
    return {
      id: 'copia-' + momentoISO + '-' + Math.random().toString(36).slice(2, 6),
      momento: momentoISO,
      dia: diaISO,
      motivo: motivo,
      resumen: resumenCopia(datos),
      datos: crearRespaldo(datos, momentoISO)
    };
  }

  // ¿Toca hacer la copia automática de hoy? Solo si hay datos, hoy no se ha hecho y algo
  // cambió desde la copia más reciente (no se llenan las 6 copias con lo mismo).
  function tocaCopiaDiaria(copias, datos, diaISO) {
    if (estaVacio(datos)) return false;
    if (copias.some((copia) => copia.motivo === 'diaria' && copia.dia === diaISO)) return false;
    const reciente = copiasOrdenadas(copias)[0];
    if (!reciente) return true;
    return huellaDe(reciente.datos) !== huellaDe(datos);
  }

  // La más nueva primero
  function copiasOrdenadas(copias) {
    return copias.slice().sort((a, b) => (a.momento < b.momento ? 1 : a.momento > b.momento ? -1 : 0));
  }

  // Ids de las copias más viejas que hay que borrar para que, al agregar una, no pasen del máximo
  function copiasQueSobran(copias, cuantasNuevas) {
    const permitidas = MAXIMO_COPIAS - (cuantasNuevas || 0);
    return copiasOrdenadas(copias).slice(Math.max(0, permitidas)).map((copia) => copia.id);
  }

  // Un campo de CSV. Si empieza con = + - @ se le antepone ' para que Excel no lo
  // ejecute como fórmula (es un ataque conocido: "inyección de CSV").
  function campoCSV(valor) {
    let texto = valor == null ? '' : String(valor);
    if (/^[=+\-@\t\r]/.test(texto)) texto = "'" + texto;
    return /[",\n\r]/.test(texto) ? '"' + texto.replace(/"/g, '""') + '"' : texto;
  }

  // Todo el inventario en una tabla que Excel abre directo (con BOM para los acentos).
  // Incluye los artículos directo en un lugar y los que no tienen ubicación.
  function inventarioCSV(datos) {
    const filas = [['Lugar', 'Tipo de lugar', 'Mueble', 'Tipo de mueble', 'Artículo', 'Categoría', 'N.º de inventario',
      'Total', 'Buen estado', 'En reparación', 'Dañado', 'Prestadas', 'Disponibles', 'Notas']];
    const fila = (lugar, mueble, articulo) => {
      filas.push([
        lugar ? lugar.nombre : 'Sin ubicación', lugar ? TIPOS_LUGAR[lugar.tipo].nombre : '',
        mueble ? mueble.nombre : '', mueble ? TIPOS_MUEBLE[mueble.tipo].nombre : '',
        articulo.nombre, categoriaDe(datos, articulo).nombre, articulo.codigo, totalDe(articulo),
        articulo.estados.bueno, articulo.estados.reparacion, articulo.estados.danado,
        prestadas(datos, articulo.id), disponibles(datos, articulo), articulo.notas
      ]);
    };
    datos.lugares.forEach((lugar) => {
      mueblesDe(datos, lugar.id).forEach((mueble) => articulosDe(datos, mueble.id).forEach((a) => fila(lugar, mueble, a)));
      articulosEnLugar(datos, lugar.id).forEach((a) => fila(lugar, null, a));
    });
    articulosSinUbicacion(datos).forEach((a) => fila(null, null, a));
    return '﻿' + filas.map((f) => f.map(campoCSV).join(',')).join('\r\n') + '\r\n';
  }

  // Un laboratorio y una bodega con plano, una dirección sin plano y artículos de todo tipo
  // (en muebles, directo en un lugar y sin ubicación), con dos préstamos (uno vencido).
  function datosDeEjemplo(hoyISO) {
    const datos = datosVacios();
    datos.categorias = categoriasIniciales();
    const lugar = (id, nombre, tipo, ancho, fondo) =>
      datos.lugares.push({ id: id, nombre: nombre, tipo: tipo, plano: ancho ? { ancho: ancho, fondo: fondo } : null });
    const mueble = (id, lugarId, tipo, nombre, x, y) => datos.muebles.push({
      id: id, lugarId: lugarId, tipo: tipo, nombre: nombre, x: x, y: y,
      ancho: TIPOS_MUEBLE[tipo].ancho, fondo: TIPOS_MUEBLE[tipo].fondo, giro: 0
    });
    const articulo = (id, sitio, nombre, cantidad, categoria, codigo, estados) => datos.articulos.push(Object.assign({
      id: id, nombre: nombre, categoriaId: 'cat-' + categoria, codigo: codigo || '', notas: '',
      muebleId: sitio.startsWith('mue') ? sitio : null, lugarId: sitio.startsWith('lug') || sitio.startsWith('esp') ? sitio : null,
      estados: Object.assign({ bueno: cantidad, reparacion: 0, danado: 0 }, estados || {}), seguimiento: 'cantidad'
    }, sitio === 'sin' ? { muebleId: null, lugarId: null } : {}));

    lugar('esp-ejemplo-lab', 'Laboratorio de Química', 'laboratorio', 8, 6);
    mueble('mue-ej-1', 'esp-ejemplo-lab', 'estante', 'Estante A', 0, 0);
    mueble('mue-ej-2', 'esp-ejemplo-lab', 'estante', 'Estante B', 1, 0);
    mueble('mue-ej-3', 'esp-ejemplo-lab', 'vitrina', 'Vitrina de reactivos', 4, 0);
    mueble('mue-ej-4', 'esp-ejemplo-lab', 'mesa', 'Mesa 1', 2, 3);
    mueble('mue-ej-5', 'esp-ejemplo-lab', 'mesa', 'Mesa 2', 5, 3);
    mueble('mue-ej-6', 'esp-ejemplo-lab', 'banco', 'Banco 1', 2, 4);
    mueble('mue-ej-7', 'esp-ejemplo-lab', 'banco', 'Banco 2', 3, 4);
    mueble('mue-ej-8', 'esp-ejemplo-lab', 'gabinete', 'Gabinete de seguridad', 0, 4);
    mueble('mue-ej-9', 'esp-ejemplo-lab', 'escritorio', 'Escritorio del profesor', 6, 5);
    articulo('eq-ej-1', 'mue-ej-1', 'Microscopio', 4, 'laboratorio', 'LAB-001', { reparacion: 1 });
    articulo('eq-ej-2', 'mue-ej-1', 'Portaobjetos', 40, 'consumibles');
    articulo('eq-ej-3', 'mue-ej-2', 'Multímetro', 3, 'laboratorio', 'LAB-014');
    articulo('eq-ej-4', 'mue-ej-3', 'Matraz Erlenmeyer', 12, 'laboratorio');
    articulo('eq-ej-5', 'mue-ej-3', 'Probeta 100 ml', 7, 'laboratorio', '', { danado: 1 });
    articulo('eq-ej-6', 'mue-ej-8', 'Lentes de seguridad', 20, 'seguridad');
    articulo('eq-ej-7', 'mue-ej-8', 'Bata', 15, 'seguridad');
    articulo('eq-ej-8', 'mue-ej-9', 'Proyector', 1, 'audiovisual', 'LAB-020');
    articulo('eq-ej-13', 'esp-ejemplo-lab', 'Extintor', 1, 'seguridad', 'SEG-002');

    lugar('esp-ejemplo-bod', 'Bodega', 'bodega', 6, 4);
    mueble('mue-ej-10', 'esp-ejemplo-bod', 'estante', 'Anaquel 1', 0, 0);
    mueble('mue-ej-11', 'esp-ejemplo-bod', 'estante', 'Anaquel 2', 1, 0);
    mueble('mue-ej-12', 'esp-ejemplo-bod', 'caja', 'Caja de cables', 4, 2);
    mueble('mue-ej-13', 'esp-ejemplo-bod', 'casillero', 'Casillero de deportes', 5, 0);
    articulo('eq-ej-9', 'mue-ej-10', 'Extensión eléctrica', 6, 'herramientas');
    articulo('eq-ej-10', 'mue-ej-11', 'Bocina portátil', 2, 'audiovisual', 'BOD-003');
    articulo('eq-ej-11', 'mue-ej-12', 'Cable HDMI', 10, 'computo');
    articulo('eq-ej-12', 'mue-ej-13', 'Balón de básquetbol', 8, 'deportes');

    lugar('lug-ejemplo-dir', 'Dirección', 'oficina', null, null);
    articulo('eq-ej-14', 'lug-ejemplo-dir', 'Engrapadora', 2, 'papeleria');
    articulo('eq-ej-16', 'lug-ejemplo-dir', 'Laptop', 3, 'computo', 'DIR-010', { reparacion: 1 });
    articulo('eq-ej-17', 'lug-ejemplo-dir', 'Hojas blancas (paquete)', 12, 'papeleria');
    articulo('eq-ej-15', 'sin', 'Cámara fotográfica', 1, 'audiovisual', 'AV-007');
    articulo('eq-ej-18', 'sin', 'Guantes de nitrilo (caja)', 6, 'consumibles');

    // Almacén general: el lugar grande, pensado para verse en 3D
    datos.lugares.unshift({ id: 'lug-ejemplo-alm', nombre: 'Almacén general', tipo: 'bodega', plano: { ancho: 12, fondo: 9 }, vista: '3d' });
    const girado = (id, lugarId, tipo, nombre, x, y) => {
      mueble(id, lugarId, tipo, nombre, x, y);
      const m = datos.muebles[datos.muebles.length - 1];
      Object.assign(m, { ancho: TIPOS_MUEBLE[tipo].fondo, fondo: TIPOS_MUEBLE[tipo].ancho, giro: 1 });
    };
    ['A', 'B', 'C', 'D', 'E', 'F'].forEach((letra, i) => mueble('mue-alm-a' + i, 'lug-ejemplo-alm', 'estante', 'Rack ' + letra, 1 + i, 0));
    ['G', 'H', 'I', 'J'].forEach((letra, i) => mueble('mue-alm-b' + i, 'lug-ejemplo-alm', 'estante', 'Rack ' + letra, 2 + i, 3));
    mueble('mue-alm-gab1', 'lug-ejemplo-alm', 'gabinete', 'Gabinete de herramientas', 9, 0);
    mueble('mue-alm-gab2', 'lug-ejemplo-alm', 'gabinete', 'Gabinete de limpieza', 10, 0);
    mueble('mue-alm-cas', 'lug-ejemplo-alm', 'casillero', 'Casilleros', 11, 3);
    mueble('mue-alm-vit', 'lug-ejemplo-alm', 'vitrina', 'Vitrina de audiovisual', 8, 3);
    girado('mue-alm-mesa', 'lug-ejemplo-alm', 'mesa', 'Mesa de recepción', 0, 5);
    mueble('mue-alm-esc', 'lug-ejemplo-alm', 'escritorio', 'Escritorio de control', 2, 7);
    mueble('mue-alm-ban', 'lug-ejemplo-alm', 'banco', 'Banco', 3, 8);
    mueble('mue-alm-c1', 'lug-ejemplo-alm', 'caja', 'Caja de refacciones', 7, 6);
    mueble('mue-alm-c2', 'lug-ejemplo-alm', 'caja', 'Caja de cables', 8, 6);
    mueble('mue-alm-c3', 'lug-ejemplo-alm', 'caja', 'Caja de papelería', 7, 7);
    articulo('art-alm-1', 'mue-alm-a0', 'Taladro', 4, 'herramientas', 'ALM-001', { reparacion: 1 });
    articulo('art-alm-2', 'mue-alm-a0', 'Juego de desarmadores', 8, 'herramientas');
    articulo('art-alm-3', 'mue-alm-a1', 'Proyector portátil', 3, 'audiovisual', 'ALM-014', { danado: 1 });
    articulo('art-alm-4', 'mue-alm-a2', 'Teclado USB', 15, 'computo');
    articulo('art-alm-5', 'mue-alm-a2', 'Mouse', 18, 'computo');
    articulo('art-alm-6', 'mue-alm-a3', 'Monitor 22 pulgadas', 6, 'computo', 'ALM-030');
    articulo('art-alm-7', 'mue-alm-a4', 'Balón de fútbol', 10, 'deportes');
    articulo('art-alm-8', 'mue-alm-a5', 'Conos de entrenamiento', 30, 'deportes');
    articulo('art-alm-9', 'mue-alm-b0', 'Resma de papel', 40, 'papeleria');
    articulo('art-alm-10', 'mue-alm-b1', 'Marcadores para pizarrón', 60, 'papeleria');
    articulo('art-alm-11', 'mue-alm-b2', 'Tóner para impresora', 5, 'consumibles', 'ALM-052');
    articulo('art-alm-12', 'mue-alm-b3', 'Foco LED', 24, 'refacciones');
    articulo('art-alm-13', 'mue-alm-gab1', 'Martillo', 5, 'herramientas');
    articulo('art-alm-14', 'mue-alm-gab1', 'Multímetro digital', 3, 'herramientas', 'ALM-060');
    articulo('art-alm-15', 'mue-alm-gab2', 'Cloro (galón)', 8, 'limpieza');
    articulo('art-alm-16', 'mue-alm-gab2', 'Trapeador', 6, 'limpieza', '', { danado: 2 });
    articulo('art-alm-17', 'mue-alm-vit', 'Micrófono inalámbrico', 4, 'audiovisual', 'ALM-071');
    articulo('art-alm-18', 'mue-alm-vit', 'Bocina con tripié', 2, 'audiovisual', 'ALM-072');
    articulo('art-alm-19', 'mue-alm-cas', 'Chaleco de seguridad', 12, 'seguridad');
    articulo('art-alm-20', 'mue-alm-c1', 'Fusibles', 50, 'refacciones');
    articulo('art-alm-21', 'mue-alm-c2', 'Cable de red (5 m)', 20, 'computo');
    articulo('art-alm-22', 'lug-ejemplo-alm', 'Escalera de aluminio', 2, 'herramientas', 'ALM-090');
    articulo('art-alm-23', 'lug-ejemplo-alm', 'Diablito de carga', 1, 'herramientas');
    datos.articulos.find((a) => a.id === 'art-alm-1').series = ['TAL-2291', 'TAL-2292', 'TAL-2305', 'TAL-2310'];
    datos.articulos.find((a) => a.id === 'art-alm-6').series = ['MON-A11', 'MON-A12', 'MON-A13'];
    datos.lugares.find((l) => l.id === 'esp-ejemplo-lab').vista = '2.5d';

    datos.prestamos.push({
      id: 'pre-ej-3', articuloId: 'art-alm-3', articuloNombre: 'Proyector portátil', origen: 'Almacén general › Rack B',
      persona: 'Mtra. Rivera', grupo: '2.º A', cantidad: 1, fechaSalida: sumarDias(hoyISO, -1),
      fechaLimite: sumarDias(hoyISO, 2), devuelto: null, devueltasDanadas: 0, nota: 'Exposición de ciencias'
    });
    datos.prestamos.push({
      id: 'pre-ej-4', articuloId: 'art-alm-7', articuloNombre: 'Balón de fútbol', origen: 'Almacén general › Rack E',
      persona: 'Prof. Gómez', grupo: 'Deportes', cantidad: 4, fechaSalida: sumarDias(hoyISO, -6),
      fechaLimite: sumarDias(hoyISO, -1), devuelto: null, devueltasDanadas: 0, nota: 'Torneo interno'
    });
    datos.prestamos.push({
      id: 'pre-ej-5', articuloId: 'art-alm-1', articuloNombre: 'Taladro', origen: 'Almacén general › Rack A',
      persona: 'Mantenimiento', grupo: '', cantidad: 1, fechaSalida: sumarDias(hoyISO, -12),
      fechaLimite: sumarDias(hoyISO, -8), devuelto: sumarDias(hoyISO, -9), devueltasDanadas: 0, nota: ''
    });
    // El historial del ejemplo: el alta de cada artículo (registros reales, uno por artículo)
    datos.articulos.forEach((a, i) => {
      const momento = sumarDias(hoyISO, -20) + 'T' + dosDigitos(8 + (i % 9)) + ':' + dosDigitos((i * 7) % 60) + ':00.000Z';
      datos.movimientos.push({
        id: 'mov-ej-' + i, momento: momento, operacionId: 'mov-ej-' + i, tipo: 'alta', entidad: 'articulo', entidadId: a.id,
        nombre: a.nombre, antes: null, despues: clonar(a), detalle: null, autor: null
      });
    });

    datos.prestamos.push({
      id: 'pre-ej-1', articuloId: 'eq-ej-1', articuloNombre: 'Microscopio', origen: 'Laboratorio de Química › Estante A',
      persona: 'Ana López', grupo: '3.º B', cantidad: 2, fechaSalida: sumarDias(hoyISO, -3),
      fechaLimite: sumarDias(hoyISO, 4), devuelto: null, devueltasDanadas: 0, nota: 'Práctica de biología'
    });
    datos.prestamos.push({
      id: 'pre-ej-2', articuloId: 'eq-ej-10', articuloNombre: 'Bocina portátil', origen: 'Bodega › Anaquel 2',
      persona: 'Prof. Martínez', grupo: 'Dirección', cantidad: 1, fechaSalida: sumarDias(hoyISO, -9),
      fechaLimite: sumarDias(hoyISO, -2), devuelto: null, devueltasDanadas: 0, nota: ''
    });
    return datos;
  }

  const Nucleo = {
    LIMITES, TIPOS_LUGAR, TIPOS_MUEBLE, TABLAS, TABLA_COPIAS, TABLAS_ANTIGUAS, INDICES, PROPORCION, ALTO_PARED,
    ZOOM_MINIMO, ZOOM_MAXIMO, UMBRAL_TOQUE, ID_OTROS, CATEGORIAS_INICIALES, COLORES_CATEGORIA, ESTADOS, CLAVES_ESTADO,
    TIPOS_MOVIMIENTO, FORMATO_RESPALDO, MAXIMO_COPIAS, MOTIVOS_COPIA,
    normalizar, escaparHTML, nuevoId, fechaISO, leerFechaISO, sumarDias, diasEntre, fechaCorta, plural, clonar,
    proyectar, casillaEnPantalla, escalaParaSala, girarUnCuarto, girar, medidasVista, aVista, aMundo,
    rectAlTocar, seEnciman, estaColocado, cabe, estaDetras, ordenarDeAtrasHaciaAdelante, siluetaEnPantalla,
    mueblesQueTapan, altoDe,
    camaraInicial, limitarCamara, zoomEn, pantallaADibujo, crearGestos,
    datosVacios, categoriasIniciales, buscarPorId, mueblesDe, mueblesColocados, articulosDe, articulosEnLugar,
    articulosSinUbicacion, totalDe, piezasEnMueble, piezasEnLugar, prestamosActivosDe, prestadas, disponibles,
    ubicacion, textoUbicacion, categoriaDe, categoriasOrdenadas, articulosDeCategoria, movimientosDe, nombreEstado,
    estadoPrestamo, prestamosActivos, historialPrestamos, textoVencimiento, buscar, mueblesQueCoinciden, resumen,
    limpiarTexto, validarTexto, validarEntero, planoValido, validarLugar, validarDatosArticulo, validarPrestamo,
    aplicarCambios, invertirCambios, crearLugar, editarLugar, afectadosPorBorrarLugar, borrarLugar,
    colocarMueble, moverMueble, girarMueble, renombrarMueble, borrarMueble,
    crearArticulo, agregarArticulo, editarArticulo, agregarExistencias, cambiarEstado, darDeBaja, moverArticulo, borrarArticulo,
    prestar, devolver, crearCategoria, editarCategoria, borrarCategoria,
    conMovimientos, movimientoGeneral, textoMovimiento,
    crearRespaldo, convertirFormato1, inferirGiro, prepararDatos, validarRespaldo, verificarReglas, revisarIntegridad,
    primerLugarLibre, planDeMigracion,
    VISTAS_LUGAR, MEDIDA_MAXIMA_MUEBLE, consultarArticulos, movimientosRecientes, piezasMueble, medidasSinGiro,
    guardarSeries, redimensionarMueble, cambiarVistaLugar, vistaDeLugar,
    estaVacio, huellaDe, crearCopia, tocaCopiaDiaria, copiasOrdenadas, copiasQueSobran,
    campoCSV, inventarioCSV, datosDeEjemplo
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Nucleo;
  else raiz.Nucleo = Nucleo;
})(typeof window !== 'undefined' ? window : globalThis);
