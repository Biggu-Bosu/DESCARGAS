// Ubica · Novedades: qué cambió en cada versión. Se ven en el menú ⋯ → «Novedades».
// Cómo añadir cambios (en cada subida que se note al usar la app):
//   - Si ya hay una entrada con la fecha de hoy, suma el cambio a su lista.
//   - Si no, crea una entrada NUEVA ARRIBA DEL TODO con fecha 'AAAA-MM-DD'.
//   - Frases cortas pensadas para quien usa la app, no técnicas.
// Las entradas viejas no se borran: así queda el historial de todas las versiones.
window.NOVEDADES = [
  {
    fecha: '2026-11-13',
    cambios: [
      'Editor 3D: «Restablecer medidas» y «Restablecer giro» en Propiedades (el objeto se queda apoyado donde estaba).',
      'Si subes un objeto y luego lo mueves de lado, ya no regresa solo al piso.',
      'Dentro de un mueble, los objetos ya no atraviesan los costados ni el fondo; en gabinetes, tampoco la puerta. Por el frente abierto de un estante solo se avisa que sobresale.',
      'Tocar un objeto ya no abre Propiedades encima de la escena: ábrelo con su botón de la barra.',
      'Dentro de un mueble ya no aparece la etiqueta «×N» sobre los objetos.'
    ]
  },
  {
    fecha: '2026-11-13',
    cambios: [
      'Editor 3D de verdad: «Agregar» crea cajas, cilindros, tubos, esferas, conos, llantas, prismas y pirámides directo en el lugar o dentro de un mueble.',
      'Muévelos, gíralos y cámbiales las medidas con las flechas, aros y cubos de colores (rojo = ancho, verde = fondo, azul = alto), o escribe números exactos con decimales en «Propiedades».',
      'Duplicar, «Apilar encima», «Asentar», agrupar y guardar como modelo. Deshacer y Rehacer guardan varios pasos.',
      'Choques: no deja meter objetos en la pared, en un mueble o encima de otro objeto; te dice por qué en rojo. Si algo sobresale de una repisa o queda flotando, te avisa en amarillo.',
      '«Interior» en un estante o gabinete: acomoda lo que guarda por niveles. Si mueves el mueble, lo de adentro se va con él.',
      'Enlaza los objetos al inventario o regístralos como artículo: 4 llantas dibujadas = 4 piezas. La lista y el 2.5D muestran los mismos objetos.',
      'Laptop: Ctrl + clic para elegir varios; atajos G, R, S, A, I, Ctrl+D, Ctrl+G, Supr y Esc. En el celular, «Elegir toda la pila».'
    ]
  },
  {
    fecha: '2026-11-11',
    cambios: [
      'Lugares: cada lugar tiene al lado su botón para borrarlo. Antes de borrar te dice qué se afecta, y hay «Deshacer».',
      'En computadora, dentro de un lugar también hay «Borrar lugar» en la barra de arriba.'
    ]
  },
  {
    fecha: '2026-11-11',
    cambios: [
      '3D: los objetos de todos los muebles se ven siempre, sin tener que tocar el mueble.',
      '3D: al seleccionar un mueble ya no se vuelve transparente. Los gabinetes y casilleros abren sus puertas para mostrar lo que guardan.',
      'Las cajas ahora están abiertas por arriba y los gabinetes son huecos, para que su contenido se vea de verdad.'
    ]
  },
  {
    fecha: '2026-11-11',
    cambios: [
      'Al agregar un artículo estando dentro de un lugar, «¿Dónde va?» solo muestra los muebles de ese lugar.',
      'Ahí mismo puedes elegir «+ Mueble nuevo…»: se crean el mueble y el artículo juntos, y el mueble se acomoda solo en el plano.',
      'Acomodar automáticamente: convierte un lugar de lista en un plano 2.5D en un toque (crea el plano, coloca los muebles y guarda los artículos sueltos en estantes por categoría).',
      '«Acomodar todos» para los muebles que estén sin colocar.',
      'Mover artículos entre muebles es más fácil: en un mueble toca «Mover artículos a otro mueble», marca los que quieras y elige el destino.',
      '3D: los objetos ya quedan completamente dentro de su mueble (antes podían asomarse, por ejemplo en una caja de cartón).'
    ]
  },
  {
    fecha: '2026-11-11',
    cambios: [
      '3D: al seleccionar un mueble se vuelve transparente y muestra sus artículos como objetos acomodados en sus repisas. Toca un objeto para abrir su ficha.',
      'Cada artículo puede tener su «Forma en 3D»: caja, cilindro, esfera, prisma triangular o pirámide, con tamaño y color.',
      'Animaciones en 3D: los muebles aparecen, se deslizan al moverlos y giran suave; los objetos brincan al tocarlos.',
      'El inventario ahora se divide por ubicación: cada lugar es un grupo que abres y cierras. Al buscar se abren solos.',
      'Nueva Configuración (en «Más») con simplificaciones que puedes encender: menos texto, inventario compacto, sin estados, sin categorías, sin préstamos, sin opciones avanzadas y sin animaciones. No borran nada.',
      '«Ver la base de datos» ahora es en crudo: el esquema de IndexedDB como código y los registros en JSON, con botón para copiar.',
      'Después de «Deshacer» puedes «Rehacer» (también con Ctrl+Y).'
    ]
  },
  {
    fecha: '2026-11-11',
    cambios: [
      'Ubica estrena interfaz: cuatro secciones (Inventario, Lugares, Préstamos y Más), letra más clara y botones más cómodos.',
      'Inventario como tabla: busca por nombre, número de inventario o serie; filtra por estado, categoría y lugar; ordena por la columna que quieras.',
      'Cada lugar se puede ver de tres formas con los mismos datos: Lista, 2.5D y 3D. Cambias cuando quieras y la selección se conserva.',
      'Nueva vista 3D: muebles con forma reconocible, luz y sombras. Gira con un dedo, acerca con dos, y toca un mueble para ver qué guarda.',
      'En 2.5D y en 3D puedes arrastrar el mueble seleccionado para moverlo; lo que muevas en una vista aparece igual en la otra.',
      '«Localizar» en la ficha de un artículo te lleva a su lugar y resalta el mueble donde está.',
      'Los muebles ahora pueden cambiar de medidas (de 1 a 6 casillas) además de moverse y girar.',
      'Devoluciones parciales: regresa solo algunas piezas de un préstamo y marca cuántas llegaron dañadas.',
      'Números de serie opcionales por artículo, que también se pueden buscar.',
      'Historial general de movimientos en «Más».',
      'En computadora: menú a la izquierda, panel a la derecha que no tapa la lista ni el plano, y atajos de teclado (/ buscar, N nuevo, 1-2-3 vistas, flechas mover, R girar, Ctrl+Z deshacer).',
      'Modo presentación para proyector o pantalla grande: solo el lugar, a pantalla completa.',
      'Ejemplo nuevo con un almacén en 3D, un laboratorio en 2.5D, un lugar solo con lista, artículos sin ubicación y préstamos. En «Más» puedes vaciar todo y empezar de cero.',
      'Si tu dispositivo no puede mostrar 3D, Ubica te avisa y sigues usando la vista 2.5D.'
    ]
  },
  {
    fecha: '2026-11-10',
    cambios: [
      'Ubica ya sirve como inventario de listas: puedes agregar artículos sin crear lugares ni planos.',
      '«Espacios» ahora se llaman «Lugares», y el plano es opcional: un lugar puede ser solo un nombre.',
      'Un artículo puede estar dentro de un mueble, directo en un lugar o «Sin ubicación».',
      'Categorías (Laboratorio, Cómputo, Herramientas, Limpieza, Seguridad…) que puedes crear, cambiar y borrar sin perder artículos.',
      'Cada artículo cuenta sus piezas en buen estado, en reparación y dañadas. Solo se prestan las de buen estado.',
      'Al devolver un préstamo puedes marcar cuántas piezas regresaron dañadas.',
      'Entrada de piezas, cambio de estado y baja (con motivo) desde la ficha del artículo.',
      'Historial: cada artículo muestra sus altas, cambios, préstamos y devoluciones.',
      'Borrar un mueble ya no borra lo que guarda: pasa al lugar. Borrar un lugar dice antes qué se afecta y ofrece llevar todo a otro lugar.',
      'Quitar el plano de un lugar no borra sus muebles; si lo vuelves a crear, todo regresa a su casilla.',
      'Tus datos anteriores se actualizan solos (antes se guarda una copia). Si algo no cuadra, Ubica te lo muestra y te pregunta.',
      'Copias de seguridad automáticas: Ubica guarda sola hasta 6 copias (una al día si hubo cambios). Están en el menú ⋯.',
      'Restaurar un respaldo ya no es un salto al vacío: antes se guarda una copia de lo que había y puedes recuperarla.',
      'Corregido: tocar dos veces muy rápido podía crear dos muebles en la misma casilla o guardar dos veces el mismo equipo.',
      'Al abrir, Ubica revisa sus datos; si encuentra muebles encimados los separa sin borrar su equipo (y antes guarda una copia).',
      'Mucho más rápida con inventarios grandes: el plano, la búsqueda y la Lista (ahora se muestra por partes con «Mostrar más»).',
      'En la versión web, el botón o gesto Atrás cierra la ficha abierta en lugar de salir de la app.',
      'El plano se dibuja también en celulares con navegador antiguo.',
      'El menú dice cuándo fue tu último respaldo en archivo y te lo recuerda si pasan 14 días.',
      'En iPhone, aviso para añadir Ubica a la pantalla de inicio y no perder datos.'
    ]
  },
  {
    fecha: '2026-11-09',
    cambios: [
      'Primera versión de Ubica: el inventario que también dice dónde está cada cosa.',
      'Crea tus espacios (laboratorio, salón, bodega…) y míralos en vista isométrica.',
      'Coloca muebles con un toque y guarda en cada uno el equipo que tiene dentro.',
      'Zoom con dos dedos, mover la vista arrastrando y girar la sala.',
      'Los muebles que tapan al que buscas se vuelven transparentes.',
      'Préstamos: quién se llevó qué, cuándo regresa y avisos de vencidos.',
      'Vista de Lista con todo el inventario en texto (funciona con lector de pantalla).',
      'Respaldo para guardar o pasar tus datos, y lista para Excel.',
      'Base de datos IndexedDB en tu celular: funciona sin internet. Puedes ver sus tablas.'
    ]
  }
];
