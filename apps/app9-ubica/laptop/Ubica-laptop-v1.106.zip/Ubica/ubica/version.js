window.APP_VERSION = { numero: '1.106', fecha: '2026-11-13', commit: '77d616d' };
