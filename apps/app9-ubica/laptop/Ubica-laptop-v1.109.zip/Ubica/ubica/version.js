window.APP_VERSION = { numero: '1.109', fecha: '2026-11-17', commit: '61acc0f' };
