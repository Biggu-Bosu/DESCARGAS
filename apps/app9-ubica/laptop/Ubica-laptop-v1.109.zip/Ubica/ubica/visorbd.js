// Ubica · «Ver base de datos»: IndexedDB en crudo, como un editor de código.
//
// Ocupa toda la pantalla, con el aspecto de un editor (explorador de archivos a la izquierda,
// texto con números de línea y barra de estado), sin adornos. Cada almacén se ve como un archivo:
// «articulos.json» es exactamente lo que IndexedDB tiene guardado, en JSON. También hay una vista
// de tabla (una fila por registro, una columna por campo) y el esquema como el código que lo crea.
//
// Solo lee: abre la base, copia lo que hay y la cierra (BaseDatos.describirBase). No hay nada que
// edite. La ventana se puede minimizar (queda una barra abajo) y, en pantallas anchas, pasar a
// modo ventana para moverla y cambiarle el tamaño.
(function () {
  'use strict';

  const U = window.Ubica;
  const { N, e } = U;
  const BD = window.BaseDatos;

  const MAXIMO_LINEAS = 5000; // más líneas vuelven lento el celular; «Copiar» siempre copia todo
  const LETRA = { minima: 10, maxima: 22 };
  const ESQUEMA = '·esquema';

  // Lo que se está viendo. Vive solo mientras la app está abierta.
  const vista = {
    abierto: false,
    modo: 'maximizado', // 'maximizado' | 'ventana' | 'minimizado'
    cual: 'mia', // 'mia' (base «ubica») o 'muestra' (base «ubica-muestra»)
    info: null, // lo leído de IndexedDB (null si esa base no existe)
    almacen: null, // nombre del almacén abierto, o ESQUEMA
    formato: 'json', // 'json' | 'tabla'
    letra: 13,
    explorador: true, // en el celular se abre y se cierra con su botón
    anchoExplorador: 240,
    geometria: null // posición y tamaño de la ventana (modo «ventana»), para regresar igual
  };

  let raiz = null;

  // ---------- Texto de cada «archivo» ----------
  function esquemaComoCodigo(info) {
    const lineas = ['// IndexedDB · base "' + info.nombre + '" · versión ' + info.version,
      'const pedido = indexedDB.open(' + JSON.stringify(info.nombre) + ', ' + info.version + ');', '',
      'pedido.onupgradeneeded = () => {', '  const db = pedido.result;'];
    info.tablas.forEach((tabla) => {
      lineas.push('', '  // ' + tabla.registros.length + ' registro' + (tabla.registros.length === 1 ? '' : 's'),
        '  const ' + tabla.nombre + ' = db.createObjectStore(' + JSON.stringify(tabla.nombre) + ', { keyPath: ' +
        JSON.stringify(tabla.llave) + (tabla.autoIncremento ? ', autoIncrement: true' : '') + ' });');
      (tabla.detalleIndices || []).forEach((indice) => {
        lineas.push('  ' + tabla.nombre + '.createIndex(' + JSON.stringify(indice.nombre) + ', ' + JSON.stringify(indice.campo) +
          ', { unique: ' + indice.unico + (indice.multiple ? ', multiEntry: true' : '') + ' });');
      });
    });
    lineas.push('};');
    return lineas.join('\n');
  }

  const tablaAbierta = () => (vista.info && vista.almacen !== ESQUEMA ? vista.info.tablas.find((t) => t.nombre === vista.almacen) : null);

  // Todo el texto del archivo abierto (es lo que copia «Copiar»)
  function textoCompleto() {
    if (!vista.info) return '';
    if (vista.almacen === ESQUEMA) return esquemaComoCodigo(vista.info);
    const tabla = tablaAbierta();
    return tabla ? JSON.stringify(tabla.registros, null, 2) : '';
  }

  // Columnas de la tabla: la llave primero y luego cada campo en el orden en que aparece
  function columnasDe(tabla) {
    const columnas = [tabla.llave];
    tabla.registros.forEach((registro) => Object.keys(registro).forEach((campo) => {
      if (!columnas.includes(campo)) columnas.push(campo);
    }));
    return columnas;
  }

  // Un valor tal como está guardado: texto tal cual; null, objetos y listas en JSON
  function celda(registro, campo) {
    if (!(campo in registro)) return '<td></td>';
    const valor = registro[campo];
    const texto = typeof valor === 'string' ? valor : JSON.stringify(valor);
    return '<td title="' + e(texto.slice(0, 400)) + '">' + e(texto) + '</td>';
  }

  // ---------- Dibujo ----------
  function htmlExplorador() {
    const archivo = (nombre, texto, detalle) => '<li><button type="button" data-vbd="almacen" data-valor="' + e(nombre) + '"' +
      (vista.almacen === nombre ? ' aria-current="true"' : '') + '><span>' + e(texto) + '</span><small>' + e(detalle) + '</small></button></li>';
    const carpeta = (cual, nombre) => '<li><button type="button" data-vbd="base" data-valor="' + cual + '"' +
      (vista.cual === cual ? ' aria-current="true"' : '') + '>' + (vista.cual === cual ? '▾ ' : '▸ ') + e(nombre) + '</button>' +
      (vista.cual === cual ? (vista.info
        ? '<ul>' + archivo(ESQUEMA, 'esquema.js', 'v' + vista.info.version) +
          vista.info.tablas.map((t) => archivo(t.nombre, t.nombre + '.json', String(t.registros.length))).join('') + '</ul>'
        : '<p class="vbd-vacio">(no existe)</p>') : '') + '</li>';
    return '<p class="vbd-seccion">EXPLORADOR · INDEXEDDB</p><ul class="vbd-arbol">' +
      carpeta('mia', BD.NOMBRE_BD) + carpeta('muestra', BD.NOMBRE_MUESTRA) + '</ul>';
  }

  function htmlEditor() {
    if (!vista.info) {
      const nombre = vista.cual === 'muestra' ? BD.NOMBRE_MUESTRA : BD.NOMBRE_BD;
      return '<pre class="vbd-mensaje">// La base "' + e(nombre) + '" no existe en este momento.' +
        (vista.cual === 'muestra' ? '\n// Se crea al entrar a la muestra y se borra al salir.' : '') + '</pre>';
    }
    if (!vista.almacen) return '<pre class="vbd-mensaje">// Elige un archivo en el explorador.</pre>';
    const tabla = tablaAbierta();
    if (vista.formato === 'tabla' && tabla) {
      if (!tabla.registros.length) return '<pre class="vbd-mensaje">// Este almacén está vacío.</pre>';
      const columnas = columnasDe(tabla);
      const filas = tabla.registros.slice(0, MAXIMO_LINEAS);
      return '<div class="vbd-codigo" tabindex="0"><table class="vbd-tabla"><thead><tr><th>#</th>' +
        columnas.map((c) => '<th>' + e(c) + '</th>').join('') + '</tr></thead><tbody>' +
        filas.map((registro, i) => '<tr><td class="vbd-n">' + (i + 1) + '</td>' + columnas.map((c) => celda(registro, c)).join('') + '</tr>').join('') +
        '</tbody></table></div>';
    }
    const lineas = textoCompleto().split('\n');
    const visibles = lineas.slice(0, MAXIMO_LINEAS);
    if (lineas.length > MAXIMO_LINEAS) visibles.push('// … ' + (lineas.length - MAXIMO_LINEAS).toLocaleString('es-MX') + ' líneas más. «Copiar» copia todo.');
    const numeros = visibles.map((_, i) => i + 1).join('\n');
    return '<div class="vbd-codigo" tabindex="0" role="region" aria-label="Contenido de ' + e(nombreArchivo()) + '">' +
      '<pre class="vbd-numeros" aria-hidden="true">' + numeros + '</pre><pre class="vbd-texto">' + e(visibles.join('\n')) + '</pre></div>';
  }

  function nombreArchivo() {
    if (!vista.almacen) return '';
    return vista.almacen === ESQUEMA ? 'esquema.js' : vista.almacen + '.json';
  }

  function htmlEstado() {
    const partes = ['solo lectura'];
    if (vista.info) partes.push('indexedDB.open("' + vista.info.nombre + '", ' + vista.info.version + ')');
    const tabla = tablaAbierta();
    if (tabla) partes.push(N.plural(tabla.registros.length, 'registro'), 'llave: ' + tabla.llave);
    if (vista.almacen) partes.push(N.plural(textoCompleto().split('\n').length, 'línea'));
    partes.push(vista.formato === 'tabla' && tabla ? 'tabla' : 'UTF-8', vista.letra + ' px');
    return partes.map((p) => '<span>' + e(p) + '</span>').join('');
  }

  function pintar() {
    if (!raiz) return;
    const ancha = window.matchMedia('(min-width: 700px)').matches;
    if (!ancha && vista.modo === 'ventana') vista.modo = 'maximizado';
    // La ventana guarda dónde estaba y su tamaño; a pantalla completa o minimizada no lleva medidas propias
    const geometria = vista.modo === 'ventana' ? vista.geometria || {} : {};
    ['left', 'top', 'width', 'height'].forEach((lado) => { raiz.style[lado] = geometria[lado] || ''; });
    raiz.className = 'visor-bd ' + vista.modo + (vista.explorador ? ' con-explorador' : '');
    raiz.setAttribute('aria-modal', vista.modo === 'minimizado' ? 'false' : 'true');
    raiz.style.setProperty('--vbd-letra', vista.letra + 'px');
    raiz.style.setProperty('--vbd-explorador', vista.anchoExplorador + 'px');
    document.body.classList.toggle('visor-bd-abierto', vista.modo !== 'minimizado');
    const archivo = nombreArchivo();
    const boton = (accion, texto, etiqueta, extra) => '<button type="button" data-vbd="' + accion + '" aria-label="' + etiqueta +
      '" title="' + etiqueta + '"' + (extra || '') + '>' + texto + '</button>';
    raiz.innerHTML =
      '<div class="vbd-titulo">' +
        boton('explorador', '☰', 'Mostrar u ocultar el explorador', ' aria-pressed="' + vista.explorador + '"') +
        '<span class="vbd-nombre">' + e((archivo ? archivo + ' — ' : '') + (vista.cual === 'muestra' ? BD.NOMBRE_MUESTRA : BD.NOMBRE_BD) + ' — IndexedDB') + '</span>' +
        '<span class="vbd-botones">' +
          boton('letraMenos', 'A−', 'Letra más chica') + boton('letraMas', 'A+', 'Letra más grande') +
          (vista.modo === 'minimizado' ? boton('restaurar', '▢', 'Restaurar') : boton('minimizar', '—', 'Minimizar')) +
          (ancha ? boton('ventana', vista.modo === 'ventana' ? '❐' : '□', vista.modo === 'ventana' ? 'Pantalla completa' : 'Ventana ajustable') : '') +
          boton('cerrar', '✕', 'Cerrar', ' class="vbd-cerrar"') +
        '</span></div>' +
      (vista.modo === 'minimizado' ? '' :
        '<div class="vbd-cuerpo">' +
          '<nav class="vbd-explorador" aria-label="Almacenes de IndexedDB">' + htmlExplorador() + '</nav>' +
          '<div class="vbd-divisor" role="separator" aria-orientation="vertical" aria-label="Ancho del explorador" tabindex="0"></div>' +
          '<div class="vbd-editor">' +
            '<div class="vbd-pestanas">' + (archivo ? '<span class="vbd-pestana">' + e(archivo) + '</span>' : '<span></span>') +
              '<span class="vbd-acciones">' +
              (tablaAbierta() ? boton('formato', vista.formato === 'json' ? '<span class="largo">Ver como tabla</span><span class="corto">Tabla</span>'
                : '<span class="largo">Ver como JSON</span><span class="corto">JSON</span>',
                'Cambiar entre JSON y tabla') : '') +
              (archivo ? boton('copiar', 'Copiar', 'Copiar todo el archivo') : '') +
              boton('releer', '<span class="largo">Volver a leer</span><span class="corto">Releer</span>', 'Volver a leer la base') +
              '</span></div>' + htmlEditor() +
          '</div></div>' +
        '<div class="vbd-estado">' + htmlEstado() + '</div>');
  }

  // ---------- Abrir, cambiar de base y cerrar ----------
  async function leer(cual) {
    vista.cual = cual;
    vista.info = await BD.describirBase(cual);
    if (vista.info && vista.almacen && vista.almacen !== ESQUEMA && !vista.info.tablas.some((t) => t.nombre === vista.almacen)) vista.almacen = null;
    if (vista.info && !vista.almacen) vista.almacen = 'articulos';
  }

  U.abrirBaseDatos = async (cual) => {
    try {
      await leer(cual || (BD.enMuestra() ? 'muestra' : 'mia'));
    } catch (error) {
      console.error(error);
      U.avisar('No se pudo leer la base de datos.');
      return;
    }
    if (!raiz) {
      raiz = document.createElement('section');
      raiz.id = 'visorBD';
      raiz.setAttribute('role', 'dialog');
      raiz.setAttribute('aria-label', 'Base de datos (solo lectura)');
      raiz.addEventListener('click', alTocar);
      raiz.addEventListener('pointerdown', alEmpezarArrastre);
      raiz.addEventListener('keydown', alTeclear);
      document.body.appendChild(raiz);
    }
    vista.abierto = true;
    if (vista.modo === 'minimizado') vista.modo = 'maximizado';
    vista.explorador = window.matchMedia('(min-width: 700px)').matches;
    U.cerrarHojas();
    pintar();
    raiz.querySelector('.vbd-codigo, .vbd-explorador button')?.focus();
  };

  U.cerrarBaseDatos = () => {
    if (!raiz) return;
    raiz.remove();
    raiz = null;
    vista.abierto = false;
    vista.info = null;
    document.body.classList.remove('visor-bd-abierto');
  };

  // Para el botón «atrás» de Android: cierra el visor si está a la vista (minimizado no estorba)
  U.visorBDAbierto = () => vista.abierto && vista.modo !== 'minimizado';

  async function alTocar(evento) {
    const boton = evento.target.closest('[data-vbd]');
    if (!boton) {
      // Minimizado: tocar la barra lo regresa
      if (vista.modo === 'minimizado' && evento.target.closest('.vbd-titulo')) {
        vista.modo = 'maximizado';
        pintar();
      }
      return;
    }
    const accion = boton.dataset.vbd;
    const ancha = window.matchMedia('(min-width: 700px)').matches;
    if (accion === 'cerrar') return U.cerrarBaseDatos();
    if (vista.modo === 'ventana') guardarGeometria();
    if (accion === 'minimizar') vista.modo = 'minimizado';
    else if (accion === 'restaurar') vista.modo = vista.geometria ? 'ventana' : 'maximizado';
    else if (accion === 'ventana') vista.modo = vista.modo === 'ventana' ? 'maximizado' : 'ventana';
    else if (accion === 'letraMenos') vista.letra = Math.max(LETRA.minima, vista.letra - 1);
    else if (accion === 'letraMas') vista.letra = Math.min(LETRA.maxima, vista.letra + 1);
    else if (accion === 'explorador') {
      if (vista.modo === 'minimizado') vista.modo = 'maximizado';
      vista.explorador = !vista.explorador;
    } else if (accion === 'formato') vista.formato = vista.formato === 'json' ? 'tabla' : 'json';
    else if (accion === 'almacen') {
      vista.almacen = boton.dataset.valor;
      if (!ancha) vista.explorador = false; // en el celular, al elegir un archivo se ve el archivo
    } else if (accion === 'base' || accion === 'releer') {
      try {
        await leer(accion === 'base' ? boton.dataset.valor : vista.cual);
      } catch (error) {
        U.avisar('No se pudo leer esa base.');
      }
    } else if (accion === 'copiar') {
      try {
        await navigator.clipboard.writeText(textoCompleto());
        U.avisar('Copiado: ' + nombreArchivo());
      } catch (error) {
        U.avisar('No se pudo copiar. Selecciona el texto a mano.');
      }
      return;
    }
    pintar();
    if (accion === 'almacen' || accion === 'formato') raiz.querySelector('.vbd-codigo')?.focus();
    else raiz.querySelector('[data-vbd="' + accion + '"]')?.focus();
  }

  function guardarGeometria() {
    vista.geometria = { left: raiz.style.left, top: raiz.style.top, width: raiz.style.width, height: raiz.style.height };
  }

  // ---------- Arrastrar: el divisor (ancho del explorador) y la barra de título (mover la ventana) ----------
  function alEmpezarArrastre(evento) {
    const divisor = evento.target.closest('.vbd-divisor');
    const titulo = evento.target.closest('.vbd-titulo');
    if (divisor) {
      evento.preventDefault();
      const inicioX = evento.clientX;
      const inicioAncho = vista.anchoExplorador;
      arrastrar(evento, (x) => {
        vista.anchoExplorador = Math.max(140, Math.min(480, inicioAncho + x - inicioX));
        raiz.style.setProperty('--vbd-explorador', vista.anchoExplorador + 'px');
      });
    } else if (titulo && vista.modo === 'ventana' && !evento.target.closest('button')) {
      evento.preventDefault();
      const caja = raiz.getBoundingClientRect();
      const desfaseX = evento.clientX - caja.left;
      const desfaseY = evento.clientY - caja.top;
      arrastrar(evento, (x, y) => {
        raiz.style.left = Math.max(0, Math.min(window.innerWidth - 120, x - desfaseX)) + 'px';
        raiz.style.top = Math.max(0, Math.min(window.innerHeight - 40, y - desfaseY)) + 'px';
      });
    }
  }

  function arrastrar(evento, mover) {
    const id = evento.pointerId;
    const alMover = (e2) => { if (e2.pointerId === id) mover(e2.clientX, e2.clientY); };
    const alSoltar = (e2) => {
      if (e2.pointerId !== id) return;
      window.removeEventListener('pointermove', alMover);
      window.removeEventListener('pointerup', alSoltar);
      window.removeEventListener('pointercancel', alSoltar);
    };
    window.addEventListener('pointermove', alMover);
    window.addEventListener('pointerup', alSoltar);
    window.addEventListener('pointercancel', alSoltar);
  }

  // Teclado: Esc cierra; flechas en el divisor cambian el ancho del explorador
  function alTeclear(evento) {
    if (evento.key === 'Escape') {
      evento.preventDefault();
      evento.stopPropagation();
      U.cerrarBaseDatos();
    } else if (evento.target.classList.contains('vbd-divisor') && (evento.key === 'ArrowLeft' || evento.key === 'ArrowRight')) {
      evento.preventDefault();
      vista.anchoExplorador = Math.max(140, Math.min(480, vista.anchoExplorador + (evento.key === 'ArrowLeft' ? -16 : 16)));
      raiz.style.setProperty('--vbd-explorador', vista.anchoExplorador + 'px');
    }
  }

  // Si la pantalla cruza el tamaño de celular (por ejemplo, al girarlo), se vuelve a acomodar
  let eraAncha = window.matchMedia('(min-width: 700px)').matches;
  window.addEventListener('resize', () => {
    const ancha = window.matchMedia('(min-width: 700px)').matches;
    if (ancha === eraAncha) return;
    eraAncha = ancha;
    if (raiz) {
      vista.explorador = ancha;
      pintar();
    }
  });
})();
