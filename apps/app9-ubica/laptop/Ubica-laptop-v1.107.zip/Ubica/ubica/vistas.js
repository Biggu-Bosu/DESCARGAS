// Ubica · Secciones (Inventario, Lugares, Préstamos, Más) y espacio de trabajo de un lugar.
// El espacio de trabajo muestra UN lugar de tres maneras —Lista, 2.5D y 3D— con los mismos datos,
// la misma selección y las mismas herramientas. Las escenas solo dibujan y avisan de los toques:
// todo cambio pasa por las operaciones de nucleo.js (ver U.ejecutar en ui.js).
(function () {
  'use strict';

  const U = window.Ubica;
  const { N, e, $, estado, ICONOS } = U;
  const datos = () => estado.datos;

  // =====================================================================
  // INVENTARIO (lista general con filtros y orden)
  // =====================================================================
  const FILTROS_ESTADO = [
    ['', 'Todos'], ['disponible', 'Disponibles'], ['prestado', 'Prestados'],
    ['reparacion', 'En reparación'], ['danado', 'Dañados'], ['agotado', 'Agotados']
  ];
  const COLUMNAS = [
    ['nombre', 'Artículo'], ['categoria', 'Categoría'], ['ubicacion', 'Ubicación'],
    ['total', 'Total'], ['disponibles', 'Disponibles']
  ];
  let consultaGuardada = { clave: null, filas: [] };

  function filasDelInventario() {
    const f = estado.filtros;
    const clave = [estado.version, f.texto, f.categoriaId, f.estado, f.lugar, estado.orden, estado.descendente].join('|');
    if (consultaGuardada.clave !== clave) {
      consultaGuardada = { clave: clave, filas: N.consultarArticulos(datos(), f, estado.orden, estado.descendente) };
    }
    return consultaGuardada.filas;
  }

  const hayFiltros = () => Boolean(estado.filtros.texto.trim() || estado.filtros.categoriaId || estado.filtros.estado || estado.filtros.lugar);

  function renderInventario() {
    const vacio = N.estaVacio(datos());
    $('bienvenida').hidden = !vacio;
    $('herramientas').hidden = vacio;
    $('tablaInventario').hidden = vacio;
    if (vacio) return;

    // Filtros: se rellenan los <select> y se marcan los botones activos
    const f = estado.filtros;
    $('filtroCategoria').innerHTML = '<option value="">Todas las categorías</option>' + N.categoriasOrdenadas(datos()).map((c) =>
      '<option value="' + e(c.id) + '"' + (c.id === f.categoriaId ? ' selected' : '') + '>' + e(c.nombre) + '</option>').join('');
    $('filtroLugar').innerHTML = '<option value="">Todos los lugares</option>' + datos().lugares.map((l) =>
      '<option value="' + e(l.id) + '"' + (l.id === f.lugar ? ' selected' : '') + '>' + e(l.nombre) + '</option>').join('') +
      '<option value="sin"' + (f.lugar === 'sin' ? ' selected' : '') + '>Sin ubicación</option>';
    $('filtrosEstado').innerHTML = FILTROS_ESTADO.map(([clave, nombre]) =>
      '<button type="button" class="chip" data-estado="' + clave + '" aria-pressed="' + (f.estado === clave) + '">' + nombre + '</button>').join('');
    $('ordenMovil').value = estado.orden + (estado.descendente ? '-' : '+');
    if ($('buscador').value !== f.texto && document.activeElement !== $('buscador')) $('buscador').value = f.texto;

    const filas = filasDelInventario();
    const flechaOrden = (columna) => (estado.orden === columna ? (estado.descendente ? ' ↓' : ' ↑') : '');
    let html = '<p class="conteo" aria-live="polite">' + N.plural(filas.length, 'artículo') +
      (hayFiltros() ? ' con estos filtros · <button type="button" class="enlace" data-limpiar>Quitar filtros</button>' : '') + '</p>';
    const filaHtml = (fila) => {
      const a = fila.articulo;
      return '<tr data-articulo="' + e(a.id) + '" tabindex="0">' +
        '<td class="col-nombre"><span class="punto" data-simple="categorias" style="background:' + e(fila.categoria.color) + '"></span><span class="nombre"><strong>' +
        e(a.nombre) + '</strong>' + (a.codigo ? ' <small class="codigo">' + e(a.codigo) + '</small>' : '') +
        '<small class="solo-movil">' + e(fila.ubicacion) + '</small></span></td>' +
        '<td class="col-categoria">' + e(fila.categoria.nombre) + '</td>' +
        '<td class="col-ubicacion">' + e(fila.ubicacion) + '</td>' +
        '<td class="col-total numero">' + fila.total + '</td>' +
        '<td class="col-disponibles numero"><strong>' + fila.disponibles + '</strong><small class="solo-movil"> de ' + fila.total + '</small></td>' +
        '<td class="col-estado">' + (U.etiquetasEstado(fila) || '<span class="etiqueta verde">Completo</span>') + '</td></tr>';
    };
    if (!filas.length) {
      html += '<p class="vacio">Ningún artículo coincide. Prueba con otra búsqueda o quita los filtros.</p>';
    } else {
      html += '<table class="tabla' + (U.ajustes.agrupar ? ' agrupada' : '') + '"><thead><tr>' + COLUMNAS.map(([clave, nombre]) =>
        '<th scope="col" class="col-' + clave + '"' + (estado.orden === clave ? ' aria-sort="' + (estado.descendente ? 'descending' : 'ascending') + '"' : '') +
        '><button type="button" data-orden="' + clave + '">' + nombre + flechaOrden(clave) + '</button></th>').join('') +
        '<th scope="col" class="col-estado">Estado</th></tr></thead>';
      let pintadas = 0;
      if (!U.ajustes.agrupar) {
        const visibles = filas.slice(0, estado.filasVisibles);
        pintadas = visibles.length;
        html += '<tbody>' + visibles.map(filaHtml).join('') + '</tbody>';
      } else {
        // Un grupo por lugar (en el orden de los lugares) y al final «Sin ubicación».
        // Al buscar o filtrar se abren todos; si no, se abren y cierran con un toque.
        const grupos = new Map();
        datos().lugares.forEach((lugar) => grupos.set(lugar.id, { id: lugar.id, nombre: lugar.nombre, filas: [] }));
        grupos.set('sin', { id: 'sin', nombre: 'Sin ubicación', filas: [] });
        filas.forEach((fila) => grupos.get(fila.lugar ? fila.lugar.id : 'sin').filas.push(fila));
        const conArticulos = Array.from(grupos.values()).filter((grupo) => grupo.filas.length);
        conArticulos.forEach((grupo) => {
          const abierto = hayFiltros() || conArticulos.length === 1 || estado.gruposAbiertos.has(grupo.id);
          const piezas = grupo.filas.reduce((suma, fila) => suma + fila.total, 0);
          html += '<tbody class="grupo-lugar' + (abierto ? ' abierto' : '') + '"><tr class="fila-grupo"><th colspan="' + (COLUMNAS.length + 1) + '" scope="rowgroup">' +
            '<button type="button" data-grupo="' + e(grupo.id) + '" aria-expanded="' + abierto + '">' + ICONOS.flecha +
            '<strong>' + e(grupo.nombre) + '</strong><span class="cuenta">' + N.plural(grupo.filas.length, 'artículo') +
            '<span data-simple="texto"> · ' + N.plural(piezas, 'pieza') + '</span></span></button></th></tr>';
          if (abierto) {
            const caben = Math.max(0, estado.filasVisibles - pintadas);
            const visibles = grupo.filas.slice(0, caben);
            pintadas += visibles.length;
            html += visibles.map(filaHtml).join('');
          }
          html += '</tbody>';
        });
        // Cuántas filas faltan por mostrar dentro de los grupos abiertos
        const abiertas = conArticulos.filter((grupo) => hayFiltros() || conArticulos.length === 1 || estado.gruposAbiertos.has(grupo.id))
          .reduce((suma, grupo) => suma + grupo.filas.length, 0);
        if (abiertas > pintadas) html += '</table><button type="button" class="boton" data-mas>Mostrar más (' + (abiertas - pintadas) + ' más)</button>';
        else html += '</table>';
      }
      if (!U.ajustes.agrupar) {
        html += '</table>';
        if (filas.length > pintadas) html += '<button type="button" class="boton" data-mas>Mostrar más (' + (filas.length - pintadas) + ' más)</button>';
      }
    }
    $('tablaInventario').innerHTML = html;
  }

  function cambiarFiltro(cambios) {
    Object.assign(estado.filtros, cambios);
    estado.filasVisibles = U.FILAS_POR_TANDA;
    U.render();
  }
  U.cambiarFiltro = cambiarFiltro;

  // Se espera un instante a que termines de teclear antes de buscar
  let esperaBusqueda = null;
  $('buscador').addEventListener('input', (evento) => {
    const texto = evento.target.value;
    clearTimeout(esperaBusqueda);
    esperaBusqueda = setTimeout(() => cambiarFiltro({ texto: texto }), 120);
  });
  $('filtroCategoria').addEventListener('change', (evento) => cambiarFiltro({ categoriaId: evento.target.value }));
  $('filtroLugar').addEventListener('change', (evento) => cambiarFiltro({ lugar: evento.target.value }));
  $('filtrosEstado').addEventListener('click', (evento) => {
    const boton = evento.target.closest('[data-estado]');
    if (boton) cambiarFiltro({ estado: boton.dataset.estado });
  });
  $('ordenMovil').addEventListener('change', (evento) => {
    estado.orden = evento.target.value.slice(0, -1);
    estado.descendente = evento.target.value.endsWith('-');
    U.render();
  });
  $('botonFiltros').addEventListener('click', () => {
    const abierto = $('herramientas').classList.toggle('filtros-abiertos');
    $('botonFiltros').setAttribute('aria-expanded', String(abierto));
  });

  $('tablaInventario').addEventListener('click', (evento) => {
    if (evento.target.closest('[data-mas]')) {
      estado.filasVisibles += U.FILAS_POR_TANDA;
      renderInventario();
      return;
    }
    if (evento.target.closest('[data-limpiar]')) {
      $('buscador').value = '';
      cambiarFiltro({ texto: '', categoriaId: '', estado: '', lugar: '' });
      return;
    }
    const grupo = evento.target.closest('[data-grupo]');
    if (grupo) {
      const id = grupo.dataset.grupo;
      if (estado.gruposAbiertos.has(id)) estado.gruposAbiertos.delete(id);
      else estado.gruposAbiertos.add(id);
      renderInventario();
      const mismo = $('tablaInventario').querySelector('[data-grupo="' + id + '"]');
      if (mismo) mismo.focus();
      return;
    }
    const orden = evento.target.closest('[data-orden]');
    if (orden) {
      estado.descendente = estado.orden === orden.dataset.orden ? !estado.descendente : false;
      estado.orden = orden.dataset.orden;
      U.render();
      return;
    }
    const fila = evento.target.closest('[data-articulo]');
    if (fila) U.abrirArticulo(fila.dataset.articulo, true);
  });
  $('tablaInventario').addEventListener('keydown', (evento) => {
    const fila = evento.target.closest('tr[data-articulo]');
    if (fila && (evento.key === 'Enter' || evento.key === ' ')) {
      evento.preventDefault();
      U.abrirArticulo(fila.dataset.articulo, true);
    }
  });

  $('bienvenida').addEventListener('click', (evento) => {
    const boton = evento.target.closest('[data-inicio]');
    if (!boton) return;
    const accion = boton.dataset.inicio;
    if (accion === 'articulo') U.abrirHoja(() => U.pantallaNuevoArticulo('sin'));
    if (accion === 'lugar') U.abrirHoja(() => U.pantallaLugar(null));
    if (accion === 'ejemplo') U.cargarEjemplo();
    if (accion === 'restaurar') $('elegirRespaldo').click();
  });

  // =====================================================================
  // LUGARES (tarjetas)
  // =====================================================================
  const NOMBRE_VISTA = { lista: 'Lista', '2.5d': '2.5D', '3d': '3D' };

  function renderLugares() {
    const lugares = datos().lugares;
    const sinUbicacion = N.articulosSinUbicacion(datos()).length;
    let html = '';
    if (!lugares.length) {
      html += '<div class="estado-vacio"><h2>Todavía no hay lugares</h2><p>Los lugares son opcionales: sirven para saber <strong>dónde</strong> ' +
        'está cada cosa. Un lugar puede ser solo un nombre, o tener un plano para verlo en 2.5D y 3D.</p>' +
        '<button type="button" class="boton principal" data-nuevo-lugar>Crear un lugar</button></div>';
    }
    html += '<div class="rejilla-lugares">' + lugares.map((lugar) => {
      const vista = N.vistaDeLugar(lugar);
      const tono = N.TIPOS_LUGAR[lugar.tipo].tono;
      // Cada lugar lleva al lado su botón de borrar (va fuera de la tarjeta: un botón no puede ir dentro de otro)
      return '<div class="fila-lugar"><button type="button" class="tarjeta-lugar" data-lugar="' + e(lugar.id) + '" style="--tono:' + tono + '">' +
        '<span class="miniatura">' + (lugar.plano ? (vista === '3d' ? ICONOS.cubo : ICONOS.plano) : ICONOS.lista) + '</span>' +
        '<span class="texto"><strong>' + e(lugar.nombre) + '</strong><small>' + e(N.TIPOS_LUGAR[lugar.tipo].nombre) + ' · ' +
        N.plural(N.mueblesDe(datos(), lugar.id).length, 'mueble') + ' · ' + N.plural(N.piezasEnLugar(datos(), lugar.id), 'pieza') + '</small></span>' +
        '<span class="etiqueta ' + (lugar.plano ? 'azul' : 'gris') + '">' + (lugar.plano ? NOMBRE_VISTA[vista] : 'Solo lista') + '</span></button>' +
        '<button type="button" class="boton borrar-lugar" data-borrar-lugar="' + e(lugar.id) + '" aria-label="Borrar ' + e(lugar.nombre) +
        '" title="Borrar lugar">' + ICONOS.borrar + '</button></div>';
    }).join('') +
      (sinUbicacion ? '<button type="button" class="tarjeta-lugar suelta" data-sin-ubicacion><span class="miniatura">' + ICONOS.lista +
        '</span><span class="texto"><strong>Sin ubicación</strong><small>' + N.plural(sinUbicacion, 'artículo') +
        ' que no están en ningún lugar</small></span><span class="etiqueta gris">Inventario</span></button>' : '') + '</div>';
    $('vistaLugares').innerHTML = html;
  }

  $('vistaLugares').addEventListener('click', (evento) => {
    const borrar = evento.target.closest('[data-borrar-lugar]');
    if (borrar) {
      // No borra de golpe: abre la pantalla que dice qué se afecta y pide confirmar
      U.abrirHojaUnica(() => U.pantallaBorrarLugar(borrar.dataset.borrarLugar));
      return;
    }
    if (evento.target.closest('[data-nuevo-lugar]')) U.abrirHoja(() => U.pantallaLugar(null));
    else if (evento.target.closest('[data-sin-ubicacion]')) {
      Object.assign(estado.filtros, { texto: '', categoriaId: '', estado: '', lugar: 'sin' });
      U.irASeccion('inventario');
    } else {
      const tarjeta = evento.target.closest('[data-lugar]');
      if (tarjeta) U.irALugar(tarjeta.dataset.lugar);
    }
  });

  // =====================================================================
  // ESPACIO DE TRABAJO DE UN LUGAR
  // =====================================================================
  const SIN_RESALTADOS = new Set();
  let salaGuardada = { clave: null, sala: null };

  // Las escenas dibujan "salas": aquí se traduce un lugar con plano a lo que ellas esperan
  function salaDe(lugar) {
    if (!lugar || !lugar.plano) return null;
    const clave = estado.version + '|' + lugar.id;
    if (salaGuardada.clave !== clave) {
      salaGuardada = { clave: clave, sala: { id: lugar.id, nombre: lugar.nombre, tipo: lugar.tipo, ancho: lugar.plano.ancho, fondo: lugar.plano.fondo } };
    }
    return salaGuardada.sala;
  }

  // Lo que ven las dos escenas (2.5D y 3D): exactamente lo mismo
  function estadoDeEscena() {
    const lugar = U.lugarAbierto();
    const sala = salaDe(lugar);
    return {
      espacio: sala,
      muebles: sala ? N.mueblesColocados(datos(), lugar.id) : [],
      seleccionadoId: estado.seleccionadoId,
      resaltados: SIN_RESALTADOS,
      modo: estado.modo,
      piezas: (muebleId) => N.piezasEnMueble(datos(), muebleId),
      // Solo lo usa el 3D: los artículos del mueble como objetos acomodados en sus repisas
      interior: (mueble) => N.acomodoInterior(datos(), mueble),
      articuloResaltadoId: estado.articuloResaltadoId,
      // Editor 3D: objetos propios del lugar, cuáles están seleccionados y con qué herramienta
      objetos3d: () => (sala ? N.objetosEnLugar(datos(), lugar.id) : []),
      objetosSeleccionados: estado.editor.seleccion,
      herramienta: estado.editor.herramienta,
      iman: Boolean(U.ajustes && U.ajustes.imanEditor),
      interiorId: estado.editor.interiorId,
      animaciones: !(U.ajustes && U.ajustes.sinAnimaciones),
      version: estado.version,
      presentacion: document.body.classList.contains('presentacion')
    };
  }

  const opcionesEscena = {
    estado: estadoDeEscena, alTocar: tocarEscena, alArrastrarMueble: soltarMueble,
    // Los resuelve editor3d.js (se carga después)
    alPrevisualizarObjetos: (propuestas) => (U.previsualizarObjetos ? U.previsualizarObjetos(propuestas) : null),
    alTransformarObjetos: (propuestas, info) => U.transformarObjetos && U.transformarObjetos(propuestas, info)
  };
  const escena = (U.escena = window.Escena.crear($('lienzo'), opcionesEscena));
  U.escena3d = null;           // se crea la primera vez que se abre la vista 3D
  let cargando3d = null;

  const vistaActual = () => N.vistaDeLugar(U.lugarAbierto());
  U.vistaActual = vistaActual;
  U.escenaActiva = () => (vistaActual() === '3d' ? U.escena3d : vistaActual() === '2.5d' ? escena : null);

  U.redibujarEscenas = () => {
    escena.pedirDibujo();
    if (U.escena3d) U.escena3d.pedirDibujo();
  };

  // Un toque en cualquiera de las dos escenas: { casilla, mueble }
  async function tocarEscena(toque) {
    const lugar = U.lugarAbierto();
    const sala = salaDe(lugar);
    if (!sala || U.ocupado()) return;
    const activa = U.escenaActiva();
    const modo = document.body.classList.contains('presentacion') ? null : estado.modo;

    if (modo && modo.tipo === 'mover') {
      if (!toque.casilla) return;
      const mueble = N.buscarPorId(datos().muebles, modo.muebleId);
      if (!mueble) return;
      const rect = N.rectAlTocar(toque.casilla, mueble, sala, activa.rotacion());
      const colocadoAntes = N.estaColocado(mueble);
      const resultado = N.moverMueble(datos(), mueble.id, rect);
      if (resultado.ok) estado.modo = null;
      await U.ejecutar(resultado, { mensaje: (colocadoAntes ? 'Moviste «' : 'Colocaste «') + mueble.nombre + '»', deshacer: colocadoAntes });
      return;
    }
    // Colocando: si el mueble cabe en la casilla tocada se coloca, aunque el dedo caiga sobre la
    // silueta de un mueble alto que está adelante.
    if (modo && modo.tipo === 'colocar' && toque.casilla) {
      const rect = N.rectAlTocar(toque.casilla, N.TIPOS_MUEBLE[modo.mueble], sala, activa.rotacion());
      const resultado = N.colocarMueble(datos(), lugar.id, modo.mueble, rect);
      if (resultado.ok || !toque.mueble) {
        await U.ejecutar(resultado, { mensaje: resultado.ok ? 'Colocaste «' + resultado.mueble.nombre + '»' : '', deshacer: resultado.ok });
        return;
      }
    }
    // Editor 3D: tocar un objeto propio lo selecciona
    if (toque.objetoId && !modo) {
      // En 2.5D no está la barra del editor: se abren sus propiedades para editarlo con números
      U.seleccionarObjetos([toque.objetoId], { panel: vistaActual() !== '3d', sumar: Boolean(toque.sumar) });
      return;
    }
    // Editando un mueble por dentro: un artículo que se dibujaba solo pasa a ser un objeto propio
    if (toque.articuloId && toque.automatico && !modo && estado.editor.interiorId === toque.muebleId) {
      U.fijarArticuloEnInterior(toque.muebleId, toque.articuloId);
      return;
    }
    if (estado.editor.interiorId) {
      // Dentro del editor del interior los demás muebles no se seleccionan; tocar fuera suelta los objetos
      if (estado.editor.seleccion.length) U.seleccionarObjetos([]);
      return;
    }
    if (estado.editor.seleccion.length && !toque.mueble) {
      U.seleccionarObjetos([]);
      return;
    }
    // 3D: tocar un objeto dentro del mueble abierto lleva a su artículo
    if (toque.articuloId && !modo) {
      estado.articuloResaltadoId = toque.articuloId;
      U.abrirArticulo(toque.articuloId, true);
      return;
    }
    if (toque.mueble) U.seleccionar(toque.mueble.id);
    else if (estado.seleccionadoId) U.deseleccionar();
  }

  // Arrastrar el mueble seleccionado a otra casilla (2.5D y 3D). rect: en coordenadas del lugar.
  async function soltarMueble(muebleId, rect) {
    const mueble = N.buscarPorId(datos().muebles, muebleId);
    if (!mueble || U.ocupado()) return;
    if (rect.x === mueble.x && rect.y === mueble.y) return;
    await U.ejecutar(N.moverMueble(datos(), muebleId, rect), { mensaje: 'Moviste «' + mueble.nombre + '»', deshacer: true });
  }

  // ---------- Selección (se comparte entre Lista, 2.5D y 3D) ----------
  U.seleccionar = (muebleId, opciones) => {
    estado.seleccionadoId = muebleId;
    estado.editor.seleccion = []; // elegir un mueble suelta los objetos 3D
    if (!(opciones && opciones.conservarArticulo)) estado.articuloResaltadoId = null;
    renderSeleccion();
    U.redibujarEscenas();
    // En pantallas anchas hay sitio: el panel del mueble se abre a un lado sin tapar la escena
    if (U.esEscritorio() || (opciones && opciones.abrir)) U.abrirMueble(muebleId);
  };

  U.deseleccionar = () => {
    if (!estado.seleccionadoId) return;
    estado.seleccionadoId = null;
    estado.articuloResaltadoId = null;
    renderSeleccion();
    U.redibujarEscenas();
  };

  U.empezarAMover = (muebleId) => {
    const mueble = N.buscarPorId(datos().muebles, muebleId);
    if (!mueble) return;
    const lugar = N.buscarPorId(datos().lugares, mueble.lugarId);
    if (vistaActual() === 'lista' || estado.lugarId !== lugar.id) U.irALugar(lugar.id, { vista: lugar.vista === '3d' ? '3d' : '2.5d' });
    estado.modo = { tipo: 'mover', muebleId: muebleId };
    estado.seleccionadoId = muebleId;
    if (!U.esEscritorio()) U.cerrarHojas();
    U.render();
  };

  function renderSeleccion() {
    const barra = $('barraSeleccion');
    const mueble = estado.seleccionadoId ? N.buscarPorId(datos().muebles, estado.seleccionadoId) : null;
    const visible = Boolean(mueble) && vistaActual() !== 'lista' && !estado.modo && mueble.lugarId === estado.lugarId && !estado.editor.interiorId;
    barra.hidden = !visible;
    if (!visible) return;
    const articulos = N.articulosDe(datos(), mueble.id);
    const resaltado = estado.articuloResaltadoId ? N.buscarPorId(datos().articulos, estado.articuloResaltadoId) : null;
    barra.innerHTML = '<div class="info"><strong>' + e(mueble.nombre) + '</strong><small>' +
      (resaltado ? 'Aquí está: ' + e(resaltado.nombre) : N.plural(articulos.length, 'artículo') + ' · ' +
      N.plural(N.piezasEnMueble(datos(), mueble.id), 'pieza')) + '</small></div>' +
      '<button type="button" class="boton principal chico" data-sel="abrir">Abrir</button>' +
      (vistaActual() === '3d' ? '<button type="button" class="boton chico edicion" data-sel="interior" title="Acomodar lo que guarda, en 3D">Interior</button>' : '') +
      '<button type="button" class="boton-icono edicion" data-sel="mover" aria-label="Mover">' + ICONOS.mover + '</button>' +
      '<button type="button" class="boton-icono edicion" data-sel="girar" aria-label="Girar el mueble">' + ICONOS.girar + '</button>' +
      '<button type="button" class="boton-icono" data-sel="cerrar" aria-label="Quitar la selección">' + ICONOS.cerrar + '</button>';
  }

  $('barraSeleccion').addEventListener('click', (evento) => {
    const boton = evento.target.closest('[data-sel]');
    if (!boton || !estado.seleccionadoId) return;
    const accion = boton.dataset.sel;
    if (accion === 'abrir') U.abrirMueble(estado.seleccionadoId);
    if (accion === 'interior') U.editarInterior(estado.seleccionadoId);
    if (accion === 'mover') U.empezarAMover(estado.seleccionadoId);
    if (accion === 'girar') U.girarMueble(estado.seleccionadoId);
    if (accion === 'cerrar') {
      U.deseleccionar();
      if (U.esEscritorio()) U.cerrarHojas();
    }
  });

  // ---------- Entrar, salir y cambiar de vista ----------
  // opciones: { vista: 'lista'|'2.5d'|'3d', muebleId, articuloId }
  U.irALugar = (lugarId, opciones) => {
    const ajustes = opciones || {};
    const lugar = N.buscarPorId(datos().lugares, lugarId);
    if (!lugar) return;
    const cambio = estado.lugarId !== lugarId;
    estado.seccion = 'lugares';
    estado.lugarId = lugarId;
    estado.modo = null;
    if (cambio) {
      estado.seleccionadoId = null;
      estado.editor.seleccion = [];
      estado.editor.interiorId = null;
      escena.reiniciar();
      if (U.escena3d) U.escena3d.reiniciar();
    }
    if (ajustes.muebleId) estado.seleccionadoId = ajustes.muebleId;
    estado.articuloResaltadoId = ajustes.articuloId || null;
    U.guardarClave('ubica.espacioActual', lugarId);
    if (ajustes.vista && ajustes.vista !== N.vistaDeLugar(lugar)) U.cambiarVista(ajustes.vista);
    else {
      U.render();
      enfocarSeleccion();
    }
  };

  U.salirDeLugar = () => {
    estado.lugarId = null;
    estado.modo = null;
    estado.editor.seleccion = [];
    estado.editor.interiorId = null;
    estado.seleccionadoId = null;
    estado.articuloResaltadoId = null;
    document.body.classList.remove('presentacion');
    // Al salir del lugar se libera la memoria gráfica del 3D (importante en celulares)
    if (U.escena3d) {
      U.escena3d.destruir();
      U.escena3d = null;
      cargando3d = null;
    }
    U.render();
  };

  // Cambiar entre Lista, 2.5D y 3D. Se guarda como preferencia del lugar (cada lugar recuerda la suya).
  U.cambiarVista = async (vista) => {
    const lugar = U.lugarAbierto();
    if (!lugar) return;
    if (vista !== 'lista' && !lugar.plano) {
      U.abrirHoja(() => U.pantallaLugar(lugar.id, { conPlano: true }));
      return;
    }
    if (vista !== 'lista' && estado.modo && estado.modo.tipo === 'colocar') estado.modo = null;
    if (N.vistaDeLugar(lugar) !== vista) await U.ejecutar(N.cambiarVistaLugar(datos(), lugar.id, vista));
    else U.render();
    enfocarSeleccion();
  };

  // Al cambiar de vista, la cámara va al mueble seleccionado (así no se pierde el contexto)
  function enfocarSeleccion() {
    const mueble = estado.seleccionadoId ? N.buscarPorId(datos().muebles, estado.seleccionadoId) : null;
    if (!mueble || !N.estaColocado(mueble)) return;
    setTimeout(() => {
      const activa = U.escenaActiva();
      if (activa) activa.enfocar(mueble);
    }, 120);
  }

  // «Localizar»: abre el lugar del artículo en su vista preferida y marca el mueble que lo guarda
  U.localizarArticulo = (articuloId) => {
    const sitio = N.ubicacion(datos(), articuloId);
    if (!sitio.articulo || !sitio.lugar) return;
    U.cerrarHojas();
    const colocado = sitio.mueble && N.estaColocado(sitio.mueble) && sitio.lugar.plano;
    U.irALugar(sitio.lugar.id, {
      muebleId: sitio.mueble ? sitio.mueble.id : null,
      articuloId: articuloId,
      vista: colocado ? (N.vistaDeLugar(sitio.lugar) === 'lista' ? '2.5d' : N.vistaDeLugar(sitio.lugar)) : 'lista'
    });
    U.avisar('«' + sitio.articulo.nombre + '» está en ' + N.textoUbicacion(sitio.lugar, sitio.mueble));
  };

  $('selectorVista').addEventListener('click', (evento) => {
    const boton = evento.target.closest('[data-vista-lugar]');
    if (boton) U.cambiarVista(boton.dataset.vistaLugar);
  });

  // ---------- Vista 3D: se carga solo cuando se abre (Three.js pesa ~690 KB) ----------
  function prepararEscena3d() {
    if (U.escena3d || cargando3d) return;
    $('cargando3d').hidden = false;
    $('cargando3d').textContent = 'Preparando la vista 3D…';
    cargando3d = import('./escena3d.js').then((modulo) => {
      U.escena3d = modulo.crear($('lienzo3d'), opcionesEscena);
      $('cargando3d').hidden = true;
      U.escena3d.pedirDibujo();
      enfocarSeleccion();
    }).catch((error) => {
      console.error(error);
      cargando3d = null;
      $('cargando3d').innerHTML = 'No se pudo abrir la vista 3D en este dispositivo. <button type="button" class="enlace" data-vista-lugar="2.5d">Usar la vista 2.5D</button>';
    });
  }
  $('cargando3d').addEventListener('click', (evento) => {
    if (evento.target.closest('[data-vista-lugar]')) U.cambiarVista('2.5d');
  });

  // ---------- Dibujar el espacio de trabajo ----------
  function filaArticulo(articulo) {
    const prestadas = N.prestadas(datos(), articulo.id);
    const fuera = articulo.estados.reparacion + articulo.estados.danado;
    return '<li><button type="button" data-articulo="' + e(articulo.id) + '"' +
      (articulo.id === estado.articuloResaltadoId ? ' class="resaltado"' : '') + '><span class="nombre"><strong>' + e(articulo.nombre) +
      '</strong>' + (articulo.codigo ? '<small>' + e(articulo.codigo) + '</small>' : '') + '</span><span class="cantidad">×' + N.totalDe(articulo) +
      '</span>' + (prestadas ? '<span class="etiqueta azul">' + prestadas + ' prest.</span>' : '') +
      (fuera ? '<span class="etiqueta ambar">' + fuera + ' fuera de uso</span>' : '') + '</button></li>';
  }

  function renderLugarLista(lugar) {
    const muebles = N.mueblesDe(datos(), lugar.id).slice().sort((a, b) => a.nombre.localeCompare(b.nombre, 'es', { numeric: true }));
    const directos = N.articulosEnLugar(datos(), lugar.id);
    let html = '';
    if (!muebles.length && !directos.length) {
      html += '<div class="estado-vacio"><h2>«' + e(lugar.nombre) + '» está vacío</h2><p>Agrega artículos con «+»' +
        (lugar.plano ? ', o cambia a 2.5D para colocar muebles.' : '. Si quieres acomodar muebles, créale un plano.') + '</p>' +
        '<button type="button" class="boton principal" data-nuevo-aqui>Agregar un artículo aquí</button></div>';
    }
    if (directos.length) {
      html += '<section class="grupo"><h2>Directo en el lugar <small>sin mueble</small></h2><ul class="lista-toque">' +
        directos.map(filaArticulo).join('') + '</ul></section>';
    }
    // Objetos 3D del piso (figuras y piezas dibujadas): también se ven aquí, como datos
    const enPiso = N.objetosEnPiso(datos(), lugar.id);
    if (enPiso.length) {
      html += '<section class="grupo"><h2>Objetos 3D en el piso <small>' + N.plural(enPiso.length, 'objeto') + '</small></h2><ul class="lista-toque">' +
        enPiso.map((o) => {
          const articulo = o.articuloId ? N.buscarPorId(datos().articulos, o.articuloId) : null;
          return '<li><button type="button" data-objeto="' + e(o.id) + '"' + (estado.editor.seleccion.includes(o.id) ? ' class="resaltado"' : '') + '>' +
            '<span class="nombre"><strong>' + e(N.nombreDeObjeto(datos(), o)) + '</strong><small>' + e(N.FIGURAS_OBJETO[o.figura].nombre) + ' · ' +
            o.medidas.ancho + ' × ' + o.medidas.fondo + ' × ' + o.medidas.alto + ' m</small></span>' +
            '<span class="cantidad">' + (articulo ? '×' + (o.unidades || 1) : '') + '</span>' +
            (articulo ? '<span class="etiqueta azul">Inventario</span>' : '<span class="etiqueta">Figura</span>') + '</button></li>';
        }).join('') + '</ul></section>';
    }
    muebles.forEach((mueble) => {
      const articulos = N.articulosDe(datos(), mueble.id);
      const fijos = N.objetosEnMueble(datos(), mueble.id).length;
      const sinColocar = lugar.plano && !N.estaColocado(mueble);
      html += '<section class="grupo' + (mueble.id === estado.seleccionadoId ? ' seleccionado' : '') + '" data-grupo="' + e(mueble.id) + '">' +
        '<h2><button type="button" class="titulo-mueble" data-mueble="' + e(mueble.id) + '">' + e(mueble.nombre) + '</button> <small>' +
        e(N.TIPOS_MUEBLE[mueble.tipo].nombre) + (sinColocar ? ' · sin colocar' : '') + ' · ' + N.plural(N.piezasEnMueble(datos(), mueble.id), 'pieza') +
        (fijos ? ' · ' + N.plural(fijos, 'objeto 3D', 'objetos 3D') : '') + '</small></h2>' +
        (articulos.length ? '<ul class="lista-toque">' + articulos.map(filaArticulo).join('') + '</ul>' : '<p class="nota">No guarda nada todavía.</p>') +
        '</section>';
    });
    $('lugarLista').innerHTML = html;
    const marcado = $('lugarLista').querySelector('.resaltado, .seleccionado');
    if (marcado && marcado.scrollIntoView) marcado.scrollIntoView({ block: 'nearest' });
  }

  $('lugarLista').addEventListener('click', (evento) => {
    if (evento.target.closest('[data-nuevo-aqui]')) U.abrirHoja(() => U.pantallaNuevoArticulo('l:' + estado.lugarId));
    const articulo = evento.target.closest('[data-articulo]');
    if (articulo) U.abrirArticulo(articulo.dataset.articulo, true);
    const mueble = evento.target.closest('[data-mueble]');
    if (mueble) U.seleccionar(mueble.dataset.mueble, { abrir: true });
    const objeto = evento.target.closest('[data-objeto]');
    if (objeto) U.seleccionarObjetos([objeto.dataset.objeto], { panel: true });
  });

  function renderLugar() {
    const lugar = U.lugarAbierto();
    const vista = vistaActual();
    const sala = salaDe(lugar);
    const presentacion = document.body.classList.contains('presentacion');
    // Selector Lista / 2.5D / 3D
    $('selectorVista').querySelectorAll('[data-vista-lugar]').forEach((boton) => {
      const clave = boton.dataset.vistaLugar;
      boton.setAttribute('aria-selected', String(clave === vista));
      boton.classList.toggle('sin-plano', clave !== 'lista' && !sala);
      boton.title = clave !== 'lista' && !sala ? 'Este lugar no tiene plano: toca para crearlo' : '';
    });
    $('avisoSinPlano').hidden = Boolean(sala);
    $('lugarLista').hidden = vista !== 'lista';
    $('escenario').hidden = vista === 'lista';
    $('lienzo').hidden = vista !== '2.5d';
    $('lienzo3d').hidden = vista !== '3d';
    $('paleta').hidden = vista === 'lista' || presentacion;
    if (vista === 'lista') {
      renderLugarLista(lugar);
      return;
    }
    if (vista === '3d') prepararEscena3d();
    else $('cargando3d').hidden = true;

    // Paleta: un botón por tipo de mueble
    if (!$('paleta').children.length) {
      $('paleta').innerHTML = Object.keys(N.TIPOS_MUEBLE).map((clave) =>
        '<button type="button" data-tipo="' + clave + '" aria-pressed="false">' + U.iconoMueble(clave) +
        N.TIPOS_MUEBLE[clave].nombre + '</button>').join('');
    }
    $('paleta').querySelectorAll('button').forEach((boton) => {
      const elegido = estado.modo && estado.modo.tipo === 'colocar' && estado.modo.mueble === boton.dataset.tipo;
      boton.setAttribute('aria-pressed', String(Boolean(elegido)));
    });

    // Muebles que están en este lugar pero no en el plano
    const pendientes = N.mueblesDe(datos(), lugar.id).filter((mueble) => !N.estaColocado(mueble));
    $('sinColocar').innerHTML = pendientes.length && !presentacion
      ? '<span>Sin colocar:</span><button type="button" class="chip acento" data-auto>Acomodar todos</button>' + pendientes.map((mueble) => '<button type="button" class="chip" data-colocar="' + e(mueble.id) + '"' +
        (estado.modo && estado.modo.muebleId === mueble.id ? ' aria-pressed="true"' : '') + '>' + e(mueble.nombre) + '</button>').join('')
      : '';

    // Indicación: solo aparece cuando hay algo que hacer (no ocupa la pantalla todo el tiempo)
    let texto = '';
    if (estado.modo && estado.modo.tipo === 'colocar') {
      texto = 'Toca el piso para poner: ' + N.TIPOS_MUEBLE[estado.modo.mueble].nombre;
      $('botonTerminarModo').textContent = 'Listo';
    } else if (estado.modo && estado.modo.tipo === 'mover') {
      const mueble = N.buscarPorId(datos().muebles, estado.modo.muebleId);
      texto = 'Toca la casilla a donde va «' + (mueble ? mueble.nombre : '') + '»';
      $('botonTerminarModo').textContent = 'Cancelar';
    } else if (!N.mueblesDe(datos(), lugar.id).length) {
      texto = 'Elige un mueble abajo y toca el piso para colocarlo.';
    }
    $('textoIndicacion').textContent = texto;
    $('indicacion').hidden = !texto || presentacion;
    $('botonTerminarModo').hidden = !estado.modo;

    $('lienzo').setAttribute('aria-label', 'Plano de ' + lugar.nombre + ': ' +
      N.plural(N.mueblesColocados(datos(), lugar.id).length, 'mueble') + '. Para leerlo en texto usa la vista Lista.');
    renderSeleccion();
    U.redibujarEscenas();
  }

  // Controles compartidos por 2.5D y 3D
  const conEscena = (accion) => () => {
    const activa = U.escenaActiva();
    if (activa) accion(activa);
  };
  $('botonGirar').addEventListener('click', conEscena((activa) => activa.girar()));
  $('botonAcercar').addEventListener('click', conEscena((activa) => activa.acercar(1.35)));
  $('botonAlejar').addEventListener('click', conEscena((activa) => activa.acercar(1 / 1.35)));
  $('botonCentrar').addEventListener('click', conEscena((activa) => activa.centrar()));
  $('botonPresentar').addEventListener('click', () => U.presentacion(!document.body.classList.contains('presentacion')));
  $('botonSalirPresentacion').addEventListener('click', () => U.presentacion(false));
  $('botonTerminarModo').addEventListener('click', () => {
    estado.modo = null;
    U.render();
  });

  // Modo presentación: solo la escena, sin herramientas de edición (para proyectar)
  U.presentacion = (activar) => {
    document.body.classList.toggle('presentacion', activar);
    if (activar) {
      estado.modo = null;
      U.cerrarHojas();
    }
    U.render();
    setTimeout(() => {
      escena.ajustarTamano();
      if (U.escena3d) U.escena3d.ajustarTamano();
    }, 60);
  };

  $('paleta').addEventListener('click', (evento) => {
    const boton = evento.target.closest('button[data-tipo]');
    if (!boton) return;
    const tipo = boton.dataset.tipo;
    const yaElegido = estado.modo && estado.modo.tipo === 'colocar' && estado.modo.mueble === tipo;
    estado.modo = yaElegido ? null : { tipo: 'colocar', mueble: tipo };
    // Al empezar a colocar se suelta la selección: el mueble abierto se cierra y no estorba
    if (estado.modo && estado.seleccionadoId) {
      estado.seleccionadoId = null;
      estado.articuloResaltadoId = null;
      U.cerrarHojas();
    }
    U.render();
    U.redibujarEscenas();
  });

  $('sinColocar').addEventListener('click', (evento) => {
    if (evento.target.closest('[data-auto]')) {
      U.abrirHojaUnica(() => U.pantallaAutoOrdenar(estado.lugarId));
      return;
    }
    const boton = evento.target.closest('[data-colocar]');
    if (!boton) return;
    estado.modo = { tipo: 'mover', muebleId: boton.dataset.colocar };
    U.render();
  });

  // =====================================================================
  // PRÉSTAMOS
  // =====================================================================
  function renderPrestamos() {
    const fecha = U.hoy();
    const activos = N.prestamosActivos(datos(), fecha);
    const historial = N.historialPrestamos(datos());
    const verActivos = estado.filtroPrestamos === 'activos';
    let html = '<div class="segmentos" role="group" aria-label="Qué préstamos ver">' +
      '<button type="button" data-filtro="activos" aria-pressed="' + verActivos + '">Activos (' + activos.length + ')</button>' +
      '<button type="button" data-filtro="historial" aria-pressed="' + !verActivos + '">Devueltos (' + historial.length + ')</button></div>';
    const lista = verActivos ? activos : historial;
    if (!lista.length) {
      html += '<div class="estado-vacio"><h2>' + (verActivos ? 'No hay préstamos activos' : 'Aún no hay devoluciones') + '</h2><p>' +
        (verActivos ? 'Para prestar algo, abre un artículo en el Inventario y toca «Prestar».' : 'Aquí aparecerán los préstamos ya devueltos.') +
        '</p>' + (verActivos ? '<button type="button" class="boton principal" data-ir-inventario>Ir al inventario</button>' : '') + '</div>';
    }
    html += '<div class="rejilla-prestamos">' + lista.map((prestamo) => {
      const situacion = N.estadoPrestamo(prestamo, fecha);
      const sitio = N.ubicacion(datos(), prestamo.articuloId);
      const origen = sitio.articulo ? N.textoUbicacion(sitio.lugar, sitio.mueble) : prestamo.origen;
      return '<article class="tarjeta' + (situacion === 'vencido' ? ' vencido' : '') + '">' +
        '<h3>' + e(prestamo.articuloNombre) + ' <span class="cantidad">×' + prestamo.cantidad + '</span></h3>' +
        '<p class="detalle"><strong>' + e(prestamo.persona) + '</strong>' + (prestamo.grupo ? ' · ' + e(prestamo.grupo) : '') + '</p>' +
        '<p class="detalle">De: ' + e(origen) + ' · salió el ' + e(N.fechaCorta(prestamo.fechaSalida, fecha)) + '</p>' +
        (prestamo.nota ? '<p class="detalle">Nota: ' + e(prestamo.nota) + '</p>' : '') +
        (situacion === 'devuelto'
          ? '<span class="etiqueta verde">✓ Devuelto el ' + e(N.fechaCorta(prestamo.devuelto, fecha)) +
            (prestamo.devueltasDanadas ? ' (' + N.plural(prestamo.devueltasDanadas, 'dañada') + ')' : '') + '</span>'
          : '<span class="etiqueta ' + (situacion === 'vencido' ? 'rojo">⚠ ' : 'azul">') + e(N.textoVencimiento(prestamo, fecha)) + '</span>' +
            '<div class="fila-botones"><button type="button" class="boton principal chico" data-devolver="' + e(prestamo.id) +
            '">Registrar devolución</button>' + (sitio.articulo ? '<button type="button" class="boton chico" data-ver="' +
            e(prestamo.articuloId) + '">Ver artículo</button>' : '') + '</div>') +
        '</article>';
    }).join('') + '</div>';
    $('vistaPrestamos').innerHTML = html;
  }

  $('vistaPrestamos').addEventListener('click', (evento) => {
    const filtro = evento.target.closest('[data-filtro]');
    if (filtro) {
      estado.filtroPrestamos = filtro.dataset.filtro;
      renderPrestamos();
      return;
    }
    if (evento.target.closest('[data-ir-inventario]')) U.irASeccion('inventario');
    const devolver = evento.target.closest('[data-devolver]');
    if (devolver) U.abrirHojaUnica(() => U.pantallaDevolver(devolver.dataset.devolver));
    const ver = evento.target.closest('[data-ver]');
    if (ver) U.abrirArticulo(ver.dataset.ver, true);
  });

  // =====================================================================
  // MÁS
  // =====================================================================
  function renderMas() {
    const r = N.resumen(datos(), U.hoy());
    const version = window.APP_VERSION && window.APP_VERSION.numero;
    const boton = (accion, icono, titulo, detalle, simple) => '<button type="button" class="opcion" data-mas="' + accion + '"' +
      (simple ? ' data-simple="' + simple + '"' : '') + '>' + ICONOS[icono] +
      '<span><strong>' + titulo + '</strong><small>' + detalle + '</small></span></button>';
    const encendidos = U.LISTA_AJUSTES.filter(([clave, , grupo]) => grupo === 'Simplificar' && U.ajustes[clave]).length;
    $('vistaMas').innerHTML =
      '<div class="cifras resumen"><div class="cifra"><strong>' + r.articulos + '</strong><span>artículos</span></div>' +
      '<div class="cifra"><strong>' + r.piezas + '</strong><span>piezas</span></div>' +
      '<div class="cifra"><strong>' + r.lugares + '</strong><span>lugares</span></div>' +
      '<div class="cifra"><strong>' + r.piezasPrestadas + '</strong><span>prestadas</span></div></div>' +
      '<h2>Inventario</h2><div class="opciones">' +
      boton('categorias', 'etiqueta', 'Categorías', N.plural(datos().categorias.length, 'categoría'), 'categorias') +
      boton('historial', 'reloj', 'Historial de movimientos', 'Altas, préstamos, cambios y bajas', 'avanzado') +
      boton('csv', 'excel', 'Exportar para Excel', 'Archivo .csv con todo el inventario', 'avanzado') +
      boton('configuracion', 'editar', 'Configuración', encendidos ? N.plural(encendidos, 'simplificación', 'simplificaciones') + ' encendida' + (encendidos === 1 ? '' : 's') : 'Simplifica la app a tu gusto') + '</div>' +
      '<h2>Tus datos</h2><div class="opciones">' +
      boton('respaldo', 'guardar', 'Guardar respaldo', U.textoUltimoRespaldo()) +
      boton('restaurar', 'abrir', 'Restaurar un respaldo', 'Reemplaza lo actual (antes se guarda una copia)') +
      boton('copias', 'reloj', 'Copias de seguridad automáticas', 'Hasta ' + N.MAXIMO_COPIAS + ' en este dispositivo') +
      boton('basedatos', 'tabla', 'Ver la base de datos', 'IndexedDB en crudo: esquema y registros en JSON', 'avanzado') +
      (N.estaVacio(datos()) ? boton('ejemplo', 'estrella', 'Cargar el ejemplo', 'Un almacén, un laboratorio y una oficina de muestra')
        : boton('vaciar', 'borrar', 'Empezar de cero', 'Borra todo (antes se guarda una copia)')) + '</div>' +
      '<h2>Ubica</h2><div class="opciones">' + boton('novedades', 'estrella', 'Novedades', 'Qué cambió en cada versión') + '</div>' +
      '<p class="nota">Tus datos se guardan solo en este dispositivo. Guarda un respaldo de vez en cuando: si desinstalas la app o borras ' +
      'los datos del navegador, se pierden.</p>' +
      (U.convieneInstalarEnIphone() ? '<p class="nota"><strong>En iPhone:</strong> añade Ubica a la pantalla de inicio ' +
        '(Compartir → «Añadir a pantalla de inicio») para que Safari no borre sus datos.</p>' : '') +
      '<p class="nota">Versión ' + e(version || 'en desarrollo') + ' · Funciona sin internet.</p>';
  }

  $('vistaMas').addEventListener('click', (evento) => {
    const boton = evento.target.closest('[data-mas]');
    if (!boton) return;
    const acciones = {
      categorias: () => U.abrirHojaUnica(U.pantallaCategorias),
      historial: () => U.abrirHojaUnica(U.pantallaHistorialGeneral),
      csv: U.exportarCSV,
      respaldo: U.guardarRespaldo,
      restaurar: () => $('elegirRespaldo').click(),
      copias: U.abrirCopias,
      basedatos: U.abrirBaseDatos,
      configuracion: () => U.abrirHojaUnica(U.pantallaConfiguracion),
      ejemplo: U.cargarEjemplo,
      vaciar: () => U.abrirHojaUnica(U.pantallaVaciar),
      novedades: () => U.abrirHojaUnica(U.pantallaNovedades)
    };
    acciones[boton.dataset.mas]();
  });

  // =====================================================================
  // RENDER GENERAL
  // =====================================================================
  const TITULOS = { inventario: 'Inventario', lugares: 'Lugares', prestamos: 'Préstamos', mas: 'Más' };

  U.render = () => {
    if (!estado.listo) return;
    if (estado.lugarId && !U.lugarAbierto()) {
      estado.lugarId = null; // el lugar abierto se borró
      estado.modo = null;
      estado.seleccionadoId = null;
    }
    if (estado.seleccionadoId && !N.buscarPorId(datos().muebles, estado.seleccionadoId)) estado.seleccionadoId = null;
    const lugar = estado.seccion === 'lugares' ? U.lugarAbierto() : null;
    const pantalla = lugar ? 'lugar' : estado.seccion;
    document.body.dataset.pantalla = pantalla;
    ['inventario', 'lugares', 'lugar', 'prestamos', 'mas'].forEach((nombre) => {
      $('vista' + nombre.charAt(0).toUpperCase() + nombre.slice(1)).hidden = nombre !== pantalla;
    });
    document.querySelectorAll('#navegacion [data-seccion]').forEach((boton) => {
      if (boton.dataset.seccion === estado.seccion) boton.setAttribute('aria-current', 'page');
      else boton.removeAttribute('aria-current');
    });

    // Barra superior: dónde estoy y la acción principal de esta pantalla
    const r = N.resumen(datos(), U.hoy());
    $('botonAtras').hidden = !lugar;
    $('titulo').textContent = lugar ? lugar.nombre : TITULOS[estado.seccion];
    const subtitulos = {
      inventario: N.plural(r.articulos, 'artículo') + ' · ' + N.plural(r.piezas, 'pieza'),
      lugares: N.plural(r.lugares, 'lugar', 'lugares') + (r.sinUbicacion ? ' · ' + r.sinUbicacion + ' sin ubicación' : ''),
      prestamos: N.plural(r.prestamosActivos, 'activo') + (r.vencidos ? ' · ' + N.plural(r.vencidos, 'vencido') : ''),
      mas: 'Categorías, historial y respaldos',
      lugar: lugar ? N.TIPOS_LUGAR[lugar.tipo].nombre + ' · ' + N.plural(N.piezasEnLugar(datos(), lugar.id), 'pieza') : ''
    };
    $('subtitulo').textContent = subtitulos[pantalla];
    const accion = (clave, icono, texto, principal) => '<button type="button" class="boton chico' + (principal ? ' principal' : '') +
      '" data-barra="' + clave + '" aria-label="' + texto + '">' + ICONOS[icono] + '<span class="texto-boton">' + texto + '</span></button>';
    $('accionesBarra').innerHTML = {
      inventario: N.estaVacio(datos()) ? '' : accion('articulo', 'mas', 'Artículo', true),
      lugares: accion('lugar', 'mas', 'Lugar', true),
      lugar: accion('borrarLugar', 'borrar', 'Borrar lugar', false).replace('boton chico', 'boton chico peligro') +
        accion('editarLugar', 'editar', 'Editar lugar', false) + accion('articuloAqui', 'mas', 'Artículo', true),
      prestamos: '',
      mas: ''
    }[pantalla];

    const contador = $('contadorVencidos');
    contador.hidden = r.vencidos === 0;
    contador.textContent = String(r.vencidos);
    contador.setAttribute('aria-label', N.plural(r.vencidos, 'préstamo vencido', 'préstamos vencidos'));

    if (pantalla === 'inventario') renderInventario();
    if (pantalla === 'lugares') renderLugares();
    if (pantalla === 'lugar') renderLugar();
    if (pantalla === 'prestamos') renderPrestamos();
    if (pantalla === 'mas') renderMas();
    U.alCambiarPaneles();
  };

  $('accionesBarra').addEventListener('click', (evento) => {
    const boton = evento.target.closest('[data-barra]');
    if (!boton) return;
    const accion = boton.dataset.barra;
    if (accion === 'articulo') U.abrirHojaUnica(() => U.pantallaNuevoArticulo(estado.filtros.lugar && estado.filtros.lugar !== 'sin' ? 'l:' + estado.filtros.lugar : 'sin'));
    if (accion === 'lugar') U.abrirHojaUnica(() => U.pantallaLugar(null));
    if (accion === 'editarLugar') U.abrirHojaUnica(() => U.pantallaLugar(estado.lugarId));
    if (accion === 'borrarLugar') U.abrirHojaUnica(() => U.pantallaBorrarLugar(estado.lugarId));
    if (accion === 'articuloAqui') {
      const mueble = estado.seleccionadoId ? N.buscarPorId(datos().muebles, estado.seleccionadoId) : null;
      U.abrirHojaUnica(() => U.pantallaNuevoArticulo(mueble ? 'm:' + mueble.id : 'l:' + estado.lugarId));
    }
  });
  $('avisoSinPlano').addEventListener('click', (evento) => {
    if (evento.target.closest('[data-auto]')) U.abrirHojaUnica(() => U.pantallaAutoOrdenar(estado.lugarId));
    else if (evento.target.closest('button')) U.abrirHoja(() => U.pantallaLugar(estado.lugarId, { conPlano: true }));
  });
})();
