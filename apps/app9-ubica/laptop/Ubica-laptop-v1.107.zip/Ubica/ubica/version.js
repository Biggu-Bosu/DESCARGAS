window.APP_VERSION = { numero: '1.107', fecha: '2026-11-13', commit: '74ffa8f' };
