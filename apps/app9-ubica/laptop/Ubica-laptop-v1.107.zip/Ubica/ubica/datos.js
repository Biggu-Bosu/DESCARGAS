// Ubica · Tus datos: respaldo en archivo, copias automáticas, Excel, base de datos, ejemplo,
// revisión al abrir y actualización de datos de versiones anteriores.
(function () {
  'use strict';

  const U = window.Ubica;
  const { N, BD, e, $, estado } = U;
  const { cabeza, abrirHoja, cerrarHojas } = U;
  const CLAVE_RESPALDO = 'ubica.ultimoRespaldo';   // día del último respaldo en archivo
  const CLAVE_DESDE = 'ubica.conDatosDesde';       // primer día en que hubo datos
  const CLAVE_RECORDADO = 'ubica.recordatorio';    // último día en que se recordó respaldar
  const DIAS_SIN_RESPALDO = 14;

  // =====================================================================
  // RESPALDO EN ARCHIVO Y EXCEL
  // =====================================================================
  async function compartir(contenido, tipo, nombre, titulo, mensaje) {
    const resultado = await window.Compartir.compartirArchivo(new Blob([contenido], { type: tipo }), nombre, titulo);
    if (resultado === 'compartido') U.avisar(mensaje);
    else if (resultado === 'error') U.avisar('No se pudo compartir el archivo en este dispositivo.');
    return resultado;
  }

  U.guardarRespaldo = async () => {
    const texto = JSON.stringify(N.crearRespaldo(estado.datos), null, 2);
    const resultado = await compartir(texto, 'application/json', 'ubica-respaldo-' + U.hoy() + '.json', 'Respaldo de Ubica', 'Respaldo listo');
    if (resultado === 'compartido') {
      U.guardarClave(CLAVE_RESPALDO, U.hoy());
      U.render();
    }
  };

  // Salida de emergencia: los datos tal como están en la base (sirve aunque la app no pueda abrirla)
  async function guardarRespaldoDeEmergencia() {
    try {
      const respaldo = await BD.exportarEmergencia();
      return compartir(JSON.stringify(respaldo, null, 2), 'application/json', 'ubica-respaldo-sin-cambios-' + U.hoy() + '.json',
        'Respaldo de Ubica (sin cambios)', 'Respaldo listo');
    } catch (error) {
      console.error(error);
      U.avisar('No se pudieron leer los datos para el respaldo.');
      return 'error';
    }
  }

  U.exportarCSV = () => compartir(N.inventarioCSV(estado.datos), 'text/csv', 'ubica-inventario-' + U.hoy() + '.csv',
    'Inventario de Ubica', 'Lista para Excel lista');

  function diasSinRespaldo() {
    const ultimo = U.leerClave(CLAVE_RESPALDO);
    return N.leerFechaISO(ultimo) ? N.diasEntre(ultimo, U.hoy()) : null;
  }

  U.textoUltimoRespaldo = () => {
    const dias = diasSinRespaldo();
    if (dias === null) return 'Aún no has guardado ninguno';
    if (dias <= 0) return 'Último respaldo: hoy';
    return 'Último respaldo: hace ' + N.plural(dias, 'día');
  };

  // Safari en iPhone/iPad sin instalar: ahí los datos de una página pueden borrarse solos
  U.convieneInstalarEnIphone = () => {
    const esApple = /iphone|ipad|ipod/i.test(navigator.userAgent);
    return esApple && !navigator.standalone && !window.Compartir.esNativa();
  };

  // ---------- Reemplazar todo el inventario, dejando antes una copia de seguridad ----------
  // La copia de lo que había se guarda en la MISMA transacción que el reemplazo.
  async function reemplazarInventario(nuevos, motivoCopia, detalle) {
    const hecho = await U.conCandado(async () => {
      const momento = new Date().toISOString();
      const datos = N.clonar(nuevos);
      if (motivoCopia) {
        const tipo = motivoCopia === 'antes-de-reparar' ? 'reparacion-datos' : 'restauracion';
        datos.movimientos.push(N.movimientoGeneral(tipo, momento, Object.assign({ motivo: motivoCopia }, detalle || {})));
      }
      try {
        let copia = null;
        let sobran = [];
        if (motivoCopia && !N.estaVacio(estado.datos)) {
          copia = N.crearCopia(estado.datos, motivoCopia, momento, U.hoy());
          sobran = N.copiasQueSobran(await BD.leerCopias(), 1);
        }
        await BD.reemplazarTodo(datos, copia, sobran);
      } catch (error) {
        console.error(error);
        return false;
      }
      estado.datos = datos;
      estado.version++;
      estado.lugarId = null;
      estado.modo = null;
      estado.seleccionadoId = null;
      estado.filasVisibles = U.FILAS_POR_TANDA;
      Object.assign(estado.filtros, { texto: '', categoriaId: '', estado: '', lugar: '' });
      return true;
    });
    if (hecho) {
      cerrarHojas();
      U.render();
    }
    return Boolean(hecho);
  }

  $('elegirRespaldo').addEventListener('change', async (evento) => {
    const archivo = evento.target.files[0];
    evento.target.value = ''; // para poder elegir el mismo archivo otra vez
    if (!archivo) return;
    if (archivo.size > 20 * 1024 * 1024) {
      U.avisar('El archivo es demasiado grande para ser un respaldo de Ubica.');
      return;
    }
    let objeto;
    try {
      objeto = JSON.parse(await archivo.text());
    } catch (error) {
      U.avisar('El archivo no es un respaldo de Ubica.');
      return;
    }
    const revision = N.prepararDatos(objeto, { hoy: U.hoy() });
    if (!revision.ok) {
      U.avisar(revision.error);
      return;
    }
    const nuevo = revision.datos;
    const piezas = nuevo.articulos.reduce((suma, articulo) => suma + N.totalDe(articulo), 0);
    U.abrirHojaUnica(() => ({
      html: cabeza('Restaurar respaldo', archivo.name) +
        '<p>El respaldo tiene ' + N.plural(nuevo.lugares.length, 'lugar', 'lugares') + ', ' + N.plural(nuevo.muebles.length, 'mueble') +
        ', ' + N.plural(nuevo.articulos.length, 'artículo') + ' (' + N.plural(piezas, 'pieza') + ') y ' + N.plural(nuevo.prestamos.length, 'préstamo') + '.' +
        (revision.formatoOriginal < 2 ? ' Es de una versión anterior: se convierte al formato actual.' : '') + '</p>' +
        listaHallazgos(revision.hallazgos) +
        (!N.estaVacio(estado.datos) ? '<p><strong>Se reemplazará todo lo que hay ahora en Ubica.</strong> Antes se guarda ' +
          'sola una copia de seguridad de lo actual, por si te equivocas de archivo.</p>' : '') +
        '<div class="fila-botones"><button type="button" class="boton" data-accion="cerrar">Cancelar</button>' +
        '<button type="button" class="boton principal" data-accion="restaurar">Restaurar</button></div>',
      acciones: {
        restaurar: async () => {
          if (await reemplazarInventario(nuevo, 'antes-de-restaurar', { hallazgos: revision.hallazgos.length })) U.avisar('Respaldo restaurado');
          else U.avisar('No se pudo restaurar. Tus datos anteriores siguen igual.');
        }
      }
    }));
  });

  // ---------- Ejemplo y empezar de cero ----------
  U.cargarEjemplo = async () => {
    if (!N.estaVacio(estado.datos)) return;
    if (!(await reemplazarInventario(N.datosDeEjemplo(U.hoy()), null))) {
      U.avisar('No se pudo guardar el ejemplo.');
      return;
    }
    U.avisar('Ejemplo cargado. Explora el Inventario o abre un lugar en «Lugares».');
  };

  U.pantallaVaciar = () => {
    const r = N.resumen(estado.datos, U.hoy());
    return {
      html: cabeza('¿Empezar de cero?') +
        '<p>Se borrarán ' + N.plural(r.articulos, 'artículo') + ', ' + N.plural(r.lugares, 'lugar', 'lugares') + ', ' +
        N.plural(r.muebles, 'mueble') + ' y los préstamos. Las categorías se conservan.</p>' +
        '<p><strong>Antes se guarda sola una copia de seguridad</strong>: podrás recuperarla en «Copias de seguridad automáticas».</p>' +
        '<div class="fila-botones"><button type="button" class="boton" data-accion="cerrar">Cancelar</button>' +
        '<button type="button" class="boton peligro-lleno" data-accion="vaciar">Sí, borrar todo</button></div>',
      acciones: {
        vaciar: async () => {
          const vacio = N.datosVacios();
          vacio.categorias = N.clonar(estado.datos.categorias);
          if (await reemplazarInventario(vacio, 'antes-de-restaurar', { vaciado: true })) U.avisar('Inventario vacío. Se guardó una copia de lo anterior.');
          else U.avisar('No se pudo borrar. Tus datos siguen igual.');
        }
      }
    };
  };

  // =====================================================================
  // COPIAS DE SEGURIDAD AUTOMÁTICAS
  // =====================================================================
  U.abrirCopias = async () => {
    try {
      const copias = N.copiasOrdenadas(await BD.leerCopias());
      U.abrirHojaUnica(() => pantallaCopias(copias));
    } catch (error) {
      U.avisar('No se pudieron leer las copias de seguridad.');
    }
  };

  // Las copias de versiones anteriores dicen «espacios» en lugar de «lugares»
  function textoResumen(resumen) {
    const lugares = resumen.lugares != null ? resumen.lugares : resumen.espacios || 0;
    return N.plural(lugares, 'lugar', 'lugares') + ', ' + N.plural(resumen.muebles, 'mueble') + ', ' +
      N.plural(resumen.piezas, 'pieza') + ' y ' + N.plural(resumen.prestamos, 'préstamo');
  }

  function pantallaCopias(copias) {
    return {
      html: cabeza('Copias de seguridad', 'Ubica guarda sola hasta ' + N.MAXIMO_COPIAS + ' copias en este dispositivo') +
        '<p class="nota">Sirven para regresar si algo sale mal. Se hace una al día si hubo cambios y otra antes de restaurar, ' +
        'vaciar o actualizar. <strong>No sustituyen al respaldo en archivo.</strong></p>' +
        (copias.length ? copias.map((copia) => '<article class="tarjeta"><h3>' + e(U.fechaYHora(copia.momento)) + '</h3>' +
          '<p class="detalle">' + e(N.MOTIVOS_COPIA[copia.motivo] || 'Copia') + '</p>' +
          '<p class="detalle">' + e(textoResumen(copia.resumen)) + '</p>' +
          '<div class="fila-botones"><button type="button" class="boton chico" data-accion="recuperar" data-id="' + e(copia.id) +
          '">Recuperar esta copia</button></div></article>').join('')
          : '<p class="vacio">Todavía no hay copias. La primera se hace sola cuando tengas datos.</p>'),
      acciones: {
        recuperar: (boton) => {
          const copia = copias.find((c) => c.id === boton.dataset.id);
          if (copia) abrirHoja(() => pantallaRecuperar(copia));
        }
      }
    };
  }

  // Lista de lo que la revisión ajusta (para restaurar, recuperar y reparar)
  function listaHallazgos(hallazgos) {
    if (!hallazgos.length) return '';
    return '<p>Al revisarlo encontramos ' + N.plural(hallazgos.length, 'cosa que se ajustará', 'cosas que se ajustarán') +
      ' (nada se borra salvo copias repetidas idénticas):</p><ul class="hallazgos">' +
      hallazgos.slice(0, 8).map((h) => '<li>' + e(h.texto) + '</li>').join('') + '</ul>' +
      (hallazgos.length > 8 ? '<p class="nota">…y ' + (hallazgos.length - 8) + ' más.</p>' : '');
  }

  function pantallaRecuperar(copia) {
    // La copia pasa por la misma revisión que un respaldo importado (también convierte las de formato 1)
    const revision = N.prepararDatos(copia.datos, { hoy: U.hoy() });
    if (!revision.ok) return { html: cabeza('No se puede recuperar') + '<p class="error">' + e(revision.error) + '</p>' };
    return {
      html: cabeza('¿Recuperar esta copia?', U.fechaYHora(copia.momento)) +
        '<p>La copia tiene ' + e(textoResumen(copia.resumen)) + '.</p>' + listaHallazgos(revision.hallazgos) +
        '<p><strong>Reemplazará lo que hay ahora.</strong> Antes se guarda una copia de lo actual, así que podrás regresar.</p>' +
        '<div class="fila-botones"><button type="button" class="boton" data-accion="volver">Cancelar</button>' +
        '<button type="button" class="boton principal" data-accion="recuperar">Recuperar</button></div>',
      acciones: {
        recuperar: async () => {
          if (await reemplazarInventario(revision.datos, 'antes-de-recuperar', { hallazgos: revision.hallazgos.length })) U.avisar('Copia recuperada');
          else U.avisar('No se pudo recuperar. Tus datos siguen igual.');
        }
      }
    };
  }

  // Al abrir la app: revisión de los datos, copia del día y recordatorio de respaldo
  U.revisarDatosAlAbrir = async () => {
    if (N.estaVacio(estado.datos)) return;
    if (!U.leerClave(CLAVE_DESDE)) U.guardarClave(CLAVE_DESDE, U.hoy());

    // 1) ¿Hay datos que no cumplen las reglas?
    const revision = N.revisarIntegridad(estado.datos, { hoy: U.hoy() });
    if (revision.problemas.length) {
      U.abrirHojaUnica(() => pantallaReparar(revision));
      return; // la copia diaria se hará después de decidir, en la próxima apertura
    }
    // 2) Copia automática del día (si hubo cambios)
    try {
      const copias = await BD.leerCopias();
      if (N.tocaCopiaDiaria(copias, estado.datos, U.hoy())) {
        const copia = N.crearCopia(estado.datos, 'diaria', new Date().toISOString(), U.hoy());
        await U.conCandado(() => BD.guardarCopia(copia, N.copiasQueSobran(copias, 1)));
      }
    } catch (error) {
      console.warn('No se pudo hacer la copia automática', error);
    }
    // 3) Recordatorio de respaldo en archivo (una vez al día como máximo)
    const dias = diasSinRespaldo();
    const diasConDatos = N.diasEntre(U.leerClave(CLAVE_DESDE) || U.hoy(), U.hoy());
    const toca = dias === null ? diasConDatos >= 3 : dias >= DIAS_SIN_RESPALDO;
    if (toca && U.leerClave(CLAVE_RECORDADO) !== U.hoy() && !U.pila.length) {
      U.guardarClave(CLAVE_RECORDADO, U.hoy());
      U.avisar(dias === null
        ? 'Aún no tienes un respaldo en archivo. Ve a Más → «Guardar respaldo».'
        : 'Hace ' + N.plural(dias, 'día') + ' que no guardas un respaldo. Ve a Más → «Guardar respaldo».');
    }
  };

  function pantallaReparar(revision) {
    const total = revision.problemas.length;
    return {
      html: cabeza('Encontramos ' + N.plural(total, 'dato por corregir', 'datos por corregir')) +
        '<p>Al abrir, Ubica revisa sus datos. Esto no cumple las reglas y así se resolvería:</p>' +
        '<ul class="hallazgos">' + revision.problemas.slice(0, 6).map((problema) => '<li>' + e(problema) + '</li>').join('') + '</ul>' +
        (total > 6 ? '<p class="nota">…y ' + (total - 6) + ' más.</p>' : '') +
        '<p>«Reparar» aplica esos cambios sin borrar artículos. <strong>Antes se guarda una copia de seguridad</strong> de todo como está ahora.</p>' +
        '<div class="fila-botones"><button type="button" class="boton" data-accion="cerrar">Ahora no</button>' +
        '<button type="button" class="boton principal" data-accion="reparar">Reparar</button></div>',
      acciones: {
        reparar: async () => {
          if (await reemplazarInventario(revision.datos, 'antes-de-reparar', { correcciones: revision.problemas })) {
            U.avisar('Datos reparados. Se guardó una copia de cómo estaban.');
          } else U.avisar('No se pudo reparar. Tus datos siguen igual.');
        }
      }
    };
  }

  // =====================================================================
  // NOVEDADES Y BASE DE DATOS
  // =====================================================================
  U.pantallaNovedades = () => {
    const version = window.APP_VERSION || {};
    return {
      html: cabeza('Novedades', version.numero ? 'Versión ' + version.numero + ' · ' + version.fecha : 'Versión en desarrollo') +
        (window.NOVEDADES || []).map((entrada) => '<div class="novedad"><h3>' + e(N.fechaCorta(entrada.fecha)) + ' ' +
          e(entrada.fecha.slice(0, 4)) + '</h3><ul>' + entrada.cambios.map((cambio) => '<li>' + e(cambio) + '</li>').join('') +
          '</ul></div>').join('')
    };
  };

  // ---------- Configuración ----------
  U.pantallaConfiguracion = () => {
    const grupos = [];
    U.LISTA_AJUSTES.forEach((ajuste) => {
      if (!grupos.includes(ajuste[2])) grupos.push(ajuste[2]);
    });
    const interruptor = ([clave, , , titulo, detalle]) =>
      '<label class="interruptor"><span><strong>' + e(titulo) + '</strong><small>' + e(detalle) + '</small></span>' +
      '<input type="checkbox" role="switch" data-ajuste="' + clave + '"' + (U.ajustes[clave] ? ' checked' : '') + '></label>';
    return {
      html: cabeza('Configuración', 'Solo cambia cómo se ve la app en este dispositivo') +
        grupos.map((grupo) => '<h3>' + e(grupo) + '</h3>' +
          (grupo === 'Simplificar' ? '<p class="nota fija">Apaga lo que no uses. No se borra ningún dato: al volver a encenderlo, todo sigue ahí.</p>' : '') +
          U.LISTA_AJUSTES.filter((ajuste) => ajuste[2] === grupo).map(interruptor).join('')).join('') +
        '<div class="fila-botones"><button type="button" class="boton chico" data-accion="todas">Simplificar todo</button>' +
        '<button type="button" class="boton chico" data-accion="ninguna">Mostrar todo</button></div>',
      acciones: {
        todas: () => cambiarSimplificaciones(true),
        ninguna: () => cambiarSimplificaciones(false)
      }
    };
  };

  function cambiarSimplificaciones(valor) {
    U.LISTA_AJUSTES.filter((ajuste) => ajuste[2] === 'Simplificar').forEach(([clave]) => { U.ajustes[clave] = valor; });
    U.cambiarAjuste('menosTexto', valor);
    U.refrescarHoja();
  }

  // Los interruptores guardan al momento
  document.getElementById('hoja').addEventListener('change', (evento) => {
    const interruptor = evento.target.closest('[data-ajuste]');
    if (interruptor) U.cambiarAjuste(interruptor.dataset.ajuste, interruptor.checked);
  });

  U.abrirBaseDatos = async () => {
    try {
      const info = await BD.describir();
      U.abrirHojaUnica(() => pantallaBaseDatos(info, ''));
    } catch (error) {
      U.avisar('No se pudo leer la base de datos.');
    }
  };

  // ---------- Visor crudo de la base de datos ----------
  // Muestra lo que hay en IndexedDB tal cual: el esquema (como el código que lo crea) y los
  // registros de cada tabla en JSON, sin adornos.
  function esquemaComoCodigo(info) {
    const lineas = ['// IndexedDB · base "' + info.nombre + '" · versión ' + info.version,
      'const pedido = indexedDB.open(' + JSON.stringify(info.nombre) + ', ' + info.version + ');', '',
      'pedido.onupgradeneeded = () => {', '  const db = pedido.result;'];
    info.tablas.forEach((tabla) => {
      lineas.push('', '  // ' + tabla.registros.length + ' registro' + (tabla.registros.length === 1 ? '' : 's'),
        '  const ' + tabla.nombre + ' = db.createObjectStore(' + JSON.stringify(tabla.nombre) + ', { keyPath: ' + JSON.stringify(tabla.llave) +
        (tabla.autoIncremento ? ', autoIncrement: true' : '') + ' });');
      (tabla.detalleIndices || []).forEach((indice) => {
        lineas.push('  ' + tabla.nombre + '.createIndex(' + JSON.stringify(indice.nombre) + ', ' + JSON.stringify(indice.campo) +
          ', { unique: ' + indice.unico + (indice.multiple ? ', multiEntry: true' : '') + ' });');
      });
    });
    lineas.push('};');
    return lineas.join('\n');
  }

  const LIMITE_CRUDO = 200;
  function pantallaBaseDatos(info, tablaElegida) {
    const tabla = info.tablas.find((t) => t.nombre === tablaElegida) || null; // null = esquema
    let codigo;
    let pie = '';
    if (!tabla) codigo = esquemaComoCodigo(info);
    else {
      codigo = '// db.transaction("' + tabla.nombre + '").objectStore("' + tabla.nombre + '").getAll()\n' +
        JSON.stringify(tabla.registros.slice(0, LIMITE_CRUDO), null, 2);
      if (tabla.registros.length > LIMITE_CRUDO) pie = 'Se muestran ' + LIMITE_CRUDO + ' de ' + tabla.registros.length + ' registros.';
    }
    const peso = info.tablas.reduce((suma, t) => suma + JSON.stringify(t.registros).length, 0);
    return {
      html: cabeza('Base de datos', 'IndexedDB «' + info.nombre + '» · versión ' + info.version + ' · ~' + Math.ceil(peso / 1024) + ' KB') +
        '<div class="chips-tablas" role="group" aria-label="Tablas">' +
        '<button type="button" class="chip" data-accion="tabla" data-tabla="" aria-pressed="' + !tabla + '">esquema</button>' +
        info.tablas.map((t) =>
          '<button type="button" class="chip" data-accion="tabla" data-tabla="' + t.nombre + '" aria-pressed="' + (t === tabla) + '">' +
          t.nombre + ' ' + t.registros.length + '</button>').join('') + '</div>' +
        '<pre class="crudo" tabindex="0" id="codigoBD">' + e(codigo) + '</pre>' +
        (pie ? '<p class="nota">' + pie + '</p>' : '') +
        '<div class="fila-botones"><button type="button" class="boton chico" data-accion="copiar">Copiar</button>' +
        '<button type="button" class="boton chico" data-accion="actualizar">Volver a leer</button></div>',
      acciones: {
        copiar: async () => {
          try {
            await navigator.clipboard.writeText(codigo);
            U.avisar('Copiado.');
          } catch (error) {
            U.avisar('No se pudo copiar. Selecciona el texto a mano.');
          }
        },
        tabla: (boton) => U.reemplazarHoja(() => pantallaBaseDatos(info, boton.dataset.tabla)),
        actualizar: async () => {
          const nueva = await BD.describir();
          U.reemplazarHoja(() => pantallaBaseDatos(nueva, tabla ? tabla.nombre : ''));
        }
      }
    };
  }

  // =====================================================================
  // INICIO Y ACTUALIZACIÓN DE LOS DATOS (MIGRACIÓN A LA VERSIÓN 3)
  // =====================================================================
  function pantallaCompleta(id) {
    document.body.dataset.pantalla = id;
    ['vistaInventario', 'vistaLugares', 'vistaLugar', 'vistaPrestamos', 'vistaMas', 'vistaError', 'vistaMigracion'].forEach((vista) => {
      $(vista).hidden = vista !== id;
    });
    $('titulo').textContent = 'Ubica';
    $('subtitulo').textContent = '';
    $('accionesBarra').innerHTML = '';
    $('botonAtras').hidden = true;
  }

  function mostrarErrorInicio(texto, conRespaldo) {
    $('textoError').textContent = texto;
    $('botonExportarEmergencia').hidden = !conRespaldo;
    pantallaCompleta('vistaError');
  }

  // Pantalla que explica la actualización y pide permiso cuando hay algo que corregir
  function mostrarMigracion(plan) {
    const a = plan.antes;
    const d = plan.despues;
    const fila = (que, antes, despues) => '<tr><th scope="row">' + que + '</th><td>' + antes + '</td><td>' + despues + '</td></tr>';
    $('contenidoMigracion').innerHTML =
      '<h2>Antes de actualizar tus datos</h2>' +
      '<p>Esta versión de Ubica organiza el inventario de otra forma: <strong>lugares</strong> (con plano opcional), ' +
      '<strong>artículos</strong> con categoría y estados, y un historial de movimientos. Tus artículos entran en la categoría «Otros».</p>' +
      '<p>Revisamos tus datos con las reglas nuevas y encontramos ' + N.plural(plan.hallazgos.length, 'cosa', 'cosas') +
      ' que hay que resolver. Así se resolverían (<strong>no se borra ningún registro</strong>):</p>' +
      '<ul class="hallazgos">' + plan.hallazgos.map((h) => '<li>' + e(h.texto) + '</li>').join('') + '</ul>' +
      '<table class="tabla-bd comparacion"><thead><tr><th></th><th scope="col">Ahora</th><th scope="col">Después</th></tr></thead><tbody>' +
      fila('Lugares', a.lugares, d.lugares) + fila('Muebles', a.muebles, d.muebles) + fila('Artículos', a.articulos, d.articulos) +
      fila('Piezas', a.piezas, d.piezas) + fila('Préstamos', a.prestamos, d.prestamos) + '</tbody></table>' +
      '<p class="nota">Al actualizar, Ubica guarda sola una copia de tus datos tal como están. ' +
      'Si prefieres, guarda también un respaldo en archivo antes. Si cierras la app sin decidir, tus datos no cambian.</p>';
    pantallaCompleta('vistaMigracion');
    $('botonActualizarDatos').onclick = async () => {
      $('botonActualizarDatos').disabled = true;
      BD.aprobarMigracion(plan.huella);
      await U.iniciar({ migracionAprobada: true });
      $('botonActualizarDatos').disabled = false;
    };
  }

  $('botonRespaldoMigracion').addEventListener('click', guardarRespaldoDeEmergencia);
  $('botonExportarEmergencia').addEventListener('click', guardarRespaldoDeEmergencia);

  U.iniciar = async (opciones) => {
    const aprobada = Boolean(opciones && opciones.migracionAprobada);
    let migro = false;
    try {
      // 1) ¿La base es de una versión anterior? Se revisa SIN cambiarla.
      if (!aprobada) {
        const info = await BD.inspeccionar();
        if (info.version >= 1 && info.version < BD.VERSION_SIN_CONVERSION) {
          const plan = N.planDeMigracion(info.crudos, info.version, { hoy: U.hoy() });
          if (!plan.comprobacion.ok) {
            console.error('Comprobación de la migración', plan.comprobacion);
            mostrarErrorInicio('No se pueden actualizar tus datos con seguridad. No se cambió nada. Descarga un respaldo y avísanos para revisarlo.', true);
            return;
          }
          if (plan.hallazgos.length) {
            mostrarMigracion(plan); // hay algo que corregir: la persona decide
            return;
          }
          BD.aprobarMigracion(plan.huella); // nada que corregir: se actualiza solo
          migro = true;
        }
      } else migro = true;
      // 2) Abrir (y, si se aprobó, migrar dentro de la misma transacción) y leer todo
      const leido = await BD.leerTodo();
      estado.datos = Object.assign(N.datosVacios(), leido);
      estado.version++;
    } catch (error) {
      console.error(error);
      const conRespaldo = error && ['version-nueva', 'migracion-cancelada', 'migracion-pendiente'].includes(error.codigo);
      mostrarErrorInicio((error && error.message) || 'Error desconocido.', conRespaldo);
      return;
    }
    estado.listo = true;
    U.render();
    if (migro && !N.estaVacio(estado.datos)) U.avisar('Datos actualizados a la versión nueva. Se guardó una copia de cómo estaban.');
    BD.pedirQueNoSeBorre();
    // La revisión de reglas recorre todo el inventario: se deja para después de pintar la pantalla
    setTimeout(U.revisarDatosAlAbrir, 250);
  };

  $('botonReintentar').addEventListener('click', () => U.iniciar());
})();
