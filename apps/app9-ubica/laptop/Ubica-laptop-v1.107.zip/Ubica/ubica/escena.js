// Ubica · Escena: dibuja el espacio en vista isométrica dentro de un <canvas> y entiende
// los toques. Las fórmulas (proyección, giro, orden de dibujo, gestos) están en nucleo.js,
// donde se prueban con node; aquí solo se usan para pintar y para responder al dedo.
//
// Cómo se dibuja (cada vez que algo cambia):
//   1. Se calcula el tamaño de las casillas para que la sala quepa (escalaParaSala).
//   2. Se aplica la cámara (zoom y desplazamiento) con setTransform del canvas.
//   3. Paredes del fondo → piso en cuadrícula → muebles de atrás hacia adelante.
//   4. Encima de todo, las etiquetas con el número de piezas (sin zoom, para que se lean).
(function (raiz) {
  'use strict';

  const N = raiz.Nucleo;
  const TRANSPARENCIA = 0.22; // opacidad de los muebles que tapan al que buscas

  // lienzo: el <canvas>. opciones.estado(): devuelve lo que hay que dibujar:
  //   { espacio, muebles, seleccionadoId, resaltados (Set), modo, piezas(muebleId), version }
  //   espacio: { id, nombre, tipo, ancho, fondo } (el plano del lugar) o null si no tiene plano.
  //   muebles: solo los COLOCADOS (los «sin colocar» no se dibujan).
  //   (version: número que cambia cada vez que cambian los datos)
  // opciones.alTocar({ casilla, mueble, objetoId }): un toque (no arrastre ni pellizco) en el lienzo.
  // opciones.alArrastrarMueble(muebleId, rect): se arrastró el mueble SELECCIONADO a otra casilla
  //   (rect en coordenadas del lugar). La escena solo avisa: quien guarda es la app.
  function crear(lienzo, opciones) {
    const ctx = lienzo.getContext('2d');
    const temaOscuro = raiz.matchMedia('(prefers-color-scheme: dark)');
    const gestos = N.crearGestos();

    let densidad = 1;  // píxeles reales por píxel CSS (2 o 3 en celulares)
    let anchoCss = 0;
    let altoCss = 0;
    let rotacion = 0;  // 0 a 3 cuartos de vuelta
    let camara = N.camaraInicial();
    let escala = null; // tamaño de las casillas del último dibujo
    let figuras = [];  // contorno de cada mueble dibujado, para saber cuál tocaste
    let huellas = [];  // contorno de cada objeto 3D del piso (su huella), para saber cuál tocaste
    let dibujoPendiente = false;
    // Orden de dibujo ya calculado: se reutiliza mientras no cambien los datos ni el giro
    let ordenGuardado = { clave: null, ordenados: [] };
    // Arrastre del mueble seleccionado: { id, puntero, inicio, origen (rect en vista), activo, vista, mundo, valido }
    let arrastre = null;

    // ---------- Tamaño ----------
    // El canvas tiene dos tamaños: el de CSS (lo que ocupa en la página) y el de sus
    // píxeles. Si no se multiplica por la densidad de la pantalla, el dibujo se ve borroso.
    function ajustarTamano() {
      const caja = lienzo.getBoundingClientRect();
      if (!caja.width || !caja.height) return;
      densidad = raiz.devicePixelRatio || 1;
      anchoCss = caja.width;
      altoCss = caja.height;
      lienzo.width = Math.round(anchoCss * densidad);
      lienzo.height = Math.round(altoCss * densidad);
      camara = N.limitarCamara(camara, anchoCss, altoCss);
      dibujar();
    }

    // Junta varios cambios en un solo dibujo por cuadro de animación (más fluido al pellizcar)
    function pedirDibujo() {
      if (dibujoPendiente) return;
      dibujoPendiente = true;
      raiz.requestAnimationFrame(dibujar);
    }

    // ---------- Colores ----------
    function colores() {
      const estilos = raiz.getComputedStyle(lienzo);
      const variable = (nombre) => estilos.getPropertyValue(nombre).trim();
      return {
        panel: variable('--panel'),
        texto: variable('--texto'),
        acento: variable('--acento'),
        resalte: variable('--resalte'),
        oscuro: temaOscuro.matches
      };
    }

    function hsl(tono, saturacion, luz) {
      return 'hsl(' + tono + ' ' + saturacion + '% ' + Math.max(4, Math.min(94, luz)) + '%)';
    }

    // ---------- Dibujo ----------
    function ponerCamara() {
      ctx.setTransform(densidad * camara.zoom, 0, 0, densidad * camara.zoom, densidad * camara.x, densidad * camara.y);
    }

    function punto(x, y, z) {
      return N.proyectar(x, y, z, escala);
    }

    function poligono(puntos) {
      const camino = new Path2D();
      camino.moveTo(puntos[0].x, puntos[0].y);
      for (let i = 1; i < puntos.length; i++) camino.lineTo(puntos[i].x, puntos[i].y);
      camino.closePath();
      return camino;
    }

    function linea(desde, hasta) {
      ctx.beginPath();
      ctx.moveTo(desde.x, desde.y);
      ctx.lineTo(hasta.x, hasta.y);
      ctx.stroke();
    }

    function dibujarSala(espacio, vista, color) {
      const tono = N.TIPOS_LUGAR[espacio.tipo].tono;
      const alto = N.ALTO_PARED;
      const luzPared = color.oscuro ? [27, 23] : [86, 80];
      const luzPiso = color.oscuro ? [21, 18] : [94, 90];

      // Paredes del fondo: la de la izquierda (x = 0) y la de atrás (y = 0)
      ctx.fillStyle = hsl(tono, 14, luzPared[0]);
      ctx.fill(poligono([punto(0, 0, 0), punto(0, vista.fondo, 0), punto(0, vista.fondo, alto), punto(0, 0, alto)]));
      ctx.fillStyle = hsl(tono, 14, luzPared[1]);
      ctx.fill(poligono([punto(0, 0, 0), punto(vista.ancho, 0, 0), punto(vista.ancho, 0, alto), punto(0, 0, alto)]));

      // Piso en cuadrícula, como tablero de ajedrez muy suave
      ctx.lineWidth = 1 / camara.zoom;
      ctx.strokeStyle = color.oscuro ? 'rgba(255,255,255,0.06)' : 'rgba(30,40,70,0.10)';
      for (let x = 0; x < vista.ancho; x++) {
        for (let y = 0; y < vista.fondo; y++) {
          const casilla = poligono([punto(x, y, 0), punto(x + 1, y, 0), punto(x + 1, y + 1, 0), punto(x, y + 1, 0)]);
          ctx.fillStyle = hsl(tono, 18, (x + y) % 2 ? luzPiso[0] : luzPiso[1]);
          ctx.fill(casilla);
          ctx.stroke(casilla);
        }
      }
    }

    // Dibuja un mueble como una caja: cara derecha, cara izquierda y tapa; y luego sus
    // detalles (repisas, puertas…). r es su rectángulo ya girado a la vista.
    function dibujarMueble(r, tipoClave, borde, discontinuo, color) {
      const tipo = N.TIPOS_MUEBLE[tipoClave];
      const alto = tipo.alto;
      const [tono, saturacion, luzBase] = tipo.color;
      const luz = luzBase - (color.oscuro ? 6 : 0);
      const x2 = r.x + r.ancho;
      const y2 = r.y + r.fondo;
      const abajo = { a: punto(x2, r.y, 0), b: punto(x2, y2, 0), c: punto(r.x, y2, 0) };
      const arriba = { n: punto(r.x, r.y, alto), a: punto(x2, r.y, alto), b: punto(x2, y2, alto), c: punto(r.x, y2, alto) };
      const caraDerecha = poligono([abajo.a, abajo.b, arriba.b, arriba.a]);
      const caraIzquierda = poligono([abajo.b, abajo.c, arriba.c, arriba.b]);
      const tapa = poligono([arriba.n, arriba.a, arriba.b, arriba.c]);

      const opacidad = ctx.globalAlpha;
      if (tipo.detalle === 'vidrio') ctx.globalAlpha = opacidad * 0.78;
      ctx.fillStyle = hsl(tono, saturacion, luz);
      ctx.fill(caraDerecha);
      ctx.fillStyle = hsl(tono, saturacion, luz - 12);
      ctx.fill(caraIzquierda);
      ctx.globalAlpha = opacidad;
      ctx.fillStyle = hsl(tono, saturacion, luz + 16);
      ctx.fill(tapa);

      dibujarDetalle(tipo, r, x2, y2, color, tono, saturacion, luz);

      ctx.lineWidth = (borde ? 3 : 1) / camara.zoom;
      ctx.strokeStyle = borde || 'rgba(0,0,0,0.22)';
      ctx.setLineDash(discontinuo ? [6 / camara.zoom, 4 / camara.zoom] : []);
      [caraDerecha, caraIzquierda, tapa].forEach((cara) => ctx.stroke(cara));
      ctx.setLineDash([]);

      return {
        contorno: poligono([arriba.n, arriba.a, abajo.a, abajo.b, abajo.c, arriba.c]),
        cima: arriba
      };
    }

    function dibujarDetalle(tipo, r, x2, y2, color, tono, saturacion, luz) {
      const alto = tipo.alto;
      const medioX = (r.x + x2) / 2;
      const medioY = (r.y + y2) / 2;
      ctx.lineWidth = 1.2 / camara.zoom;
      ctx.strokeStyle = color.oscuro ? 'rgba(0,0,0,0.45)' : 'rgba(0,0,0,0.25)';

      // Líneas horizontales en las dos caras visibles, a ciertas alturas
      const repisas = (alturas) => alturas.forEach((fraccion) => {
        const z = alto * fraccion;
        linea(punto(x2, r.y + 0.06, z), punto(x2, y2 - 0.06, z));
        linea(punto(r.x + 0.06, y2, z), punto(x2 - 0.06, y2, z));
      });

      if (tipo.detalle === 'repisas' || tipo.detalle === 'vidrio') repisas([0.33, 0.66]);
      if (tipo.detalle === 'puertas') {
        // Una línea vertical a la mitad de cada cara: dos puertas
        linea(punto(x2, medioY, 0.06), punto(x2, medioY, alto - 0.06));
        linea(punto(medioX, y2, 0.06), punto(medioX, y2, alto - 0.06));
      }
      if (tipo.detalle === 'cajones') {
        linea(punto(r.x + 0.06, y2, alto * 0.5), punto(x2 - 0.06, y2, alto * 0.5));
        linea(punto(medioX, y2, 0.04), punto(medioX, y2, alto - 0.04));
      }
      if (tipo.detalle === 'cinta') {
        // La cinta de la caja: cruza la tapa y baja por la cara derecha
        ctx.strokeStyle = hsl(tono, saturacion, luz + 28);
        ctx.lineWidth = 3 / camara.zoom;
        linea(punto(r.x, medioY, alto), punto(x2, medioY, alto));
        linea(punto(x2, medioY, alto), punto(x2, medioY, alto * 0.55));
      }
    }

    // Etiqueta redonda con el número de piezas, encima del mueble
    // Rectángulo con los lados redondos. ctx.roundRect no existe en los WebView antiguos
    // (antes de 2022): ahí se arma con dos semicírculos, que funciona en todos.
    function pastilla(x, y, ancho, alto) {
      if (typeof ctx.roundRect === 'function') {
        ctx.roundRect(x, y, ancho, alto, alto / 2);
        return;
      }
      const radio = alto / 2;
      ctx.moveTo(x + radio, y);
      ctx.lineTo(x + ancho - radio, y);
      ctx.arc(x + ancho - radio, y + radio, radio, -Math.PI / 2, Math.PI / 2);
      ctx.lineTo(x + radio, y + alto);
      ctx.arc(x + radio, y + radio, radio, Math.PI / 2, -Math.PI / 2);
      ctx.closePath();
    }

    // ocupadas: etiquetas ya dibujadas; si esta se encimaría con otra, baja un poco
    function dibujarEtiqueta(figura, total, color, resaltada, ocupadas) {
      const medio = { x: (figura.cima.n.x + figura.cima.b.x) / 2, y: (figura.cima.n.y + figura.cima.b.y) / 2 };
      const x = camara.x + camara.zoom * medio.x;
      let y = camara.y + camara.zoom * medio.y - 4;
      const texto = String(total);
      ctx.font = '600 12px system-ui, sans-serif';
      const ancho = Math.max(22, ctx.measureText(texto).width + 12);
      const choca = () => ocupadas.some((o) => Math.abs(o.x - x) < (o.ancho + ancho) / 2 && Math.abs(o.y - y) < 23);
      for (let intento = 0; intento < 3 && choca(); intento++) y += 24;
      ocupadas.push({ x: x, y: y, ancho: ancho });
      ctx.globalAlpha = figura.transparente ? 0.35 : 1;
      ctx.fillStyle = resaltada ? color.resalte : color.panel;
      ctx.strokeStyle = 'rgba(0,0,0,0.18)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      pastilla(x - ancho / 2, y - 11, ancho, 22);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = resaltada ? '#1a1300' : color.texto;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(texto, x, y + 0.5);
      ctx.globalAlpha = 1;
    }

    function pintarHuella(r, tono, opacidad) {
      const huella = poligono([punto(r.x, r.y, 0), punto(r.x + r.ancho, r.y, 0), punto(r.x + r.ancho, r.y + r.fondo, 0), punto(r.x, r.y + r.fondo, 0)]);
      ctx.save();
      ctx.globalAlpha = opacidad;
      ctx.fillStyle = tono;
      ctx.fill(huella);
      ctx.globalAlpha = 1;
      ctx.strokeStyle = tono;
      ctx.lineWidth = 2 / camara.zoom;
      ctx.stroke(huella);
      ctx.restore();
    }

    // Objetos 3D que están en el piso: aquí se ven como su HUELLA (lo que ocupan en el piso).
    // Su altura y sus giros solo se ven en 3D: el plano no inventa una caja que no corresponde.
    // Si hay varios encimados (una pila de llantas), se marca cuántas piezas hay ahí.
    function dibujarObjetosDelPiso(estado, sala, color) {
      huellas = [];
      if (!estado.objetos3d || !raiz.Espacio) return;
      const elegidos = new Set(estado.objetosSeleccionados || []);
      const pilas = new Map();
      estado.objetos3d().filter((o) => !o.muebleId).forEach((o) => {
        const puntos = raiz.Espacio.huellaEnPiso(o).map(([x, y]) => {
          const enVista = N.aVista({ x: x, y: y, ancho: 0, fondo: 0 }, sala, rotacion);
          return punto(enVista.x, enVista.y, 0);
        });
        if (puntos.length < 3) return;
        const contorno = poligono(puntos);
        ctx.save();
        ctx.globalAlpha = 0.8;
        ctx.fillStyle = o.color;
        ctx.fill(contorno);
        ctx.globalAlpha = 1;
        ctx.lineWidth = (elegidos.has(o.id) ? 3 : 1.2) / camara.zoom;
        ctx.strokeStyle = elegidos.has(o.id) ? color.acento : color.oscuro ? 'rgba(255,255,255,0.55)' : 'rgba(20,24,40,0.45)';
        ctx.stroke(contorno);
        ctx.restore();
        huellas.push({ objetoId: o.id, contorno: contorno });
        const clave = Math.round(o.pos.x * 20) + ',' + Math.round(o.pos.y * 20);
        const pila = pilas.get(clave) || { x: o.pos.x, y: o.pos.y, piezas: 0 };
        pila.piezas += o.unidades || 1;
        pilas.set(clave, pila);
      });
      pilas.forEach((pila) => {
        if (pila.piezas < 2) return;
        const enVista = N.aVista({ x: pila.x, y: pila.y, ancho: 0, fondo: 0 }, sala, rotacion);
        const centro = punto(enVista.x, enVista.y, 0);
        ctx.save();
        ctx.font = '700 ' + Math.max(10, 13 / camara.zoom) + 'px Inter, system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.lineWidth = 3 / camara.zoom;
        ctx.strokeStyle = color.panel;
        ctx.strokeText('×' + pila.piezas, centro.x, centro.y);
        ctx.fillStyle = color.texto;
        ctx.fillText('×' + pila.piezas, centro.x, centro.y);
        ctx.restore();
      });
    }

    // ¿Se tocó la huella de un objeto del piso? (los muebles, que van encima, tienen prioridad)
    function objetoEn(px, py) {
      ponerCamara();
      for (let i = huellas.length - 1; i >= 0; i--) {
        if (ctx.isPointInPath(huellas[i].contorno, px * densidad, py * densidad)) return huellas[i].objetoId;
      }
      return null;
    }

    function dibujar() {
      dibujoPendiente = false;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, lienzo.width, lienzo.height);
      const estado = opciones.estado();
      figuras = [];
      if (!estado.espacio || !anchoCss) return;

      const sala = estado.espacio;
      const vista = N.medidasVista(sala, rotacion);
      const color = colores();
      escala = N.escalaParaSala(vista.ancho, vista.fondo, anchoCss, altoCss);
      ponerCamara();
      dibujarSala(sala, vista, color);
      dibujarObjetosDelPiso(estado, sala, color);

      // Muebles de atrás hacia adelante
      // Ordenar cuesta trabajo: solo se repite si cambiaron los datos, el espacio o el giro
      const clave = sala.id + '|' + rotacion + '|' + estado.version;
      if (ordenGuardado.clave !== clave) {
        const items = estado.muebles.map((mueble) => ({ mueble: mueble, vista: N.aVista(mueble, sala, rotacion) }));
        ordenGuardado = { clave: clave, ordenados: N.ordenarDeAtrasHaciaAdelante(items) };
      }
      const ordenados = ordenGuardado.ordenados;
      const moviendoId = estado.modo && estado.modo.tipo === 'mover' ? estado.modo.muebleId : null;
      const objetivos = Array.from(estado.resaltados);
      if (estado.seleccionadoId) objetivos.push(estado.seleccionadoId);
      if (moviendoId) objetivos.push(moviendoId);
      const tapan = N.mueblesQueTapan(ordenados, objetivos);

      // Huella del mueble seleccionado sobre el piso (se ve aunque otro mueble lo tape)
      const elegido = ordenados.find((item) => item.mueble.id === estado.seleccionadoId);
      if (elegido) pintarHuella(elegido.vista, color.acento, 0.22);

      ordenados.forEach((item) => {
        const id = item.mueble.id;
        let borde = null;
        if (estado.resaltados.has(id)) borde = color.resalte;
        if (id === estado.seleccionadoId || id === moviendoId) borde = color.acento;
        ctx.globalAlpha = arrastre && arrastre.activo && arrastre.id === id ? 0.2 : tapan.has(id) ? TRANSPARENCIA : 1;
        const figura = dibujarMueble(item.vista, item.mueble.tipo, borde, id === moviendoId, color);
        ctx.globalAlpha = 1;
        figuras.push({ mueble: item.mueble, contorno: figura.contorno, cima: figura.cima, transparente: tapan.has(id) });
      });

      // Mueble que se está arrastrando: su huella (verde si cabe, roja si no) y su figura encima
      if (arrastre && arrastre.activo && arrastre.vista) {
        const tono = arrastre.valido ? (color.oscuro ? '#4cc98e' : '#13795b') : (color.oscuro ? '#ff6b74' : '#c62f3b');
        pintarHuella(arrastre.vista, tono, 0.4);
        ctx.globalAlpha = 0.75;
        dibujarMueble(arrastre.vista, arrastre.tipo, tono, true, color);
        ctx.globalAlpha = 1;
      }

      // Etiquetas sin zoom (siempre del mismo tamaño para que se lean)
      ctx.setTransform(densidad, 0, 0, densidad, 0, 0);
      const ocupadas = [];
      figuras.forEach((figura) => {
        const total = estado.piezas(figura.mueble.id);
        if (total) dibujarEtiqueta(figura, total, color, estado.resaltados.has(figura.mueble.id), ocupadas);
      });
    }

    // ---------- Toques ----------
    function muebleEn(px, py) {
      ponerCamara();
      const tocados = figuras.filter((figura) =>
        ctx.isPointInPath(figura.contorno, px * densidad, py * densidad));
      if (!tocados.length) return null;
      // Del frente hacia atrás, prefiriendo los que no están transparentes
      const visibles = tocados.filter((figura) => !figura.transparente);
      const lista = visibles.length ? visibles : tocados;
      return lista[lista.length - 1].mueble;
    }

    function casillaEn(px, py) {
      const estado = opciones.estado();
      if (!escala || !estado.espacio) return null;
      const enDibujo = N.pantallaADibujo(camara, px, py);
      const casilla = N.casillaEnPantalla(enDibujo.x, enDibujo.y, escala);
      const vista = N.medidasVista(estado.espacio, rotacion);
      if (casilla.x < 0 || casilla.y < 0 || casilla.x >= vista.ancho || casilla.y >= vista.fondo) return null;
      return casilla;
    }

    function procesar(acciones) {
      acciones.forEach((accion) => {
        if (accion.tipo === 'desplazar') {
          camara = N.limitarCamara({ zoom: camara.zoom, x: camara.x + accion.dx, y: camara.y + accion.dy }, anchoCss, altoCss);
          pedirDibujo();
        } else if (accion.tipo === 'zoom') {
          camara = N.limitarCamara(N.zoomEn(camara, accion.factor, accion.x, accion.y), anchoCss, altoCss);
          pedirDibujo();
        } else if (accion.tipo === 'toque') {
          const mueble = muebleEn(accion.x, accion.y);
          opciones.alTocar({ casilla: casillaEn(accion.x, accion.y), mueble: mueble, objetoId: mueble ? null : objetoEn(accion.x, accion.y) });
        }
      });
    }

    function posicion(evento) {
      const caja = lienzo.getBoundingClientRect();
      return { x: evento.clientX - caja.left, y: evento.clientY - caja.top };
    }

    // Casilla de la vista bajo un punto, sin recortar a los bordes (para medir desplazamientos)
    function casillaSinLimite(px, py) {
      const enDibujo = N.pantallaADibujo(camara, px, py);
      return N.casillaEnPantalla(enDibujo.x, enDibujo.y, escala);
    }

    // ¿Empieza un arrastre? Solo sobre el mueble seleccionado, con un dedo y fuera de los modos.
    function empezarArrastre(evento, p) {
      const estado = opciones.estado();
      if (!opciones.alArrastrarMueble || !estado.seleccionadoId || estado.modo || estado.presentacion) return false;
      if (gestos.dedosEnPantalla() > 0 || !escala) return false;
      const mueble = muebleEn(p.x, p.y);
      if (!mueble || mueble.id !== estado.seleccionadoId) return false;
      arrastre = { id: mueble.id, tipo: mueble.tipo, mueble: mueble, puntero: evento.pointerId, inicio: p, activo: false,
        casillaInicio: casillaSinLimite(p.x, p.y), origen: N.aVista(mueble, estado.espacio, rotacion) };
      return true;
    }

    function seguirArrastre(p) {
      const estado = opciones.estado();
      if (!arrastre.activo && Math.hypot(p.x - arrastre.inicio.x, p.y - arrastre.inicio.y) < N.UMBRAL_TOQUE) return;
      arrastre.activo = true;
      const casilla = casillaSinLimite(p.x, p.y);
      const medidas = N.medidasVista(estado.espacio, rotacion);
      const limitar = (valor, maximo) => Math.max(0, Math.min(maximo, valor));
      arrastre.vista = {
        x: limitar(arrastre.origen.x + casilla.x - arrastre.casillaInicio.x, medidas.ancho - arrastre.origen.ancho),
        y: limitar(arrastre.origen.y + casilla.y - arrastre.casillaInicio.y, medidas.fondo - arrastre.origen.fondo),
        ancho: arrastre.origen.ancho, fondo: arrastre.origen.fondo
      };
      const mundo = N.aMundo(arrastre.vista, estado.espacio, rotacion);
      arrastre.mundo = { x: mundo.x, y: mundo.y, ancho: arrastre.mueble.ancho, fondo: arrastre.mueble.fondo };
      arrastre.valido = N.cabe(arrastre.mundo, estado.espacio, estado.muebles, arrastre.id);
      lienzo.style.cursor = 'grabbing';
      pedirDibujo();
    }

    function terminarArrastre(p, cancelado) {
      const fin = arrastre;
      arrastre = null;
      lienzo.style.cursor = '';
      pedirDibujo();
      if (cancelado) return;
      if (!fin.activo) { // fue un toque
        opciones.alTocar({ casilla: casillaEn(p.x, p.y), mueble: fin.mueble, objetoId: fin.mueble ? null : objetoEn(p.x, p.y) });
      }
      else if (fin.valido && fin.mundo) opciones.alArrastrarMueble(fin.id, fin.mundo);
    }

    // Pointer Events juntan dedo, ratón y lápiz en un solo tipo de evento.
    // "touch-action: none" (en styles.css) evita que el navegador haga su propio zoom.
    lienzo.addEventListener('pointerdown', (evento) => {
      if (evento.pointerType === 'mouse' && evento.button !== 0) return;
      try {
        lienzo.setPointerCapture(evento.pointerId);
      } catch (error) {
        // Sin captura el gesto funciona igual mientras el dedo siga sobre el lienzo
      }
      const p = posicion(evento);
      if (arrastre) terminarArrastre(p, true); // llegó otro dedo: se cancela el arrastre
      else if (empezarArrastre(evento, p)) return;
      procesar(gestos.bajar(evento.pointerId, p.x, p.y));
    });
    lienzo.addEventListener('pointermove', (evento) => {
      const p = posicion(evento);
      if (arrastre && arrastre.puntero === evento.pointerId) {
        seguirArrastre(p);
        return;
      }
      procesar(gestos.mover(evento.pointerId, p.x, p.y));
    });
    lienzo.addEventListener('pointerup', (evento) => {
      const p = posicion(evento);
      if (arrastre && arrastre.puntero === evento.pointerId) {
        terminarArrastre(p, false);
        return;
      }
      procesar(gestos.subir(evento.pointerId, p.x, p.y));
    });
    lienzo.addEventListener('pointercancel', (evento) => {
      if (arrastre && arrastre.puntero === evento.pointerId) terminarArrastre({ x: 0, y: 0 }, true);
      else procesar(gestos.cancelar(evento.pointerId));
    });
    // Rueda del ratón o pellizco del touchpad en la computadora
    lienzo.addEventListener('wheel', (evento) => {
      evento.preventDefault();
      const p = posicion(evento);
      const factor = Math.exp(-evento.deltaY * 0.0015);
      camara = N.limitarCamara(N.zoomEn(camara, factor, p.x, p.y), anchoCss, altoCss);
      pedirDibujo();
    }, { passive: false });

    if (raiz.ResizeObserver) new raiz.ResizeObserver(ajustarTamano).observe(lienzo);
    else raiz.addEventListener('resize', ajustarTamano);
    temaOscuro.addEventListener('change', pedirDibujo);

    // ---------- Lo que la app puede pedirle a la escena ----------
    return {
      pedirDibujo: pedirDibujo,
      ajustarTamano: ajustarTamano,
      girar() {
        rotacion = (rotacion + 1) % 4;
        pedirDibujo();
      },
      acercar(factor) {
        camara = N.limitarCamara(N.zoomEn(camara, factor, anchoCss / 2, altoCss / 2), anchoCss, altoCss);
        pedirDibujo();
      },
      centrar() {
        camara = N.camaraInicial();
        pedirDibujo();
      },
      reiniciar() {
        rotacion = 0;
        camara = N.camaraInicial();
        pedirDibujo();
      },
      // Acerca la vista para que el mueble quede en la parte de arriba (la hoja tapa abajo)
      enfocar(mueble) {
        const estado = opciones.estado();
        if (!estado.espacio || !anchoCss) return;
        const vista = N.medidasVista(estado.espacio, rotacion);
        const escalaSala = N.escalaParaSala(vista.ancho, vista.fondo, anchoCss, altoCss);
        const r = N.aVista(mueble, estado.espacio, rotacion);
        const centro = N.proyectar(r.x + r.ancho / 2, r.y + r.fondo / 2, N.altoDe(mueble) / 2, escalaSala);
        const zoom = Math.max(camara.zoom, 1.6);
        camara = N.limitarCamara(
          { zoom: zoom, x: anchoCss / 2 - zoom * centro.x, y: altoCss * 0.3 - zoom * centro.y }, anchoCss, altoCss);
        pedirDibujo();
      },
      // Punto de la pantalla (relativo al lienzo) donde está la tapa de un mueble o el centro
      // de una casilla de la vista. Los usan las pruebas automáticas para saber dónde tocar.
      puntoDeMueble(muebleId) {
        const figura = figuras.find((f) => f.mueble.id === muebleId);
        if (!figura) return null;
        const x = (figura.cima.n.x + figura.cima.b.x) / 2;
        const y = (figura.cima.n.y + figura.cima.b.y) / 2;
        return { x: camara.x + camara.zoom * x, y: camara.y + camara.zoom * y };
      },
      // Centro (en la pantalla) de la huella de un objeto 3D del piso, y cuántas huellas hay
      puntoDeObjeto(objetoId) {
        const estado = opciones.estado();
        const o = estado.objetos3d ? estado.objetos3d().find((x) => x.id === objetoId) : null;
        if (!o || !escala) return null;
        const sala = estado.espacio;
        const enVista = N.aVista({ x: o.pos.x, y: o.pos.y, ancho: 0, fondo: 0 }, sala, rotacion);
        const centro = punto(enVista.x, enVista.y, 0);
        return { x: camara.x + camara.zoom * centro.x, y: camara.y + camara.zoom * centro.y };
      },
      huellas: () => huellas.map((h) => h.objetoId),
      puntoDeCasilla(x, y) {
        if (!escala) return null;
        const centro = N.proyectar(x + 0.5, y + 0.5, 0, escala);
        return { x: camara.x + camara.zoom * centro.x, y: camara.y + camara.zoom * centro.y };
      },
      rotacion: () => rotacion,
      zoom: () => camara.zoom
    };
  }

  raiz.Escena = { crear };
})(window);
