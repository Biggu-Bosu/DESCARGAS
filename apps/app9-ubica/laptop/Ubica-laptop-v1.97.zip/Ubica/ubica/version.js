window.APP_VERSION = { numero: '1.97', fecha: '2026-11-13', commit: '99366d8' };
