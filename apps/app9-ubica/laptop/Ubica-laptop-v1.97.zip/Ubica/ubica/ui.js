// Ubica · Base de la interfaz: estado compartido, guardar cambios, avisos, paneles e íconos.
// Todos los archivos de la interfaz comparten el objeto window.Ubica (aquí se llama U):
//   ui.js      → esto: lo que usan todas las pantallas.
//   fichas.js  → paneles de artículo, mueble, lugar, préstamo y categorías.
//   vistas.js  → las secciones (Inventario, Lugares, Préstamos, Más) y el espacio de trabajo.
//   datos.js   → respaldo, copias, Excel, base de datos, ejemplo y actualización de datos.
//   app.js     → navegación, botón Atrás, atajos de teclado e inicio.
//
// Cómo fluye un cambio (por ejemplo, prestar un artículo):
//   1. El formulario llama a una operación de nucleo.js, que valida y devuelve "cambios".
//   2. U.ejecutar() les agrega su historial y guarda todo en IndexedDB en UNA transacción.
//   3. Solo si se guardó, se aplican a la copia en memoria y se redibuja la pantalla.
// Las tres vistas (Lista, 2.5D y 3D) leen esa misma copia: por eso siempre coinciden.
(function () {
  'use strict';

  const N = window.Nucleo;
  const BD = window.BaseDatos;
  const U = (window.Ubica = { N: N, BD: BD });
  const e = (U.e = N.escaparHTML); // todo texto del usuario pasa por aquí antes de ir al HTML
  const $ = (U.$ = (id) => document.getElementById(id));

  // =====================================================================
  // ESTADO
  // =====================================================================
  const estado = (U.estado = {
    datos: N.datosVacios(),  // copia en memoria de la base de datos
    seccion: 'inventario',   // 'inventario' | 'lugares' | 'prestamos' | 'mas'
    lugarId: null,           // lugar abierto en el espacio de trabajo (null = lista de lugares)
    modo: null,              // null | { tipo: 'colocar', mueble } | { tipo: 'mover', muebleId }
    seleccionadoId: null,    // mueble seleccionado (se conserva al cambiar entre Lista, 2.5D y 3D)
    articuloResaltadoId: null, // artículo que se está localizando
    filtros: { texto: '', categoriaId: '', estado: '', lugar: '' },
    orden: 'nombre',
    descendente: false,
    filtroPrestamos: 'activos',
    gruposAbiertos: new Set(), // lugares desplegados en el inventario (mientras la app esté abierta)
    filasVisibles: 60,       // la tabla crece con «Mostrar más»
    version: 0,              // sube cada vez que cambian los datos
    listo: false,            // ya se leyó la base de datos
    // Editor 3D: objetos seleccionados, herramienta del manipulador y mueble que se edita por dentro
    editor: { seleccion: [], herramienta: 'mover', interiorId: null }
  });
  U.FILAS_POR_TANDA = 60;

  U.hoy = () => N.fechaISO(new Date());
  U.lugarAbierto = () => N.buscarPorId(estado.datos.lugares, estado.lugarId);
  U.esEscritorio = () => window.matchMedia('(min-width: 900px)').matches;

  // localStorage solo guarda preferencias pequeñas; si falla, la app sigue funcionando
  U.leerClave = (clave) => {
    try {
      return localStorage.getItem(clave);
    } catch (error) {
      return null;
    }
  };
  U.guardarClave = (clave, valor) => {
    try {
      localStorage.setItem(clave, valor);
    } catch (error) {
      // Sin localStorage solo se pierde esa preferencia
    }
  };

  // =====================================================================
  // CONFIGURACIÓN
  // =====================================================================
  // Preferencias de este dispositivo (no son parte del inventario ni del respaldo). Cada ajuste
  // encendido pone una clase «aj-<clave>» en <body>; el CSS y las vistas hacen el resto.
  // [clave, valor inicial, grupo, título, explicación]
  U.LISTA_AJUSTES = [
    ['agrupar', true, 'Inventario', 'Dividir el inventario por ubicación', 'Cada lugar es un grupo que se abre y se cierra.'],
    ['menosTexto', false, 'Simplificar', 'Menos texto', 'Oculta explicaciones, subtítulos y notas de ayuda.'],
    ['compacto', false, 'Simplificar', 'Inventario compacto', 'Cada artículo en un renglón: solo nombre y cantidad.'],
    ['sinEstados', false, 'Simplificar', 'Sin estados', 'Oculta «en reparación» y «dañadas»: solo cuántas hay.'],
    ['sinCategorias', false, 'Simplificar', 'Sin categorías', 'Oculta las categorías y sus colores.'],
    ['sinPrestamos', false, 'Simplificar', 'Sin préstamos', 'Oculta la sección Préstamos y el botón «Prestar».'],
    ['sinAvanzado', false, 'Simplificar', 'Sin opciones avanzadas', 'Oculta números de serie, historial, notas, medidas, Excel y base de datos.'],
    ['sinAnimaciones', false, 'Simplificar', 'Sin animaciones', 'Todo cambia al instante, también en 3D.'],
    ['asentarAlSoltar', true, 'Editor 3D', 'Asentar al soltar', 'Al mover un objeto, baja solo hasta apoyarse en el piso, una repisa u otro objeto. Si lo subes con la flecha azul, se queda a esa altura.'],
    ['imanEditor', false, 'Editor 3D', 'Imán', 'Las flechas, aros y cubos del editor avanzan de 5 cm en 5 cm y de 15° en 15°.'],
    ['permitirEncimar', false, 'Editor 3D', 'Permitir objetos encimados', 'Dos objetos pueden ocupar el mismo espacio (se guarda con aviso). Paredes, repisas y muebles se respetan siempre.']
  ];
  U.ajustes = {};
  (function leerAjustes() {
    let guardados = {};
    try {
      guardados = JSON.parse(U.leerClave('ubica-ajustes') || '{}') || {};
    } catch (error) {
      guardados = {};
    }
    U.LISTA_AJUSTES.forEach(([clave, inicial]) => {
      U.ajustes[clave] = typeof guardados[clave] === 'boolean' ? guardados[clave] : inicial;
    });
  })();
  U.aplicarAjustes = () => {
    U.LISTA_AJUSTES.forEach(([clave]) => document.body.classList.toggle('aj-' + clave, U.ajustes[clave]));
  };
  U.cambiarAjuste = (clave, valor) => {
    U.ajustes[clave] = Boolean(valor);
    U.guardarClave('ubica-ajustes', JSON.stringify(U.ajustes));
    U.aplicarAjustes();
    estado.version++; // las listas se vuelven a pintar
    U.render();
    if (U.redibujarEscenas) U.redibujarEscenas();
  };
  U.aplicarAjustes();

  // =====================================================================
  // GUARDAR CAMBIOS
  // =====================================================================
  let ocupado = false; // el candado: hay un cambio guardándose
  U.ocupado = () => ocupado;

  // Ejecuta una tarea que escribe en la base de datos, de una en una.
  U.conCandado = async (tarea) => {
    if (ocupado) return undefined;
    ocupado = true;
    try {
      return await tarea();
    } finally {
      ocupado = false;
    }
  };

  // Guarda unos cambios junto con su historial. Devuelve true si quedaron guardados.
  async function guardarConHistorial(resultado) {
    const cambios = resultado.sinHistorial
      ? resultado.cambios
      : N.conMovimientos(estado.datos, resultado, new Date().toISOString(), N.nuevoId('op'));
    try {
      await BD.escribir(cambios);
    } catch (error) {
      console.error(error);
      return false;
    }
    N.aplicarCambios(estado.datos, cambios);
    estado.version++;
    return true;
  }

  // resultado: lo que devuelve una operación de nucleo.js (calculado justo antes, sin "await" en medio).
  // opciones.mensaje: aviso al terminar. opciones.deshacer: ofrecer «Deshacer».
  // opciones.form: formulario donde mostrar el error (si no, se muestra como aviso).
  U.ejecutar = async (resultado, opciones) => {
    const ajustes = opciones || {};
    if (ocupado) return false; // segundo toque mientras se guardaba el primero: se ignora
    if (!resultado.ok) {
      if (ajustes.form) U.mostrarError(ajustes.form, resultado.error);
      else U.avisar(resultado.error);
      return false;
    }
    const guardado = await U.conCandado(async () => {
      const inverso = N.invertirCambios(estado.datos, resultado.cambios);
      if (!(await guardarConHistorial(resultado))) {
        U.avisar('No se pudo guardar. Revisa el espacio libre del dispositivo e inténtalo de nuevo.');
        return false;
      }
      if (ajustes.deshacer) {
        pilaDeshacer.push({ cambios: inverso, texto: ajustes.mensaje || 'el último cambio' });
        if (pilaDeshacer.length > MAXIMO_DESHACER) pilaDeshacer.shift();
        pilaRehacer.length = 0;
      } else if (!resultado.sinHistorial) {
        // Un cambio que no se puede deshacer invalida lo que había en las pilas
        pilaDeshacer.length = 0;
        pilaRehacer.length = 0;
      }
      if (cambiosParaDeshacer) ocultarAviso(); // un «Deshacer» viejo ya no sirve
      if (ajustes.mensaje) U.avisar(ajustes.mensaje, ajustes.deshacer ? inverso : null);
      return true;
    });
    if (!guardado) return false;
    U.render();
    return true;
  };

  // =====================================================================
  // AVISO (con «Deshacer»)
  // =====================================================================
  let temporizadorAviso = null;
  let cambiosParaDeshacer = null;
  // Deshacer y rehacer de varios pasos (los cambios que se pueden deshacer, más recientes al final)
  const MAXIMO_DESHACER = 60;
  const pilaDeshacer = [];
  const pilaRehacer = [];
  U.puedeDeshacer = () => pilaDeshacer.length > 0;
  U.puedeRehacer = () => pilaRehacer.length > 0;
  let esRehacer = false; // el botón del aviso dice «Rehacer» justo después de deshacer

  U.avisar = (texto, deshacer, rehacer) => {
    cambiosParaDeshacer = deshacer || null;
    esRehacer = Boolean(deshacer && rehacer);
    $('textoAviso').textContent = texto;
    $('botonDeshacer').textContent = esRehacer ? 'Rehacer' : 'Deshacer';
    $('botonDeshacer').hidden = !deshacer;
    $('aviso').classList.add('visible');
    clearTimeout(temporizadorAviso);
    temporizadorAviso = setTimeout(ocultarAviso, deshacer ? 8000 : 3000);
  };

  function ocultarAviso() {
    $('aviso').classList.remove('visible');
    cambiosParaDeshacer = null;
  }

  // Deshacer también queda en el historial (tipo «deshacer»). Ctrl+Z / Ctrl+Y y los botones del
  // editor recorren las pilas; el botón del aviso deshace (o rehace) el paso que acaba de pasar.
  async function revertir(rehaciendo) {
    const origen = rehaciendo ? pilaRehacer : pilaDeshacer;
    const destino = rehaciendo ? pilaDeshacer : pilaRehacer;
    if (!origen.length || ocupado) {
      if (!origen.length) U.avisar(rehaciendo ? 'No hay nada que rehacer.' : 'No hay nada que deshacer.');
      return;
    }
    const paso = origen[origen.length - 1];
    ocultarAviso();
    let contrario = null;
    const hecho = await U.conCandado(() => {
      contrario = N.invertirCambios(estado.datos, paso.cambios);
      return guardarConHistorial({ tipo: 'deshacer', cambios: paso.cambios });
    });
    if (!hecho) {
      U.avisar(rehaciendo ? 'No se pudo rehacer.' : 'No se pudo deshacer.');
      return;
    }
    origen.pop();
    destino.push({ cambios: contrario, texto: paso.texto });
    U.render();
    U.refrescarHoja();
    U.avisar((rehaciendo ? 'Se rehízo: ' : 'Se deshizo: ') + paso.texto.charAt(0).toLowerCase() + paso.texto.slice(1), contrario, !rehaciendo);
  }
  U.deshacer = () => revertir(false);
  U.rehacer = () => revertir(true);
  $('botonDeshacer').addEventListener('click', () => revertir(esRehacer));

  // =====================================================================
  // PANELES («hojas»)
  // =====================================================================
  // En el celular suben desde abajo; en pantallas anchas son un panel fijo a la derecha, que no
  // tapa la lista ni el plano. Funcionan como una pila: el mueble abre el artículo, que abre
  // «Prestar». «Volver» (o Atrás) quita el de arriba. Cada "pantalla" es una función que
  // devuelve { html, acciones } o null si lo que mostraba ya no existe.
  const pila = (U.pila = []);
  let accionesHoja = {};
  let focoAntes = null;
  let abiertaDesde = 0; // para ignorar el "clic fantasma" que llega justo después de un toque
  let temporizadorOcultar = null;
  const FONDO = ['navegacion', 'cuerpo'];

  U.abrirHoja = (pantalla) => {
    if (!pila.length) {
      focoAntes = document.activeElement;
      abiertaDesde = performance.now();
    }
    pila.push(pantalla);
    mostrarHoja(true);
  };

  // Sustituye todo lo abierto por un panel nuevo (al elegir otra cosa de la lista o del plano)
  U.abrirHojaUnica = (pantalla) => {
    if (!pila.length) {
      focoAntes = document.activeElement;
      abiertaDesde = performance.now();
    }
    pila.length = 0;
    pila.push(pantalla);
    mostrarHoja(true);
  };

  U.reemplazarHoja = (pantalla) => {
    pila[pila.length - 1] = pantalla;
    mostrarHoja(true);
  };

  U.volverHoja = () => {
    pila.pop();
    if (pila.length) mostrarHoja(true);
    else U.cerrarHojas();
  };

  U.refrescarHoja = () => {
    if (pila.length) mostrarHoja(false);
  };

  function mostrarHoja(enfocar) {
    let vista = null;
    while (pila.length && !(vista = pila[pila.length - 1]())) pila.pop();
    if (!vista) {
      U.cerrarHojas();
      return;
    }
    const contenido = $('contenidoHoja');
    accionesHoja = vista.acciones || {};
    contenido.innerHTML = vista.html;
    const hoja = $('hoja');
    clearTimeout(temporizadorOcultar);
    hoja.hidden = false;
    document.body.classList.add('con-hoja');
    if (!U.esEscritorio()) {
      // En el celular el panel es modal: el resto queda "inerte" para el lector de pantalla y el Tab
      $('velo').classList.add('abierta');
      FONDO.forEach((id) => $(id).setAttribute('inert', ''));
    }
    requestAnimationFrame(() => hoja.classList.add('abierta'));
    if (enfocar) {
      hoja.scrollTop = 0;
      contenido.scrollTop = 0;
      const titulo = $('tituloHoja');
      if (titulo && !U.esEscritorio()) titulo.focus();
    }
    U.alCambiarPaneles();
  }

  U.cerrarHojas = () => {
    const habia = pila.length > 0 || document.body.classList.contains('con-hoja');
    pila.length = 0;
    accionesHoja = {};
    const hoja = $('hoja');
    hoja.classList.remove('abierta');
    $('velo').classList.remove('abierta');
    FONDO.forEach((id) => $(id).removeAttribute('inert'));
    document.body.classList.remove('con-hoja');
    clearTimeout(temporizadorOcultar);
    temporizadorOcultar = setTimeout(() => {
      if (!pila.length) hoja.hidden = true;
    }, 230);
    if (focoAntes && document.contains(focoAntes) && !U.esEscritorio()) focoAntes.focus();
    focoAntes = null;
    if (habia) U.alCambiarPaneles();
  };

  // app.js lo reemplaza: avisa que cambió lo abierto (para el botón Atrás y el tamaño de las escenas)
  U.alCambiarPaneles = () => {};

  // Encabezado de cada panel: «Volver» si hay otro debajo, título y cerrar
  U.cabeza = (titulo, subtitulo) => {
    const volver = pila.length > 1
      ? '<button type="button" class="boton-icono" data-accion="volver" aria-label="Volver">' + U.ICONOS.volver + '</button>'
      : '';
    return '<div class="cabeza-hoja">' + volver +
      '<div class="titulos"><h2 id="tituloHoja" tabindex="-1">' + e(titulo) + '</h2>' +
      (subtitulo ? '<p>' + e(subtitulo) + '</p>' : '') + '</div>' +
      '<button type="button" class="boton-icono" data-accion="cerrar" aria-label="Cerrar">' + U.ICONOS.cerrar + '</button></div>';
  };

  // Un solo "escuchador" para todos los botones y formularios del panel (delegación)
  $('contenidoHoja').addEventListener('click', (evento) => {
    const contador = evento.target.closest('[data-sumar]');
    if (contador) {
      sumarAlCampo(contador);
      return;
    }
    const boton = evento.target.closest('[data-accion]');
    if (!boton || boton.disabled) return;
    const nombre = boton.dataset.accion;
    if (nombre === 'volver') U.volverHoja();
    else if (nombre === 'cerrar') U.cerrarHojas();
    else if (accionesHoja[nombre]) accionesHoja[nombre](boton);
  });

  $('contenidoHoja').addEventListener('submit', (evento) => {
    evento.preventDefault();
    const form = evento.target;
    const accion = accionesHoja[form.dataset.form];
    if (accion) accion(form);
  });

  // Casillas que muestran u ocultan un bloque (por ejemplo, las medidas del plano)
  $('contenidoHoja').addEventListener('change', (evento) => {
    const casilla = evento.target.closest('[data-muestra]');
    if (!casilla) return;
    const bloque = $('contenidoHoja').querySelector('#' + casilla.dataset.muestra);
    // Una casilla lo muestra al marcarse; una lista, al elegir el valor de data-muestra-valor
    if (bloque) bloque.hidden = casilla.dataset.muestraValor ? casilla.value !== casilla.dataset.muestraValor : !casilla.checked;
  });

  $('velo').addEventListener('click', () => {
    if (performance.now() - abiertaDesde > 500) U.cerrarHojas();
  });

  // ---------- Campos reutilizables ----------
  function sumarAlCampo(boton) {
    const campo = boton.parentElement.querySelector('input');
    const minimo = Number(campo.min || 1);
    const maximo = Number(campo.max || N.LIMITES.cantidad);
    const actual = Number.isInteger(Number(campo.value)) ? Number(campo.value) : minimo;
    campo.value = String(Math.min(maximo, Math.max(minimo, actual + Number(boton.dataset.sumar))));
    campo.dispatchEvent(new Event('input', { bubbles: true }));
  }

  U.campoContador = (nombre, etiqueta, valor, minimo, maximo) =>
    '<label class="campo">' + e(etiqueta) + '<div class="contador-campo">' +
    '<button type="button" data-sumar="-1" aria-label="Uno menos">−</button>' +
    '<input name="' + nombre + '" type="number" inputmode="numeric" min="' + minimo + '" max="' + maximo +
    '" value="' + valor + '" required>' +
    '<button type="button" data-sumar="1" aria-label="Uno más">+</button></div></label>';

  U.mostrarError = (form, texto) => {
    const caja = form.querySelector('.error');
    caja.textContent = texto;
    caja.hidden = false;
  };

  U.valores = (form) => Object.fromEntries(new FormData(form).entries());

  U.selectorCategoria = (elegida) =>
    '<label class="campo" data-simple="categorias">Categoría<select name="categoriaId">' + N.categoriasOrdenadas(estado.datos).map((categoria) =>
      '<option value="' + e(categoria.id) + '"' + (categoria.id === elegida ? ' selected' : '') + '>' + e(categoria.nombre) +
      '</option>').join('') + '</select></label>';

  // Valor de una ubicación en un <select>: 'sin', 'l:<lugarId>' o 'm:<muebleId>'
  U.claveUbicacion = (articulo) => {
    if (articulo.muebleId) return 'm:' + articulo.muebleId;
    if (articulo.lugarId) return 'l:' + articulo.lugarId;
    return 'sin';
  };

  U.leerUbicacion = (valor) => {
    if (valor && valor.startsWith('m:')) return { muebleId: valor.slice(2) };
    if (valor && valor.startsWith('l:')) return { lugarId: valor.slice(2) };
    return null;
  };

  U.selectorUbicacion = (elegida, etiqueta) => {
    const opcion = (valor, texto) => '<option value="' + e(valor) + '"' + (valor === elegida ? ' selected' : '') + '>' + e(texto) + '</option>';
    const grupos = estado.datos.lugares.map((lugar) =>
      '<optgroup label="' + e(lugar.nombre) + '">' + opcion('l:' + lugar.id, lugar.nombre + ' (sin mueble)') +
      N.mueblesDe(estado.datos, lugar.id).map((mueble) => opcion('m:' + mueble.id, mueble.nombre)).join('') + '</optgroup>').join('');
    return '<label class="campo">' + e(etiqueta || 'Ubicación (opcional)') + '<select name="ubicacion">' +
      opcion('sin', 'Sin ubicación') + grupos + '</select></label>';
  };

  // Ubicaciones de UN solo lugar: se usa al agregar un artículo estando dentro de ese lugar.
  // Ofrece sus muebles, dejarlo sin mueble, o crear un mueble nuevo ahí mismo (valor 'nuevo').
  U.selectorUbicacionDeLugar = (lugarId, elegida) => {
    const lugar = N.buscarPorId(estado.datos.lugares, lugarId);
    const opcion = (valor, texto) => '<option value="' + e(valor) + '"' + (valor === elegida ? ' selected' : '') + '>' + e(texto) + '</option>';
    const tipos = Object.keys(N.TIPOS_MUEBLE).map((clave) => '<option value="' + clave + '"' + (clave === 'estante' ? ' selected' : '') + '>' +
      e(N.TIPOS_MUEBLE[clave].nombre) + '</option>').join('');
    return '<label class="campo">¿Dónde va? (en ' + e(lugar.nombre) + ')<select name="ubicacion" data-muestra="muebleNuevo" data-muestra-valor="nuevo">' +
      N.mueblesDe(estado.datos, lugarId).map((mueble) => opcion('m:' + mueble.id, mueble.nombre)).join('') +
      opcion('l:' + lugarId, 'Sin mueble (directo en el lugar)') + opcion('nuevo', '+ Mueble nuevo…') + '</select></label>' +
      '<div class="campos-fila" id="muebleNuevo" hidden><label class="campo">Tipo de mueble<select name="tipoMueble">' + tipos + '</select></label>' +
      '<label class="campo">Nombre (opcional)<input name="nombreMueble" maxlength="' + N.LIMITES.nombre + '" placeholder="Ej. Estante azul" autocomplete="off"></label></div>';
  };

  U.fechaYHora = (momentoISO) => {
    const fecha = new Date(momentoISO);
    if (isNaN(fecha)) return '';
    return N.fechaCorta(N.fechaISO(fecha), U.hoy()) + ' ' + fecha.getFullYear() + ', ' + String(fecha.getHours()).padStart(2, '0') + ':' +
      String(fecha.getMinutes()).padStart(2, '0');
  };

  // Etiquetas pequeñas con el estado de un artículo (texto, no solo color)
  U.etiquetasEstado = (fila) => {
    const a = fila.articulo;
    let html = '';
    if (fila.total === 0) html += '<span class="etiqueta gris">Agotado</span>';
    if (fila.prestadas) html += '<span class="etiqueta azul">' + fila.prestadas + ' prestad' + (fila.prestadas === 1 ? 'a' : 'as') + '</span>';
    if (a.estados.reparacion) html += '<span class="etiqueta ambar">' + a.estados.reparacion + ' en reparación</span>';
    if (a.estados.danado) html += '<span class="etiqueta rojo">' + a.estados.danado + ' dañad' + (a.estados.danado === 1 ? 'a' : 'as') + '</span>';
    return html;
  };

  // =====================================================================
  // ÍCONOS
  // =====================================================================
  const svg = (camino) => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="' + camino + '"/></svg>';
  U.ICONOS = {
    volver: svg('M15.4 7.4 14 6l-6 6 6 6 1.4-1.4L10.8 12z'),
    cerrar: svg('M18.3 5.7 16.9 4.3 12 9.2 7.1 4.3 5.7 5.7l4.9 4.9-4.9 4.9 1.4 1.4 4.9-4.9 4.9 4.9 1.4-1.4-4.9-4.9z'),
    flecha: svg('M8.6 16.6 13.2 12 8.6 7.4 10 6l6 6-6 6z'),
    mas: svg('M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z'),
    lista: svg('M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z'),
    lugar: svg('M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z'),
    prestamo: svg('M6.99 11 3 15l3.99 4v-3H14v-2H6.99v-3zM21 9l-3.99-4v3H10v2h7.01v3L21 9z'),
    puntos: svg('M6 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm12 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-6 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z'),
    plano: svg('M12 3 2 8.5l10 5.5 10-5.5L12 3zm-7.4 9L2 13.5 12 19l10-5.5-2.6-1.5L12 16.2 4.6 12z'),
    cubo: svg('M12 2 3 7v10l9 5 9-5V7l-9-5zm0 2.3 6.5 3.6L12 11.5 5.5 7.9 12 4.3zM5 9.6l6 3.3v6.6l-6-3.3V9.6zm8 9.9v-6.6l6-3.3v6.6l-6 3.3z'),
    girar: svg('M12 5V2L8 6l4 4V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z'),
    mover: svg('M10 9h4V6h3l-5-5-5 5h3v3zm-1 1H6V7l-5 5 5 5v-3h3v-4zm14 2-5-5v3h-3v4h3v3l5-5zm-9 3h-4v3H7l5 5 5-5h-3v-3z'),
    borrar: svg('M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z'),
    acercar: svg('M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z'),
    alejar: svg('M5 11h14v2H5z'),
    centrar: svg('M4 9V4h5v2H6v3zm10-5h6v5h-2V6h-4zM4 15h2v3h3v2H4zm14 0h2v5h-6v-2h4z'),
    guardar: svg('M12 3 7 8h3v6h4V8h3zM5 18h14v2H5z'),
    abrir: svg('M12 21 17 16h-3v-6h-4v6H7zM5 4h14v2H5z'),
    tabla: svg('M3 4h18v16H3zm2 2v3h6V6zm8 0v3h6V6zM5 11v3h6v-3zm8 0v3h6v-3zM5 16v2h6v-2zm8 0v2h6v-2z'),
    excel: svg('M6 2h9l5 5v15H6zm8 1.5V8h4.5zM8.5 11l2.2 3.5-2.4 3.5h1.9l1.5-2.4 1.5 2.4h1.9l-2.4-3.5 2.2-3.5h-1.8L11.7 13l-1.4-2z'),
    editar: svg('M4 17.2V20h2.8l8.3-8.3-2.8-2.8zM19.7 7a1 1 0 0 0 0-1.4l-1.3-1.3a1 1 0 0 0-1.4 0l-1.6 1.6 2.8 2.8z'),
    reloj: svg('M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16zm-1 3v6l5 3 1-1.7-4-2.3V7z'),
    estrella: svg('M12 17.3 18.2 21l-1.6-7L22 9.2l-7.2-.6L12 2 9.2 8.6 2 9.2 7.4 14l-1.6 7z'),
    etiqueta: svg('M3 3h8l10 10-8 8L3 11zm4 2.5A1.5 1.5 0 1 0 7 8.5a1.5 1.5 0 0 0 0-3z'),
    presentar: svg('M3 4h18v12H3zm2 2v8h14V6zm3 12h8v2H8z'),
    buscar: svg('M10 3a7 7 0 0 1 5.6 11.2l5.1 5.1-1.4 1.4-5.1-5.1A7 7 0 1 1 10 3zm0 2a5 5 0 1 0 0 10 5 5 0 0 0 0-10z'),
    filtro: svg('M3 5h18v2l-7 7v6l-4-2v-4L3 7z'),
    orden: svg('M7 4 3 8h3v12h2V8h3zm10 16 4-4h-3V4h-2v12h-3z')
  };

  // Dibujito isométrico de cada tipo de mueble para la paleta (mismas proporciones que el plano)
  U.iconoMueble = (clave) => {
    const tipo = N.TIPOS_MUEBLE[clave];
    const p = (x, y, z) => [(x - y) * 6, (x + y) * 3 - z * 7.2];
    const a = tipo.ancho;
    const f = tipo.fondo;
    const h = tipo.alto;
    const caras = [
      [p(a, 0, 0), p(a, f, 0), p(a, f, h), p(a, 0, h)],
      [p(a, f, 0), p(0, f, 0), p(0, f, h), p(a, f, h)],
      [p(0, 0, h), p(a, 0, h), p(a, f, h), p(0, f, h)]
    ];
    const todos = caras.flat();
    const minX = Math.min(...todos.map((q) => q[0])) - 1;
    const maxX = Math.max(...todos.map((q) => q[0])) + 1;
    const minY = Math.min(...todos.map((q) => q[1])) - 1;
    const maxY = Math.max(...todos.map((q) => q[1])) + 1;
    const [tono, saturacion, luz] = tipo.color;
    const luces = [luz, luz - 12, luz + 16];
    const poligonos = caras.map((cara, i) =>
      '<polygon points="' + cara.map((q) => q.join(',')).join(' ') + '" fill="hsl(' + tono + ' ' + saturacion + '% ' +
      luces[i] + '%)" stroke="rgba(0,0,0,.25)" stroke-width=".6"/>').join('');
    return '<svg viewBox="' + [minX, minY, maxX - minX, maxY - minY].join(' ') + '" aria-hidden="true">' + poligonos + '</svg>';
  };
})();
