// Ubica · Paneles (fichas y formularios): artículo, mueble, lugar, préstamo y categorías.
// Cada función "pantalla…" devuelve { html, acciones } para U.abrirHoja (ver ui.js).
(function () {
  'use strict';

  const U = window.Ubica;
  const { N, e, $, estado } = U;
  const { cabeza, campoContador, valores, ejecutar, abrirHoja, volverHoja, cerrarHojas, refrescarHoja, ICONOS } = U;
  const datos = () => estado.datos;

  // =====================================================================
  // ARTÍCULOS
  // =====================================================================

  // Alta rápida: solo el nombre y la cantidad son obligatorios; lo demás está plegado.
  // Estando dentro de un lugar ('l:…' o 'm:…') solo se ofrecen las ubicaciones de ese lugar
  function lugarDeClave(clave) {
    if (clave && clave.startsWith('l:')) return clave.slice(2);
    if (clave && clave.startsWith('m:')) {
      const mueble = N.buscarPorId(datos().muebles, clave.slice(2));
      return mueble ? mueble.lugarId : null;
    }
    return null;
  }

  U.pantallaNuevoArticulo = (ubicacionInicial) => {
    const lugarId = lugarDeClave(ubicacionInicial);
    const lugar = lugarId ? N.buscarPorId(datos().lugares, lugarId) : null;
    return pantallaNuevo(ubicacionInicial, lugar);
  };

  const pantallaNuevo = (ubicacionInicial, lugar) => ({
    html: cabeza('Nuevo artículo', lugar ? 'En ' + lugar.nombre : '') +
      '<form data-form="crear" novalidate><p class="error" role="alert" hidden></p>' +
      '<label class="campo">Nombre<input name="nombre" maxlength="' + N.LIMITES.nombre +
      '" placeholder="Ej. Microscopio" autocomplete="off" required></label>' +
      '<div class="campos-fila">' + campoContador('cantidad', 'Cantidad', 1, 1, N.LIMITES.cantidad) +
      U.selectorCategoria(N.ID_OTROS) + '</div>' +
      (lugar ? U.selectorUbicacionDeLugar(lugar.id, ubicacionInicial) : U.selectorUbicacion(ubicacionInicial || 'sin')) +
      '<details class="plegable"><summary>Más datos (opcional)</summary>' +
      '<label class="campo">N.º de inventario<input name="codigo" maxlength="' + N.LIMITES.codigo + '" autocomplete="off"></label>' +
      '<label class="campo">Notas<textarea name="notas" maxlength="' + N.LIMITES.notas + '"></textarea></label></details>' +
      '<button class="boton principal">Agregar artículo</button>' +
      '<p class="nota">Si ya existe uno con el mismo nombre en esa ubicación, se suman las piezas.</p></form>',
    acciones: {
      crear: async (form) => {
        const entrada = valores(form);
        let resultado;
        let mensaje = '';
        if (lugar && entrada.ubicacion === 'nuevo') {
          // Mueble y artículo se crean juntos (un solo «Deshacer»)
          resultado = N.crearArticuloEnMuebleNuevo(datos(), lugar.id, entrada.tipoMueble, entrada.nombreMueble, entrada);
          if (resultado.ok) {
            mensaje = 'Agregaste «' + resultado.articulo.nombre + '» en el mueble nuevo «' + resultado.mueble.nombre + '»' +
              (lugar.plano && !resultado.colocado ? ' (sin colocar: no había hueco en el plano)' : '');
          }
        } else {
          entrada.ubicacion = U.leerUbicacion(entrada.ubicacion);
          resultado = N.crearArticulo(datos(), entrada);
          if (resultado.ok) mensaje = (resultado.sumado ? 'Se sumó a «' : 'Agregaste «') + resultado.articulo.nombre + '»';
        }
        if (await ejecutar(resultado, { form: form, mensaje: mensaje, deshacer: Boolean(resultado.mueble) })) cerrarHojas();
      }
    }
  });

  // Cuántas piezas del artículo están dibujadas como objetos 3D. Solo informa: el inventario
  // (la cantidad) sigue siendo el del artículo; los objetos solo lo representan.
  function representacion3d(articulo) {
    const objetos = N.objetosDeArticulo(datos(), articulo.id);
    if (!objetos.length) return '';
    const piezas = N.unidadesRepresentadas(datos(), articulo.id);
    return '<p class="nota">En 3D: ' + N.plural(objetos.length, 'objeto') + ' ' + (objetos.length === 1 ? 'representa ' : 'representan ') +
      piezas + ' de ' + N.totalDe(articulo) + ' piezas.</p>' +
      '<div class="fila-botones"><button type="button" class="boton chico" data-accion="ver3d">Ver en 3D</button></div>';
  }

  U.abrirArticulo = (articuloId, unica) => (unica ? U.abrirHojaUnica : abrirHoja)(() => pantallaArticulo(articuloId));

  function pantallaArticulo(articuloId) {
    const sitio = N.ubicacion(datos(), articuloId);
    const articulo = sitio.articulo;
    if (!articulo) return null;
    const prestadas = N.prestadas(datos(), articuloId);
    const disponibles = N.disponibles(datos(), articulo);
    const activos = N.prestamosActivosDe(datos(), articuloId);
    const categoria = N.categoriaDe(datos(), articulo);
    const fecha = U.hoy();
    const estados = articulo.estados;
    const series = articulo.series || [];
    const html = cabeza(articulo.nombre, N.textoUbicacion(sitio.lugar, sitio.mueble)) +
      '<p class="linea-etiquetas"><span class="etiqueta" data-simple="categorias" style="--tono:' + e(categoria.color) + '"><span class="punto"></span>' +
      e(categoria.nombre) + '</span>' + (articulo.codigo ? '<span class="etiqueta gris" data-simple="avanzado">' + e(articulo.codigo) + '</span>' : '') + '</p>' +
      '<div class="cifras cuatro"><div class="cifra"><strong>' + N.totalDe(articulo) + '</strong><span>total</span></div>' +
      '<div class="cifra bien" data-simple="estados"><strong>' + estados.bueno + '</strong><span>buen estado</span></div>' +
      '<div class="cifra aviso-c" data-simple="estados"><strong>' + estados.reparacion + '</strong><span>reparación</span></div>' +
      '<div class="cifra mal" data-simple="estados"><strong>' + estados.danado + '</strong><span>dañadas</span></div></div>' +
      '<p class="disponibilidad" data-simple="prestamos"><strong>' + N.plural(disponibles, 'disponible') + '</strong> para prestar · ' +
      N.plural(prestadas, 'prestada') + '</p>' +
      '<div class="fila-botones"><button type="button" class="boton principal" data-simple="prestamos" data-accion="prestar"' +
      (disponibles < 1 ? ' disabled' : '') + '>' + (disponibles < 1 ? 'Nada disponible' : 'Prestar') + '</button>' +
      (sitio.lugar ? '<button type="button" class="boton" data-accion="localizar">' + ICONOS.lugar + 'Localizar</button>' : '') + '</div>' +
      (activos.length ? '<h3>Prestado ahora</h3>' + activos.map((prestamo) =>
        '<div class="tarjeta' + (N.estadoPrestamo(prestamo, fecha) === 'vencido' ? ' vencido' : '') + '"><strong>' +
        prestamo.cantidad + ' · ' + e(prestamo.persona) + '</strong><p class="detalle">' +
        e(N.textoVencimiento(prestamo, fecha)) + '</p><div class="fila-botones"><button type="button" class="boton chico" ' +
        'data-accion="devolver" data-id="' + e(prestamo.id) + '">Registrar devolución</button></div></div>').join('') : '') +
      '<h3>Existencias</h3><div class="fila-botones tres"><button type="button" class="boton chico" data-accion="entrada">Entrada</button>' +
      '<button type="button" class="boton chico" data-simple="estados" data-accion="estado">Cambiar estado</button>' +
      '<button type="button" class="boton chico" data-accion="baja">Dar de baja</button></div>' +
      '<details class="plegable"><summary>Editar datos</summary>' +
      '<form data-form="guardar" novalidate><p class="error" role="alert" hidden></p>' +
      '<label class="campo">Nombre<input name="nombre" maxlength="' + N.LIMITES.nombre + '" value="' + e(articulo.nombre) + '" required></label>' +
      U.selectorCategoria(articulo.categoriaId) +
      '<label class="campo" data-simple="avanzado">N.º de inventario<input name="codigo" maxlength="' + N.LIMITES.codigo + '" value="' +
      e(articulo.codigo) + '" autocomplete="off"></label>' +
      '<label class="campo" data-simple="avanzado">Notas<textarea name="notas" maxlength="' + N.LIMITES.notas + '">' +
      e(articulo.notas) + '</textarea></label><button class="boton">Guardar cambios</button></form></details>' +
      formaHtml(articulo) +
      '<details class="plegable" data-simple="avanzado"><summary>Números de serie' + (series.length ? ' (' + series.length + ')' : '') + '</summary>' +
      '<form data-form="series" novalidate><p class="error" role="alert" hidden></p>' +
      '<label class="campo">Uno por línea (opcional)<textarea name="series" placeholder="Ej. MIC-001">' + e(series.join('\n')) +
      '</textarea></label><p class="nota">Sirven para identificar cada pieza y encontrarla con el buscador.</p>' +
      '<button class="boton">Guardar números de serie</button></form></details>' +
      (articulo.notas ? '<p class="nota"><strong>Notas:</strong> ' + e(articulo.notas) + '</p>' : '') +
      representacion3d(articulo) +
      '<div class="fila-botones"><button type="button" class="boton chico" data-accion="mover">Cambiar ubicación</button>' +
      '<button type="button" class="boton chico" data-simple="avanzado" data-accion="historial">' + ICONOS.reloj + 'Historial</button></div>' +
      '<div class="fila-botones"><button type="button" class="boton peligro chico" data-accion="borrar">Borrar artículo</button></div>';

    return {
      html: html,
      acciones: {
        prestar: () => abrirHoja(() => pantallaPrestar(articuloId)),
        localizar: () => U.localizarArticulo(articuloId),
        ver3d: () => U.verObjetosEn3D(N.objetosDeArticulo(datos(), articuloId).map((o) => o.id)),
        devolver: (boton) => abrirHoja(() => U.pantallaDevolver(boton.dataset.id)),
        entrada: () => abrirHoja(() => pantallaEntrada(articuloId)),
        estado: () => abrirHoja(() => pantallaCambiarEstado(articuloId)),
        baja: () => abrirHoja(() => pantallaBaja(articuloId)),
        guardar: async (form) => {
          if (await ejecutar(N.editarArticulo(datos(), articuloId, valores(form)), { form: form, mensaje: 'Cambios guardados' })) refrescarHoja();
        },
        forma: async (form) => {
          const elegido = valores(form);
          const forma = { figura: elegido.figura, tamano: Number(elegido.tamano), color: elegido.color || undefined };
          if (await ejecutar(N.guardarForma(datos(), articuloId, forma), { form: form, mensaje: 'Forma guardada', deshacer: true })) refrescarHoja();
        },
        series: async (form) => {
          const resultado = N.guardarSeries(datos(), articuloId, valores(form).series);
          if (await ejecutar(resultado, { form: form, mensaje: 'Números de serie guardados' })) refrescarHoja();
        },
        mover: () => abrirHoja(() => pantallaMoverArticulo(articuloId)),
        historial: () => abrirHoja(() => pantallaHistorial(articuloId)),
        borrar: () => abrirHoja(() => pantallaBorrarArticulo(articuloId))
      }
    };
  }

  // ---------- Forma del artículo en la vista 3D ----------
  // Dibujitos de cada figura para los botones (las mismas figuras que usa el 3D)
  const DIBUJO_FIGURA = {
    caja: '<path d="M4 8l8-4 8 4v8l-8 4-8-4z M4 8l8 4 8-4 M12 12v8"/>',
    cilindro: '<ellipse cx="12" cy="6.5" rx="7" ry="2.8"/><path d="M5 6.5v11c0 1.5 3.1 2.8 7 2.8s7-1.300 7-2.800v-11"/>',
    esfera: '<circle cx="12" cy="12" r="8"/><path d="M4 12c2 2.600 14 2.600 16 0"/>',
    prisma: '<path d="M3 17l5-10 5 10z M8 7l8-1 5 9-8 2 M21 15l-8 2"/>',
    piramide: '<path d="M12 3l9 14-9 4-9-4z M12 3v18"/>'
  };
  const COLORES_FORMA = ['#d9534f', '#e8a33d', '#e6cf4a', '#5aa469', '#3fa7a3', '#4a8fe0', '#8e6bd1', '#d16ba5', '#8a6a4f', '#5f6b76'];

  function formaHtml(articulo) {
    const forma = N.formaDe(datos(), articulo);
    const colorPropio = articulo.forma && articulo.forma.color;
    return '<details class="plegable"><summary>Forma en 3D · ' + e(N.FIGURAS[forma.figura]) + '</summary>' +
      '<form data-form="forma" novalidate><p class="error" role="alert" hidden></p>' +
      '<p class="nota">Así se ve este artículo dentro de su mueble en la vista 3D.</p>' +
      '<div class="figuras" role="radiogroup" aria-label="Figura">' + Object.keys(N.FIGURAS).map((clave) =>
        '<label class="figura"><input type="radio" name="figura" value="' + clave + '"' + (forma.figura === clave ? ' checked' : '') + '>' +
        '<svg viewBox="0 0 24 24" aria-hidden="true">' + DIBUJO_FIGURA[clave] + '</svg><span>' + e(N.FIGURAS[clave]) + '</span></label>').join('') + '</div>' +
      '<label class="campo">Tamaño<select name="tamano">' + Object.keys(N.TAMANOS_FORMA).map((t) =>
        '<option value="' + t + '"' + (forma.tamano === Number(t) ? ' selected' : '') + '>' + N.TAMANOS_FORMA[t] + '</option>').join('') + '</select></label>' +
      '<div class="colores" role="radiogroup" aria-label="Color">' +
      '<label class="color" title="El color de su categoría"><input type="radio" name="color" value=""' + (colorPropio ? '' : ' checked') +
      '><span style="background:' + e(N.categoriaDe(datos(), articulo).color) + '">A</span></label>' +
      COLORES_FORMA.map((color) => '<label class="color" title="' + color + '"><input type="radio" name="color" value="' + color + '"' +
        (colorPropio === color ? ' checked' : '') + '><span style="background:' + color + '"></span></label>').join('') + '</div>' +
      '<button class="boton">Guardar forma</button></form></details>';
  }

  function pantallaBorrarArticulo(articuloId) {
    const articulo = N.buscarPorId(datos().articulos, articuloId);
    if (!articulo) return null;
    return {
      html: cabeza('¿Borrar «' + articulo.nombre + '»?') +
        '<p>Se borrará el artículo con sus ' + N.plural(N.totalDe(articulo), 'pieza') + '. Su historial se conserva. ' +
        'Si solo se acabaron o se rompieron, es mejor «Dar de baja».</p>' +
        '<div class="fila-botones"><button type="button" class="boton" data-accion="volver">Cancelar</button>' +
        '<button type="button" class="boton peligro-lleno" data-accion="borrar">Sí, borrar</button></div>',
      acciones: {
        borrar: async () => {
          const mensaje = 'Borraste «' + articulo.nombre + '»';
          if (await ejecutar(N.borrarArticulo(datos(), articuloId), { mensaje: mensaje, deshacer: true })) cerrarHojas();
          else volverHoja();
        }
      }
    };
  }

  function pantallaEntrada(articuloId) {
    const articulo = N.buscarPorId(datos().articulos, articuloId);
    if (!articulo) return null;
    return {
      html: cabeza('Entrada de piezas', articulo.nombre + ' · hoy hay ' + N.totalDe(articulo)) +
        '<form data-form="entrada" novalidate><p class="error" role="alert" hidden></p>' +
        campoContador('cantidad', '¿Cuántas llegaron? (en buen estado)', 1, 1, N.LIMITES.cantidad) +
        '<button class="boton principal">Sumar</button></form>',
      acciones: {
        entrada: async (form) => {
          const resultado = N.agregarExistencias(datos(), articuloId, valores(form).cantidad);
          if (await ejecutar(resultado, { form: form, mensaje: 'Entrada registrada', deshacer: true })) volverHoja();
        }
      }
    };
  }

  const opcionesEstado = (elegido) => N.ESTADOS.map((pieza) =>
    '<option value="' + pieza.clave + '"' + (pieza.clave === elegido ? ' selected' : '') + '>' + pieza.nombre + '</option>').join('');

  function pantallaCambiarEstado(articuloId) {
    const articulo = N.buscarPorId(datos().articulos, articuloId);
    if (!articulo) return null;
    const estados = articulo.estados;
    const desde = estados.reparacion ? 'reparacion' : 'bueno';
    return {
      html: cabeza('Cambiar estado', articulo.nombre) +
        '<p class="nota">Ahora: ' + estados.bueno + ' en buen estado (' + N.disponibles(datos(), articulo) + ' sin prestar), ' +
        estados.reparacion + ' en reparación y ' + estados.danado + ' dañadas. Las prestadas no cambian de estado hasta que regresen.</p>' +
        '<form data-form="cambiar" novalidate><p class="error" role="alert" hidden></p><div class="campos-fila">' +
        '<label class="campo">De<select name="de">' + opcionesEstado(desde) + '</select></label>' +
        '<label class="campo">A<select name="a">' + opcionesEstado(desde === 'bueno' ? 'reparacion' : 'bueno') + '</select></label></div>' +
        campoContador('cantidad', 'Cantidad', 1, 1, N.LIMITES.cantidad) +
        '<button class="boton principal">Cambiar</button></form>',
      acciones: {
        cambiar: async (form) => {
          const resultado = N.cambiarEstado(datos(), articuloId, valores(form));
          if (await ejecutar(resultado, { form: form, mensaje: 'Estado actualizado', deshacer: true })) volverHoja();
        }
      }
    };
  }

  function pantallaBaja(articuloId) {
    const articulo = N.buscarPorId(datos().articulos, articuloId);
    if (!articulo) return null;
    return {
      html: cabeza('Dar de baja', articulo.nombre) +
        '<p class="nota">Las piezas dadas de baja salen del inventario (perdidas, sin arreglo, consumidas) y queda registro en el historial.</p>' +
        '<form data-form="baja" novalidate><p class="error" role="alert" hidden></p><div class="campos-fila">' +
        '<label class="campo">Salen de<select name="estado">' + opcionesEstado(articulo.estados.danado ? 'danado' : 'bueno') +
        '</select></label>' + campoContador('cantidad', 'Cantidad', 1, 1, N.LIMITES.cantidad) + '</div>' +
        '<label class="campo">Motivo<input name="motivo" maxlength="' + N.LIMITES.motivo +
        '" placeholder="Ej. Se rompió, no tiene arreglo" autocomplete="off" required></label>' +
        '<button class="boton peligro-lleno">Dar de baja</button></form>',
      acciones: {
        baja: async (form) => {
          const resultado = N.darDeBaja(datos(), articuloId, valores(form));
          if (await ejecutar(resultado, { form: form, mensaje: 'Baja registrada', deshacer: true })) volverHoja();
        }
      }
    };
  }

  function pantallaPrestar(articuloId) {
    const sitio = N.ubicacion(datos(), articuloId);
    if (!sitio.articulo) return null;
    const disponibles = N.disponibles(datos(), sitio.articulo);
    const fecha = U.hoy();
    return {
      html: cabeza('Prestar ' + sitio.articulo.nombre, N.plural(disponibles, 'disponible')) +
        '<form data-form="prestar" novalidate><p class="error" role="alert" hidden></p>' +
        '<label class="campo">¿Quién se lo lleva?<input name="persona" maxlength="' + N.LIMITES.persona +
        '" autocomplete="off" placeholder="Nombre y apellido" required></label>' +
        '<div class="campos-fila">' + campoContador('cantidad', 'Cantidad', 1, 1, Math.max(1, disponibles)) +
        '<label class="campo">Regresa el<input name="fechaLimite" type="date" min="' + fecha + '" max="' +
        N.sumarDias(fecha, N.LIMITES.diasPrestamo) + '" value="' + N.sumarDias(fecha, 7) + '" required></label></div>' +
        '<details class="plegable"><summary>Grupo y nota (opcional)</summary>' +
        '<label class="campo">Grupo o área<input name="grupo" maxlength="' + N.LIMITES.grupo +
        '" autocomplete="off" placeholder="Ej. 3.º B"></label>' +
        '<label class="campo">Nota<textarea name="nota" maxlength="' + N.LIMITES.notas +
        '" placeholder="Ej. Para la práctica de biología"></textarea></label></details>' +
        '<button class="boton principal">Registrar préstamo</button></form>',
      acciones: {
        prestar: async (form) => {
          const resultado = N.prestar(datos(), articuloId, valores(form), U.hoy());
          const mensaje = resultado.ok ? 'Préstamo registrado: ' + resultado.prestamo.persona : '';
          if (await ejecutar(resultado, { form: form, mensaje: mensaje })) volverHoja();
        }
      }
    };
  }

  // Devolución completa o parcial, indicando cuántas regresaron dañadas
  U.pantallaDevolver = (prestamoId) => {
    const prestamo = N.buscarPorId(datos().prestamos, prestamoId);
    if (!prestamo || prestamo.devuelto) return null;
    const varias = prestamo.cantidad > 1;
    return {
      html: cabeza('Registrar devolución', prestamo.articuloNombre + ' ×' + prestamo.cantidad + ' · ' + prestamo.persona) +
        '<form data-form="devolver" novalidate><p class="error" role="alert" hidden></p><div class="campos-fila">' +
        (varias ? campoContador('cantidad', '¿Cuántas regresan?', prestamo.cantidad, 1, prestamo.cantidad) : '') +
        campoContador('danadas', '¿Cuántas dañadas?', 0, 0, prestamo.cantidad) + '</div>' +
        '<p class="nota">' + (varias ? 'Si regresan menos, el préstamo sigue activo por las que faltan. ' : '') +
        'Las dañadas pasan al estado «Dañado» y dejan de estar disponibles.</p>' +
        '<button class="boton principal">Registrar devolución</button></form>',
      acciones: {
        devolver: async (form) => {
          const entrada = valores(form);
          const resultado = N.devolver(datos(), prestamoId, U.hoy(), { cantidad: entrada.cantidad, danadas: entrada.danadas });
          const mensaje = resultado.ok
            ? 'Devolución registrada: ' + prestamo.articuloNombre + (resultado.parcial ? ' (faltan ' + resultado.faltan + ')' : '') : '';
          if (await ejecutar(resultado, { form: form, mensaje: mensaje, deshacer: true })) volverHoja();
        }
      }
    };
  };

  // Mover varios artículos de un mueble a otro de una sola vez
  function pantallaMoverVarios(muebleId) {
    const mueble = N.buscarPorId(datos().muebles, muebleId);
    if (!mueble) return null;
    const lugar = N.buscarPorId(datos().lugares, mueble.lugarId);
    const articulos = N.articulosDe(datos(), muebleId);
    const opcion = (valor, texto) => '<option value="' + e(valor) + '">' + e(texto) + '</option>';
    // Primero los muebles del mismo lugar (lo más común); después, los demás lugares
    const aqui = N.mueblesDe(datos(), lugar.id).filter((otro) => otro.id !== muebleId);
    const otros = datos().lugares.filter((otro) => otro.id !== lugar.id).map((otro) =>
      '<optgroup label="' + e(otro.nombre) + '">' + opcion('l:' + otro.id, otro.nombre + ' (sin mueble)') +
      N.mueblesDe(datos(), otro.id).map((m) => opcion('m:' + m.id, m.nombre)).join('') + '</optgroup>').join('');
    return {
      html: cabeza('Mover artículos', 'Desde ' + mueble.nombre + ' · ' + lugar.nombre) +
        '<form data-form="mover" novalidate><p class="error" role="alert" hidden></p>' +
        '<div class="fila-botones"><button type="button" class="boton chico" data-accion="todos">Marcar todos</button>' +
        '<button type="button" class="boton chico" data-accion="ninguno">Ninguno</button></div>' +
        '<div class="lista-casillas">' + articulos.map((articulo) =>
          '<label class="casilla"><input type="checkbox" name="articulo" value="' + e(articulo.id) + '"><span>' + e(articulo.nombre) +
          ' <small>×' + N.totalDe(articulo) + '</small></span></label>').join('') + '</div>' +
        '<label class="campo">Llevar a<select name="ubicacion"><optgroup label="' + e(lugar.nombre) + '">' +
        aqui.map((otro) => opcion('m:' + otro.id, otro.nombre)).join('') + opcion('l:' + lugar.id, 'Sin mueble (directo en el lugar)') +
        '</optgroup>' + otros + opcion('sin', 'Sin ubicación') + '</select></label>' +
        '<button class="boton principal">Mover los marcados</button></form>',
      acciones: {
        todos: () => $('contenidoHoja').querySelectorAll('input[name="articulo"]').forEach((casilla) => { casilla.checked = true; }),
        ninguno: () => $('contenidoHoja').querySelectorAll('input[name="articulo"]').forEach((casilla) => { casilla.checked = false; }),
        mover: async (form) => {
          const ids = Array.from(form.querySelectorAll('input[name="articulo"]:checked')).map((casilla) => casilla.value);
          const resultado = N.moverArticulos(datos(), ids, U.leerUbicacion(form.elements.ubicacion.value));
          const mensaje = resultado.ok ? 'Moviste ' + N.plural(resultado.movidos, 'artículo') +
            (resultado.juntos ? ' (' + resultado.juntos + ' se juntaron con uno igual)' : '') : '';
          if (await ejecutar(resultado, { form: form, mensaje: mensaje, deshacer: true })) volverHoja();
        }
      }
    };
  }

  // Acomodo automático: de lista a plano en un toque
  U.pantallaAutoOrdenar = (lugarId) => {
    const lugar = N.buscarPorId(datos().lugares, lugarId);
    if (!lugar) return null;
    const muebles = N.mueblesDe(datos(), lugarId);
    const pendientes = lugar.plano || lugar.planoAnterior ? muebles.filter((mueble) => !N.estaColocado(mueble)) : muebles;
    const sueltos = datos().articulos.filter((articulo) => !articulo.muebleId && articulo.lugarId === lugarId);
    const pasos = [];
    if (!lugar.plano) pasos.push(lugar.planoAnterior ? 'Se recupera el plano que tenía, con cada mueble en su casilla.' : 'Se crea un plano del tamaño justo para este lugar.');
    if (pendientes.length) pasos.push('Se ' + (pendientes.length === 1 ? 'acomoda 1 mueble' : 'acomodan ' + pendientes.length + ' muebles') + ' junto a las paredes, dejando pasillos.');
    return {
      html: cabeza('Acomodar automáticamente', lugar.nombre) +
        '<form data-form="acomodar" novalidate><p class="error" role="alert" hidden></p>' +
        (pasos.length ? '<ul class="lista-simple">' + pasos.map((paso) => '<li>' + e(paso) + '</li>').join('') + '</ul>' : '') +
        (sueltos.length ? '<label class="casilla"><input type="checkbox" name="estantes" value="si" checked><span>' +
          (sueltos.length === 1 ? 'Guardar el artículo suelto en un estante' : 'Guardar los ' + sueltos.length + ' artículos sueltos en estantes, uno por categoría') +
          '</span></label>' : '') +
        '<p class="nota">No se borra nada. Después puedes mover, girar o cambiar cualquier mueble, y hay «Deshacer».</p>' +
        '<button class="boton principal">Acomodar</button></form>',
      acciones: {
        acomodar: async (form) => {
          const resultado = N.autoOrdenar(datos(), lugarId, { estantes: Boolean(form.elements.estantes && form.elements.estantes.checked) });
          let mensaje = '';
          if (resultado.ok) {
            mensaje = 'Listo: ' + N.plural(resultado.colocados, 'mueble acomodado', 'muebles acomodados') +
              (resultado.creados ? ', ' + N.plural(resultado.creados, 'estante nuevo', 'estantes nuevos') : '') +
              (resultado.sinSitio.length ? '. No cupieron: ' + resultado.sinSitio.join(', ') : '');
          }
          if (await ejecutar(resultado, { form: form, mensaje: mensaje, deshacer: true })) {
            cerrarHojas();
            U.render();
            U.redibujarEscenas();
          }
        }
      }
    };
  };

  function pantallaMoverArticulo(articuloId) {
    const sitio = N.ubicacion(datos(), articuloId);
    if (!sitio.articulo) return null;
    return {
      html: cabeza('Cambiar ubicación', sitio.articulo.nombre + ' · ahora en ' + N.textoUbicacion(sitio.lugar, sitio.mueble)) +
        '<form data-form="mover" novalidate><p class="error" role="alert" hidden></p>' +
        U.selectorUbicacion(U.claveUbicacion(sitio.articulo), 'Llevar a') +
        '<p class="nota">Si allá ya hay un artículo con el mismo nombre, se juntan en uno solo.</p>' +
        '<button class="boton principal">Mover</button></form>',
      acciones: {
        mover: async (form) => {
          const resultado = N.moverArticulo(datos(), articuloId, U.leerUbicacion(valores(form).ubicacion));
          let mensaje = '';
          if (resultado.ok) {
            const destino = N.ubicacion(Object.assign({}, datos(), { articulos: [resultado.articulo] }), resultado.articulo.id);
            mensaje = (resultado.juntos ? 'Se juntó con el de «' : 'Movido a «') + N.textoUbicacion(destino.lugar, destino.mueble) + '»';
          }
          if (await ejecutar(resultado, { form: form, mensaje: mensaje, deshacer: true })) {
            volverHoja();
            if (resultado.juntos && U.pila.length) U.reemplazarHoja(() => pantallaArticulo(resultado.articulo.id));
          }
        }
      }
    };
  }

  const listaMovimientos = (movimientos, conNombre) => '<ul class="historial">' + movimientos.map((movimiento) =>
    '<li><strong>' + e(N.textoMovimiento(movimiento)) + (conNombre && movimiento.nombre ? ' · ' + e(movimiento.nombre) : '') +
    '</strong><small>' + e(U.fechaYHora(movimiento.momento)) + '</small></li>').join('') + '</ul>';

  function pantallaHistorial(articuloId) {
    const articulo = N.buscarPorId(datos().articulos, articuloId);
    if (!articulo) return null;
    const movimientos = N.movimientosDe(datos(), articuloId);
    return {
      html: cabeza('Historial', articulo.nombre) +
        (movimientos.length ? listaMovimientos(movimientos.slice(0, 60)) +
          (movimientos.length > 60 ? '<p class="nota">Se muestran los 60 más recientes.</p>' : '')
          : '<p class="vacio">Sin movimientos registrados todavía.</p>')
    };
  }

  // Historial de todo el inventario (sección Más)
  U.pantallaHistorialGeneral = () => {
    const movimientos = N.movimientosRecientes(datos(), 80);
    return {
      html: cabeza('Historial de movimientos', 'Los más recientes de todo el inventario') +
        (movimientos.length ? listaMovimientos(movimientos, true)
          : '<p class="vacio">Aquí aparecerá cada alta, préstamo, cambio de estado y baja.</p>')
    };
  };

  // =====================================================================
  // MUEBLES
  // =====================================================================
  U.abrirMueble = (muebleId) => U.abrirHojaUnica(() => pantallaMueble(muebleId));

  function pantallaMueble(muebleId) {
    const mueble = N.buscarPorId(datos().muebles, muebleId);
    if (!mueble) return null;
    const lugar = N.buscarPorId(datos().lugares, mueble.lugarId);
    const articulos = N.articulosDe(datos(), muebleId);
    const total = N.piezasEnMueble(datos(), muebleId);
    const prestadas = articulos.reduce((suma, articulo) => suma + N.prestadas(datos(), articulo.id), 0);
    const colocado = N.estaColocado(mueble);
    const conPlano = Boolean(lugar && lugar.plano);
    const html = cabeza(mueble.nombre, N.TIPOS_MUEBLE[mueble.tipo].nombre + ' · ' + lugar.nombre +
      (conPlano && !colocado ? ' · sin colocar' : '')) +
      '<div class="cifras"><div class="cifra"><strong>' + total + '</strong><span>piezas</span></div>' +
      '<div class="cifra"><strong>' + articulos.length + '</strong><span>artículos</span></div>' +
      '<div class="cifra"><strong>' + prestadas + '</strong><span>prestadas</span></div></div>' +
      (articulos.length
        ? '<ul class="lista-toque">' + articulos.map((articulo) =>
          '<li><button type="button" data-accion="articulo" data-id="' + e(articulo.id) + '"' +
          (articulo.id === estado.articuloResaltadoId ? ' class="resaltado"' : '') + '><span class="nombre"><strong>' +
          e(articulo.nombre) + '</strong><small>' + (articulo.codigo ? e(articulo.codigo) + ' · ' : '') +
          N.disponibles(datos(), articulo) + ' disponibles</small></span><span class="cantidad">×' +
          N.totalDe(articulo) + '</span><span class="flecha">' + ICONOS.flecha + '</span></button></li>').join('') + '</ul>'
        : '<p class="nota">Aún no guarda nada. Agrégalo aquí abajo.</p>') +
      (articulos.length ? '<button type="button" class="boton chico" data-accion="moverVarios">' + ICONOS.mover + 'Mover artículos a otro mueble</button>' : '') +
      '<form data-form="agregar" class="alta-rapida" novalidate><p class="error" role="alert" hidden></p><div class="campos-fila">' +
      '<label class="campo ancho-2">Agregar artículo<input name="nombre" maxlength="' + N.LIMITES.nombre +
      '" placeholder="Nombre" autocomplete="off" required></label>' +
      '<label class="campo">Cantidad<input name="cantidad" type="number" inputmode="numeric" min="1" max="' +
      N.LIMITES.cantidad + '" value="1" required></label></div>' +
      '<button class="boton">Agregar a este mueble</button></form>' +
      '<h3>Mueble</h3>' +
      (colocado && conPlano ? '<div class="fila-botones"><button type="button" class="boton chico" data-accion="interior">' +
        'Editar el interior en 3D' + (N.objetosEnMueble(datos(), muebleId).length ? ' (' + N.objetosEnMueble(datos(), muebleId).length + ' objetos)' : '') +
        '</button></div>' : '') +
      '<div class="fila-botones">' +
      (conPlano ? '<button type="button" class="boton chico" data-accion="mover">' + ICONOS.mover + (colocado ? 'Mover' : 'Colocar') + '</button>' : '') +
      '<button type="button" class="boton chico" data-accion="girar">' + ICONOS.girar + 'Girar</button>' +
      '<button type="button" class="boton chico" data-simple="avanzado" data-accion="medidas">Medidas</button></div>' +
      '<div class="fila-botones"><button type="button" class="boton chico" data-accion="renombrar">Renombrar</button>' +
      '<button type="button" class="boton peligro chico" data-accion="borrar">Borrar mueble</button></div>';

    return {
      html: html,
      acciones: {
        articulo: (boton) => U.abrirArticulo(boton.dataset.id),
        agregar: async (form) => {
          const resultado = N.agregarArticulo(datos(), muebleId, valores(form));
          if (await ejecutar(resultado, { form: form })) {
            refrescarHoja();
            U.avisar(resultado.sumado ? 'Se sumó a «' + resultado.articulo.nombre + '»' : 'Agregaste «' + resultado.articulo.nombre + '»');
            const campo = $('contenidoHoja').querySelector('input[name="nombre"]');
            if (campo) campo.focus();
          }
        },
        moverVarios: () => abrirHoja(() => pantallaMoverVarios(muebleId)),
        interior: () => U.editarInterior(muebleId),
        girar: () => U.girarMueble(muebleId),
        mover: () => U.empezarAMover(muebleId),
        medidas: () => abrirHoja(() => pantallaMedidas(muebleId)),
        renombrar: () => abrirHoja(() => pantallaRenombrar(muebleId)),
        borrar: () => abrirHoja(() => pantallaBorrarMueble(muebleId))
      }
    };
  }

  U.girarMueble = (muebleId) => ejecutar(N.girarMueble(datos(), muebleId), { mensaje: 'Girado', deshacer: true }).then(refrescarHoja);

  function pantallaMedidas(muebleId) {
    const mueble = N.buscarPorId(datos().muebles, muebleId);
    if (!mueble) return null;
    const maximo = N.MEDIDA_MAXIMA_MUEBLE;
    return {
      html: cabeza('Medidas', mueble.nombre) +
        '<form data-form="guardar" novalidate><p class="error" role="alert" hidden></p><div class="campos-fila">' +
        campoContador('ancho', 'Ancho (casillas)', mueble.ancho, 1, maximo) + campoContador('fondo', 'Fondo (casillas)', mueble.fondo, 1, maximo) +
        '</div><p class="nota">1 casilla ≈ 1 metro. El mueble crece desde su esquina; debe caber sin encimarse. ' +
        'El cambio se ve igual en 2.5D y en 3D.</p><button class="boton principal">Guardar medidas</button></form>',
      acciones: {
        guardar: async (form) => {
          if (await ejecutar(N.redimensionarMueble(datos(), muebleId, valores(form)), { form: form, mensaje: 'Medidas guardadas', deshacer: true })) volverHoja();
        }
      }
    };
  }

  function pantallaRenombrar(muebleId) {
    const mueble = N.buscarPorId(datos().muebles, muebleId);
    if (!mueble) return null;
    return {
      html: cabeza('Renombrar', mueble.nombre) +
        '<form data-form="guardar" novalidate><p class="error" role="alert" hidden></p>' +
        '<label class="campo">Nombre del mueble<input name="nombre" maxlength="' + N.LIMITES.nombre + '" value="' +
        e(mueble.nombre) + '" required></label><button class="boton principal">Guardar</button></form>',
      acciones: {
        guardar: async (form) => {
          if (await ejecutar(N.renombrarMueble(datos(), muebleId, valores(form).nombre), { form: form })) volverHoja();
        }
      }
    };
  }

  // Borrar un mueble: por defecto sus artículos se quedan en el lugar. Borrarlos también
  // pide una segunda confirmación que dice exactamente qué se pierde.
  function pantallaBorrarMueble(muebleId) {
    const mueble = N.buscarPorId(datos().muebles, muebleId);
    if (!mueble) return null;
    const lugar = N.buscarPorId(datos().lugares, mueble.lugarId);
    const articulos = N.articulosDe(datos(), muebleId);
    const piezas = N.piezasEnMueble(datos(), muebleId);
    const borrarSolo = async () => {
      const mensaje = 'Borraste «' + mueble.nombre + '»' + (articulos.length ? '; sus artículos quedaron en «' + lugar.nombre + '»' : '');
      if (await ejecutar(N.borrarMueble(datos(), muebleId), { mensaje: mensaje, deshacer: true })) {
        U.deseleccionar();
        cerrarHojas();
      }
    };
    return {
      html: cabeza('¿Borrar «' + mueble.nombre + '»?', lugar.nombre) +
        (articulos.length
          ? '<p>Guarda ' + N.plural(articulos.length, 'artículo') + ' (' + N.plural(piezas, 'pieza') + '). ' +
            '<strong>No se pierden:</strong> pasan directo a «' + e(lugar.nombre) + '».</p>' +
            '<div class="lista-menu"><button type="button" class="boton principal" data-accion="borrarSolo">' +
            'Borrar el mueble y conservar sus artículos</button>' +
            '<button type="button" class="boton peligro" data-accion="conArticulos">Borrar también sus artículos…</button>' +
            '<button type="button" class="boton" data-accion="volver">No, conservarlo</button></div>'
          : '<p>Está vacío.</p><div class="fila-botones"><button type="button" class="boton" data-accion="volver">No, conservarlo</button>' +
            '<button type="button" class="boton peligro-lleno" data-accion="borrarSolo">Sí, borrar</button></div>'),
      acciones: {
        borrarSolo: borrarSolo,
        conArticulos: () => abrirHoja(() => pantallaBorrarMuebleYArticulos(muebleId))
      }
    };
  }

  function pantallaBorrarMuebleYArticulos(muebleId) {
    const mueble = N.buscarPorId(datos().muebles, muebleId);
    if (!mueble) return null;
    const articulos = N.articulosDe(datos(), muebleId);
    const piezas = N.piezasEnMueble(datos(), muebleId);
    return {
      html: cabeza('¿Borrar el mueble y sus artículos?', mueble.nombre) +
        '<p>Se borrarán «' + e(mueble.nombre) + '» y estos artículos (' + N.plural(piezas, 'pieza') + '):</p>' +
        '<ul>' + articulos.slice(0, 8).map((a) => '<li>' + e(a.nombre) + ' ×' + N.totalDe(a) + '</li>').join('') + '</ul>' +
        (articulos.length > 8 ? '<p class="nota">…y ' + (articulos.length - 8) + ' más.</p>' : '') +
        '<p class="nota">Podrás deshacerlo unos segundos después.</p>' +
        '<div class="fila-botones"><button type="button" class="boton" data-accion="volver">Cancelar</button>' +
        '<button type="button" class="boton peligro-lleno" data-accion="borrar">Sí, borrar todo</button></div>',
      acciones: {
        borrar: async () => {
          const resultado = N.borrarMueble(datos(), muebleId, { conArticulos: true });
          const mensaje = 'Borraste «' + mueble.nombre + '» y ' + N.plural(piezas, 'pieza');
          if (await ejecutar(resultado, { mensaje: mensaje, deshacer: true })) {
            U.deseleccionar();
            cerrarHojas();
          }
        }
      }
    };
  }

  // =====================================================================
  // LUGARES
  // =====================================================================
  // El plano es opcional: un lugar puede ser solo un nombre (inventario de listas).
  U.pantallaLugar = (lugarId, opciones) => {
    const lugar = lugarId ? N.buscarPorId(datos().lugares, lugarId) : null;
    if (lugarId && !lugar) return null;
    const medidas = (lugar && (lugar.plano || lugar.planoAnterior)) || { ancho: 8, fondo: 6 };
    const conPlano = opciones && opciones.conPlano != null ? opciones.conPlano : lugar ? Boolean(lugar.plano) : true;
    const actual = lugar || { nombre: '', tipo: 'bodega' };
    const tipos = Object.keys(N.TIPOS_LUGAR).map((clave) =>
      '<option value="' + clave + '"' + (clave === actual.tipo ? ' selected' : '') + '>' + N.TIPOS_LUGAR[clave].nombre + '</option>').join('');
    const lado = [N.LIMITES.ladoMinimo, N.LIMITES.ladoMaximo];
    const muebles = lugar ? N.mueblesDe(datos(), lugar.id).length : 0;
    return {
      html: cabeza(lugar ? 'Editar lugar' : 'Nuevo lugar') +
        '<form data-form="guardar" novalidate><p class="error" role="alert" hidden></p><div class="campos-fila">' +
        '<label class="campo ancho-2">Nombre<input name="nombre" maxlength="' + N.LIMITES.nombre + '" value="' + e(actual.nombre) +
        '" placeholder="Ej. Almacén" autocomplete="off" required></label>' +
        '<label class="campo">Tipo<select name="tipo">' + tipos + '</select></label></div>' +
        '<label class="casilla"><input type="checkbox" name="conPlano" value="si" data-muestra="medidasPlano"' +
        (conPlano ? ' checked' : '') + '> Con plano (para verlo en 2.5D y 3D)</label>' +
        '<div id="medidasPlano"' + (conPlano ? '' : ' hidden') + '><div class="campos-fila">' +
        campoContador('ancho', 'Ancho', medidas.ancho, lado[0], lado[1]) +
        campoContador('fondo', 'Fondo', medidas.fondo, lado[0], lado[1]) + '</div>' +
        '<p class="nota">En casillas (1 casilla ≈ 1 metro), de ' + lado[0] + ' a ' + lado[1] + ' por lado.</p></div>' +
        (lugar && lugar.plano && muebles
          ? '<p class="nota">Si quitas el plano, los muebles y sus artículos se conservan y recuerdan su posición.</p>' : '') +
        '<button class="boton principal">' + (lugar ? 'Guardar' : 'Crear lugar') + '</button></form>' +
        (lugar ? '<div class="fila-botones"><button type="button" class="boton peligro chico" data-accion="borrar">Borrar lugar</button></div>' : ''),
      acciones: {
        guardar: async (form) => {
          const entrada = valores(form);
          if (lugar) {
            const resultado = N.editarLugar(datos(), lugar.id, entrada);
            let mensaje = 'Lugar guardado';
            if (resultado.ok && resultado.detalle && resultado.detalle.plano === 'quitado') {
              mensaje = 'Plano quitado. Los muebles y artículos siguen en «' + resultado.lugar.nombre + '»';
            } else if (resultado.ok && resultado.sinColocar.length) {
              mensaje = 'Plano listo. Quedaron sin colocar: ' + resultado.sinColocar.join(', ');
            }
            if (await ejecutar(resultado, { form: form, mensaje: mensaje, deshacer: true })) cerrarHojas();
            return;
          }
          const resultado = N.crearLugar(datos(), entrada);
          if (await ejecutar(resultado, { form: form })) {
            cerrarHojas();
            U.irALugar(resultado.lugar.id);
            U.avisar(resultado.lugar.plano
              ? 'Lugar creado. Elige un mueble abajo y toca el piso para ponerlo.'
              : 'Lugar creado. Agrega artículos con «+».');
          }
        },
        borrar: () => abrirHoja(() => pantallaBorrarLugar(lugar.id))
      }
    };
  };

  // Borrar un lugar nunca borra artículos en silencio: se muestra qué se afecta y hay dos caminos.
  U.pantallaBorrarLugar = (lugarId) => pantallaBorrarLugar(lugarId);
  function pantallaBorrarLugar(lugarId) {
    const lugar = N.buscarPorId(datos().lugares, lugarId);
    if (!lugar) return null;
    const afectados = N.afectadosPorBorrarLugar(datos(), lugarId);
    const otros = datos().lugares.filter((otro) => otro.id !== lugarId);
    const vacio = !afectados.muebles.length && !afectados.articulos.length;
    const terminar = async (resultado, mensaje) => {
      if (await ejecutar(resultado, { mensaje: mensaje, deshacer: true })) {
        cerrarHojas();
        U.salirDeLugar();
      }
    };
    return {
      html: cabeza('¿Borrar «' + lugar.nombre + '»?') +
        (vacio
          ? '<p>Está vacío: no tiene muebles ni artículos.</p>'
          : '<p>Esto se verá afectado:</p><ul>' +
            (afectados.muebles.length ? '<li>' + N.plural(afectados.muebles.length, 'mueble') + ': ' +
              e(afectados.muebles.slice(0, 6).map((m) => m.nombre).join(', ')) + (afectados.muebles.length > 6 ? '…' : '') + '</li>' : '') +
            (afectados.articulos.length ? '<li>' + N.plural(afectados.articulos.length, 'artículo') + ' (' +
              N.plural(afectados.piezas, 'pieza') + ')</li>' : '') + '</ul>') +
        (!vacio && otros.length
          ? '<form data-form="mover" novalidate><p class="error" role="alert" hidden></p>' +
            '<label class="campo">Opción segura: llevar sus muebles y artículos a<select name="destino">' +
            otros.map((otro) => '<option value="' + e(otro.id) + '">' + e(otro.nombre) + '</option>').join('') + '</select></label>' +
            '<p class="nota">Los muebles llegan «sin colocar» con todo lo que guardan.</p>' +
            '<button class="boton principal">Mover todo y borrar el lugar</button></form><hr class="separador">'
          : '') +
        (vacio
          ? '<div class="fila-botones"><button type="button" class="boton" data-accion="volver">No, conservarlo</button>' +
            '<button type="button" class="boton peligro-lleno" data-accion="borrar">Sí, borrar</button></div>'
          : '<p>' + (otros.length ? 'O bien: ' : '') + 'borrar el lugar' + (afectados.muebles.length ? ' y sus muebles' : '') +
            '. <strong>Los artículos no se borran:</strong> pasan a «Sin ubicación».</p>' +
            '<div class="fila-botones"><button type="button" class="boton" data-accion="volver">No, conservarlo</button>' +
            '<button type="button" class="boton peligro-lleno" data-accion="borrar">Borrar' +
            (afectados.muebles.length ? ' lugar y muebles' : '') + '</button></div>') +
        '<p class="nota">Podrás deshacerlo unos segundos después.</p>',
      acciones: {
        mover: (form) => {
          const resultado = N.borrarLugar(datos(), lugarId, { destinoId: valores(form).destino });
          return terminar(resultado, resultado.ok ? 'Borraste «' + lugar.nombre + '»; todo pasó a «' + resultado.destino.nombre + '»' : '');
        },
        borrar: () => {
          const resultado = N.borrarLugar(datos(), lugarId);
          return terminar(resultado, 'Borraste «' + lugar.nombre + '»' +
            (resultado.articulos ? '; ' + N.plural(resultado.articulos, 'artículo') + ' pasaron a «Sin ubicación»' : ''));
        }
      }
    };
  }

  // =====================================================================
  // CATEGORÍAS
  // =====================================================================
  U.pantallaCategorias = () => {
    const categorias = N.categoriasOrdenadas(datos());
    return {
      html: cabeza('Categorías', 'Crea, cambia o borra las tuyas') +
        '<ul class="lista-toque">' + categorias.map((categoria) => '<li><button type="button" data-accion="editar" data-id="' +
          e(categoria.id) + '"><span class="punto" style="background:' + e(categoria.color) + '"></span><span class="nombre"><strong>' +
          e(categoria.nombre) + '</strong><small>' + N.plural(N.articulosDeCategoria(datos(), categoria.id).length, 'artículo') +
          (categoria.fija ? ' · fija' : '') + '</small></span><span class="flecha">' + ICONOS.flecha + '</span></button></li>').join('') +
        '</ul><form data-form="crear" class="alta-rapida" novalidate><p class="error" role="alert" hidden></p><div class="campos-fila">' +
        '<label class="campo ancho-2">Nueva categoría<input name="nombre" maxlength="' + N.LIMITES.nombre +
        '" autocomplete="off" placeholder="Ej. Música" required></label>' +
        '<label class="campo">Color<input name="color" type="color" value="' + N.COLORES_CATEGORIA[categorias.length % N.COLORES_CATEGORIA.length] +
        '"></label></div><button class="boton">Crear categoría</button></form>',
      acciones: {
        editar: (boton) => abrirHoja(() => pantallaCategoria(boton.dataset.id)),
        crear: async (form) => {
          const resultado = N.crearCategoria(datos(), valores(form));
          if (await ejecutar(resultado, { form: form, mensaje: resultado.ok ? 'Categoría «' + resultado.categoria.nombre + '» creada' : '' })) refrescarHoja();
        }
      }
    };
  };

  function pantallaCategoria(categoriaId) {
    const categoria = N.buscarPorId(datos().categorias, categoriaId);
    if (!categoria) return null;
    const cuantos = N.articulosDeCategoria(datos(), categoriaId).length;
    const otras = N.categoriasOrdenadas(datos()).filter((otra) => otra.id !== categoriaId);
    return {
      html: cabeza(categoria.nombre, N.plural(cuantos, 'artículo')) +
        '<form data-form="guardar" novalidate><p class="error" role="alert" hidden></p><div class="campos-fila">' +
        '<label class="campo ancho-2">Nombre<input name="nombre" maxlength="' + N.LIMITES.nombre + '" value="' + e(categoria.nombre) +
        '" required></label><label class="campo">Color<input name="color" type="color" value="' + e(categoria.color) + '"></label></div>' +
        '<button class="boton principal">Guardar</button></form>' +
        (categoria.fija
          ? '<p class="nota">Esta categoría no se puede borrar: ahí pasan los artículos de las categorías que se borran.</p>'
          : '<hr class="separador"><form data-form="borrar" novalidate><p class="error" role="alert" hidden></p>' +
            (cuantos ? '<label class="campo">Sus ' + N.plural(cuantos, 'artículo') + ' pasan a<select name="destino">' +
              otras.map((otra) => '<option value="' + e(otra.id) + '"' + (otra.id === N.ID_OTROS ? ' selected' : '') + '>' +
              e(otra.nombre) + '</option>').join('') + '</select></label>' : '') +
            '<button class="boton peligro">Borrar categoría</button></form>'),
      acciones: {
        guardar: async (form) => {
          if (await ejecutar(N.editarCategoria(datos(), categoriaId, valores(form)), { form: form, mensaje: 'Categoría guardada' })) volverHoja();
        },
        borrar: async (form) => {
          const resultado = N.borrarCategoria(datos(), categoriaId, valores(form).destino);
          const mensaje = resultado.ok ? 'Borraste «' + categoria.nombre + '»' +
            (resultado.articulos ? '; sus artículos pasaron a «' + resultado.destino.nombre + '»' : '') : '';
          if (await ejecutar(resultado, { form: form, mensaje: mensaje, deshacer: true })) volverHoja();
        }
      }
    };
  }
})();
