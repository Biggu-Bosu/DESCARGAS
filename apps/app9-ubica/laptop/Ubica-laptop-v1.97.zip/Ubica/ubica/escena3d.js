// Ubica · Escena 3D: el mismo lugar que dibuja escena.js, en tres dimensiones reales (Three.js).
//
// Este archivo es un "módulo" que la app carga SOLO cuando se abre la vista 3D (ver vistas.js):
// así quien usa listas o 2.5D no descarga el motor 3D (~690 KB).
//
// Reglas de la arquitectura:
//   - No guarda nada. Lee lo mismo que la escena 2.5D (opciones.estado()) y avisa de lo que hace
//     la persona con opciones.alTocar() y opciones.alArrastrarMueble(); quien valida y guarda es
//     nucleo.js a través de la app. Por eso un mueble movido aquí aparece movido en 2.5D.
//   - Los muebles se arman con el catálogo de piezas de nucleo.js (piezasMueble): tablero,
//     patas, repisas, puertas… con las medidas y el giro guardados en los datos.
//   - Coordenadas: la casilla (x, y) del lugar es el punto (x, z) del mundo 3D; la altura es Y.
//   - Se dibuja solo cuando algo cambia (no 60 veces por segundo) para cuidar la batería.
import * as THREE from './vendor/three.module.min.js';
import { TransformControls } from './vendor/TransformControls.js';

const N = window.Nucleo;
const E = window.Espacio;        // geometría de los objetos propios (ejes, giros, medidas)
const ALTO_PISO = E.METROS_POR_PISO; // cuánto mide en el mundo un "piso" de altura del catálogo
const POLAR_MINIMO = 0.12;       // la cámara casi desde arriba…
const POLAR_MAXIMO = 1.42;       // …y nunca por debajo del piso
const UMBRAL_TOQUE = 8;

export function crear(contenedor, opciones) {
  const temaOscuro = window.matchMedia('(prefers-color-scheme: dark)');
  const renderizador = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'low-power' });
  renderizador.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderizador.shadowMap.enabled = true;
  renderizador.shadowMap.type = THREE.PCFSoftShadowMap;
  renderizador.outputColorSpace = THREE.SRGBColorSpace;
  const lienzo = renderizador.domElement;
  lienzo.setAttribute('role', 'img');
  lienzo.setAttribute('aria-label', 'Vista 3D del lugar');
  lienzo.style.touchAction = 'none';
  contenedor.appendChild(lienzo);

  const escena = new THREE.Scene();
  const camara = new THREE.PerspectiveCamera(42, 1, 0.1, 400);
  const luzAmbiente = new THREE.HemisphereLight(0xffffff, 0x8892a6, 1.15);
  const sol = new THREE.DirectionalLight(0xffffff, 2.1);
  sol.castShadow = true;
  sol.shadow.mapSize.set(1024, 1024);
  sol.shadow.bias = -0.0005;
  sol.shadow.normalBias = 0.03;
  escena.add(luzAmbiente, sol, sol.target);

  const grupoSala = new THREE.Group();     // piso y paredes
  const grupoMuebles = new THREE.Group();  // un grupo por mueble
  const grupoMarcas = new THREE.Group();   // selección y vista previa al arrastrar
  escena.add(grupoSala, grupoMuebles, grupoMarcas);
  const grupoObjetos = new THREE.Group();  // objetos propios que están en el piso del lugar
  escena.add(grupoObjetos);

  const cubo = new THREE.BoxGeometry(1, 1, 1); // todas las piezas son este cubo, estirado
  const materiales = new Map();
  const texturasEtiqueta = new Map();
  const muebles3d = new Map();              // id → { grupo, firma, etiqueta }
  let paredes = [];
  let sala = null;
  let claveSala = '';
  let ancho = 0;
  let alto = 0;
  let destruida = false;
  let cuadroPedido = false;
  let sombrasRevisadas = 0;
  let tiempoAnterior = 0;

  // ---------- Animaciones ----------
  // Cada animación es una función paso(t) con t de 0 a 1. Se apagan con «reducir movimiento»
  // del sistema o con el ajuste «Sin animaciones» de la app: entonces saltan directo al final.
  const pocoMovimiento = window.matchMedia('(prefers-reduced-motion: reduce)');
  const animaciones = [];
  const conAnimaciones = () => !pocoMovimiento.matches && opciones.estado().animaciones !== false;
  const suave = (t) => 1 - Math.pow(1 - t, 3);
  const rebote = (t) => { // llega, se pasa un poco y regresa
    const c = 1.9;
    return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2);
  };
  function animar(duracion, paso, espera) {
    if (!conAnimaciones()) {
      paso(1);
      return;
    }
    paso(0);
    animaciones.push({ inicio: performance.now() + (espera || 0), duracion: duracion, paso: paso });
    pedirCuadro();
  }
  function avanzarAnimaciones(ahora) {
    for (let i = animaciones.length - 1; i >= 0; i--) {
      const a = animaciones[i];
      const t = Math.min(1, (ahora - a.inicio) / a.duracion);
      if (t >= 0) a.paso(t);
      if (t >= 1) animaciones.splice(i, 1);
    }
    return animaciones.length > 0;
  }

  // ---------- Interior del mueble seleccionado ----------
  // Al seleccionar un mueble se vuelve translúcido y aparecen sus artículos como objetos 3D
  // (caja, cilindro, esfera, prisma o pirámide) acomodados en sus repisas.
  const figuras = {
    caja: cubo,
    cilindro: new THREE.CylinderGeometry(0.5, 0.5, 1, 24),
    esfera: new THREE.SphereGeometry(0.5, 24, 16),
    prisma: new THREE.CylinderGeometry(0.58, 0.58, 1, 3),
    piramide: new THREE.ConeGeometry(0.64, 1, 4)
  };
  figuras.piramide.rotateY(Math.PI / 4);
  // Figuras de los objetos propios: cada una cabe justo en una caja de 1 × 1 × 1 centrada (después
  // se estira a sus medidas). Así lo que se ve coincide con lo que revisa espacio.js.
  const figurasPropias = (() => {
    const aro = new THREE.TorusGeometry(0.34, 0.16, 12, 32);
    aro.rotateX(Math.PI / 2);
    aro.scale(1, 1 / 0.32, 1);
    const piramide = new THREE.ConeGeometry(Math.SQRT1_2, 1, 4);
    piramide.rotateY(Math.PI / 4);
    const perfilTubo = [[0.38, -0.5], [0.5, -0.5], [0.5, 0.5], [0.38, 0.5], [0.38, -0.5]].map(([x, y]) => new THREE.Vector2(x, y));
    return {
      caja: cubo, cilindro: figuras.cilindro, esfera: figuras.esfera, cono: new THREE.ConeGeometry(0.5, 1, 28),
      tubo: new THREE.LatheGeometry(perfilTubo, 28), aro: aro, prisma: new THREE.CylinderGeometry(0.5, 0.5, 1, 3), piramide: piramide
    };
  })();
  let interior = null; // el mueble seleccionado («abierto»): { muebleId, firma, resaltadoId }

  // ---------- Cámara: gira alrededor de un punto del piso ----------
  // actual → lo que se ve; meta → a dónde va. Cada cuadro se acerca un poco (movimiento suave).
  const actual = { azimut: Math.PI / 4, polar: 0.95, distancia: 14, x: 0, z: 0 };
  const meta = Object.assign({}, actual);
  let ultimaInteraccion = 0;

  function limitarMeta() {
    meta.polar = Math.max(POLAR_MINIMO, Math.min(POLAR_MAXIMO, meta.polar));
    if (!sala) return;
    const radio = Math.hypot(sala.ancho, sala.fondo) / 2;
    meta.distancia = Math.max(2.5, Math.min(radio * 5 + 6, meta.distancia));
    meta.x = Math.max(-1, Math.min(sala.ancho + 1, meta.x));   // el punto de mira no sale del lugar:
    meta.z = Math.max(-1, Math.min(sala.fondo + 1, meta.z));   // así la cámara nunca se pierde
  }

  function distanciaGeneral() {
    const radio = Math.hypot(sala.ancho, sala.fondo) / 2 + 0.8;
    const medioAngulo = THREE.MathUtils.degToRad(camara.fov / 2);
    const aspecto = ancho && alto ? ancho / alto : 1;
    return (radio / Math.sin(medioAngulo)) * (aspecto < 1 ? Math.min(1.9, 0.8 / aspecto) : 0.74);
  }

  function vistaGeneral(inmediata) {
    if (!sala) return;
    Object.assign(meta, { azimut: Math.PI / 4, polar: 0.95, distancia: distanciaGeneral(), x: sala.ancho / 2, z: sala.fondo / 2 });
    if (inmediata) Object.assign(actual, meta);
    pedirCuadro();
  }

  function colocarCamara() {
    const s = Math.sin(actual.polar);
    camara.position.set(
      actual.x + actual.distancia * s * Math.sin(actual.azimut),
      actual.distancia * Math.cos(actual.polar),
      actual.z + actual.distancia * s * Math.cos(actual.azimut));
    camara.lookAt(actual.x, 0.6, actual.z);
    // Casa de muñecas: se ocultan las paredes que quedarían entre la cámara y el interior
    if (sala && paredes.length) {
      paredes[0].visible = camara.position.x > 0;            // pared en x = 0
      paredes[1].visible = camara.position.x < sala.ancho;   // pared en x = ancho
      paredes[2].visible = camara.position.z > 0;            // pared en z = 0
      paredes[3].visible = camara.position.z < sala.fondo;   // pared en z = fondo
    }
  }

  // ---------- Colores y materiales ----------
  const variableCss = (nombre) => getComputedStyle(contenedor).getPropertyValue(nombre).trim();

  function material(clave, crearMaterial) {
    if (!materiales.has(clave)) materiales.set(clave, crearMaterial());
    return materiales.get(clave);
  }

  function materialDePieza(tipoClave, mat) {
    return material(tipoClave + '|' + mat + '|' + temaOscuro.matches, () => {
      const [tono, saturacion, luzBase] = (N.TIPOS_MUEBLE[tipoClave] || N.TIPOS_MUEBLE.caja).color;
      const luz = luzBase - (temaOscuro.matches ? 5 : 0);
      const hsl = (t, s, l) => new THREE.Color().setHSL(t / 360, s / 100, Math.max(6, Math.min(92, l)) / 100, THREE.SRGBColorSpace);
      if (mat === 'vidrio') {
        return new THREE.MeshStandardMaterial({ color: 0xbfe9f2, transparent: true, opacity: 0.3, roughness: 0.08, metalness: 0.1, depthWrite: false });
      }
      if (mat === 'metal') return new THREE.MeshStandardMaterial({ color: 0x9aa1ad, roughness: 0.35, metalness: 0.75 });
      if (mat === 'madera') return new THREE.MeshStandardMaterial({ color: hsl(30, 48, 60), roughness: 0.7 });
      const luces = { cuerpo: luz, oscuro: luz - 14, claro: luz + 13 };
      return new THREE.MeshStandardMaterial({ color: hsl(tono, saturacion, luces[mat] == null ? luz : luces[mat]), roughness: 0.78 });
    });
  }

  // ---------- Sala: piso con cuadrícula y cuatro paredes bajas ----------
  function construirSala() {
    grupoSala.children.slice().forEach((hijo) => {
      grupoSala.remove(hijo);
      if (hijo.material.map) hijo.material.map.dispose();
      hijo.material.dispose();
      if (hijo.geometry !== cubo) hijo.geometry.dispose();
    });
    const tono = N.TIPOS_LUGAR[sala.tipo].tono;
    const oscuro = temaOscuro.matches;
    // El piso es una imagen con las casillas (una por metro), igual que en 2.5D
    const px = 48;
    const imagen = document.createElement('canvas');
    imagen.width = sala.ancho * px;
    imagen.height = sala.fondo * px;
    const ctx = imagen.getContext('2d');
    for (let x = 0; x < sala.ancho; x++) {
      for (let y = 0; y < sala.fondo; y++) {
        ctx.fillStyle = 'hsl(' + tono + ' 18% ' + ((x + y) % 2 ? (oscuro ? 22 : 93) : (oscuro ? 19 : 89)) + '%)';
        ctx.fillRect(x * px, y * px, px, px);
        ctx.strokeStyle = oscuro ? 'rgba(255,255,255,0.07)' : 'rgba(30,40,70,0.10)';
        ctx.strokeRect(x * px + 0.5, y * px + 0.5, px - 1, px - 1);
      }
    }
    const textura = new THREE.CanvasTexture(imagen);
    textura.colorSpace = THREE.SRGBColorSpace;
    textura.anisotropy = Math.min(8, renderizador.capabilities.getMaxAnisotropy());
    const piso = new THREE.Mesh(new THREE.PlaneGeometry(sala.ancho, sala.fondo), new THREE.MeshStandardMaterial({ map: textura, roughness: 0.95 }));
    piso.rotation.x = -Math.PI / 2;
    piso.position.set(sala.ancho / 2, 0, sala.fondo / 2);
    piso.receiveShadow = true;
    piso.userData.piso = true;
    grupoSala.add(piso);

    const altoPared = N.ALTO_PARED * ALTO_PISO;
    const grosor = 0.12;
    const colorPared = new THREE.Color().setHSL(tono / 360, 0.14, oscuro ? 0.27 : 0.86, THREE.SRGBColorSpace);
    const pared = (x, z, w, d) => {
      const malla = new THREE.Mesh(cubo, new THREE.MeshStandardMaterial({ color: colorPared, roughness: 0.95 }));
      malla.scale.set(w, altoPared, d);
      malla.position.set(x, altoPared / 2, z);
      malla.receiveShadow = true;
      grupoSala.add(malla);
      return malla;
    };
    paredes = [
      pared(-grosor / 2, sala.fondo / 2, grosor, sala.fondo + 2 * grosor),
      pared(sala.ancho + grosor / 2, sala.fondo / 2, grosor, sala.fondo + 2 * grosor),
      pared(sala.ancho / 2, -grosor / 2, sala.ancho, grosor),
      pared(sala.ancho / 2, sala.fondo + grosor / 2, sala.ancho, grosor)
    ];
    // Luces según el tamaño del lugar (las sombras deben cubrirlo completo)
    const radio = Math.hypot(sala.ancho, sala.fondo) / 2 + 1;
    sol.position.set(sala.ancho / 2 + radio * 0.6, radio * 1.8 + 4, sala.fondo / 2 + radio * 0.9);
    sol.target.position.set(sala.ancho / 2, 0, sala.fondo / 2);
    Object.assign(sol.shadow.camera, { left: -radio, right: radio, top: radio, bottom: -radio, near: 0.5, far: radio * 5 + 10 });
    sol.shadow.camera.updateProjectionMatrix();
    luzAmbiente.intensity = oscuro ? 0.75 : 1.15;
    sol.intensity = oscuro ? 1.5 : 2.1;
  }

  // ---------- Muebles ----------
  function construirMueble(mueble) {
    const grupo = new THREE.Group();
    const medidas = N.medidasSinGiro(mueble);
    N.piezasMueble(mueble.tipo, medidas.ancho, medidas.fondo).forEach((pieza) => {
      const malla = new THREE.Mesh(cubo, materialDePieza(mueble.tipo, pieza.mat));
      malla.scale.set(pieza.w, pieza.h * ALTO_PISO, pieza.d);
      // El modelo se arma centrado en su huella, con el frente hacia +z
      malla.position.set(pieza.x + pieza.w / 2 - medidas.ancho / 2, (pieza.z + pieza.h / 2) * ALTO_PISO, pieza.y + pieza.d / 2 - medidas.fondo / 2);
      malla.castShadow = pieza.mat !== 'vidrio';
      malla.receiveShadow = true;
      if (pieza.puerta) {
        // Se recuerda cómo es cerrada, para poder abrirla y volver a cerrarla
        malla.userData.puerta = pieza.puerta;
        malla.userData.cerrada = { ancho: pieza.w, x: malla.position.x };
      }
      grupo.add(malla);
    });
    grupo.rotation.y = -(mueble.giro || 0) * Math.PI / 2; // la orientación guardada en los datos
    grupo.position.set(mueble.x + mueble.ancho / 2, 0, mueble.y + mueble.fondo / 2);
    grupo.userData.muebleId = mueble.id;
    return grupo;
  }

  function texturaEtiqueta(texto) {
    if (!texturasEtiqueta.has(texto)) {
      const imagen = document.createElement('canvas');
      imagen.width = 128;
      imagen.height = 64;
      const ctx = imagen.getContext('2d');
      ctx.fillStyle = temaOscuro.matches ? '#eceef4' : '#ffffff';
      ctx.strokeStyle = 'rgba(20,24,40,0.35)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(32, 6);
      ctx.arcTo(122, 6, 122, 58, 26);
      ctx.arcTo(122, 58, 6, 58, 26);
      ctx.arcTo(6, 58, 6, 6, 26);
      ctx.arcTo(6, 6, 122, 6, 26);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#171a26';
      ctx.font = '700 34px Inter, system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(texto, 64, 34);
      const textura = new THREE.CanvasTexture(imagen);
      textura.colorSpace = THREE.SRGBColorSpace;
      texturasEtiqueta.set(texto, textura);
    }
    return texturasEtiqueta.get(texto);
  }

  function ponerEtiqueta(registro, mueble, piezas) {
    if (registro.etiqueta) {
      registro.grupo.remove(registro.etiqueta);
      registro.etiqueta.material.dispose();
      registro.etiqueta = null;
    }
    if (!piezas) return;
    const etiqueta = new THREE.Sprite(new THREE.SpriteMaterial({ map: texturaEtiqueta(String(piezas)), depthTest: false, sizeAttenuation: false }));
    const altoEtiqueta = 0.03 * Math.min(1.4, 620 / (alto || 620)); // tamaño parecido en celular y en pantalla grande
    etiqueta.scale.set(altoEtiqueta * 2, altoEtiqueta, 1);
    etiqueta.position.set(0, N.altoDe(mueble) * ALTO_PISO + 0.28, 0);
    etiqueta.renderOrder = 10;
    registro.grupo.add(etiqueta);
    registro.etiqueta = etiqueta;
  }

  function quitarMueble(id) {
    const registro = muebles3d.get(id);
    if (!registro) return;
    if (interior && interior.muebleId === id) interior = null;
    if (registro.etiqueta) registro.etiqueta.material.dispose();
    grupoMuebles.remove(registro.grupo);
    muebles3d.delete(id);
  }

  // Pone la escena al día con los datos: solo se rehacen los muebles que cambiaron
  function sincronizar(estado) {
    const nuevaClave = estado.espacio.id + '|' + estado.espacio.ancho + '×' + estado.espacio.fondo + '|' + estado.espacio.tipo + '|' + temaOscuro.matches;
    const cambioDeLugar = !sala || sala.id !== estado.espacio.id;
    sala = estado.espacio;
    if (nuevaClave !== claveSala) {
      claveSala = nuevaClave;
      Array.from(muebles3d.keys()).forEach(quitarMueble);
      construirSala();
      if (cambioDeLugar) vistaGeneral(true);
    }
    const salaRecienAbierta = muebles3d.size === 0;
    const vivos = new Set();
    estado.muebles.forEach((mueble, orden) => {
      vivos.add(mueble.id);
      const piezas = estado.piezas(mueble.id);
      const firma = [mueble.tipo, mueble.x, mueble.y, mueble.ancho, mueble.fondo, mueble.giro || 0].join(',');
      let registro = muebles3d.get(mueble.id);
      if (!registro || registro.firma !== firma) {
        // Si el mueble ya estaba (se movió o giró), el modelo nuevo viaja desde donde estaba el anterior
        const antes = registro ? { posicion: registro.grupo.position.clone(), giro: registro.grupo.rotation.y } : null;
        quitarMueble(mueble.id);
        registro = { grupo: construirMueble(mueble), firma: firma, etiqueta: null, piezas: -1 };
        grupoMuebles.add(registro.grupo);
        muebles3d.set(mueble.id, registro);
        animarLlegada(registro.grupo, antes, salaRecienAbierta ? Math.min(orden * 22, 500) : 0);
      }
      ponerObjetos(registro, mueble, estado, salaRecienAbierta ? Math.min(orden * 22, 500) + 260 : 0);
      if (registro.piezas !== piezas) {
        registro.piezas = piezas;
        ponerEtiqueta(registro, mueble, piezas);
      }
    });
    Array.from(muebles3d.keys()).filter((id) => !vivos.has(id)).forEach(quitarMueble);
    sincronizarObjetos(estado, salaRecienAbierta);
    actualizarInterior(estado);
    marcarSeleccion(estado);
    actualizarSeleccionObjetos(estado);
  }

  // Mueble nuevo: crece desde el piso con un pequeño rebote. Mueble movido o girado: se desliza.
  function animarLlegada(grupo, antes, espera) {
    const destino = grupo.position.clone();
    const giroFinal = grupo.rotation.y;
    if (antes) {
      // El giro va por el camino corto (un cuarto de vuelta, nunca tres)
      let diferencia = (antes.giro - giroFinal) % (Math.PI * 2);
      if (diferencia > Math.PI) diferencia -= Math.PI * 2;
      if (diferencia < -Math.PI) diferencia += Math.PI * 2;
      animar(260, (t) => {
        const k = suave(t);
        grupo.position.lerpVectors(antes.posicion, destino, k);
        grupo.rotation.y = giroFinal + diferencia * (1 - k);
      });
      return;
    }
    animar(380, (t) => {
      const k = Math.max(0.001, rebote(t));
      grupo.scale.set(0.85 + 0.15 * Math.min(1, k), k, 0.85 + 0.15 * Math.min(1, k));
    }, espera);
  }

  function materialDeObjeto(color) {
    return material('objeto|' + color, () => new THREE.MeshStandardMaterial({ color: new THREE.Color(color), roughness: 0.55, metalness: 0.05 }));
  }

  // ---------- Objetos (los artículos de cada mueble) ----------
  // Se dibujan SIEMPRE, en todos los muebles: se ven a simple vista en estantes, mesas, vitrinas
  // y cajas. Los muebles con puertas las abren al seleccionarlos. Nada se vuelve transparente.
  function ponerObjetos(registro, mueble, estado, espera) {
    if (!estado.interior) return;
    const acomodo = estado.interior(mueble);
    const firma = registro.firma + '|' + acomodo.objetos.map((o) => [o.articuloId, o.figura, o.color, o.lado].join(':')).join(',');
    if (registro.firmaObjetos === firma) return;
    const anteriores = new Set(registro.objetos ? registro.objetos.children.map((malla) => malla.userData.articuloId) : []);
    if (registro.objetos) registro.grupo.remove(registro.objetos);
    const grupo = new THREE.Group();
    acomodo.objetos.forEach((objeto, i) => {
      const malla = new THREE.Mesh(figuras[objeto.figura] || cubo, materialDeObjeto(objeto.color));
      malla.position.set(objeto.x, objeto.z * ALTO_PISO + objeto.lado / 2 + 0.02, objeto.y);
      malla.userData.articuloId = objeto.articuloId;
      malla.userData.lado = objeto.lado;
      malla.userData.piso = malla.position.y;
      malla.castShadow = true;
      malla.scale.setScalar(objeto.lado);
      grupo.add(malla);
      // Solo los objetos nuevos aparecen con un rebote (los que ya estaban no parpadean)
      if (!anteriores.has(objeto.articuloId)) {
        animar(300, (t) => malla.scale.setScalar(Math.max(0.001, objeto.lado * rebote(t))), (espera || 0) + 120 + i * 25);
      }
    });
    registro.grupo.add(grupo);
    registro.objetos = grupo;
    registro.firmaObjetos = firma;
  }

  // Abre o cierra las puertas de un mueble: la hoja se pliega hacia su bisagra y las jaladeras se esconden
  function moverPuertas(registro, abrir) {
    if (!registro || Boolean(registro.abierto) === abrir) return;
    registro.abierto = abrir;
    registro.grupo.children.forEach((malla) => {
      const tipo = malla.userData.puerta;
      if (!tipo) return;
      const cerrada = malla.userData.cerrada;
      const desde = abrir ? 0 : 1;
      animar(240, (t) => {
        const k = desde + (abrir ? 1 : -1) * suave(t); // 0 = cerrada, 1 = abierta
        if (tipo === 'hoja') {
          const anchoHoja = cerrada.ancho * (1 - k) + 0.025 * k;
          malla.scale.x = anchoHoja;
          malla.position.x = cerrada.x - cerrada.ancho / 2 + anchoHoja / 2;
        } else {
          malla.visible = k < 0.5;
        }
      });
    });
  }

  function cerrarInterior() {
    if (!interior) return;
    moverPuertas(muebles3d.get(interior.muebleId), false);
    interior = null;
  }

  function abrirInterior(mueble) {
    const registro = muebles3d.get(mueble.id);
    if (!registro) return;
    moverPuertas(registro, true);
    interior = { muebleId: mueble.id, firma: registro.firma, resaltadoId: null };
    // La cámara se acerca al mueble para ver mejor sus objetos
    meta.x = mueble.x + mueble.ancho / 2;
    meta.z = mueble.y + mueble.fondo / 2;
    meta.distancia = Math.min(meta.distancia, Math.max(4.6, distanciaGeneral() * 0.42));
    limitarMeta();
  }

  function enfocarInterior(mueble) {
    const medidas = N.medidasSinGiro(mueble);
    const giro = ((mueble.giro || 0) % 4) * Math.PI / 2;
    meta.x = mueble.x + mueble.ancho / 2;
    meta.z = mueble.y + mueble.fondo / 2;
    // De frente: el frente del mueble mira hacia +y de su marco (girado con el mueble)
    meta.azimut = giro;
    meta.polar = 1.08;
    meta.distancia = Math.max(2.4, Math.max(medidas.ancho, N.altoDe(mueble) * ALTO_PISO) * 2.1);
    limitarMeta();
    pedirCuadro();
  }

  const objetosDe = (muebleId) => {
    const registro = muebles3d.get(muebleId);
    return registro && registro.objetos ? registro.objetos.children : [];
  };

  // Un saltito para el objeto que se tocó o que se está buscando
  function saltar(malla) {
    const piso = malla.userData.piso;
    animar(520, (t) => { malla.position.y = piso + Math.abs(Math.sin(t * Math.PI * 2)) * (1 - t) * 0.16; });
  }

  // El mueble seleccionado es el «abierto»: puertas abiertas y sus objetos se pueden tocar
  let interiorEditado = null; // el mueble que se edita por dentro (editor 3D)
  function actualizarInterior(estado) {
    const moviendo = estado.modo && estado.modo.tipo === 'mover';
    const abiertoId = estado.interiorId || estado.seleccionadoId;
    const mueble = !moviendo && abiertoId && estado.interior ? estado.muebles.find((m) => m.id === abiertoId) : null;
    // Al entrar a editar un mueble por dentro, la cámara se acerca y lo mira de frente
    if ((estado.interiorId || null) !== interiorEditado) {
      interiorEditado = estado.interiorId || null;
      if (mueble && interiorEditado) enfocarInterior(mueble);
    }
    if (!mueble || !muebles3d.get(mueble.id)) {
      cerrarInterior();
      return;
    }
    const firma = muebles3d.get(mueble.id).firma;
    if (!interior || interior.muebleId !== mueble.id || interior.firma !== firma) {
      cerrarInterior();
      abrirInterior(mueble);
    }
    if (interior && interior.resaltadoId !== (estado.articuloResaltadoId || null)) {
      interior.resaltadoId = estado.articuloResaltadoId || null;
      const buscado = objetosDe(mueble.id).find((malla) => malla.userData.articuloId === interior.resaltadoId);
      if (buscado) saltar(buscado);
    }
  }

  // ---------- Objetos propios (los que se crean y editan en el editor 3D) ----------
  // Están en el piso (grupoObjetos, marco del lugar) o dentro de un mueble (en el grupo del mueble,
  // con su posición relativa: si el mueble se mueve o gira, lo acompañan sin cambiar sus datos).
  // Ejes: la app usa x (ancho), y (fondo), z (altura); Three.js usa la altura como su eje y.
  const objetosPropios = new Map(); // id → { malla, figura, etiqueta, unidades, datos, borde }
  const bordeUnidad = new THREE.EdgesGeometry(cubo);
  const materialBorde = new THREE.LineBasicMaterial({ color: 0xffa21a, depthTest: false, transparent: true });
  const materialesRevision = {
    error: new THREE.MeshStandardMaterial({ color: 0xe0434f, emissive: 0x7a1018, roughness: 0.6 }),
    aviso: new THREE.MeshStandardMaterial({ color: 0xf0a72a, emissive: 0x5a3a00, roughness: 0.6 })
  };
  const auxMatriz = new THREE.Matrix4();
  const auxPosicion = new THREE.Vector3();
  const auxGiro = new THREE.Quaternion();
  const auxEscala = new THREE.Vector3();
  let seleccionObjetos = [];
  const tintes = new Map(); // id → 'error' | 'aviso' (mientras se arrastra con el manipulador)

  function ponerPose(malla, objeto) {
    malla.position.set(objeto.pos.x, objeto.pos.z, objeto.pos.y);
    const m = E.cambiarEjesYZ(E.matrizRotacion(objeto.rot));
    auxMatriz.set(m[0][0], m[0][1], m[0][2], 0, m[1][0], m[1][1], m[1][2], 0, m[2][0], m[2][1], m[2][2], 0, 0, 0, 0, 1);
    malla.quaternion.setFromRotationMatrix(auxMatriz);
    malla.scale.set(objeto.medidas.ancho, objeto.medidas.alto, objeto.medidas.fondo);
  }

  // Posición, giro y medidas de una malla, medidos en el marco de "padre" (el lugar o su mueble)
  function poseDe(malla, padre) {
    malla.updateWorldMatrix(true, false);
    padre.updateWorldMatrix(true, false);
    auxMatriz.copy(padre.matrixWorld).invert().multiply(malla.matrixWorld);
    auxMatriz.decompose(auxPosicion, auxGiro, auxEscala);
    const giro = new THREE.Matrix4().makeRotationFromQuaternion(auxGiro).elements; // por columnas
    const filas = [[giro[0], giro[4], giro[8]], [giro[1], giro[5], giro[9]], [giro[2], giro[6], giro[10]]];
    return {
      pos: { x: E.redondear(auxPosicion.x, 4), y: E.redondear(auxPosicion.z, 4), z: E.redondear(auxPosicion.y, 4) },
      rot: E.rotacionDesdeMatriz(E.cambiarEjesYZ(filas)),
      medidas: { ancho: E.redondear(Math.abs(auxEscala.x), 3), fondo: E.redondear(Math.abs(auxEscala.z), 3), alto: E.redondear(Math.abs(auxEscala.y), 3) }
    };
  }

  function padreDe(objeto) {
    if (!objeto.muebleId) return grupoObjetos;
    const registro = muebles3d.get(objeto.muebleId);
    return registro ? registro.grupo : null;
  }

  function quitarObjeto(id) {
    const registro = objetosPropios.get(id);
    if (!registro) return;
    if (transformador.object === registro.malla) transformador.detach();
    if (registro.malla.parent) registro.malla.parent.remove(registro.malla);
    if (registro.etiqueta) {
      if (registro.etiqueta.parent) registro.etiqueta.parent.remove(registro.etiqueta);
      registro.etiqueta.material.dispose();
    }
    objetosPropios.delete(id);
  }

  function sincronizarObjetos(estado, salaRecienAbierta) {
    const lista = estado.objetos3d ? estado.objetos3d() : [];
    const vivos = new Set();
    const arrastrados = new Set(arrastreGizmo ? arrastreGizmo.ids : []);
    lista.forEach((objeto, orden) => {
      const padre = padreDe(objeto);
      if (!padre) return; // su mueble no está en el plano
      vivos.add(objeto.id);
      let registro = objetosPropios.get(objeto.id);
      const figura = objeto.figura + '|' + objeto.color;
      const nuevo = !registro;
      if (nuevo) {
        const malla = new THREE.Mesh(figurasPropias[objeto.figura] || cubo, materialDeObjeto(objeto.color));
        malla.castShadow = true;
        malla.receiveShadow = true;
        malla.userData.objetoId = objeto.id;
        registro = { malla: malla, figura: figura, etiqueta: null, unidades: 0, borde: null };
        objetosPropios.set(objeto.id, registro);
      } else if (registro.figura !== figura) {
        registro.malla.geometry = figurasPropias[objeto.figura] || cubo;
        registro.malla.material = materialDeObjeto(objeto.color);
        registro.figura = figura;
      }
      registro.datos = objeto;
      if (arrastrados.has(objeto.id)) return; // el manipulador lo está moviendo: no se toca
      if (registro.malla.parent !== padre) padre.add(registro.malla);
      ponerPose(registro.malla, objeto);
      registro.malla.material = tintes.has(objeto.id) ? materialesRevision[tintes.get(objeto.id)] : materialDeObjeto(objeto.color);
      ponerEtiquetaObjeto(registro, objeto, padre);
      if (nuevo) {
        // Aparece creciendo con un rebote (al abrir el lugar, uno tras otro)
        const final = registro.malla.scale.clone();
        animar(320, (t) => registro.malla.scale.copy(final).multiplyScalar(Math.max(0.001, rebote(t))),
          salaRecienAbierta ? Math.min(orden * 18, 600) + 300 : 0);
      }
    });
    Array.from(objetosPropios.keys()).filter((id) => !vivos.has(id)).forEach(quitarObjeto);
  }

  // «×4» sobre un objeto que representa varias piezas
  function ponerEtiquetaObjeto(registro, objeto, padre) {
    const unidades = objeto.unidades || 1;
    if (registro.etiqueta && (unidades < 2 || registro.unidades !== unidades)) {
      if (registro.etiqueta.parent) registro.etiqueta.parent.remove(registro.etiqueta);
      registro.etiqueta.material.dispose();
      registro.etiqueta = null;
    }
    registro.unidades = unidades;
    if (unidades < 2) return;
    if (!registro.etiqueta) {
      registro.etiqueta = new THREE.Sprite(new THREE.SpriteMaterial({ map: texturaEtiqueta('×' + unidades), depthTest: false, sizeAttenuation: false }));
      const altoEtiqueta = 0.026 * Math.min(1.4, 620 / (alto || 620));
      registro.etiqueta.scale.set(altoEtiqueta * 2, altoEtiqueta, 1);
      registro.etiqueta.renderOrder = 11;
    }
    if (registro.etiqueta.parent !== padre) padre.add(registro.etiqueta);
    const tope = E.limites(E.formaDeChoque(objeto)).max[2];
    registro.etiqueta.position.set(objeto.pos.x, tope + 0.14, objeto.pos.y);
  }

  // ---------- Manipulador (flechas para mover, aros para girar, cubos para estirar) ----------
  // Se crea ANTES que los gestos de la cámara: así, si el dedo cae en una flecha, el manipulador
  // se entera primero y la cámara no gira.
  const transformador = new TransformControls(camara, lienzo);
  transformador.setSize(window.matchMedia('(pointer: coarse)').matches ? 1.3 : 0.95);
  const ayudaManipulador = transformador.getHelper();
  escena.add(ayudaManipulador);
  const pivote = new THREE.Object3D(); // centro de varios objetos que se mueven juntos
  escena.add(pivote);
  const MODOS = { mover: 'translate', rotar: 'rotate', escalar: 'scale' };
  let arrastreGizmo = null; // { ids, mallas: [{ id, malla, padre }], eje }
  let revisionPendiente = false;

  function actualizarSeleccionObjetos(estado) {
    const ids = (estado.objetosSeleccionados || []).filter((id) => objetosPropios.has(id));
    seleccionObjetos = ids;
    objetosPropios.forEach((registro, id) => {
      const marcado = ids.includes(id);
      if (marcado && !registro.borde) {
        registro.borde = new THREE.LineSegments(bordeUnidad, materialBorde);
        registro.borde.renderOrder = 9;
        registro.malla.add(registro.borde);
      } else if (!marcado && registro.borde) {
        registro.malla.remove(registro.borde);
        registro.borde = null;
      }
    });
    if (arrastreGizmo) return;
    const editable = ids.length && !estado.presentacion && estado.herramienta && MODOS[estado.herramienta];
    if (!editable) {
      if (transformador.object) transformador.detach();
      return;
    }
    const modo = ids.length > 1 && estado.herramienta === 'escalar' ? 'translate' : MODOS[estado.herramienta];
    transformador.setMode(modo);
    transformador.setSpace(modo === 'scale' ? 'local' : 'world');
    transformador.setTranslationSnap(estado.iman ? 0.05 : null);
    transformador.setRotationSnap(estado.iman ? THREE.MathUtils.degToRad(15) : null);
    transformador.setScaleSnap(estado.iman ? 0.05 : null);
    if (ids.length === 1) {
      const malla = objetosPropios.get(ids[0]).malla;
      if (transformador.object !== malla) transformador.attach(malla);
      return;
    }
    // Varios: el manipulador va en el centro de todos
    const caja = new THREE.Box3();
    ids.forEach((id) => caja.expandByObject(objetosPropios.get(id).malla));
    caja.getCenter(pivote.position);
    pivote.quaternion.identity();
    pivote.scale.set(1, 1, 1);
    pivote.updateMatrixWorld(true);
    if (transformador.object !== pivote) transformador.attach(pivote);
  }

  function propuestasDelArrastre() {
    return arrastreGizmo.mallas.map(({ id, malla, padre }) => Object.assign({ id: id }, poseDe(malla, padre)));
  }

  function pintarRevision(resultado) {
    tintes.clear();
    if (resultado && resultado.porId) {
      Object.keys(resultado.porId).forEach((id) => {
        if (resultado.porId[id] === 'error' || resultado.porId[id] === 'aviso') tintes.set(id, resultado.porId[id]);
      });
    }
    arrastreGizmo && arrastreGizmo.mallas.forEach(({ id, malla }) => {
      const registro = objetosPropios.get(id);
      malla.material = tintes.has(id) ? materialesRevision[tintes.get(id)] : materialDeObjeto(registro.datos.color);
    });
  }

  transformador.addEventListener('change', pedirCuadro);
  transformador.addEventListener('mouseDown', () => {
    ultimaInteraccion = performance.now();
    const mallas = seleccionObjetos.map((id) => {
      const malla = objetosPropios.get(id).malla;
      return { id: id, malla: malla, padre: malla.parent };
    });
    arrastreGizmo = { ids: seleccionObjetos.slice(), mallas: mallas, eje: transformador.axis, modo: transformador.mode };
    if (transformador.object === pivote) mallas.forEach(({ malla }) => pivote.attach(malla));
  });
  transformador.addEventListener('objectChange', () => {
    if (!arrastreGizmo || revisionPendiente || !opciones.alPrevisualizarObjetos) return;
    revisionPendiente = true;
    requestAnimationFrame(() => {
      revisionPendiente = false;
      if (!arrastreGizmo) return;
      pintarRevision(opciones.alPrevisualizarObjetos(propuestasDelArrastre()));
      pedirCuadro();
    });
  });
  transformador.addEventListener('mouseUp', () => {
    if (!arrastreGizmo) return;
    const fin = arrastreGizmo;
    const propuestas = propuestasDelArrastre();
    if (transformador.object === pivote) fin.mallas.forEach(({ malla, padre }) => padre.attach(malla));
    arrastreGizmo = null;
    tintes.clear();
    fin.mallas.forEach(({ id, malla }) => { malla.material = materialDeObjeto(objetosPropios.get(id).datos.color); });
    const cambio = propuestas.some((p) => {
      const antes = objetosPropios.get(p.id).datos;
      return JSON.stringify([antes.pos, antes.rot, antes.medidas]) !== JSON.stringify([p.pos, p.rot, p.medidas]);
    });
    if (cambio && opciones.alTransformarObjetos) {
      opciones.alTransformarObjetos(propuestas, { modo: fin.modo, vertical: fin.modo === 'translate' && /Y/.test(fin.eje || '') });
    } else pedirDibujo();
  });

  // ---------- Selección y vista previa del arrastre ----------
  function limpiarMarcas() {
    grupoMarcas.children.slice().forEach((hijo) => {
      grupoMarcas.remove(hijo);
      hijo.geometry.dispose();
      hijo.material.dispose();
    });
  }

  function marco(rect, alturaMueble, color, opacidadPiso) {
    const altura = alturaMueble * ALTO_PISO + 0.06;
    const caja = new THREE.BoxGeometry(rect.ancho + 0.04, altura, rect.fondo + 0.04);
    const lineas = new THREE.LineSegments(new THREE.EdgesGeometry(caja), new THREE.LineBasicMaterial({ color: color, depthTest: false, transparent: true }));
    caja.dispose();
    lineas.position.set(rect.x + rect.ancho / 2, altura / 2, rect.y + rect.fondo / 2);
    lineas.renderOrder = 8;
    const huella = new THREE.Mesh(new THREE.PlaneGeometry(rect.ancho, rect.fondo),
      new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: opacidadPiso, depthWrite: false }));
    huella.rotation.x = -Math.PI / 2;
    huella.position.set(rect.x + rect.ancho / 2, 0.012, rect.y + rect.fondo / 2);
    grupoMarcas.add(lineas, huella);
  }

  function marcarSeleccion(estado) {
    limpiarMarcas();
    const acento = new THREE.Color(variableCss('--acento') || '#3552e0');
    const idMarcado = estado.modo && estado.modo.tipo === 'mover' ? estado.modo.muebleId : estado.seleccionadoId;
    const mueble = idMarcado ? estado.muebles.find((m) => m.id === idMarcado) : null;
    if (mueble && !(arrastre && arrastre.activo)) marco(mueble, N.altoDe(mueble), acento, 0.28);
    if (arrastre && arrastre.activo && arrastre.rect) {
      marco(arrastre.rect, N.altoDe(arrastre.mueble), new THREE.Color(arrastre.valido ? '#19a974' : '#e0434f'), 0.4);
    }
  }

  // ---------- Dibujar ----------
  function pedirCuadro() {
    if (cuadroPedido || destruida) return;
    cuadroPedido = true;
    requestAnimationFrame(cuadro);
  }

  function cuadro(ahora) {
    cuadroPedido = false;
    if (destruida || !sala || !ancho || contenedor.hidden) return;
    const estado = opciones.estado();
    // En modo presentación la cámara gira despacio mientras nadie la toca
    // El avance depende del tiempo, no de cuántos cuadros por segundo logre el dispositivo
    const transcurrido = Math.min(120, tiempoAnterior ? ahora - tiempoAnterior : 16);
    tiempoAnterior = ahora;
    if (estado.presentacion && ahora - ultimaInteraccion > 3500) meta.azimut += 0.00014 * transcurrido;
    let enMovimiento = estado.presentacion;
    const avance = 1 - Math.exp(-transcurrido / 75);
    ['azimut', 'polar', 'distancia', 'x', 'z'].forEach((clave) => {
      const falta = meta[clave] - actual[clave];
      if (Math.abs(falta) > 0.0008) {
        actual[clave] += falta * avance;
        enMovimiento = true;
      } else actual[clave] = meta[clave];
    });
    if (avanzarAnimaciones(performance.now())) enMovimiento = true;
    if (!enMovimiento) tiempoAnterior = 0;
    colocarCamara();
    const inicio = performance.now();
    renderizador.render(escena, camara);
    // Si el dispositivo va lento con sombras, se apagan (prioridad: que se pueda usar)
    if (renderizador.shadowMap.enabled && sombrasRevisadas < 12) {
      sombrasRevisadas++;
      if (sombrasRevisadas > 4 && performance.now() - inicio > 45) {
        renderizador.shadowMap.enabled = false;
        sol.castShadow = false;
        materiales.forEach((m) => { m.needsUpdate = true; });
        enMovimiento = true;
      }
    }
    if (enMovimiento) pedirCuadro();
  }

  function pedirDibujo() {
    if (destruida) return;
    const estado = opciones.estado();
    if (!estado.espacio || contenedor.hidden) return;
    if (!ancho) ajustarTamano();
    sincronizar(estado);
    pedirCuadro();
  }

  function ajustarTamano() {
    const caja = contenedor.getBoundingClientRect();
    if (!caja.width || !caja.height) return;
    const primera = !ancho;
    ancho = caja.width;
    alto = caja.height;
    renderizador.setSize(ancho, alto, false);
    lienzo.style.width = '100%';
    lienzo.style.height = '100%';
    camara.aspect = ancho / alto;
    camara.updateProjectionMatrix();
    if (primera && sala) vistaGeneral(true);
    pedirCuadro();
  }

  // ---------- Qué hay bajo el dedo ----------
  const rayo = new THREE.Raycaster();
  const planoPiso = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

  function apuntar(p) {
    rayo.setFromCamera(new THREE.Vector2((p.x / ancho) * 2 - 1, -(p.y / alto) * 2 + 1), camara);
  }

  function muebleEn(p) {
    apuntar(p);
    const toques = rayo.intersectObjects(grupoMuebles.children, true).filter((t) => !t.object.isSprite);
    if (!toques.length) return null;
    let objeto = toques[0].object;
    while (objeto && !objeto.userData.muebleId) objeto = objeto.parent;
    if (!objeto) return null;
    return opciones.estado().muebles.find((m) => m.id === objeto.userData.muebleId) || null;
  }

  // ¿Se tocó uno de los objetos del mueble seleccionado? Devuelve el id de su artículo.
  // Las repisas y paredes del propio mueble no estorban al toque (desde arriba suelen tapar un
  // poco al objeto), pero otro mueble que esté delante sí.
  function objetoEn(p) {
    if (!interior) return null;
    const registro = muebles3d.get(interior.muebleId);
    if (!registro) return null;
    apuntar(p);
    const toques = rayo.intersectObjects(grupoMuebles.children, true).filter((t) => !t.object.isSprite && t.object.visible);
    for (const toque of toques) {
      if (toque.object.userData.articuloId && toque.object.parent === registro.objetos) {
        saltar(toque.object);
        return toque.object.userData.articuloId;
      }
      if (toque.object.parent !== registro.grupo) return null; // hay otro mueble (o un objeto ajeno) delante
    }
    return null;
  }

  function muebleDeMalla(objeto) {
    while (objeto && !objeto.userData.muebleId) objeto = objeto.parent;
    return objeto ? objeto.userData.muebleId : null;
  }

  // Qué hay bajo el dedo: un objeto propio, un objeto del mueble abierto (dibujado solo) o un mueble
  function resolverToque(p) {
    const estado = opciones.estado();
    const casilla = casillaEn(p);
    apuntar(p);
    const abiertoId = interior ? interior.muebleId : null;
    const toques = rayo.intersectObjects([grupoObjetos, grupoMuebles], true)
      .filter((t) => !t.object.isSprite && !t.object.isLineSegments && t.object.visible);
    let tocoAbierto = false;
    for (const toque of toques) {
      const malla = toque.object;
      if (malla.userData.objetoId) return { casilla: casilla, mueble: null, objetoId: malla.userData.objetoId };
      const muebleId = muebleDeMalla(malla);
      if (malla.userData.articuloId && abiertoId && muebleId === abiertoId) {
        saltar(malla);
        return { casilla: casilla, mueble: null, articuloId: malla.userData.articuloId, muebleId: abiertoId, automatico: true };
      }
      if (abiertoId && muebleId === abiertoId) {
        tocoAbierto = true; // sus repisas y paredes no tapan lo que guarda
        continue;
      }
      return { casilla: casilla, mueble: muebleId ? estado.muebles.find((m) => m.id === muebleId) || null : null };
    }
    return { casilla: casilla, mueble: tocoAbierto ? estado.muebles.find((m) => m.id === abiertoId) || null : null };
  }

  function objetoPropioBajo(p) {
    apuntar(p);
    const toque = rayo.intersectObjects([grupoObjetos, grupoMuebles], true).find((t) => !t.object.isSprite && !t.object.isLineSegments && t.object.visible);
    return toque && toque.object.userData.objetoId ? toque.object.userData.objetoId : null;
  }

  function puntoDelPiso(p) {
    apuntar(p);
    return rayo.ray.intersectPlane(planoPiso, new THREE.Vector3());
  }

  function casillaEn(p) {
    const punto = puntoDelPiso(p);
    if (!punto || !sala) return null;
    const casilla = { x: Math.floor(punto.x), y: Math.floor(punto.z) };
    if (casilla.x < 0 || casilla.y < 0 || casilla.x >= sala.ancho || casilla.y >= sala.fondo) return null;
    return casilla;
  }

  // ---------- Gestos: orbitar, desplazar, acercar, tocar y arrastrar un mueble ----------
  const dedos = new Map();
  let gesto = null;     // { tipo: 'orbita' | 'desplazar' | 'arrastre', inicio, movido }
  let arrastre = null;  // { mueble, pisoInicio, rect, valido, activo }
  let pellizco = null;

  const posicion = (evento) => {
    const caja = lienzo.getBoundingClientRect();
    return { x: evento.clientX - caja.left, y: evento.clientY - caja.top };
  };

  function desplazar(dx, dy) {
    // Mueve el punto de mira sobre el piso, en la dirección en que se arrastra la pantalla
    const paso = actual.distancia * 0.0016;
    const cos = Math.cos(actual.azimut);
    const sen = Math.sin(actual.azimut);
    meta.x += (-dx * cos - dy * sen) * paso;
    meta.z += (dx * sen - dy * cos) * paso;
  }

  lienzo.addEventListener('pointerdown', (evento) => {
    if (transformador.dragging) return; // el dedo cayó en el manipulador
    try {
      lienzo.setPointerCapture(evento.pointerId);
    } catch (error) {
      // Sin captura el gesto funciona igual mientras el dedo siga sobre el lienzo
    }
    const p = posicion(evento);
    dedos.set(evento.pointerId, p);
    ultimaInteraccion = performance.now();
    if (dedos.size === 2) {
      // Segundo dedo: pellizco. Se cancela cualquier arrastre de mueble.
      if (arrastre) soltarArrastre(true);
      const [a, b] = Array.from(dedos.values());
      pellizco = { separacion: Math.hypot(a.x - b.x, a.y - b.y), cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2 };
      gesto = { tipo: 'pellizco', movido: true };
      return;
    }
    const estado = opciones.estado();
    const mueble = muebleEn(p);
    const puedeArrastrar = opciones.alArrastrarMueble && mueble && mueble.id === estado.seleccionadoId && !estado.modo &&
      !estado.presentacion && !estado.interiorId && !objetoPropioBajo(p);
    if (puedeArrastrar) {
      arrastre = { mueble: mueble, pisoInicio: puntoDelPiso(p), rect: null, valido: false, activo: false };
      gesto = { tipo: 'arrastre', inicio: p, movido: false };
    } else {
      const desplazando = evento.button === 2 || evento.button === 1 || evento.shiftKey;
      gesto = { tipo: desplazando ? 'desplazar' : 'orbita', inicio: p, movido: false, mueble: mueble };
    }
  });

  lienzo.addEventListener('pointermove', (evento) => {
    if (!dedos.has(evento.pointerId) || !gesto) return;
    const antes = dedos.get(evento.pointerId);
    const p = posicion(evento);
    dedos.set(evento.pointerId, p);
    ultimaInteraccion = performance.now();
    if (gesto.tipo === 'pellizco' && dedos.size >= 2) {
      const [a, b] = Array.from(dedos.values());
      const separacion = Math.hypot(a.x - b.x, a.y - b.y);
      const cx = (a.x + b.x) / 2;
      const cy = (a.y + b.y) / 2;
      if (pellizco.separacion > 0 && separacion > 0) meta.distancia *= pellizco.separacion / separacion;
      desplazar(cx - pellizco.cx, cy - pellizco.cy);
      pellizco = { separacion: separacion, cx: cx, cy: cy };
      limitarMeta();
      pedirCuadro();
      return;
    }
    if (!gesto.movido && Math.hypot(p.x - gesto.inicio.x, p.y - gesto.inicio.y) < UMBRAL_TOQUE) return;
    gesto.movido = true;
    if (gesto.tipo === 'arrastre') {
      moverArrastre(p);
      return;
    }
    const dx = p.x - antes.x;
    const dy = p.y - antes.y;
    if (gesto.tipo === 'orbita') {
      meta.azimut -= dx * 0.008;
      meta.polar -= dy * 0.006;
    } else desplazar(dx, dy);
    limitarMeta();
    pedirCuadro();
  });

  function moverArrastre(p) {
    const punto = puntoDelPiso(p);
    if (!punto || !arrastre.pisoInicio) return;
    const m = arrastre.mueble;
    const limitar = (valor, maximo) => Math.max(0, Math.min(maximo, valor));
    arrastre.activo = true;
    arrastre.rect = {
      x: limitar(m.x + Math.round(punto.x - arrastre.pisoInicio.x), sala.ancho - m.ancho),
      y: limitar(m.y + Math.round(punto.z - arrastre.pisoInicio.z), sala.fondo - m.fondo),
      ancho: m.ancho, fondo: m.fondo
    };
    const estado = opciones.estado();
    arrastre.valido = N.cabe(arrastre.rect, sala, estado.muebles, m.id);
    const registro = muebles3d.get(m.id);
    if (registro) registro.grupo.position.set(arrastre.rect.x + m.ancho / 2, 0.05, arrastre.rect.y + m.fondo / 2);
    lienzo.style.cursor = 'grabbing';
    marcarSeleccion(estado);
    pedirCuadro();
  }

  function soltarArrastre(cancelado) {
    const fin = arrastre;
    arrastre = null;
    lienzo.style.cursor = '';
    const seMueve = !cancelado && fin.activo && fin.valido && fin.rect && (fin.rect.x !== fin.mueble.x || fin.rect.y !== fin.mueble.y);
    const registro = muebles3d.get(fin.mueble.id);
    // Si no se movió (o no cabe), el modelo regresa deslizándose a su casilla
    if (registro && !seMueve && fin.activo) {
      const desde = registro.grupo.position.clone();
      const casa = new THREE.Vector3(fin.mueble.x + fin.mueble.ancho / 2, 0, fin.mueble.y + fin.mueble.fondo / 2);
      animar(220, (t) => registro.grupo.position.lerpVectors(desde, casa, suave(t)));
    }
    marcarSeleccion(opciones.estado());
    pedirCuadro();
    if (seMueve) opciones.alArrastrarMueble(fin.mueble.id, fin.rect);
  }

  function terminarGesto(evento, cancelado) {
    if (!dedos.has(evento.pointerId)) return;
    const p = posicion(evento);
    dedos.delete(evento.pointerId);
    const fin = gesto;
    if (dedos.size === 0) gesto = null;
    if (!fin) return;
    if (fin.tipo === 'arrastre' && arrastre) {
      const fueToque = !fin.movido;
      const mueble = arrastre.mueble;
      soltarArrastre(cancelado);
      if (fueToque && !cancelado) opciones.alTocar(Object.assign(resolverToque(p), { sumar: evento.ctrlKey || evento.metaKey }));
      return;
    }
    if (!cancelado && !fin.movido && fin.tipo !== 'pellizco') {
      // Ctrl (o Cmd en Mac) + clic suma o quita el objeto de la selección
      opciones.alTocar(Object.assign(resolverToque(p), { sumar: evento.ctrlKey || evento.metaKey }));
    }
  }
  lienzo.addEventListener('pointerup', (evento) => terminarGesto(evento, false));
  lienzo.addEventListener('pointercancel', (evento) => terminarGesto(evento, true));
  lienzo.addEventListener('contextmenu', (evento) => evento.preventDefault());
  lienzo.addEventListener('wheel', (evento) => {
    evento.preventDefault();
    ultimaInteraccion = performance.now();
    meta.distancia *= Math.exp(evento.deltaY * 0.0012);
    limitarMeta();
    pedirCuadro();
  }, { passive: false });

  lienzo.addEventListener('webglcontextlost', (evento) => {
    evento.preventDefault();
    console.warn('El dispositivo liberó la memoria gráfica de la vista 3D.');
  });
  lienzo.addEventListener('webglcontextrestored', () => {
    claveSala = '';
    pedirDibujo();
  });

  const observador = window.ResizeObserver ? new ResizeObserver(ajustarTamano) : null;
  if (observador) observador.observe(contenedor);
  const alCambiarTema = () => {
    materiales.forEach((m) => m.dispose());
    materiales.clear();
    texturasEtiqueta.forEach((t) => t.dispose());
    texturasEtiqueta.clear();
    claveSala = '';
    pedirDibujo();
  };
  temaOscuro.addEventListener('change', alCambiarTema);

  // Punto de la pantalla (relativo al lienzo) de un punto del mundo: lo usan las pruebas
  function aPantalla(x, y, z) {
    colocarCamara();
    camara.updateMatrixWorld();
    const v = new THREE.Vector3(x, y, z).project(camara);
    return { x: (v.x + 1) / 2 * ancho, y: (1 - v.y) / 2 * alto };
  }

  // ---------- Lo que la app puede pedirle a la escena (mismo contrato que escena.js) ----------
  return {
    pedirDibujo: pedirDibujo,
    ajustarTamano: ajustarTamano,
    rotacion: () => 0, // aquí las casillas ya vienen en coordenadas del lugar
    zoom: () => (sala ? distanciaGeneral() / actual.distancia : 1),
    girar() {
      meta.azimut += Math.PI / 2;
      pedirCuadro();
    },
    acercar(factor) {
      meta.distancia /= factor;
      limitarMeta();
      pedirCuadro();
    },
    centrar: () => vistaGeneral(false),
    reiniciar() {
      sala = null;
      claveSala = '';
    },
    // Lleva la cámara a un mueble (al seleccionarlo desde la lista o al cambiar de vista)
    enfocar(mueble) {
      if (!sala) return;
      meta.x = mueble.x + mueble.ancho / 2;
      meta.z = mueble.y + mueble.fondo / 2;
      meta.distancia = Math.min(meta.distancia, Math.max(6, distanciaGeneral() * 0.55));
      limitarMeta();
      pedirCuadro();
    },
    puntoDeMueble(muebleId) {
      const m = opciones.estado().muebles.find((mueble) => mueble.id === muebleId);
      return m ? aPantalla(m.x + m.ancho / 2, N.altoDe(m) * ALTO_PISO * 0.6, m.y + m.fondo / 2) : null;
    },
    puntoDeCasilla: (x, y) => aPantalla(x + 0.5, 0, y + 0.5),
    // Punto del piso que está al centro de la vista (ahí se crean los objetos nuevos)
    centroDeVista: () => ({ x: meta.x, y: meta.z }),
    // Un punto de la pantalla donde el objeto se ve (no tapado ni en un hueco, como el de un aro)
    puntoDeObjetoPropio(id) {
      const registro = objetosPropios.get(id);
      if (!registro) return null;
      const caja = new THREE.Box3().setFromObject(registro.malla);
      const centro = caja.getCenter(new THREE.Vector3());
      const medida = caja.getSize(new THREE.Vector3());
      const pruebas = [[0, 0, 0], [0.35, 0.3, 0], [-0.35, 0.3, 0], [0, 0.3, 0.35], [0, 0.3, -0.35], [0.3, 0, 0.3], [-0.3, 0, -0.3]];
      for (const [fx, fy, fz] of pruebas) {
        const p = aPantalla(centro.x + fx * medida.x, centro.y + fy * medida.y, centro.z + fz * medida.z);
        apuntar(p);
        const toque = rayo.intersectObjects([grupoObjetos, grupoMuebles], true).find((t) => !t.object.isSprite && !t.object.isLineSegments && t.object.visible);
        if (toque && toque.object === registro.malla) return p;
      }
      return aPantalla(centro.x, centro.y, centro.z);
    },
    // Punto de pantalla de una manija del manipulador ('X', 'Y', 'Z', 'XY'…) — para las pruebas
    puntoDeManija(eje) {
      if (!transformador.object) return null;
      colocarCamara();
      ayudaManipulador.updateMatrixWorld(true);
      const selector = transformador._gizmo.picker[transformador.mode];
      const manija = selector && selector.children.find((hijo) => hijo.name === eje);
      if (!manija) return null;
      const centro = new THREE.Box3().setFromObject(manija).getCenter(new THREE.Vector3());
      return aPantalla(centro.x, centro.y, centro.z);
    },
    // Dónde se ve en pantalla el objeto de un artículo (solo con su mueble abierto)
    puntoDeObjeto(articuloId) {
      const malla = interior && objetosDe(interior.muebleId).find((m) => m.userData.articuloId === articuloId);
      if (!malla) return null;
      const punto = malla.getWorldPosition(new THREE.Vector3());
      return aPantalla(punto.x, punto.y, punto.z);
    },
    // Datos para las pruebas automáticas: qué hay construido y dónde
    info() {
      const posiciones = {};
      muebles3d.forEach((registro, id) => {
        posiciones[id] = { x: registro.grupo.position.x, z: registro.grupo.position.z, giro: registro.grupo.rotation.y, mallas: registro.grupo.children.length };
      });
      const propios = {};
      objetosPropios.forEach((registro, id) => {
        const punto = registro.malla.getWorldPosition(new THREE.Vector3());
        propios[id] = { x: E.redondear(punto.x, 4), y: E.redondear(punto.z, 4), z: E.redondear(punto.y, 4), muebleId: muebleDeMalla(registro.malla), figura: registro.datos.figura, etiqueta: registro.etiqueta ? registro.unidades : null };
      });
      return {
        propios: propios, seleccionObjetos: seleccionObjetos.slice(), tintes: Object.fromEntries(tintes),
        manipulador: { visible: Boolean(transformador.object), modo: transformador.mode, enPivote: transformador.object === pivote, arrastrando: Boolean(arrastreGizmo) },
        interiorEditado: interiorEditado,
        muebles: muebles3d.size, posiciones: posiciones, sombras: renderizador.shadowMap.enabled,
interior: interior ? { muebleId: interior.muebleId, objetos: objetosDe(interior.muebleId).map((m) => ({ articuloId: m.userData.articuloId, figura: m.geometry.type, color: '#' + m.material.color.getHexString(THREE.SRGBColorSpace) })) } : null,
        // Objetos dibujados en total (en todos los muebles) y piezas translúcidas que no sean vidrio
        objetos: Array.from(muebles3d.keys()).reduce((suma, id) => suma + objetosDe(id).length, 0),
        translucidas: Array.from(muebles3d.values()).reduce((suma, r) => suma + r.grupo.children.filter((m) => m.isMesh && m.material.transparent && m.material.opacity > 0.35 && m.material.opacity < 1).length, 0),
        animando: animaciones.length,
        camara: Object.assign({}, actual), memoria: Object.assign({}, renderizador.info.memory), dibujos: renderizador.info.render.calls
      };
    },
    // Libera la memoria gráfica (al salir del lugar): geometrías, materiales, texturas y el lienzo
    destruir() {
      destruida = true;
      if (observador) observador.disconnect();
      temaOscuro.removeEventListener('change', alCambiarTema);
      animaciones.length = 0;
      interior = null;
      transformador.detach();
      transformador.dispose();
      Array.from(objetosPropios.keys()).forEach(quitarObjeto);
      Array.from(muebles3d.keys()).forEach(quitarMueble);
      bordeUnidad.dispose();
      materialBorde.dispose();
      Object.values(materialesRevision).forEach((m) => m.dispose());
      ['cono', 'tubo', 'aro', 'prisma', 'piramide'].forEach((clave) => figurasPropias[clave].dispose());
      limpiarMarcas();
      Object.values(figuras).forEach((geometria) => geometria.dispose());
      grupoSala.children.forEach((hijo) => {
        if (hijo.material.map) hijo.material.map.dispose();
        hijo.material.dispose();
        if (hijo.geometry !== cubo) hijo.geometry.dispose();
      });
      materiales.forEach((m) => m.dispose());
      texturasEtiqueta.forEach((t) => t.dispose());
      cubo.dispose();
      sol.shadow.map && sol.shadow.map.dispose();
      renderizador.dispose();
      renderizador.forceContextLoss();
      lienzo.remove();
    }
  };
}
