// Ubica · Núcleo: toda la lógica que NO dibuja ni toca la pantalla.
// Por eso se puede probar con node (carpeta Pruebas/) sin abrir un navegador.
//
// Contenido:
//   1. Catálogos (tipos de lugar y de mueble, categorías, estados) y límites
//   2. Utilidades de texto y fechas
//   3. Geometría isométrica: proyección, giro de la vista, choques y orden de dibujo
//   4. Cámara (zoom y desplazamiento) y gestos táctiles
//   5. Consultas: dónde está cada artículo, existencias, búsqueda, préstamos y resumen
//   6. Validación de formularios
//   7. Operaciones: cada una devuelve una lista de "cambios" para la base de datos
//   8. Historial (movimientos)
//   9. Respaldo: formato 2, conversión del formato 1, revisión y reparación segura
//  10. Migración de la base de datos a la versión 3
//  11. Copias de seguridad, CSV y datos de ejemplo
//
// El modelo (Etapa 1A):
//   - Un LUGAR puede tener plano (medidas) o no. Sin plano sirve para listas.
//   - Un MUEBLE pertenece a un lugar; puede estar colocado en el plano (x, y) o sin colocar.
//   - Un ARTÍCULO está en UNO solo de estos sitios: en un mueble, directo en un lugar o sin ubicación.
//   - Las existencias de un artículo se cuentan por estado: buen estado, en reparación y dañado.
//     El total se calcula (nunca se guarda) y las prestadas salen de los préstamos activos.
(function (raiz) {
  'use strict';

  // Geometría 3D y reglas espaciales (espacio.js): en el navegador se carga antes que este archivo
  const Espacio = typeof module !== 'undefined' && module.exports ? require('./espacio.js') : raiz.Espacio;

  // =====================================================================
  // 1. CATÁLOGOS Y LÍMITES
  // =====================================================================

  const LIMITES = {
    nombre: 40,
    persona: 60,
    grupo: 40,
    codigo: 30,
    notas: 200,
    motivo: 120,
    cantidad: 9999,
    ladoMinimo: 3,
    ladoMaximo: 20,
    lugares: 100,
    categorias: 40,
    objetos: 3000,
    modelos: 60,
    piezasModelo: 40,
    diasPrestamo: 365
  };

  // tono: el color (de 0 a 360 en el círculo de colores) con que se tiñe el piso del plano
  const TIPOS_LUGAR = {
    laboratorio: { nombre: 'Laboratorio', tono: 195 },
    salon: { nombre: 'Salón', tono: 40 },
    computo: { nombre: 'Sala de cómputo', tono: 250 },
    bodega: { nombre: 'Bodega', tono: 80 },
    biblioteca: { nombre: 'Biblioteca', tono: 320 },
    taller: { nombre: 'Taller', tono: 15 },
    oficina: { nombre: 'Oficina', tono: 160 },
    otro: { nombre: 'Otro', tono: 220 }
  };

  // ancho y fondo: casillas que ocupa (1 casilla ≈ 1 metro). alto: altura en "pisos".
  // color: [tono, saturación %, luz %]. detalle: dibujo extra en sus caras.
  const TIPOS_MUEBLE = {
    mesa: { nombre: 'Mesa', ancho: 2, fondo: 1, alto: 0.45, color: [28, 45, 52], detalle: null },
    escritorio: {
      nombre: 'Escritorio', ancho: 2, fondo: 1, alto: 0.5, color: [20, 30, 42], detalle: 'cajones'
    },
    estante: {
      nombre: 'Estante', ancho: 1, fondo: 1, alto: 1.6, color: [215, 35, 50], detalle: 'repisas'
    },
    gabinete: {
      nombre: 'Gabinete', ancho: 1, fondo: 1, alto: 1.0, color: [150, 30, 42], detalle: 'puertas'
    },
    vitrina: {
      nombre: 'Vitrina', ancho: 2, fondo: 1, alto: 1.3, color: [190, 45, 58], detalle: 'vidrio'
    },
    casillero: {
      nombre: 'Casillero', ancho: 1, fondo: 1, alto: 1.5, color: [5, 45, 52], detalle: 'puertas'
    },
    caja: { nombre: 'Caja', ancho: 1, fondo: 1, alto: 0.45, color: [38, 55, 55], detalle: 'cinta' },
    banco: { nombre: 'Banco', ancho: 1, fondo: 1, alto: 0.3, color: [0, 0, 50], detalle: null }
  };

  // Categorías con las que empieza toda base de datos. «Otros» es fija: no se puede borrar,
  // porque es a donde pasan los artículos cuando se borra su categoría.
  const ID_OTROS = 'cat-otros';
  const CATEGORIAS_INICIALES = [
    ['cat-laboratorio', 'Laboratorio', '#2f80ed'],
    ['cat-computo', 'Cómputo', '#6c5ce7'],
    ['cat-audiovisual', 'Audiovisual', '#d63384'],
    ['cat-deportes', 'Deportes', '#14966b'],
    ['cat-mobiliario', 'Mobiliario', '#9a5b2e'],
    ['cat-papeleria', 'Papelería', '#c99a06'],
    ['cat-herramientas', 'Herramientas', '#5f6b76'],
    ['cat-limpieza', 'Limpieza', '#0f9fa8'],
    ['cat-seguridad', 'Seguridad', '#d63031'],
    ['cat-consumibles', 'Consumibles', '#e0662f'],
    ['cat-refacciones', 'Refacciones', '#2563a8'],
    [ID_OTROS, 'Otros', '#7b8794']
  ];
  const COLORES_CATEGORIA = CATEGORIAS_INICIALES.map((categoria) => categoria[2]);

  function categoriasIniciales() {
    return CATEGORIAS_INICIALES.map(([id, nombre, color], orden) =>
      ({ id: id, nombre: nombre, color: color, orden: orden, fija: id === ID_OTROS }));
  }

  // Estados de las existencias de un artículo (las prestadas NO son un estado: salen de los préstamos)
  const ESTADOS = [
    { clave: 'bueno', nombre: 'Buen estado' },
    { clave: 'reparacion', nombre: 'En reparación' },
    { clave: 'danado', nombre: 'Dañado' }
  ];
  const CLAVES_ESTADO = ESTADOS.map((estado) => estado.clave);

  const TIPOS_MOVIMIENTO = {
    alta: 'Alta',
    edicion: 'Edición',
    'cambio-ubicacion': 'Cambio de ubicación',
    'auto-orden': 'Acomodo automático',
    entrada: 'Entrada de existencias',
    'cambio-estado': 'Cambio de estado',
    baja: 'Baja',
    prestamo: 'Préstamo',
    devolucion: 'Devolución',
    colocar: 'Colocado en el plano',
    mover: 'Movido en el plano',
    girar: 'Girado',
    borrado: 'Borrado',
    deshacer: 'Deshacer',
    restauracion: 'Restauración de respaldo',
    migracion: 'Actualización de los datos',
    'reparacion-datos': 'Reparación de datos'
  };

  // Tablas (almacenes) de la base de datos, versión 3:
  //   lugares ← muebles (lugarId) ← articulos (muebleId o lugarId) ← prestamos (articuloId)
  //   categorias ← articulos (categoriaId) · movimientos: historial de todo lo anterior
  const VISTAS_LUGAR = ['lista', '2.5d', '3d'];
  // Versión 4: objetos ← formas 3D (en el piso de un lugar o dentro de un mueble, enlazables a un
  // artículo) · modelos ← formas compuestas que la persona guarda para reutilizar.
  const TABLAS = ['lugares', 'muebles', 'articulos', 'prestamos', 'categorias', 'movimientos', 'objetos', 'modelos'];
  const TABLA_COPIAS = 'copias'; // copias de seguridad automáticas (no forma parte del respaldo)
  const INDICES = {
    lugares: [],
    muebles: ['lugarId'],
    articulos: ['muebleId', 'lugarId', 'categoriaId'],
    prestamos: ['articuloId'],
    categorias: [],
    movimientos: ['entidadId', 'momento'],
    objetos: ['lugarId', 'muebleId', 'articuloId'],
    modelos: []
  };
  // Tablas de las versiones 1 y 2 de la base de datos (para migrar)
  const TABLAS_ANTIGUAS = ['espacios', 'muebles', 'equipo', 'prestamos'];

  // =====================================================================
  // 2. UTILIDADES DE TEXTO Y FECHAS
  // =====================================================================

  // Quita acentos y mayúsculas para que "matraz erlenmeyer" encuentre "Matraz Erlenmeyer".
  function normalizar(texto) {
    return String(texto == null ? '' : texto)
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Evita que un texto escrito por el usuario se convierta en HTML (por ejemplo <script>).
  function escaparHTML(texto) {
    return String(texto == null ? '' : texto)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Identificador único, por ejemplo "mue-lz3k9a-4f2c"
  function nuevoId(prefijo) {
    const azar = Math.random().toString(36).slice(2, 6);
    return (prefijo || 'id') + '-' + Date.now().toString(36) + '-' + azar;
  }

  function dosDigitos(numero) {
    return (numero < 10 ? '0' : '') + numero;
  }

  // Fecha local como texto 'AAAA-MM-DD' (así la guarda la base de datos)
  function fechaISO(fecha) {
    const dia = fecha || new Date();
    return dia.getFullYear() + '-' + dosDigitos(dia.getMonth() + 1) + '-' + dosDigitos(dia.getDate());
  }

  function leerFechaISO(texto) {
    const partes = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(texto || ''));
    if (!partes) return null;
    const fecha = new Date(Number(partes[1]), Number(partes[2]) - 1, Number(partes[3]));
    // new Date(2026, 1, 31) se convierte en 3 de marzo: así detectamos fechas que no existen
    if (fechaISO(fecha) !== texto) return null;
    return fecha;
  }

  function sumarDias(textoISO, dias) {
    const fecha = leerFechaISO(textoISO);
    fecha.setDate(fecha.getDate() + dias);
    return fechaISO(fecha);
  }

  // Días de "desde" a "hasta" (negativo si "hasta" ya pasó)
  function diasEntre(desdeISO, hastaISO) {
    const desde = leerFechaISO(desdeISO);
    const hasta = leerFechaISO(hastaISO);
    return Math.round((hasta - desde) / 86400000);
  }

  const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];

  // "16 nov" (o "16 nov 2027" si no es de este año)
  function fechaCorta(textoISO, hoyISO) {
    const fecha = leerFechaISO(textoISO);
    if (!fecha) return '';
    let texto = fecha.getDate() + ' ' + MESES[fecha.getMonth()];
    if (hoyISO && textoISO.slice(0, 4) !== hoyISO.slice(0, 4)) texto += ' ' + fecha.getFullYear();
    return texto;
  }

  function plural(cantidad, singular, varios) {
    return cantidad + ' ' + (cantidad === 1 ? singular : varios || singular + 's');
  }

  // =====================================================================
  // 3. GEOMETRÍA ISOMÉTRICA
  // =====================================================================
  //
  // El piso es una cuadrícula. Una casilla (x, y) del piso se dibuja como un rombo:
  //   pantallaX = origenX + (x - y) * medioAncho
  //   pantallaY = origenY + (x + y) * medioAlto - altura * altoPiso
  // Moverse +1 en x baja a la derecha; +1 en y baja a la izquierda; la altura sube.
  // Ese es todo el "3D": geometría de secundaria, sin librerías.

  // Proporciones respecto a medioAncho: el rombo mide el doble de ancho que de alto
  const PROPORCION = { medioAlto: 0.5, altoPiso: 1.2 };
  const ALTO_PARED = 1.8;

  function proyectar(x, y, z, escala) {
    return {
      x: escala.origenX + (x - y) * escala.medioAncho,
      y: escala.origenY + (x + y) * escala.medioAlto - z * escala.altoPiso
    };
  }

  // Lo contrario de proyectar() con altura 0: ¿qué casilla del piso está en este punto?
  // Despejando las dos fórmulas: a = x - y, b = x + y  →  x = (a + b) / 2, y = (b - a) / 2
  function casillaEnPantalla(px, py, escala) {
    const a = (px - escala.origenX) / escala.medioAncho;
    const b = (py - escala.origenY) / escala.medioAlto;
    return { x: Math.floor((a + b) / 2), y: Math.floor((b - a) / 2) };
  }

  // Calcula el tamaño de las casillas para que la sala completa quepa en el lienzo.
  function escalaParaSala(anchoVista, fondoVista, anchoLienzo, altoLienzo) {
    // De izquierda a derecha la sala ocupa (ancho + fondo) "medios anchos"
    const unidades = anchoVista + fondoVista;
    const porAncho = (anchoLienzo * 0.92) / unidades;
    const porAlto = (altoLienzo * 0.86) / (unidades * PROPORCION.medioAlto + ALTO_PARED * PROPORCION.altoPiso);
    const medioAncho = Math.max(8, Math.min(porAncho, porAlto, 56));
    const escala = {
      medioAncho: medioAncho,
      medioAlto: medioAncho * PROPORCION.medioAlto,
      altoPiso: medioAncho * PROPORCION.altoPiso
    };
    const altoTotal = unidades * escala.medioAlto + ALTO_PARED * escala.altoPiso;
    // El rombo del piso está centrado si su punta izquierda y derecha quedan a la misma distancia
    escala.origenX = anchoLienzo / 2 - ((anchoVista - fondoVista) * medioAncho) / 2;
    escala.origenY = (altoLienzo - altoTotal) / 2 + ALTO_PARED * escala.altoPiso;
    return escala;
  }

  // ---------- Girar la vista ----------
  // Los muebles se guardan siempre en "coordenadas del mundo". Para ver la sala desde otro
  // lado no se cambia nada guardado: solo se giran los rectángulos antes de dibujarlos.
  // Un cuarto de vuelta convierte la sala de ancho × fondo en una de fondo × ancho.
  function girarUnCuarto(rect, anchoSala, fondoSala) {
    return {
      rect: { x: fondoSala - (rect.y + rect.fondo), y: rect.x, ancho: rect.fondo, fondo: rect.ancho },
      anchoSala: fondoSala,
      fondoSala: anchoSala
    };
  }

  function girar(rect, anchoSala, fondoSala, cuartos) {
    let actual = { rect: rect, anchoSala: anchoSala, fondoSala: fondoSala };
    const vueltas = ((cuartos % 4) + 4) % 4;
    for (let i = 0; i < vueltas; i++) {
      actual = girarUnCuarto(actual.rect, actual.anchoSala, actual.fondoSala);
    }
    return actual;
  }

  // Medidas de la sala tal como se ve (con un cuarto de vuelta, ancho y fondo se intercambian)
  function medidasVista(sala, rotacion) {
    return rotacion % 2 ? { ancho: sala.fondo, fondo: sala.ancho } : { ancho: sala.ancho, fondo: sala.fondo };
  }

  function aVista(rect, sala, rotacion) {
    return girar(rect, sala.ancho, sala.fondo, rotacion).rect;
  }

  function aMundo(rectVista, sala, rotacion) {
    const vista = medidasVista(sala, rotacion);
    return girar(rectVista, vista.ancho, vista.fondo, 4 - rotacion).rect;
  }

  // Rectángulo (en el mundo) que ocupa un mueble si su primera casilla queda donde tocaste.
  // Corrige un error del prototipo: allá se convertía solo la casilla y el mueble crecía
  // hacia el lado contrario cuando la vista estaba girada media vuelta o tres cuartos.
  function rectAlTocar(casillaVista, medidas, sala, rotacion) {
    const enVista = rotacion % 2
      ? { ancho: medidas.fondo, fondo: medidas.ancho }
      : { ancho: medidas.ancho, fondo: medidas.fondo };
    return aMundo(
      { x: casillaVista.x, y: casillaVista.y, ancho: enVista.ancho, fondo: enVista.fondo },
      sala,
      rotacion
    );
  }

  // ---------- Choques ----------
  function seEnciman(a, b) {
    return a.x < b.x + b.ancho && b.x < a.x + a.ancho && a.y < b.y + b.fondo && b.y < a.y + a.fondo;
  }

  // Un mueble está colocado si tiene casilla (x, y). Sin casilla está «sin colocar».
  function estaColocado(mueble) {
    return Number.isInteger(mueble.x) && Number.isInteger(mueble.y);
  }

  // ¿Cabe el rectángulo en la sala sin encimarse con otro mueble colocado? (ignorarId: el que se mueve)
  // obstaculos (opcional): huellas de objetos 3D del piso, que un mueble tampoco puede pisar
  function cabe(rect, sala, muebles, ignorarId, obstaculos) {
    if (rect.x < 0 || rect.y < 0) return false;
    if (rect.x + rect.ancho > sala.ancho || rect.y + rect.fondo > sala.fondo) return false;
    if (obstaculos && obstaculoEn(rect, obstaculos)) return false;
    return !muebles.some((otro) => otro.id !== ignorarId && estaColocado(otro) && seEnciman(rect, otro));
  }

  // ---------- Orden de dibujo ("algoritmo del pintor") ----------
  // Se dibuja primero lo de atrás y al final lo de adelante, que lo tapa.
  // ¿El rectángulo a queda completamente detrás de b? (más arriba en la pantalla)
  function estaDetras(a, b) {
    return a.x + a.ancho <= b.x || a.y + a.fondo <= b.y;
  }

  // lista: objetos con la propiedad "vista" (su rectángulo ya girado).
  // Primero se anota, para cada par, quién debe dibujarse antes; luego se van tomando los que
  // ya no esperan a nadie. Cuesta n × n comparaciones (antes eran n × n × n: lento con 200 muebles).
  function ordenarDeAtrasHaciaAdelante(lista) {
    const total = lista.length;
    const esperaA = new Array(total).fill(0);      // cuántos muebles deben dibujarse antes que este
    const vanDespues = lista.map(() => []);        // a quiénes libera este mueble al dibujarse
    for (let i = 0; i < total; i++) {
      for (let j = i + 1; j < total; j++) {
        const iDetras = estaDetras(lista[i].vista, lista[j].vista);
        const jDetras = estaDetras(lista[j].vista, lista[i].vista);
        if (iDetras && !jDetras) {
          vanDespues[i].push(j);
          esperaA[j]++;
        } else if (jDetras && !iDetras) {
          vanDespues[j].push(i);
          esperaA[i]++;
        }
      }
    }
    const usado = new Array(total).fill(false);
    const ordenados = [];
    for (let paso = 0; paso < total; paso++) {
      let elegido = -1;
      for (let i = 0; i < total; i++) {
        if (usado[i]) continue;
        if (esperaA[i] === 0) {
          elegido = i;
          break;
        }
        if (elegido === -1) elegido = i; // si hubiera un ciclo, se toma el primero que quede
      }
      if (esperaA[elegido] !== 0) elegido = usado.indexOf(false);
      usado[elegido] = true;
      ordenados.push(lista[elegido]);
      vanDespues[elegido].forEach((j) => {
        esperaA[j]--;
      });
    }
    return ordenados;
  }

  // Rectángulo que ocupa un mueble en la pantalla, en unidades de medioAncho (horizontal)
  // y medioAlto (vertical). Sirve para saber si uno tapa a otro sin dibujar nada.
  function siluetaEnPantalla(vista, alto) {
    const subePorPiso = PROPORCION.altoPiso / PROPORCION.medioAlto;
    return {
      izquierda: vista.x - (vista.y + vista.fondo),
      derecha: vista.x + vista.ancho - vista.y,
      arriba: vista.x + vista.y - alto * subePorPiso,
      abajo: vista.x + vista.ancho + vista.y + vista.fondo
    };
  }

  function siluetasSeEnciman(a, b) {
    const margen = 0.05;
    return a.izquierda + margen < b.derecha && b.izquierda + margen < a.derecha &&
      a.arriba + margen < b.abajo && b.arriba + margen < a.abajo;
  }

  // ordenados: lista ya en orden de dibujo, cada uno { mueble, vista }.
  // Devuelve los id de los muebles que están ADELANTE de algún objetivo y lo tapan:
  // esos se dibujan semitransparentes para que el objetivo se vea.
  function mueblesQueTapan(ordenados, idsObjetivo) {
    const objetivos = new Set(idsObjetivo);
    const tapan = new Set();
    ordenados.forEach((objetivo, posicion) => {
      if (!objetivos.has(objetivo.mueble.id)) return;
      const siluetaObjetivo = siluetaEnPantalla(objetivo.vista, altoDe(objetivo.mueble));
      for (let i = posicion + 1; i < ordenados.length; i++) {
        const delante = ordenados[i];
        if (objetivos.has(delante.mueble.id)) continue;
        const silueta = siluetaEnPantalla(delante.vista, altoDe(delante.mueble));
        if (siluetasSeEnciman(silueta, siluetaObjetivo)) tapan.add(delante.mueble.id);
      }
    });
    return tapan;
  }

  function altoDe(mueble) {
    const tipo = TIPOS_MUEBLE[mueble.tipo];
    return tipo ? tipo.alto : 1;
  }

  // =====================================================================
  // 4. CÁMARA Y GESTOS
  // =====================================================================
  //
  // La cámara dice cómo se ve el dibujo ya acomodado: punto en pantalla =
  //   desplazamiento + zoom × punto del dibujo.
  // zoom 1 = la sala completa cabe en el lienzo.

  const ZOOM_MINIMO = 0.6;
  const ZOOM_MAXIMO = 4;

  function camaraInicial() {
    return { zoom: 1, x: 0, y: 0 };
  }

  function limitarCamara(camara, anchoLienzo, altoLienzo) {
    const zoom = Math.min(ZOOM_MAXIMO, Math.max(ZOOM_MINIMO, camara.zoom));
    // El centro del dibujo nunca sale del lienzo: así no se "pierde" la sala
    const limitar = (valor, minimo, maximo) => Math.min(maximo, Math.max(minimo, valor));
    return {
      zoom: zoom,
      x: limitar(camara.x, -zoom * anchoLienzo / 2, anchoLienzo - zoom * anchoLienzo / 2),
      y: limitar(camara.y, -zoom * altoLienzo / 2, altoLienzo - zoom * altoLienzo / 2)
    };
  }

  // Acerca o aleja manteniendo fijo el punto (fx, fy) de la pantalla, por ejemplo
  // el punto medio entre los dos dedos: lo que está bajo tus dedos se queda bajo tus dedos.
  function zoomEn(camara, factor, fx, fy) {
    const zoom = Math.min(ZOOM_MAXIMO, Math.max(ZOOM_MINIMO, camara.zoom * factor));
    const dibujoX = (fx - camara.x) / camara.zoom;
    const dibujoY = (fy - camara.y) / camara.zoom;
    return { zoom: zoom, x: fx - dibujoX * zoom, y: fy - dibujoY * zoom };
  }

  // Convierte un punto de la pantalla al dibujo (lo contrario de la cámara)
  function pantallaADibujo(camara, px, py) {
    return { x: (px - camara.x) / camara.zoom, y: (py - camara.y) / camara.zoom };
  }

  // ---------- Gestos táctiles ----------
  // Recibe los eventos de cada dedo (pointerdown, pointermove, pointerup) y decide qué
  // significan. Devuelve una lista de acciones:
  //   { tipo: 'toque', x, y }          un dedo, sin moverse: colocar o abrir
  //   { tipo: 'desplazar', dx, dy }    mover la vista (1 dedo arrastrando o 2 dedos)
  //   { tipo: 'zoom', factor, x, y }   pellizco con 2 dedos
  // Regla clave: si el dedo se movió más de UMBRAL px, o si en algún momento hubo dos
  // dedos, ya NO es un toque. Así un pellizco nunca coloca un mueble por accidente.
  const UMBRAL_TOQUE = 10;

  function crearGestos() {
    const dedos = new Map(); // id del dedo → { x, y } última posición
    let inicio = null;       // dónde bajó el primer dedo
    let arrastrando = false;
    let huboVariosDedos = false;

    function centroYDistancia() {
      const [a, b] = Array.from(dedos.values());
      return {
        x: (a.x + b.x) / 2,
        y: (a.y + b.y) / 2,
        distancia: Math.hypot(a.x - b.x, a.y - b.y)
      };
    }

    function reiniciarSiNoHayDedos() {
      if (dedos.size) return;
      inicio = null;
      arrastrando = false;
      huboVariosDedos = false;
    }

    return {
      bajar(id, x, y) {
        if (dedos.size === 0) inicio = { x: x, y: y };
        dedos.set(id, { x: x, y: y });
        if (dedos.size > 1) huboVariosDedos = true;
        return [];
      },

      mover(id, x, y) {
        const anterior = dedos.get(id);
        if (!anterior) return [];
        const acciones = [];
        if (dedos.size === 1) {
          if (!arrastrando && Math.hypot(x - inicio.x, y - inicio.y) > UMBRAL_TOQUE) arrastrando = true;
          if (arrastrando && !huboVariosDedos) {
            acciones.push({ tipo: 'desplazar', dx: x - anterior.x, dy: y - anterior.y });
          }
          dedos.set(id, { x: x, y: y });
        } else if (dedos.size === 2) {
          const antes = centroYDistancia();
          dedos.set(id, { x: x, y: y });
          const despues = centroYDistancia();
          if (antes.distancia > 0 && despues.distancia > 0) {
            acciones.push({
              tipo: 'zoom', factor: despues.distancia / antes.distancia, x: despues.x, y: despues.y
            });
          }
          acciones.push({ tipo: 'desplazar', dx: despues.x - antes.x, dy: despues.y - antes.y });
        } else {
          dedos.set(id, { x: x, y: y });
        }
        return acciones;
      },

      subir(id, x, y) {
        if (!dedos.has(id)) return [];
        dedos.delete(id);
        const acciones = [];
        if (dedos.size === 0 && !arrastrando && !huboVariosDedos) {
          acciones.push({ tipo: 'toque', x: x, y: y });
        }
        reiniciarSiNoHayDedos();
        return acciones;
      },

      // El sistema canceló el gesto (por ejemplo, llegó una llamada): nunca cuenta como toque
      cancelar(id) {
        dedos.delete(id);
        huboVariosDedos = huboVariosDedos || dedos.size > 0;
        reiniciarSiNoHayDedos();
        return [];
      },

      dedosEnPantalla() {
        return dedos.size;
      }
    };
  }

  // =====================================================================
  // 5. CONSULTAS
  // =====================================================================
  // "datos" tiene la misma forma que la base de datos: una lista por tabla.
  //   { lugares: [], muebles: [], articulos: [], prestamos: [], categorias: [], movimientos: [] }

  function datosVacios() {
    const datos = {};
    TABLAS.forEach((tabla) => {
      datos[tabla] = [];
    });
    return datos;
  }

  function buscarPorId(lista, id) {
    return lista.find((registro) => registro.id === id) || null;
  }

  // Copia profunda de un registro (los estados son un objeto dentro del artículo)
  function clonar(valor) {
    return valor == null ? valor : JSON.parse(JSON.stringify(valor));
  }

  // ---------- Índices en memoria ----------
  // Preguntar "¿qué hay en este mueble?" recorriendo TODOS los artículos es lento cuando hay
  // miles (y el plano lo pregunta por cada mueble en cada dibujo). Un índice es como el índice
  // de un libro: se arma una vez y luego se consulta al instante. Se guarda aparte (WeakMap)
  // para no ensuciar los datos, y se vuelve a armar cuando los datos cambian.
  const indices = new WeakMap();
  const textos = new WeakMap(); // registro → su nombre y código ya sin acentos (para buscar)

  function textoDe(registro) {
    let texto = textos.get(registro);
    if (!texto) {
      texto = { nombre: normalizar(registro.nombre), codigo: normalizar(registro.codigo),
        series: normalizar((registro.series || []).join(' ')) };
      textos.set(registro, texto);
    }
    return texto;
  }

  function firmaDe(datos) {
    return TABLAS.map((tabla) => (datos[tabla] || []).length).join('/');
  }

  function agrupar(lista, campo) {
    const grupos = new Map();
    lista.forEach((registro) => {
      const clave = registro[campo];
      if (clave == null) return;
      if (!grupos.has(clave)) grupos.set(clave, []);
      grupos.get(clave).push(registro);
    });
    return grupos;
  }

  const porNombre = (a, b) => textoDe(a).nombre.localeCompare(textoDe(b).nombre, 'es', { numeric: true });

  function indiceDe(datos) {
    const firma = firmaDe(datos);
    let indice = indices.get(datos);
    if (indice && indice.firma === firma) return indice;
    indice = {
      firma: firma,
      muebles: agrupar(datos.muebles, 'lugarId'),
      enMueble: agrupar(datos.articulos, 'muebleId'),
      enLugar: agrupar(datos.articulos.filter((a) => !a.muebleId), 'lugarId'),
      sinUbicacion: datos.articulos.filter((a) => !a.muebleId && !a.lugarId).sort(porNombre),
      activos: agrupar(datos.prestamos.filter((prestamo) => !prestamo.devuelto), 'articuloId'),
      piezas: new Map(),
      movimientos: null // se arma solo si alguien lo pide (el historial puede ser grande)
    };
    indice.enMueble.forEach((lista, muebleId) => {
      lista.sort(porNombre);
      indice.piezas.set(muebleId, lista.reduce((suma, articulo) => suma + totalDe(articulo), 0));
    });
    indice.enLugar.forEach((lista) => lista.sort(porNombre));
    indices.set(datos, indice);
    return indice;
  }

  const VACIA = Object.freeze([]);

  // Las listas que devuelven estas funciones son del índice: se leen, no se modifican.
  function mueblesDe(datos, lugarId) {
    return indiceDe(datos).muebles.get(lugarId) || VACIA;
  }

  function mueblesColocados(datos, lugarId) {
    const lugar = buscarPorId(datos.lugares, lugarId);
    if (!lugar || !lugar.plano) return VACIA;
    return mueblesDe(datos, lugarId).filter(estaColocado);
  }

  function articulosDe(datos, muebleId) {
    return indiceDe(datos).enMueble.get(muebleId) || VACIA;
  }

  // Artículos que están directo en el lugar (sin mueble)
  function articulosEnLugar(datos, lugarId) {
    return indiceDe(datos).enLugar.get(lugarId) || VACIA;
  }

  function articulosSinUbicacion(datos) {
    return indiceDe(datos).sinUbicacion;
  }

  // Existencias: total = buen estado + en reparación + dañado (se calcula, nunca se guarda)
  function totalDe(articulo) {
    const estados = articulo.estados || {};
    return (estados.bueno || 0) + (estados.reparacion || 0) + (estados.danado || 0);
  }

  function piezasEnMueble(datos, muebleId) {
    return indiceDe(datos).piezas.get(muebleId) || 0;
  }

  function piezasEnLugar(datos, lugarId) {
    return mueblesDe(datos, lugarId).reduce((suma, mueble) => suma + piezasEnMueble(datos, mueble.id), 0) +
      articulosEnLugar(datos, lugarId).reduce((suma, articulo) => suma + totalDe(articulo), 0);
  }

  function prestamosActivosDe(datos, articuloId) {
    return indiceDe(datos).activos.get(articuloId) || VACIA;
  }

  function prestadas(datos, articuloId) {
    return prestamosActivosDe(datos, articuloId).reduce((suma, prestamo) => suma + prestamo.cantidad, 0);
  }

  // Disponibles para prestar = en buen estado − prestadas (las prestadas salen de las de buen estado)
  function disponibles(datos, articulo) {
    return articulo.estados.bueno - prestadas(datos, articulo.id);
  }

  // Dónde está un artículo: { articulo, mueble, lugar } (mueble y lugar pueden ser null)
  function ubicacion(datos, articuloId) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    const mueble = articulo && articulo.muebleId ? buscarPorId(datos.muebles, articulo.muebleId) : null;
    const lugarId = mueble ? mueble.lugarId : articulo ? articulo.lugarId : null;
    const lugar = lugarId ? buscarPorId(datos.lugares, lugarId) : null;
    return { articulo: articulo, mueble: mueble, lugar: lugar };
  }

  // "Laboratorio › Estante A", "Bodega" o "Sin ubicación"
  function textoUbicacion(lugar, mueble) {
    if (lugar && mueble) return lugar.nombre + ' › ' + mueble.nombre;
    if (lugar) return lugar.nombre;
    return 'Sin ubicación';
  }

  function categoriaDe(datos, articulo) {
    return buscarPorId(datos.categorias, articulo.categoriaId) || buscarPorId(datos.categorias, ID_OTROS);
  }

  function categoriasOrdenadas(datos) {
    return datos.categorias.slice().sort((a, b) => (a.orden - b.orden) || a.nombre.localeCompare(b.nombre, 'es'));
  }

  function articulosDeCategoria(datos, categoriaId) {
    return datos.articulos.filter((articulo) => articulo.categoriaId === categoriaId);
  }

  // Historial de un registro, el más reciente primero. Para un artículo incluye también los
  // movimientos de sus préstamos (préstamo y devolución), que se guardan a nombre del préstamo.
  function movimientosDe(datos, entidadId) {
    const indice = indiceDe(datos);
    if (!indice.movimientos) {
      const grupos = new Map();
      const sumar = (clave, movimiento) => {
        if (!clave) return;
        if (!grupos.has(clave)) grupos.set(clave, []);
        grupos.get(clave).push(movimiento);
      };
      datos.movimientos.forEach((movimiento) => {
        sumar(movimiento.entidadId, movimiento);
        if (movimiento.entidad === 'prestamo') {
          const prestamo = movimiento.despues || movimiento.antes || {};
          if (prestamo.articuloId !== movimiento.entidadId) sumar(prestamo.articuloId, movimiento);
        }
      });
      // Una sola línea por operación (una devolución con dañadas cambia el préstamo Y el artículo)
      grupos.forEach((lista, clave) => {
        const vistas = new Set();
        const unica = lista.filter((movimiento) => {
          if (vistas.has(movimiento.operacionId)) return false;
          vistas.add(movimiento.operacionId);
          return true;
        });
        unica.sort((a, b) => (a.momento < b.momento ? 1 : a.momento > b.momento ? -1 : 0));
        grupos.set(clave, unica);
      });
      indice.movimientos = grupos;
    }
    return indice.movimientos.get(entidadId) || VACIA;
  }

  // 'devuelto', 'vencido' (ya pasó la fecha límite) o 'activo'
  function estadoPrestamo(prestamo, hoyISO) {
    if (prestamo.devuelto) return 'devuelto';
    return diasEntre(hoyISO, prestamo.fechaLimite) < 0 ? 'vencido' : 'activo';
  }

  // Activos con los vencidos primero; dentro de cada grupo, el que vence antes va primero
  function prestamosActivos(datos, hoyISO) {
    return datos.prestamos
      .filter((prestamo) => !prestamo.devuelto)
      .sort((a, b) => {
        const vencidoA = estadoPrestamo(a, hoyISO) === 'vencido' ? 0 : 1;
        const vencidoB = estadoPrestamo(b, hoyISO) === 'vencido' ? 0 : 1;
        if (vencidoA !== vencidoB) return vencidoA - vencidoB;
        return a.fechaLimite < b.fechaLimite ? -1 : a.fechaLimite > b.fechaLimite ? 1 : 0;
      });
  }

  // Devueltos, el más reciente primero
  function historialPrestamos(datos) {
    return datos.prestamos
      .filter((prestamo) => prestamo.devuelto)
      .sort((a, b) => (a.devuelto < b.devuelto ? 1 : a.devuelto > b.devuelto ? -1 : 0));
  }

  // "Vence hoy", "Regresa el 16 nov", "Vencido hace 2 días"
  function textoVencimiento(prestamo, hoyISO) {
    const dias = diasEntre(hoyISO, prestamo.fechaLimite);
    if (dias < 0) return 'Vencido hace ' + plural(-dias, 'día');
    if (dias === 0) return 'Vence hoy';
    if (dias === 1) return 'Vence mañana';
    return 'Regresa el ' + fechaCorta(prestamo.fechaLimite, hoyISO);
  }

  // Búsqueda en todo el inventario, sin importar acentos ni mayúsculas.
  // Encuentra artículos por nombre o número de inventario (estén donde estén, también sin
  // ubicación) y muebles por su nombre. Cada resultado: { lugar, mueble, articulo } (pueden ser null).
  function buscar(datos, consulta) {
    const texto = normalizar(consulta);
    if (!texto) return [];
    const coincide = (articulo) => {
      const t = textoDe(articulo);
      return t.nombre.includes(texto) || t.codigo.includes(texto) || t.series.includes(texto);
    };
    const resultados = [];
    datos.lugares.forEach((lugar) => {
      mueblesDe(datos, lugar.id).forEach((mueble) => {
        const encontrados = articulosDe(datos, mueble.id).filter(coincide);
        encontrados.forEach((articulo) => resultados.push({ lugar: lugar, mueble: mueble, articulo: articulo }));
        if (!encontrados.length && textoDe(mueble).nombre.includes(texto)) {
          resultados.push({ lugar: lugar, mueble: mueble, articulo: null });
        }
      });
      articulosEnLugar(datos, lugar.id).filter(coincide)
        .forEach((articulo) => resultados.push({ lugar: lugar, mueble: null, articulo: articulo }));
    });
    articulosSinUbicacion(datos).filter(coincide)
      .forEach((articulo) => resultados.push({ lugar: null, mueble: null, articulo: articulo }));
    return resultados;
  }

  // Ids de los muebles de un lugar que coinciden con la búsqueda (para resaltarlos en el plano)
  function mueblesQueCoinciden(datos, consulta, lugarId) {
    return new Set(
      buscar(datos, consulta)
        .filter((resultado) => resultado.lugar && resultado.lugar.id === lugarId && resultado.mueble)
        .map((resultado) => resultado.mueble.id)
    );
  }

  function resumen(datos, hoyISO) {
    const activos = prestamosActivos(datos, hoyISO);
    const suma = (clave) => datos.articulos.reduce((total, articulo) => total + (articulo.estados[clave] || 0), 0);
    return {
      lugares: datos.lugares.length,
      muebles: datos.muebles.length,
      articulos: datos.articulos.length,
      piezas: datos.articulos.reduce((total, articulo) => total + totalDe(articulo), 0),
      enReparacion: suma('reparacion'),
      danadas: suma('danado'),
      sinUbicacion: articulosSinUbicacion(datos).length,
      piezasPrestadas: activos.reduce((total, prestamo) => total + prestamo.cantidad, 0),
      prestamosActivos: activos.length,
      vencidos: activos.filter((prestamo) => estadoPrestamo(prestamo, hoyISO) === 'vencido').length
    };
  }

  // Inventario completo como filas listas para una tabla, con filtros combinables y orden.
  // filtros: { texto, categoriaId, estado, lugar }   (todos opcionales)
  //   estado: 'disponible' | 'prestado' | 'reparacion' | 'danado' | 'agotado'
  //   lugar: id de un lugar | 'sin' (sin ubicación)
  // orden: 'nombre' | 'total' | 'disponibles' | 'categoria' | 'ubicacion'; descendente: true/false
  function consultarArticulos(datos, filtros, orden, descendente) {
    const f = filtros || {};
    const texto = normalizar(f.texto);
    const filas = [];
    datos.articulos.forEach((articulo) => {
      const t = textoDe(articulo);
      if (texto && !(t.nombre.includes(texto) || t.codigo.includes(texto) || t.series.includes(texto))) return;
      if (f.categoriaId && (categoriaDe(datos, articulo).id !== f.categoriaId)) return;
      const mueble = articulo.muebleId ? buscarPorId(datos.muebles, articulo.muebleId) : null;
      const lugarId = mueble ? mueble.lugarId : articulo.lugarId;
      if (f.lugar === 'sin' ? Boolean(lugarId) : f.lugar && lugarId !== f.lugar) return;
      const fila = {
        articulo: articulo, mueble: mueble, lugar: lugarId ? buscarPorId(datos.lugares, lugarId) : null,
        categoria: categoriaDe(datos, articulo), total: totalDe(articulo), prestadas: prestadas(datos, articulo.id)
      };
      fila.disponibles = articulo.estados.bueno - fila.prestadas;
      if (f.estado === 'disponible' && fila.disponibles < 1) return;
      if (f.estado === 'prestado' && fila.prestadas < 1) return;
      if (f.estado === 'reparacion' && articulo.estados.reparacion < 1) return;
      if (f.estado === 'danado' && articulo.estados.danado < 1) return;
      if (f.estado === 'agotado' && fila.total > 0) return;
      fila.ubicacion = textoUbicacion(fila.lugar, mueble);
      filas.push(fila);
    });
    const comparar = {
      nombre: (a, b) => porNombre(a.articulo, b.articulo),
      total: (a, b) => a.total - b.total,
      disponibles: (a, b) => a.disponibles - b.disponibles,
      categoria: (a, b) => a.categoria.nombre.localeCompare(b.categoria.nombre, 'es'),
      ubicacion: (a, b) => a.ubicacion.localeCompare(b.ubicacion, 'es', { numeric: true })
    }[orden] || ((a, b) => porNombre(a.articulo, b.articulo));
    filas.sort((a, b) => (comparar(a, b) || porNombre(a.articulo, b.articulo)) * (descendente ? -1 : 1));
    return filas;
  }

  // Los movimientos más recientes de todo el inventario (una línea por operación)
  function movimientosRecientes(datos, limite) {
    const vistas = new Set();
    return datos.movimientos.slice()
      .sort((a, b) => (a.momento < b.momento ? 1 : a.momento > b.momento ? -1 : 0))
      .filter((movimiento) => {
        if (vistas.has(movimiento.operacionId)) return false;
        vistas.add(movimiento.operacionId);
        return true;
      })
      .slice(0, limite || 50);
  }

  // =====================================================================
  // 5b. CATÁLOGO DE PIEZAS (para el 3D)
  // =====================================================================
  // Cada tipo de mueble se arma con cajas: tablero, patas, repisas, puertas… Es solo geometría
  // (sin dibujo), así sirve a cualquier vista. Medidas en casillas; la altura (z) en "pisos".
  //   ancho, fondo: medidas del mueble SIN girar (su frente mira hacia +y).
  //   Devuelve cajas { x, y, z, w, d, h, mat } con origen en una esquina del mueble.
  //   mat: 'cuerpo' | 'oscuro' | 'claro' | 'madera' | 'metal' | 'vidrio'
  function piezasMueble(tipoClave, ancho, fondo) {
    const tipo = TIPOS_MUEBLE[tipoClave] || TIPOS_MUEBLE.caja;
    const alto = tipo.alto;
    const m = 0.06; // margen para que dos muebles juntos no se vean pegados
    const w = ancho - 2 * m;
    const d = fondo - 2 * m;
    const cajas = [];
    const caja = (x, y, z, cw, cd, ch, mat) => cajas.push({ x: m + x, y: m + y, z: z, w: cw, d: cd, h: ch, mat: mat });
    const patas = (grosor, altura, mat) => {
      [[0, 0], [w - grosor, 0], [0, d - grosor], [w - grosor, d - grosor]].forEach(([x, y]) => caja(x, y, 0, grosor, grosor, altura, mat));
    };
    if (tipoClave === 'mesa') {
      patas(0.08, alto - 0.06, 'metal');
      caja(0, 0, alto - 0.06, w, d, 0.06, 'madera');
    } else if (tipoClave === 'banco') {
      patas(0.07, alto - 0.05, 'metal');
      caja(0.04, 0.04, alto - 0.05, w - 0.08, d - 0.08, 0.05, 'cuerpo');
    } else if (tipoClave === 'escritorio') {
      caja(0, 0, alto - 0.05, w, d, 0.05, 'madera');
      caja(0, 0.05, 0, Math.min(0.55, w * 0.35), d - 0.05, alto - 0.05, 'cuerpo'); // cajonera
      const cw = Math.min(0.55, w * 0.35);
      [0.25, 0.55, 0.85].forEach((f) => caja(0.06, d - 0.01, (alto - 0.05) * f - 0.02, cw - 0.12, 0.02, 0.03, 'metal')); // jaladeras
      caja(w - 0.05, 0.05, 0, 0.05, d - 0.05, alto - 0.05, 'oscuro'); // costado
      caja(cw, 0.02, alto * 0.35, w - cw - 0.05, 0.03, alto * 0.55, 'oscuro'); // faldón trasero
    } else if (tipoClave === 'estante') {
      caja(0, 0, 0, 0.05, d, alto, 'cuerpo');
      caja(w - 0.05, 0, 0, 0.05, d, alto, 'cuerpo');
      caja(0.05, 0, 0, w - 0.1, 0.03, alto, 'oscuro');
      const niveles = 5;
      for (let n = 0; n < niveles; n++) caja(0.05, 0.03, 0.08 + n * ((alto - 0.12) / (niveles - 1)), w - 0.1, d - 0.03, 0.04, 'claro');
    } else if (tipoClave === 'gabinete' || tipoClave === 'casillero') {
      // Cuerpo hueco (para que adentro quepan y se vean los objetos al abrir las puertas)
      const fondoCuerpo = d - 0.03;
      caja(0, 0, 0, 0.04, fondoCuerpo, alto, 'cuerpo'); // costado izquierdo
      caja(w - 0.04, 0, 0, 0.04, fondoCuerpo, alto, 'cuerpo'); // costado derecho
      caja(0.04, 0, 0, w - 0.08, 0.03, alto, 'oscuro'); // espalda
      caja(0.04, 0.03, 0, w - 0.08, fondoCuerpo - 0.03, 0.04, 'cuerpo'); // piso
      caja(0.04, 0.03, alto - 0.04, w - 0.08, fondoCuerpo - 0.03, 0.04, 'cuerpo'); // techo
      caja(0.04, 0.03, alto * 0.5 - 0.02, w - 0.08, fondoCuerpo - 0.06, 0.03, 'claro'); // repisa
      const columnas = Math.max(1, Math.round(w / 0.5));
      const filas = tipoClave === 'casillero' ? 2 : 1;
      const pw = (w - 0.04) / columnas;
      const ph = (alto - 0.06) / filas;
      // Las puertas llevan una marca: el 3D las abre cuando el mueble está seleccionado
      const dePuerta = (marca) => { cajas[cajas.length - 1].puerta = marca; };
      for (let c = 0; c < columnas; c++) {
        for (let f = 0; f < filas; f++) {
          caja(0.02 + c * pw + 0.015, d - 0.03, 0.03 + f * ph + 0.015, pw - 0.03, 0.03, ph - 0.03, 'claro'); // puerta
          dePuerta('hoja');
          caja(0.02 + c * pw + pw - 0.09, d, 0.03 + f * ph + ph * 0.5, 0.03, 0.02, 0.1, 'metal'); // jaladera
          dePuerta('detalle');
          if (tipoClave === 'casillero') {
            caja(0.02 + c * pw + pw * 0.3, d, 0.03 + f * ph + ph * 0.8, pw * 0.4, 0.005, 0.03, 'oscuro'); // rejilla
            dePuerta('detalle');
          }
        }
      }
    } else if (tipoClave === 'vitrina') {
      caja(0, 0, 0, w, d, alto * 0.3, 'cuerpo');
      caja(0, 0, alto - 0.05, w, d, 0.05, 'cuerpo');
      [[0, 0], [w - 0.04, 0], [0, d - 0.04], [w - 0.04, d - 0.04]].forEach(([x, y]) => caja(x, y, alto * 0.3, 0.04, 0.04, alto * 0.7 - 0.05, 'oscuro'));
      caja(0.04, 0.04, alto * 0.62, w - 0.08, d - 0.08, 0.02, 'claro'); // repisa interior
      caja(0.02, 0.02, alto * 0.3, w - 0.04, d - 0.04, alto * 0.7 - 0.05, 'vidrio');
    } else { // caja
      // Caja abierta por arriba: fondo, cuatro paredes y dos solapas (así se ve lo que guarda)
      const x0 = 0.12, y0 = 0.12, cw = w - 0.24, cd = d - 0.24, g = 0.025;
      caja(x0, y0, 0, cw, cd, 0.025, 'cuerpo');
      caja(x0, y0, 0, g, cd, alto, 'cuerpo');
      caja(x0 + cw - g, y0, 0, g, cd, alto, 'cuerpo');
      caja(x0 + g, y0, 0, cw - 2 * g, g, alto, 'cuerpo');
      caja(x0 + g, y0 + cd - g, 0, cw - 2 * g, g, alto, 'cuerpo');
      caja(x0 - 0.1, y0, alto - 0.012, 0.1, cd, 0.012, 'claro'); // solapa abierta
      caja(x0 + cw, y0, alto - 0.012, 0.1, cd, 0.012, 'claro'); // solapa abierta
    }
    return cajas;
  }

  // Medidas del mueble sin girar: lo que mide "de fábrica" su frente y su fondo
  function medidasSinGiro(mueble) {
    return (mueble.giro || 0) % 2 ? { ancho: mueble.fondo, fondo: mueble.ancho } : { ancho: mueble.ancho, fondo: mueble.fondo };
  }

  // =====================================================================
  // 6. VALIDACIÓN
  // =====================================================================
  // Cada función devuelve { ok: true, valor } o { ok: false, error: 'mensaje para el usuario' }.

  // Junta espacios repetidos y quita caracteres de control (invisibles)
  function limpiarTexto(valor) {
    return String(valor == null ? '' : valor)
      .replace(/[\u0000-\u001f\u007f]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function validarTexto(valor, opciones) {
    const texto = limpiarTexto(valor);
    const campo = opciones.campo;
    const minimo = opciones.minimo == null ? 1 : opciones.minimo;
    if (!texto && minimo > 0) return { ok: false, error: 'Escribe ' + campo + '.' };
    if (texto.length < minimo) return { ok: false, error: campo + ': al menos ' + minimo + ' letras.' };
    if (texto.length > opciones.maximo) {
      return { ok: false, error: campo + ': máximo ' + opciones.maximo + ' caracteres.' };
    }
    return { ok: true, valor: texto };
  }

  function validarEntero(valor, opciones) {
    const texto = String(valor == null ? '' : valor).trim();
    const numero = Number(texto);
    if (texto === '' || !Number.isInteger(numero)) {
      return { ok: false, error: opciones.campo + ': escribe un número entero.' };
    }
    if (numero < opciones.minimo || numero > opciones.maximo) {
      return { ok: false, error: opciones.campo + ': de ' + opciones.minimo + ' a ' + opciones.maximo + '.' };
    }
    return { ok: true, valor: numero };
  }

  // Un plano válido: { ancho, fondo } con enteros de 3 a 20
  function planoValido(plano) {
    return Boolean(plano) && [plano.ancho, plano.fondo].every((lado) =>
      Number.isInteger(lado) && lado >= LIMITES.ladoMinimo && lado <= LIMITES.ladoMaximo);
  }

  // entrada: { nombre, tipo, conPlano, ancho, fondo }. conPlano puede venir como 'si'/'on'/true.
  function validarLugar(entrada) {
    const nombre = validarTexto(entrada.nombre, { campo: 'el nombre', maximo: LIMITES.nombre });
    if (!nombre.ok) return nombre;
    if (!TIPOS_LUGAR[entrada.tipo]) return { ok: false, error: 'Elige el tipo de lugar.' };
    const conPlano = entrada.conPlano === true || entrada.conPlano === 'si' || entrada.conPlano === 'on';
    let plano = null;
    if (conPlano) {
      const lado = { minimo: LIMITES.ladoMinimo, maximo: LIMITES.ladoMaximo };
      const ancho = validarEntero(entrada.ancho, Object.assign({ campo: 'Ancho' }, lado));
      if (!ancho.ok) return ancho;
      const fondo = validarEntero(entrada.fondo, Object.assign({ campo: 'Fondo' }, lado));
      if (!fondo.ok) return fondo;
      plano = { ancho: ancho.valor, fondo: fondo.valor };
    }
    return { ok: true, valor: { nombre: nombre.valor, tipo: entrada.tipo, plano: plano } };
  }

  // Datos descriptivos de un artículo (las existencias se cambian con sus propias operaciones)
  function validarDatosArticulo(datos, entrada) {
    const nombre = validarTexto(entrada.nombre, { campo: 'el nombre del artículo', maximo: LIMITES.nombre });
    if (!nombre.ok) return nombre;
    const categoriaId = entrada.categoriaId || ID_OTROS;
    if (!buscarPorId(datos.categorias, categoriaId)) return { ok: false, error: 'Elige una categoría.' };
    const codigo = validarTexto(entrada.codigo, { campo: 'N.º de inventario', minimo: 0, maximo: LIMITES.codigo });
    if (!codigo.ok) return codigo;
    const notas = validarTexto(entrada.notas, { campo: 'Notas', minimo: 0, maximo: LIMITES.notas });
    if (!notas.ok) return notas;
    return { ok: true, valor: { nombre: nombre.valor, categoriaId: categoriaId, codigo: codigo.valor, notas: notas.valor } };
  }

  function validarPrestamo(entrada, maximoCantidad, hoyISO) {
    const persona = validarTexto(entrada.persona, { campo: 'quién se lo lleva', minimo: 2, maximo: LIMITES.persona });
    if (!persona.ok) return persona;
    const grupo = validarTexto(entrada.grupo, { campo: 'Grupo o área', minimo: 0, maximo: LIMITES.grupo });
    if (!grupo.ok) return grupo;
    if (maximoCantidad < 1) return { ok: false, error: 'No hay piezas disponibles para prestar.' };
    const cantidad = validarEntero(entrada.cantidad, { campo: 'Cantidad', minimo: 1, maximo: maximoCantidad });
    if (!cantidad.ok) return cantidad;
    if (!leerFechaISO(entrada.fechaLimite)) return { ok: false, error: 'Elige la fecha en que regresa.' };
    const dias = diasEntre(hoyISO, entrada.fechaLimite);
    if (dias < 0) return { ok: false, error: 'La fecha de regreso no puede ser antes de hoy.' };
    if (dias > LIMITES.diasPrestamo) return { ok: false, error: 'El préstamo puede durar máximo un año.' };
    const nota = validarTexto(entrada.nota, { campo: 'Nota', minimo: 0, maximo: LIMITES.notas });
    if (!nota.ok) return nota;
    return {
      ok: true,
      valor: { persona: persona.valor, grupo: grupo.valor, cantidad: cantidad.valor, fechaLimite: entrada.fechaLimite, nota: nota.valor }
    };
  }

  function colorValido(color) {
    return typeof color === 'string' && /^#[0-9a-f]{6}$/i.test(color);
  }

  // =====================================================================
  // 7. OPERACIONES
  // =====================================================================
  // Ninguna operación cambia "datos" directamente. Devuelven:
  //   { ok: true, tipo, cambios: [...], ... }  o  { ok: false, error }
  // donde cada cambio es { tabla, poner: registro } o { tabla, borrar: id }, y "tipo" es el tipo de
  // movimiento para el historial. La app guarda los cambios (y su historial) en UNA transacción,
  // los aplica en memoria (aplicarCambios) y con invertirCambios() obtiene el «Deshacer».

  function fallo(error) {
    return { ok: false, error: error };
  }

  function exito(tipo, cambios, extra) {
    return Object.assign({ ok: true, tipo: tipo, cambios: cambios }, extra || {});
  }

  function aplicarCambios(datos, cambios) {
    indices.delete(datos); // los datos cambian: el índice se arma de nuevo en la próxima consulta
    cambios.forEach((cambio) => {
      const lista = datos[cambio.tabla];
      const id = cambio.poner ? cambio.poner.id : cambio.borrar;
      const posicion = lista.findIndex((registro) => registro.id === id);
      if (cambio.poner) {
        const copia = clonar(cambio.poner);
        if (posicion === -1) lista.push(copia);
        else lista[posicion] = copia;
      } else if (posicion !== -1) {
        lista.splice(posicion, 1);
      }
    });
    return datos;
  }

  // Los cambios que regresan "datos" a como estaba ANTES de aplicar "cambios".
  // El historial (movimientos) nunca se deshace: deshacer agrega su propio movimiento.
  function invertirCambios(datos, cambios) {
    const inverso = [];
    cambios.filter((cambio) => cambio.tabla !== 'movimientos').forEach((cambio) => {
      const id = cambio.poner ? cambio.poner.id : cambio.borrar;
      const anterior = buscarPorId(datos[cambio.tabla], id);
      if (anterior) inverso.unshift({ tabla: cambio.tabla, poner: clonar(anterior) });
      else inverso.unshift({ tabla: cambio.tabla, borrar: id });
    });
    return inverso;
  }

  function nombreRepetido(lista, nombre, ignorarId) {
    const buscado = normalizar(nombre);
    return lista.some((registro) => registro.id !== ignorarId && normalizar(registro.nombre) === buscado);
  }

  // "Estante", y si ya existe, "Estante 2", "Estante 3"…
  function nombreLibre(lista, base) {
    if (!nombreRepetido(lista, base)) return base;
    let numero = 2;
    while (nombreRepetido(lista, base + ' ' + numero)) numero++;
    return base + ' ' + numero;
  }

  // ---------- Lugares ----------
  function crearLugar(datos, entrada, id) {
    if (datos.lugares.length >= LIMITES.lugares) return fallo('Llegaste al máximo de ' + LIMITES.lugares + ' lugares.');
    const revision = validarLugar(entrada);
    if (!revision.ok) return revision;
    if (nombreRepetido(datos.lugares, revision.valor.nombre)) return fallo('Ya hay un lugar con ese nombre.');
    const lugar = Object.assign({ id: id || nuevoId('lug') }, revision.valor);
    return exito('alta', [{ tabla: 'lugares', poner: lugar }], { lugar: lugar });
  }

  // Editar nombre, tipo y plano.
  //   - Quitar el plano: los muebles conservan sus casillas como dato inactivo y el lugar recuerda
  //     sus medidas (planoAnterior). Nada se borra.
  //   - Volver a ponerle plano: los muebles cuya casilla guardada cabe vuelven a su lugar; los que
  //     no caben quedan «sin colocar» (se avisa cuáles) para acomodarlos después.
  //   - Achicar un plano que ya existe: si algún mueble colocado quedaría fuera, no se permite.
  function editarLugar(datos, lugarId, entrada) {
    const actual = buscarPorId(datos.lugares, lugarId);
    if (!actual) return fallo('Ese lugar ya no existe.');
    const revision = validarLugar(entrada);
    if (!revision.ok) return revision;
    if (nombreRepetido(datos.lugares, revision.valor.nombre, lugarId)) return fallo('Ya hay un lugar con ese nombre.');
    const plano = revision.valor.plano;
    const lugar = Object.assign({}, actual, revision.valor);
    const cambios = [];
    const sinColocar = [];
    let detalle = null;
    if (actual.plano && !plano) {
      lugar.planoAnterior = clonar(actual.plano);
      detalle = { plano: 'quitado' };
    } else if (actual.plano && plano) {
      const fuera = mueblesDe(datos, lugarId).filter((mueble) =>
        estaColocado(mueble) && (mueble.x + mueble.ancho > plano.ancho || mueble.y + mueble.fondo > plano.fondo));
      if (fuera.length) {
        return fallo('Con esas medidas quedarían fuera: ' + fuera.map((m) => m.nombre).join(', ') + '. Muévelos primero.');
      }
    } else if (!actual.plano && plano) {
      // Se vuelve a usar el plano: se revisa cada casilla guardada, los muebles con más artículos primero
      delete lugar.planoAnterior;
      detalle = { plano: 'puesto' };
      const colocados = [];
      mueblesDe(datos, lugarId).slice()
        .sort((a, b) => piezasEnMueble(datos, b.id) - piezasEnMueble(datos, a.id))
        .forEach((mueble) => {
          if (!estaColocado(mueble)) return;
          if (cabe(mueble, plano, colocados)) {
            colocados.push(mueble);
            return;
          }
          sinColocar.push(mueble.nombre);
          cambios.push({ tabla: 'muebles', poner: Object.assign({}, mueble, { x: null, y: null }) });
        });
    }
    cambios.unshift({ tabla: 'lugares', poner: lugar });
    return exito('edicion', cambios, { lugar: lugar, sinColocar: sinColocar, detalle: detalle });
  }

  // Qué se vería afectado si se borra un lugar (para mostrarlo antes de confirmar)
  function afectadosPorBorrarLugar(datos, lugarId) {
    const muebles = mueblesDe(datos, lugarId);
    const enMuebles = [];
    muebles.forEach((mueble) => articulosDe(datos, mueble.id).forEach((articulo) => enMuebles.push(articulo)));
    const directos = articulosEnLugar(datos, lugarId);
    const articulos = enMuebles.concat(directos);
    return {
      muebles: muebles.slice(),
      articulos: articulos,
      piezas: articulos.reduce((suma, articulo) => suma + totalDe(articulo), 0)
    };
  }

  // Borrar un lugar SIN perder artículos. Dos caminos:
  //   - destinoId: los muebles pasan a ese lugar «sin colocar» (con sus artículos dentro) y los
  //     artículos directos pasan directo a ese lugar. Nada se borra salvo el lugar.
  //   - sin destino: se borran el lugar y sus muebles; TODOS sus artículos pasan a «Sin ubicación».
  function borrarLugar(datos, lugarId, opciones) {
    const lugar = buscarPorId(datos.lugares, lugarId);
    if (!lugar) return fallo('Ese lugar ya no existe.');
    const destinoId = opciones && opciones.destinoId;
    const destino = destinoId ? buscarPorId(datos.lugares, destinoId) : null;
    if (destinoId && (!destino || destinoId === lugarId)) return fallo('Elige otro lugar como destino.');
    const afectados = afectadosPorBorrarLugar(datos, lugarId);
    const cambios = [];
    if (destino) {
      const vecinos = mueblesDe(datos, destino.id);
      afectados.muebles.forEach((mueble) => {
        const nombre = nombreRepetido(vecinos, mueble.nombre) ? nombreLibre(vecinos, mueble.nombre) : mueble.nombre;
        cambios.push({ tabla: 'muebles', poner: Object.assign({}, mueble, { lugarId: destino.id, nombre: nombre, x: null, y: null }) });
      });
      articulosEnLugar(datos, lugarId).forEach((articulo) => {
        cambios.push({ tabla: 'articulos', poner: Object.assign({}, articulo, { lugarId: destino.id }) });
      });
      // Los objetos 3D van con sus muebles; los del piso conservan su posición en el lugar nuevo
      objetosEnLugar(datos, lugarId).forEach((o) => cambios.push({ tabla: 'objetos', poner: Object.assign({}, o, { lugarId: destino.id }) }));
    } else {
      objetosEnLugar(datos, lugarId).forEach((o) => cambios.push({ tabla: 'objetos', borrar: o.id }));
      afectados.articulos.forEach((articulo) => {
        cambios.push({ tabla: 'articulos', poner: Object.assign({}, articulo, { muebleId: null, lugarId: null }) });
      });
      afectados.muebles.forEach((mueble) => cambios.push({ tabla: 'muebles', borrar: mueble.id }));
    }
    cambios.push({ tabla: 'lugares', borrar: lugarId });
    return exito('borrado', cambios, {
      muebles: afectados.muebles.length,
      articulos: afectados.articulos.length,
      piezas: afectados.piezas,
      destino: destino,
      detalle: { destino: destino ? destino.nombre : 'Sin ubicación' }
    });
  }

  // ---------- Muebles ----------
  function colocarMueble(datos, lugarId, tipo, rect, id) {
    const lugar = buscarPorId(datos.lugares, lugarId);
    if (!lugar) return fallo('Ese lugar ya no existe.');
    if (!lugar.plano) return fallo('Este lugar no tiene plano.');
    const datosTipo = TIPOS_MUEBLE[tipo];
    if (!datosTipo) return fallo('Ese tipo de mueble no existe.');
    const forma = { x: rect.x, y: rect.y, ancho: rect.ancho, fondo: rect.fondo };
    const estorbaAlColocar = obstaculoEn(forma, obstaculosDePiso(datos, lugarId));
    if (estorbaAlColocar) return fallo('Ahí está «' + estorbaAlColocar.nombre + '». Muévelo primero.');
    if (!cabe(forma, lugar.plano, mueblesDe(datos, lugarId))) return fallo('No cabe ahí.');
    const mueble = Object.assign(
      { id: id || nuevoId('mue'), lugarId: lugarId, tipo: tipo, nombre: nombreLibre(mueblesDe(datos, lugarId), datosTipo.nombre) },
      forma,
      { giro: forma.ancho === datosTipo.ancho ? 0 : 1 }
    );
    return exito('colocar', [{ tabla: 'muebles', poner: mueble }], { mueble: mueble });
  }

  // Casillas de un plano en el orden en que conviene llenarlo: primero pegado a las paredes
  // (fondo, izquierda, derecha) y después filas interiores dejando un pasillo entre ellas.
  function casillasParaAcomodar(plano) {
    const lista = [];
    const vistas = new Set();
    const poner = (x, y) => {
      if (x < 0 || y < 0 || x >= plano.ancho || y >= plano.fondo || vistas.has(x + ',' + y)) return;
      vistas.add(x + ',' + y);
      lista.push({ x: x, y: y });
    };
    for (let x = 0; x < plano.ancho; x++) poner(x, 0);
    for (let y = 1; y < plano.fondo; y++) poner(0, y);
    for (let y = 1; y < plano.fondo; y++) poner(plano.ancho - 1, y);
    for (let y = 2; y < plano.fondo; y += 2) for (let x = 2; x < plano.ancho - 2; x++) poner(x, y);
    for (let y = 1; y < plano.fondo; y++) for (let x = 1; x < plano.ancho - 1; x++) poner(x, y);
    return lista;
  }

  // Busca dónde cabe un mueble (probando también girado). Devuelve el mueble ya con x, y o null.
  function buscarSitio(mueble, plano, ocupados, obstaculos) {
    const formas = [{ ancho: mueble.ancho, fondo: mueble.fondo, giro: mueble.giro || 0 }];
    if (mueble.ancho !== mueble.fondo) formas.push({ ancho: mueble.fondo, fondo: mueble.ancho, giro: ((mueble.giro || 0) + 1) % 4 });
    const casillas = casillasParaAcomodar(plano);
    for (const casilla of casillas) {
      for (const forma of formas) {
        const rect = { x: casilla.x, y: casilla.y, ancho: forma.ancho, fondo: forma.fondo };
        if (cabe(rect, plano, ocupados, null, obstaculos)) return Object.assign({}, mueble, rect, { giro: forma.giro });
      }
    }
    return null;
  }

  // Crea un mueble sin pedir casilla: si el lugar tiene plano se acomoda solo en el primer hueco;
  // si no tiene plano (o no cabe) queda «sin colocar» y sirve igual para guardar artículos.
  function crearMueble(datos, lugarId, tipo, nombre, id) {
    const lugar = buscarPorId(datos.lugares, lugarId);
    if (!lugar) return fallo('Ese lugar ya no existe.');
    const datosTipo = TIPOS_MUEBLE[tipo];
    if (!datosTipo) return fallo('Elige un tipo de mueble.');
    const delLugar = mueblesDe(datos, lugarId);
    let nombreFinal = nombreLibre(delLugar, datosTipo.nombre);
    if (limpiarTexto(nombre)) {
      const revision = validarTexto(nombre, { campo: 'el nombre del mueble', maximo: LIMITES.nombre });
      if (!revision.ok) return revision;
      if (nombreRepetido(delLugar, revision.valor)) return fallo('Ya hay un mueble con ese nombre en este lugar.');
      nombreFinal = revision.valor;
    }
    const base = { id: id || nuevoId('mue'), lugarId: lugarId, tipo: tipo, nombre: nombreFinal, x: null, y: null,
      ancho: datosTipo.ancho, fondo: datosTipo.fondo, giro: 0 };
    const mueble = (lugar.plano && buscarSitio(base, lugar.plano, delLugar.filter(estaColocado), obstaculosDePiso(datos, lugarId))) || base;
    return exito('colocar', [{ tabla: 'muebles', poner: mueble }], { mueble: mueble, colocado: estaColocado(mueble) });
  }

  // Alta de un artículo dentro de un mueble que todavía no existe (se crean los dos de una vez)
  function crearArticuloEnMuebleNuevo(datos, lugarId, tipoMueble, nombreMueble, entrada) {
    const creado = crearMueble(datos, lugarId, tipoMueble, nombreMueble);
    if (!creado.ok) return creado;
    const conMueble = Object.assign({}, datos, { muebles: datos.muebles.concat([creado.mueble]) });
    const alta = crearArticulo(conMueble, Object.assign({}, entrada, { ubicacion: { muebleId: creado.mueble.id } }));
    if (!alta.ok) return alta;
    return exito('alta', creado.cambios.concat(alta.cambios), { articulo: alta.articulo, mueble: creado.mueble, colocado: creado.colocado });
  }

  // Lleva varios artículos al mismo destino en una sola operación (un solo «Deshacer»)
  function moverArticulos(datos, articuloIds, destino) {
    const ids = Array.from(new Set(articuloIds || []));
    if (!ids.length) return fallo('Elige al menos un artículo.');
    const copia = Object.assign({}, datos, { articulos: datos.articulos.slice(), prestamos: datos.prestamos.slice() });
    let cambios = [];
    let juntos = 0;
    for (const id of ids) {
      const paso = moverArticulo(copia, id, destino);
      if (!paso.ok) {
        const articulo = buscarPorId(copia.articulos, id);
        return fallo((articulo ? '«' + articulo.nombre + '»: ' : '') + paso.error);
      }
      aplicarCambios(copia, paso.cambios);
      cambios = cambios.concat(paso.cambios);
      if (paso.juntos) juntos++;
    }
    return exito('cambio-ubicacion', cambios, { movidos: ids.length, juntos: juntos });
  }

  // Acomodo automático: convierte un lugar de lista en un plano listo para usar.
  //  - Si no tiene plano, calcula uno donde quepa todo.
  //  - Coloca los muebles que estén sin colocar (los ya colocados no se tocan).
  //  - Con opciones.estantes, guarda los artículos sueltos del lugar en un estante por categoría.
  // No borra nada y todo sale en una sola operación (se deshace de un toque).
  function autoOrdenar(datos, lugarId, opciones) {
    const lugar = buscarPorId(datos.lugares, lugarId);
    if (!lugar) return fallo('Ese lugar ya no existe.');
    const conEstantes = Boolean(opciones && opciones.estantes);
    let muebles = mueblesDe(datos, lugarId).map((mueble) => Object.assign({}, mueble));
    const cambios = [];
    const nuevos = [];
    const movidos = [];
    if (conEstantes) {
      const sueltos = datos.articulos.filter((articulo) => !articulo.muebleId && articulo.lugarId === lugarId);
      const porCategoria = new Map();
      sueltos.forEach((articulo) => {
        const categoria = categoriaDe(datos, articulo);
        if (!porCategoria.has(categoria.id)) porCategoria.set(categoria.id, { categoria: categoria, articulos: [] });
        porCategoria.get(categoria.id).articulos.push(articulo);
      });
      porCategoria.forEach((grupo) => {
        const estante = { id: nuevoId('mue'), lugarId: lugarId, tipo: 'estante', nombre: nombreLibre(muebles, 'Estante ' + grupo.categoria.nombre).slice(0, LIMITES.nombre),
          x: null, y: null, ancho: 1, fondo: 1, giro: 0 };
        muebles.push(estante);
        nuevos.push(estante);
        grupo.articulos.forEach((articulo) => movidos.push(Object.assign({}, articulo, { muebleId: estante.id, lugarId: null })));
      });
    }
    // Si el plano se quitó antes, se recupera con sus medidas y cada mueble vuelve a su casilla
    const planoBase = lugar.plano || lugar.planoAnterior || null;
    const tienePlano = Boolean(planoBase);
    if (!tienePlano) muebles.forEach((mueble) => { mueble.x = null; mueble.y = null; });
    const pendientes = muebles.filter((mueble) => !estaColocado(mueble))
      .sort((a, b) => b.ancho * b.fondo - a.ancho * a.fondo || piezasEnMueble(datos, b.id) - piezasEnMueble(datos, a.id));
    if (lugar.plano && !pendientes.length) return fallo('No hay nada que acomodar: todos los muebles ya están en el plano.');
    // Tamaño del plano nuevo: empieza justo y crece hasta que todo quepa
    const area = muebles.reduce((suma, mueble) => suma + mueble.ancho * mueble.fondo, 0);
    let lado = Math.max(LIMITES.ladoMinimo, 4, Math.ceil(Math.sqrt(area * 2.6)));
    let plano = planoBase;
    let colocados = [];
    let sinSitio = [];
    for (;;) {
      if (!tienePlano) plano = { ancho: Math.min(lado, LIMITES.ladoMaximo), fondo: Math.min(lado, LIMITES.ladoMaximo) };
      const ocupados = muebles.filter(estaColocado);
      colocados = [];
      sinSitio = [];
      pendientes.forEach((mueble) => {
        const puesto = buscarSitio(mueble, plano, ocupados, obstaculosDePiso(datos, lugarId));
        if (!puesto) {
          sinSitio.push(mueble);
          return;
        }
        ocupados.push(puesto);
        colocados.push(puesto);
      });
      if (!sinSitio.length || tienePlano || lado >= LIMITES.ladoMaximo) break;
      lado++;
    }
    const lugarNuevo = Object.assign({}, lugar, { plano: plano, vista: lugar.vista === '3d' ? '3d' : '2.5d' });
    delete lugarNuevo.planoAnterior;
    cambios.push({ tabla: 'lugares', poner: lugarNuevo });
    const finales = new Map(colocados.map((mueble) => [mueble.id, mueble]));
    muebles.forEach((mueble) => {
      const original = buscarPorId(datos.muebles, mueble.id);
      const final = finales.get(mueble.id) || mueble;
      if (!original || original.x !== final.x || original.y !== final.y || original.ancho !== final.ancho ||
          original.fondo !== final.fondo || (original.giro || 0) !== (final.giro || 0)) {
        cambios.push({ tabla: 'muebles', poner: final });
      }
    });
    movidos.forEach((articulo) => cambios.push({ tabla: 'articulos', poner: articulo }));
    return exito('auto-orden', cambios, {
      lugar: lugarNuevo, colocados: colocados.length, creados: nuevos.length, guardados: movidos.length,
      sinSitio: sinSitio.map((mueble) => mueble.nombre), planoNuevo: !lugar.plano,
      detalle: { colocados: colocados.length, estantes: nuevos.length }
    });
  }

  // Mover a otra casilla (también sirve para colocar un mueble que estaba «sin colocar»)
  function moverMueble(datos, muebleId, rect) {
    const mueble = buscarPorId(datos.muebles, muebleId);
    if (!mueble) return fallo('Ese mueble ya no existe.');
    const lugar = buscarPorId(datos.lugares, mueble.lugarId);
    if (!lugar || !lugar.plano) return fallo('Este lugar no tiene plano.');
    const forma = { x: rect.x, y: rect.y, ancho: rect.ancho, fondo: rect.fondo };
    const estorba = obstaculoEn(forma, obstaculosDePiso(datos, lugar.id));
    if (estorba) return fallo('Ahí está «' + estorba.nombre + '». Muévelo primero.');
    if (!cabe(forma, lugar.plano, mueblesDe(datos, lugar.id), muebleId)) return fallo('No cabe ahí.');
    const movido = Object.assign({}, mueble, forma);
    return exito(estaColocado(mueble) ? 'mover' : 'colocar', [{ tabla: 'muebles', poner: movido }], { mueble: movido });
  }

  // Gira el mueble un cuarto de vuelta sobre su primera casilla. "giro" dice hacia dónde mira
  // (0 a 3 cuartos de vuelta): el 2.5D usa sus medidas y el 3D usará también su orientación.
  function girarMueble(datos, muebleId) {
    const mueble = buscarPorId(datos.muebles, muebleId);
    if (!mueble) return fallo('Ese mueble ya no existe.');
    if (mueble.ancho === mueble.fondo) return fallo('Este mueble es cuadrado: girarlo no cambia nada.');
    const forma = { ancho: mueble.fondo, fondo: mueble.ancho, giro: ((mueble.giro || 0) + 1) % 4 };
    if (estaColocado(mueble)) {
      const lugar = buscarPorId(datos.lugares, mueble.lugarId);
      const rect = { x: mueble.x, y: mueble.y, ancho: forma.ancho, fondo: forma.fondo };
      if (lugar && lugar.plano && !cabe(rect, lugar.plano, mueblesDe(datos, lugar.id), muebleId, obstaculosDePiso(datos, lugar.id))) {
        return fallo('No hay espacio para girarlo.');
      }
    }
    const girado = Object.assign({}, mueble, forma);
    return exito('girar', [{ tabla: 'muebles', poner: girado }], { mueble: girado });
  }

  function renombrarMueble(datos, muebleId, nombre) {
    const mueble = buscarPorId(datos.muebles, muebleId);
    if (!mueble) return fallo('Ese mueble ya no existe.');
    const revision = validarTexto(nombre, { campo: 'el nombre', maximo: LIMITES.nombre });
    if (!revision.ok) return revision;
    if (nombreRepetido(mueblesDe(datos, mueble.lugarId), revision.valor, muebleId)) {
      return fallo('Ya hay un mueble con ese nombre en este lugar.');
    }
    const renombrado = Object.assign({}, mueble, { nombre: revision.valor });
    return exito('edicion', [{ tabla: 'muebles', poner: renombrado }], { mueble: renombrado });
  }

  // Borrar un mueble. Por defecto sus artículos NO se borran: pasan directo al lugar del mueble.
  // Con { conArticulos: true } (requiere confirmación explícita en la app) se borran también,
  // salvo que alguno tenga préstamos activos.
  function borrarMueble(datos, muebleId, opciones) {
    const mueble = buscarPorId(datos.muebles, muebleId);
    if (!mueble) return fallo('Ese mueble ya no existe.');
    const articulos = articulosDe(datos, muebleId);
    const piezas = articulos.reduce((suma, articulo) => suma + totalDe(articulo), 0);
    const conArticulos = Boolean(opciones && opciones.conArticulos);
    const cambios = [];
    if (conArticulos) {
      const conPrestamo = articulos.find((articulo) => prestadas(datos, articulo.id) > 0);
      if (conPrestamo) {
        return fallo('«' + conPrestamo.nombre + '» está prestado. Regístralo como devuelto antes de borrarlo.');
      }
      articulos.forEach((articulo) => cambios.push({ tabla: 'articulos', borrar: articulo.id }));
    } else {
      const vecinos = articulosEnLugar(datos, mueble.lugarId);
      articulos.forEach((articulo) => {
        const nombre = nombreRepetido(vecinos, articulo.nombre) ? nombreLibre(vecinos, articulo.nombre) : articulo.nombre;
        cambios.push({ tabla: 'articulos', poner: Object.assign({}, articulo, { muebleId: null, lugarId: mueble.lugarId, nombre: nombre }) });
      });
    }
    // Sus objetos 3D quedan en el piso, donde estaban (los de artículos borrados se borran)
    const borrados = new Set(conArticulos ? articulos.map((a) => a.id) : []);
    const pose = Espacio.poseDeMueble(estaColocado(mueble) ? mueble : Object.assign({}, mueble, { x: 0, y: 0 }));
    objetosEnMueble(datos, muebleId).forEach((o) => {
      if (o.articuloId && borrados.has(o.articuloId)) cambios.push({ tabla: 'objetos', borrar: o.id });
      else cambios.push({ tabla: 'objetos', poner: Object.assign(Espacio.objetoAMundo(pose, o), { muebleId: null }) });
    });
    cambios.push({ tabla: 'muebles', borrar: muebleId });
    return exito('borrado', cambios, { articulos: articulos.length, piezas: piezas, conArticulos: conArticulos });
  }

  // ---------- Artículos ----------
  // ubicacion: { muebleId } | { lugarId } | null. Devuelve los campos normalizados o un error.
  function revisarUbicacion(datos, destino) {
    if (destino && destino.muebleId) {
      if (!buscarPorId(datos.muebles, destino.muebleId)) return fallo('Ese mueble ya no existe.');
      return { ok: true, valor: { muebleId: destino.muebleId, lugarId: null } };
    }
    if (destino && destino.lugarId) {
      if (!buscarPorId(datos.lugares, destino.lugarId)) return fallo('Ese lugar ya no existe.');
      return { ok: true, valor: { muebleId: null, lugarId: destino.lugarId } };
    }
    return { ok: true, valor: { muebleId: null, lugarId: null } };
  }

  // Artículos que ya están en esa misma ubicación (para no repetir nombres)
  function vecinosDe(datos, sitio) {
    if (sitio.muebleId) return articulosDe(datos, sitio.muebleId);
    if (sitio.lugarId) return articulosEnLugar(datos, sitio.lugarId);
    return articulosSinUbicacion(datos);
  }

  // Alta de un artículo. entrada: { nombre, cantidad, categoriaId, codigo, notas, ubicacion }.
  // Si en esa ubicación ya hay uno con el mismo nombre, se suman las piezas (entrada de existencias).
  function crearArticulo(datos, entrada, id) {
    const sitio = revisarUbicacion(datos, entrada.ubicacion);
    if (!sitio.ok) return sitio;
    const revision = validarDatosArticulo(datos, entrada);
    if (!revision.ok) return revision;
    const cantidad = validarEntero(entrada.cantidad, { campo: 'Cantidad', minimo: 1, maximo: LIMITES.cantidad });
    if (!cantidad.ok) return cantidad;
    const existente = vecinosDe(datos, sitio.valor).find((a) => normalizar(a.nombre) === normalizar(revision.valor.nombre));
    if (existente) {
      const sumado = agregarExistencias(datos, existente.id, cantidad.valor);
      return sumado.ok ? Object.assign(sumado, { sumado: true }) : sumado;
    }
    const articulo = Object.assign({ id: id || nuevoId('art') }, revision.valor, sitio.valor, {
      estados: { bueno: cantidad.valor, reparacion: 0, danado: 0 },
      seguimiento: 'cantidad'
    });
    return exito('alta', [{ tabla: 'articulos', poner: articulo }], { articulo: articulo, sumado: false });
  }

  // Atajo usado por la ficha del mueble: agregar un artículo dentro de ese mueble
  function agregarArticulo(datos, muebleId, entrada, id) {
    return crearArticulo(datos, Object.assign({}, entrada, { ubicacion: { muebleId: muebleId } }), id);
  }

  function editarArticulo(datos, articuloId, entrada) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const revision = validarDatosArticulo(datos, Object.assign({ categoriaId: articulo.categoriaId }, entrada));
    if (!revision.ok) return revision;
    if (nombreRepetido(vecinosDe(datos, articulo), revision.valor.nombre, articuloId)) {
      return fallo('Ya hay un artículo con ese nombre en esa ubicación.');
    }
    const editado = Object.assign({}, articulo, revision.valor);
    return exito('edicion', [{ tabla: 'articulos', poner: editado }], { articulo: editado });
  }

  function conEstados(articulo, cambios) {
    return Object.assign({}, articulo, { estados: Object.assign({}, articulo.estados, cambios) });
  }

  // Entrada de existencias: llegan piezas nuevas en buen estado
  function agregarExistencias(datos, articuloId, cantidad) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const revision = validarEntero(cantidad, { campo: 'Cantidad', minimo: 1, maximo: LIMITES.cantidad });
    if (!revision.ok) return revision;
    if (totalDe(articulo) + revision.valor > LIMITES.cantidad) return fallo('Cantidad: máximo ' + LIMITES.cantidad + ' piezas.');
    const nuevo = conEstados(articulo, { bueno: articulo.estados.bueno + revision.valor });
    return exito('entrada', [{ tabla: 'articulos', poner: nuevo }], { articulo: nuevo, detalle: { cantidad: revision.valor } });
  }

  // Pasar piezas de un estado a otro (por ejemplo, 1 de buen estado a reparación).
  // Desde «buen estado» solo se pueden pasar las disponibles: lo prestado no se manda a reparar.
  function cambiarEstado(datos, articuloId, entrada) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const de = entrada.de;
    const a = entrada.a;
    if (!CLAVES_ESTADO.includes(de) || !CLAVES_ESTADO.includes(a) || de === a) return fallo('Elige dos estados distintos.');
    const maximo = de === 'bueno' ? disponibles(datos, articulo) : articulo.estados[de];
    if (maximo < 1) {
      return fallo(de === 'bueno' && articulo.estados.bueno > 0
        ? 'Las piezas en buen estado están prestadas.'
        : 'No hay piezas en «' + nombreEstado(de) + '».');
    }
    const revision = validarEntero(entrada.cantidad, { campo: 'Cantidad', minimo: 1, maximo: maximo });
    if (!revision.ok) return revision;
    const cambio = {};
    cambio[de] = articulo.estados[de] - revision.valor;
    cambio[a] = articulo.estados[a] + revision.valor;
    const nuevo = conEstados(articulo, cambio);
    return exito('cambio-estado', [{ tabla: 'articulos', poner: nuevo }], {
      articulo: nuevo, detalle: { de: de, a: a, cantidad: revision.valor }
    });
  }

  // Dar de baja: las piezas salen del inventario (rotas sin arreglo, perdidas, consumidas).
  // El artículo puede quedar en 0 (por ejemplo, un consumible agotado) sin borrarse.
  function darDeBaja(datos, articuloId, entrada) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const estado = entrada.estado;
    if (!CLAVES_ESTADO.includes(estado)) return fallo('Elige de qué estado salen las piezas.');
    const maximo = estado === 'bueno' ? disponibles(datos, articulo) : articulo.estados[estado];
    if (maximo < 1) return fallo('No hay piezas que se puedan dar de baja en «' + nombreEstado(estado) + '».');
    const revision = validarEntero(entrada.cantidad, { campo: 'Cantidad', minimo: 1, maximo: maximo });
    if (!revision.ok) return revision;
    const motivo = validarTexto(entrada.motivo, { campo: 'el motivo', minimo: 2, maximo: LIMITES.motivo });
    if (!motivo.ok) return motivo;
    const cambio = {};
    cambio[estado] = articulo.estados[estado] - revision.valor;
    const nuevo = conEstados(articulo, cambio);
    // Si ya no hay tantas piezas como objetos 3D que las dibujan, se desenlazan los que sobran
    const desenlazar = ajustarRepresentacion(datos, articulo, totalDe(nuevo));
    return exito('baja', [{ tabla: 'articulos', poner: nuevo }].concat(desenlazar), {
      articulo: nuevo, desenlazados: desenlazar.length, detalle: { estado: estado, cantidad: revision.valor, motivo: motivo.valor }
    });
  }

  function nombreEstado(clave) {
    const estado = ESTADOS.find((e) => e.clave === clave);
    return estado ? estado.nombre : clave;
  }

  // Lleva el artículo a otra ubicación: un mueble, directo a un lugar o «Sin ubicación».
  // Si allá ya hay uno con el mismo nombre, se juntan (se suman las existencias por estado y sus
  // préstamos pasan al de destino).
  function moverArticulo(datos, articuloId, destino) {
    const resultado = moverArticuloSolo(datos, articuloId, destino);
    if (!resultado.ok || !objetosDeArticulo(datos, articuloId).length) return resultado;
    // Sus objetos 3D lo siguen si caben allá; si no, quedan como figuras sin enlazar
    const trabajo = copiaParaTrabajar(datos);
    aplicarCambios(trabajo, resultado.cambios);
    const seguir = seguirAlArticulo(trabajo, buscarPorId(datos.articulos, articuloId), resultado.articulo);
    return Object.assign({}, resultado, {
      cambios: resultado.cambios.concat(seguir.cambios), objetosQueSiguieron: seguir.siguieron, objetosSueltos: seguir.sueltos
    });
  }

  // Copia de los datos para simular varios pasos sin tocar los originales
  function copiaParaTrabajar(datos) {
    const copia = {};
    TABLAS.forEach((tabla) => {
      copia[tabla] = (datos[tabla] || []).slice();
    });
    return copia;
  }

  // Cambia de sitio solo el artículo (sin ocuparse de sus objetos 3D)
  function moverArticuloSolo(datos, articuloId, destino) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const sitio = revisarUbicacion(datos, destino);
    if (!sitio.ok) return sitio;
    if (sitio.valor.muebleId === (articulo.muebleId || null) && sitio.valor.lugarId === (articulo.lugarId || null)) {
      return fallo('Ya está ahí.');
    }
    const igual = vecinosDe(datos, sitio.valor).find((otro) => normalizar(otro.nombre) === normalizar(articulo.nombre));
    if (!igual) {
      const movido = Object.assign({}, articulo, sitio.valor);
      return exito('cambio-ubicacion', [{ tabla: 'articulos', poner: movido }], { articulo: movido, juntos: false });
    }
    if (totalDe(igual) + totalDe(articulo) > LIMITES.cantidad) return fallo('Juntos pasarían de ' + LIMITES.cantidad + ' piezas.');
    const juntos = conEstados(igual, {
      bueno: igual.estados.bueno + articulo.estados.bueno,
      reparacion: igual.estados.reparacion + articulo.estados.reparacion,
      danado: igual.estados.danado + articulo.estados.danado
    });
    const prestamosMovidos = datos.prestamos
      .filter((prestamo) => prestamo.articuloId === articuloId)
      .map((prestamo) => ({ tabla: 'prestamos', poner: Object.assign({}, prestamo, { articuloId: igual.id }) }));
    return exito('cambio-ubicacion', [{ tabla: 'articulos', poner: juntos }]
      .concat(prestamosMovidos)
      .concat([{ tabla: 'articulos', borrar: articuloId }]), { articulo: juntos, juntos: true });
  }

  function borrarArticulo(datos, articuloId) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    if (prestadas(datos, articuloId) > 0) return fallo('Tiene préstamos activos. Regístralos como devueltos antes de borrarlo.');
    // Sus objetos 3D se quedan como figuras sin enlazar
    const sueltos = objetosDeArticulo(datos, articuloId).map((o) => ({ tabla: 'objetos', poner: Object.assign({}, o, { articuloId: null }) }));
    return exito('borrado', [{ tabla: 'articulos', borrar: articuloId }].concat(sueltos));
  }

  // ---------- Préstamos ----------
  function prestar(datos, articuloId, entrada, hoyISO, id) {
    const lugar = ubicacion(datos, articuloId);
    if (!lugar.articulo) return fallo('Ese artículo ya no existe.');
    const revision = validarPrestamo(entrada, disponibles(datos, lugar.articulo), hoyISO);
    if (!revision.ok) return revision;
    const prestamo = {
      id: id || nuevoId('pre'),
      articuloId: articuloId,
      // Copia de qué y de dónde: el historial sigue legible aunque luego se borre el artículo
      articuloNombre: lugar.articulo.nombre,
      origen: textoUbicacion(lugar.lugar, lugar.mueble),
      persona: revision.valor.persona,
      grupo: revision.valor.grupo,
      cantidad: revision.valor.cantidad,
      fechaSalida: hoyISO,
      fechaLimite: revision.valor.fechaLimite,
      devuelto: null, // fecha de devolución; vacío mientras siga prestado
      devueltasDanadas: 0,
      nota: revision.valor.nota
    };
    return exito('prestamo', [{ tabla: 'prestamos', poner: prestamo }], { prestamo: prestamo });
  }

  // Registrar la devolución.
  //   opciones.cantidad: cuántas regresan (por defecto, todas). Si regresan menos, el préstamo
  //     sigue activo por las que faltan y se crea un registro aparte, ya devuelto, por las que volvieron.
  //   opciones.danadas: cuántas de las que regresan vienen dañadas; pasan de «buen estado» a «dañado».
  function devolver(datos, prestamoId, hoyISO, opciones) {
    const ajustes = opciones || {};
    const prestamo = buscarPorId(datos.prestamos, prestamoId);
    if (!prestamo) return fallo('Ese préstamo ya no existe.');
    if (prestamo.devuelto) return fallo('Ese préstamo ya estaba devuelto.');
    const cantidad = validarEntero(ajustes.cantidad != null && ajustes.cantidad !== '' ? ajustes.cantidad : prestamo.cantidad,
      { campo: 'Cantidad que regresa', minimo: 1, maximo: prestamo.cantidad });
    if (!cantidad.ok) return cantidad;
    const danadas = validarEntero(ajustes.danadas != null && ajustes.danadas !== '' ? ajustes.danadas : 0,
      { campo: 'Dañadas', minimo: 0, maximo: cantidad.valor });
    if (!danadas.ok) return danadas;
    const parcial = cantidad.valor < prestamo.cantidad;
    const devuelto = Object.assign({}, prestamo, { cantidad: cantidad.valor, devuelto: hoyISO, devueltasDanadas: danadas.valor });
    const cambios = [];
    if (parcial) {
      devuelto.id = ajustes.id || nuevoId('pre');
      cambios.push({ tabla: 'prestamos', poner: Object.assign({}, prestamo, { cantidad: prestamo.cantidad - cantidad.valor }) });
    }
    cambios.push({ tabla: 'prestamos', poner: devuelto });
    const articulo = buscarPorId(datos.articulos, prestamo.articuloId);
    if (articulo && danadas.valor) {
      cambios.push({ tabla: 'articulos', poner: conEstados(articulo, {
        bueno: articulo.estados.bueno - danadas.valor,
        danado: articulo.estados.danado + danadas.valor
      }) });
    }
    return exito('devolucion', cambios, {
      prestamo: devuelto, parcial: parcial, faltan: prestamo.cantidad - cantidad.valor,
      detalle: { cantidad: cantidad.valor, danadas: danadas.valor, faltan: prestamo.cantidad - cantidad.valor }
    });
  }

  // ---------- Números de serie (seguimiento individual, primera parte) ----------
  // Un artículo puede llevar una lista de números de serie o etiquetas de sus piezas. Es un
  // registro para identificarlas y encontrarlas con el buscador; el estado y los préstamos se
  // siguen contando por cantidad. (El modelo deja lista la evolución a seguimiento por pieza.)
  function limpiarSeries(lista) {
    const vistas = new Set();
    const salida = [];
    lista.forEach((valor) => {
      const texto = limpiarTexto(valor).slice(0, LIMITES.codigo);
      const clave = normalizar(texto);
      if (!texto || vistas.has(clave)) return;
      vistas.add(clave);
      salida.push(texto);
    });
    return salida;
  }

  // texto: un número de serie por línea (o separados por comas)
  function guardarSeries(datos, articuloId, texto) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const series = limpiarSeries(String(texto == null ? '' : texto).split(/[\n,;]+/));
    if (series.length > totalDe(articulo)) {
      return fallo('Hay ' + series.length + ' números de serie pero solo ' + plural(totalDe(articulo), 'pieza') + '.');
    }
    const nuevo = Object.assign({}, articulo);
    if (series.length) nuevo.series = series;
    else delete nuevo.series;
    return exito('edicion', [{ tabla: 'articulos', poner: nuevo }], { articulo: nuevo, detalle: { series: series.length } });
  }

  // ---------- Forma del artículo en la vista 3D ----------
  // Cada artículo puede tener una figura sencilla (con color y tamaño) para verse dentro de su mueble.
  // Es opcional: sin forma, se dibuja como una caja mediana del color de su categoría.
  const FIGURAS = {
    caja: 'Caja', cilindro: 'Cilindro', esfera: 'Esfera', prisma: 'Prisma triangular', piramide: 'Pirámide'
  };
  const TAMANOS_FORMA = { 1: 'Chico', 2: 'Mediano', 3: 'Grande' };

  // Devuelve una forma válida ({ figura, tamano, color? }) o null si no hay nada que guardar
  function limpiarForma(forma) {
    if (!forma || typeof forma !== 'object' || !FIGURAS[forma.figura]) return null;
    const tamano = TAMANOS_FORMA[forma.tamano] ? Number(forma.tamano) : 2;
    const limpia = { figura: forma.figura, tamano: tamano };
    if (colorValido(forma.color)) limpia.color = forma.color.toLowerCase();
    return limpia;
  }

  function guardarForma(datos, articuloId, forma) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    const nuevo = Object.assign({}, articulo);
    const limpia = limpiarForma(forma);
    if (limpia) nuevo.forma = limpia;
    else delete nuevo.forma;
    return exito('edicion', [{ tabla: 'articulos', poner: nuevo }], { articulo: nuevo, detalle: { forma: limpia ? limpia.figura : 'ninguna' } });
  }

  // La forma con la que se dibuja un artículo (la suya o la de por defecto)
  function formaDe(datos, articulo) {
    const propia = limpiarForma(articulo.forma) || { figura: 'caja', tamano: 2 };
    const categoria = buscarPorId(datos.categorias, articulo.categoriaId);
    return { figura: propia.figura, tamano: propia.tamano, color: propia.color || (categoria && categoria.color) || '#8a93a6' };
  }

  // El hueco donde caben objetos en cada tipo de mueble (sin girar): cuánto mide de frente y de
  // fondo, y sus niveles (repisas, cubierta o piso) con la altura libre de cada uno. Sale de las
  // mismas medidas que piezasMueble: por eso un objeto nunca asoma por las paredes del mueble.
  function huecoInterior(tipoClave, ancho, fondo) {
    const tipo = TIPOS_MUEBLE[tipoClave] || TIPOS_MUEBLE.caja;
    const alto = tipo.alto;
    const w = ancho - 0.12; // el modelo deja 0.06 de margen por lado
    const d = fondo - 0.12;
    const hueco = (menosAncho, menosFondo, niveles) => ({
      ancho: Math.max(0.2, w - menosAncho), fondo: Math.max(0.2, d - menosFondo), niveles: niveles
    });
    if (tipoClave === 'mesa' || tipoClave === 'escritorio') return hueco(0.12, 0.12, [{ z: alto, libre: 0.45 }]);
    if (tipoClave === 'banco') return hueco(0.2, 0.2, [{ z: alto, libre: 0.45 }]);
    if (tipoClave === 'estante') {
      const paso = (alto - 0.12) / 4;
      return hueco(0.18, 0.12, [0, 1, 2, 3].map((n) => ({ z: 0.12 + n * paso, libre: paso - 0.05 })));
    }
    if (tipoClave === 'gabinete' || tipoClave === 'casillero') {
      return hueco(0.12, 0.14, [{ z: 0.04, libre: alto * 0.5 - 0.06 }, { z: alto * 0.5 + 0.02, libre: alto * 0.5 - 0.08 }]);
    }
    if (tipoClave === 'vitrina') {
      return hueco(0.16, 0.16, [{ z: alto * 0.3, libre: alto * 0.32 - 0.02 }, { z: alto * 0.64, libre: alto * 0.31 - 0.02 }]);
    }
    return hueco(0.3, 0.3, [{ z: 0.03, libre: alto - 0.07 }]); // caja: sus paredes van 0.12 más adentro
  }

  // Alturas donde se apoyan los objetos (se conserva para quien solo necesita los niveles)
  function nivelesInterior(tipoClave) {
    return huecoInterior(tipoClave, 1, 1).niveles.map((nivel) => nivel.z);
  }

  // Reparte los artículos de un mueble en sus repisas. Las posiciones son del mueble SIN girar y
  // centradas en su huella: x (frente), y (fondo), z (altura en unidades de alto). `lado` es el
  // tamaño del objeto: nunca mayor que su celda ni que la altura libre de su nivel.
  // Si no caben todos, `sobran` dice cuántos se quedaron sin dibujar.
  const CELDA_OBJETO = 0.42;
  function acomodoInterior(datos, mueble) {
    const medidas = medidasSinGiro(mueble);
    const hueco = huecoInterior(mueble.tipo, medidas.ancho, medidas.fondo);
    const columnas = Math.max(1, Math.floor(hueco.ancho / CELDA_OBJETO));
    const filas = Math.max(1, Math.floor(hueco.fondo / CELDA_OBJETO));
    const celdaX = hueco.ancho / columnas;
    const celdaY = hueco.fondo / filas;
    const niveles = hueco.niveles;
    // Los artículos que ya tienen objetos colocados a mano no se dibujan otra vez, y las celdas
    // que esos objetos ocupan se saltan
    const fijos = objetosEnMueble(datos, mueble.id);
    const dibujados = new Set(fijos.map((o) => o.articuloId).filter(Boolean));
    const ocupado = fijos.map((o) => Espacio.limites(Espacio.formaDeChoque(o)));
    const celdas = [];
    for (let n = niveles.length - 1; n >= 0; n--) { // de arriba hacia abajo: lo primero queda a la altura de los ojos
      for (let fila = 0; fila < filas; fila++) {
        for (let columna = 0; columna < columnas; columna++) {
          const x = (columna + 0.5 - columnas / 2) * celdaX;
          const y = (filas / 2 - fila - 0.5) * celdaY; // primero el frente
          const z0 = niveles[n].z * MPP;
          const z1 = z0 + Math.min(CELDA_OBJETO, niveles[n].libre * MPP);
          const libre = !ocupado.some((l) => l.min[0] < x + celdaX / 2 && l.max[0] > x - celdaX / 2 &&
            l.min[1] < y + celdaY / 2 && l.max[1] > y - celdaY / 2 && l.min[2] < z1 && l.max[2] > z0);
          if (libre) celdas.push({ nivel: niveles[n], x: x, y: y });
        }
      }
    }
    const articulos = articulosDe(datos, mueble.id).filter((articulo) => !dibujados.has(articulo.id));
    const objetos = articulos.slice(0, celdas.length).map((articulo, i) => {
      const celda = celdas[i];
      const forma = formaDe(datos, articulo);
      const maximo = Math.min(CELDA_OBJETO, celdaX, celdaY, celda.nivel.libre) * 0.92;
      return {
        articuloId: articulo.id, figura: forma.figura, color: forma.color,
        lado: maximo * [0.56, 0.78, 1][forma.tamano - 1],
        x: celda.x, y: celda.y, z: celda.nivel.z
      };
    });
    return { objetos: objetos, sobran: articulos.length - objetos.length, cupo: celdas.length, hueco: hueco, fijos: fijos.length };
  }

  // ---------- Medidas del mueble y vista preferida del lugar ----------
  const MEDIDA_MAXIMA_MUEBLE = 6;

  function redimensionarMueble(datos, muebleId, entrada) {
    const mueble = buscarPorId(datos.muebles, muebleId);
    if (!mueble) return fallo('Ese mueble ya no existe.');
    const limites = { minimo: 1, maximo: MEDIDA_MAXIMA_MUEBLE };
    const ancho = validarEntero(entrada.ancho, Object.assign({ campo: 'Ancho' }, limites));
    if (!ancho.ok) return ancho;
    const fondo = validarEntero(entrada.fondo, Object.assign({ campo: 'Fondo' }, limites));
    if (!fondo.ok) return fondo;
    if (estaColocado(mueble)) {
      const lugar = buscarPorId(datos.lugares, mueble.lugarId);
      const rect = { x: mueble.x, y: mueble.y, ancho: ancho.valor, fondo: fondo.valor };
      if (lugar && lugar.plano && !cabe(rect, lugar.plano, mueblesDe(datos, lugar.id), muebleId, obstaculosDePiso(datos, lugar.id))) {
        return fallo('Con esas medidas no cabe donde está. Muévelo primero.');
      }
    }
    const nuevo = Object.assign({}, mueble, { ancho: ancho.valor, fondo: fondo.valor });
    return exito('edicion', [{ tabla: 'muebles', poner: nuevo }], { mueble: nuevo });
  }

  // Cómo se prefiere ver cada lugar: 'lista', '2.5d' o '3d'. Es una preferencia: no deja historial.
  function cambiarVistaLugar(datos, lugarId, vista) {
    const lugar = buscarPorId(datos.lugares, lugarId);
    if (!lugar) return fallo('Ese lugar ya no existe.');
    if (!VISTAS_LUGAR.includes(vista)) return fallo('Esa vista no existe.');
    if (vista !== 'lista' && !lugar.plano) return fallo('Este lugar no tiene plano.');
    return exito('edicion', [{ tabla: 'lugares', poner: Object.assign({}, lugar, { vista: vista }) }], { sinHistorial: true });
  }

  function vistaDeLugar(lugar) {
    if (!lugar || !lugar.plano) return 'lista';
    return VISTAS_LUGAR.includes(lugar.vista) ? lugar.vista : '2.5d';
  }

  // ---------- Categorías ----------
  function crearCategoria(datos, entrada, id) {
    if (datos.categorias.length >= LIMITES.categorias) return fallo('Llegaste al máximo de ' + LIMITES.categorias + ' categorías.');
    const nombre = validarTexto(entrada.nombre, { campo: 'el nombre de la categoría', maximo: LIMITES.nombre });
    if (!nombre.ok) return nombre;
    if (nombreRepetido(datos.categorias, nombre.valor)) return fallo('Ya hay una categoría con ese nombre.');
    const color = colorValido(entrada.color) ? entrada.color.toLowerCase() : COLORES_CATEGORIA[datos.categorias.length % COLORES_CATEGORIA.length];
    const orden = datos.categorias.reduce((maximo, categoria) => Math.max(maximo, categoria.orden), 0) + 1;
    const categoria = { id: id || nuevoId('cat'), nombre: nombre.valor, color: color, orden: orden, fija: false };
    return exito('alta', [{ tabla: 'categorias', poner: categoria }], { categoria: categoria });
  }

  function editarCategoria(datos, categoriaId, entrada) {
    const categoria = buscarPorId(datos.categorias, categoriaId);
    if (!categoria) return fallo('Esa categoría ya no existe.');
    const nombre = validarTexto(entrada.nombre, { campo: 'el nombre de la categoría', maximo: LIMITES.nombre });
    if (!nombre.ok) return nombre;
    if (nombreRepetido(datos.categorias, nombre.valor, categoriaId)) return fallo('Ya hay una categoría con ese nombre.');
    const editada = Object.assign({}, categoria, { nombre: nombre.valor, color: colorValido(entrada.color) ? entrada.color.toLowerCase() : categoria.color });
    return exito('edicion', [{ tabla: 'categorias', poner: editada }], { categoria: editada });
  }

  // Borrar una categoría nunca borra artículos: los suyos pasan a otra (por defecto, «Otros»).
  function borrarCategoria(datos, categoriaId, destinoId) {
    const categoria = buscarPorId(datos.categorias, categoriaId);
    if (!categoria) return fallo('Esa categoría ya no existe.');
    if (categoria.fija) return fallo('«' + categoria.nombre + '» no se puede borrar: ahí van los artículos de las categorías borradas.');
    const destino = buscarPorId(datos.categorias, destinoId || ID_OTROS);
    if (!destino || destino.id === categoriaId) return fallo('Elige otra categoría para sus artículos.');
    const articulos = articulosDeCategoria(datos, categoriaId);
    const cambios = articulos.map((articulo) => ({ tabla: 'articulos', poner: Object.assign({}, articulo, { categoriaId: destino.id }) }));
    cambios.push({ tabla: 'categorias', borrar: categoriaId });
    return exito('borrado', cambios, { articulos: articulos.length, destino: destino, detalle: { destino: destino.nombre } });
  }

  // =====================================================================
  // 7b. OBJETOS 3D
  // =====================================================================
  // Un OBJETO es una figura (caja, cilindro, esfera, cono, aro, tubo, prisma o pirámide) con
  // medidas, posición y giro en metros (ver espacio.js). Vive en un lugar:
  //   - en el piso (muebleId null): pos y rot en el marco del lugar;
  //   - dentro de un mueble: pos y rot RELATIVOS al mueble (si el mueble se mueve, lo acompaña).
  // Puede representar piezas de un artículo (articuloId + unidades). Reglas con el inventario:
  //   - Un objeto enlazado está donde está su artículo: en el mismo mueble, o en el piso del
  //     mismo lugar si el artículo está «directo en el lugar».
  //   - Las unidades que representan los objetos de un artículo no pasan de su total.
  // Los choques y límites los revisa espacio.js con el "entorno" que arma entornoDe().
  // Los objetos no llenan el historial: los cambios del inventario que causan sí se anotan.
  const COLOR_OBJETO = '#8a94a6';
  const FIGURAS_OBJETO = Espacio.FIGURAS;
  const MPP = Espacio.METROS_POR_PISO;
  const TECHO_CERRADO = { estante: true, gabinete: true, casillero: true, vitrina: true };
  const MEDIDAS_INICIALES = {
    caja: { ancho: 0.4, fondo: 0.3, alto: 0.3 },
    cilindro: { ancho: 0.5, fondo: 0.5, alto: 0.8 },
    tubo: { ancho: 0.15, fondo: 0.15, alto: 1.5 },
    esfera: { ancho: 0.4, fondo: 0.4, alto: 0.4 },
    cono: { ancho: 0.35, fondo: 0.35, alto: 0.5 },
    aro: { ancho: 0.65, fondo: 0.65, alto: 0.22 },
    prisma: { ancho: 0.5, fondo: 0.45, alto: 0.4 },
    piramide: { ancho: 0.4, fondo: 0.4, alto: 0.4 }
  };

  // Modelos que trae la app (además de los que guarda la persona en la tabla «modelos»).
  // Cada pieza se mide desde el centro de la base del modelo.
  const pieza = (figura, medidas, pos, color, rot) => ({ figura: figura, medidas: medidas, pos: pos, color: color, rot: rot || { x: 0, y: 0, z: 0 } });
  const MODELOS_BASE = [
    { id: 'base-llanta', nombre: 'Llanta', piezas: [pieza('aro', { ancho: 0.65, fondo: 0.65, alto: 0.22 }, { x: 0, y: 0, z: 0.11 }, '#2b2d33')] },
    { id: 'base-barril', nombre: 'Barril', piezas: [pieza('cilindro', { ancho: 0.58, fondo: 0.58, alto: 0.88 }, { x: 0, y: 0, z: 0.44 }, '#2f6fb0')] },
    { id: 'base-caja-carton', nombre: 'Caja de cartón', piezas: [pieza('caja', { ancho: 0.45, fondo: 0.35, alto: 0.3 }, { x: 0, y: 0, z: 0.15 }, '#b98a55')] },
    { id: 'base-tarima', nombre: 'Tarima', piezas: [pieza('caja', { ancho: 1.2, fondo: 1, alto: 0.14 }, { x: 0, y: 0, z: 0.07 }, '#a07a4f')] },
    { id: 'base-tubo', nombre: 'Tubo', piezas: [pieza('tubo', { ancho: 0.12, fondo: 0.12, alto: 2 }, { x: 0, y: 0, z: 0.06 }, '#9aa1ad', { x: 90, y: 0, z: 0 })] },
    { id: 'base-cubeta', nombre: 'Cubeta', piezas: [pieza('cilindro', { ancho: 0.3, fondo: 0.3, alto: 0.35 }, { x: 0, y: 0, z: 0.175 }, '#e0a030')] },
    { id: 'base-cono', nombre: 'Cono de seguridad', piezas: [pieza('cono', { ancho: 0.32, fondo: 0.32, alto: 0.5 }, { x: 0, y: 0, z: 0.25 }, '#f26b1d')] },
    {
      id: 'base-garrafon', nombre: 'Garrafón', piezas: [
        pieza('cilindro', { ancho: 0.27, fondo: 0.27, alto: 0.42 }, { x: 0, y: 0, z: 0.21 }, '#7fb8d8'),
        pieza('cilindro', { ancho: 0.08, fondo: 0.08, alto: 0.07 }, { x: 0, y: 0, z: 0.455 }, '#3d6fa0')
      ]
    },
    {
      id: 'base-silla', nombre: 'Silla', piezas: [
        pieza('caja', { ancho: 0.42, fondo: 0.42, alto: 0.04 }, { x: 0, y: 0, z: 0.45 }, '#7a5236'),
        pieza('caja', { ancho: 0.42, fondo: 0.03, alto: 0.4 }, { x: 0, y: -0.195, z: 0.67 }, '#7a5236'),
        pieza('caja', { ancho: 0.03, fondo: 0.03, alto: 0.43 }, { x: -0.19, y: -0.19, z: 0.215 }, '#3a3d45'),
        pieza('caja', { ancho: 0.03, fondo: 0.03, alto: 0.43 }, { x: 0.19, y: -0.19, z: 0.215 }, '#3a3d45'),
        pieza('caja', { ancho: 0.03, fondo: 0.03, alto: 0.43 }, { x: -0.19, y: 0.19, z: 0.215 }, '#3a3d45'),
        pieza('caja', { ancho: 0.03, fondo: 0.03, alto: 0.43 }, { x: 0.19, y: 0.19, z: 0.215 }, '#3a3d45')
      ]
    }
  ];

  // ---------- Consultas ----------
  const objetosEnLugar = (datos, lugarId) => (datos.objetos || []).filter((o) => o.lugarId === lugarId);
  const objetosEnPiso = (datos, lugarId) => (datos.objetos || []).filter((o) => o.lugarId === lugarId && !o.muebleId);
  const objetosEnMueble = (datos, muebleId) => (datos.objetos || []).filter((o) => o.muebleId === muebleId);
  const objetosDeArticulo = (datos, articuloId) => (datos.objetos || []).filter((o) => o.articuloId === articuloId);

  function unidadesRepresentadas(datos, articuloId, ignorar) {
    return objetosDeArticulo(datos, articuloId)
      .filter((o) => !(ignorar && ignorar.has(o.id)))
      .reduce((suma, o) => suma + (o.unidades || 1), 0);
  }

  function nombreDeObjeto(datos, objeto) {
    if (objeto.nombre) return objeto.nombre;
    const articulo = objeto.articuloId ? buscarPorId(datos.articulos, objeto.articuloId) : null;
    if (articulo) return articulo.nombre;
    return (FIGURAS_OBJETO[objeto.figura] || FIGURAS_OBJETO.caja).nombre;
  }

  // Dónde «vive» un artículo, en los mismos términos que un objeto: { lugarId, muebleId }
  function contenedorDeArticulo(datos, articulo) {
    if (articulo.muebleId) {
      const mueble = buscarPorId(datos.muebles, articulo.muebleId);
      return mueble ? { lugarId: mueble.lugarId, muebleId: mueble.id } : null;
    }
    if (articulo.lugarId) return { lugarId: articulo.lugarId, muebleId: null };
    return null;
  }

  const mismoContenedor = (a, b) => Boolean(a && b) && a.lugarId === b.lugarId && (a.muebleId || null) === (b.muebleId || null);
  const destinoDe = (contenedor) => (contenedor.muebleId ? { muebleId: contenedor.muebleId } : { lugarId: contenedor.lugarId });

  // ---------- Entorno espacial (lo que rodea a un objeto) ----------
  // Un mueble como sólido. Mesas y bancos solo cuentan su cubierta: debajo, entre las patas,
  // cabe algo; encima se puede apoyar.
  function solidoDeMueble(mueble) {
    const alto = altoDe(mueble) * MPP;
    const soloCubierta = mueble.tipo === 'mesa' || mueble.tipo === 'banco';
    return Espacio.cajaRecta([mueble.x, mueble.y, soloCubierta ? alto - 0.08 : 0], [mueble.x + mueble.ancho, mueble.y + mueble.fondo, alto],
      'mueble:' + mueble.id, mueble.nombre, 'mueble');
  }

  function solidoDeObjeto(datos, objeto) {
    return Object.assign(Espacio.formaDeChoque(objeto, objeto.id, nombreDeObjeto(datos, objeto)), { solido: 'objeto' });
  }

  // "lista": los objetos tal como quedarían (con los propuestos ya puestos); "omitir": ids que
  // no cuentan como obstáculo (por ejemplo, los que se mueven juntos al asentarse).
  function entornoDe(datos, contenedor, lista, omitir) {
    const objetos = (lista || datos.objetos || []).filter((o) => !(omitir && omitir.has(o.id)));
    if (contenedor.muebleId) {
      const mueble = buscarPorId(datos.muebles, contenedor.muebleId);
      if (!mueble) return null;
      const medidas = medidasSinGiro(mueble);
      const hueco = huecoInterior(mueble.tipo, medidas.ancho, medidas.fondo);
      return {
        tipo: 'mueble', nombre: mueble.nombre, hueco: { ancho: hueco.ancho, fondo: hueco.fondo },
        niveles: hueco.niveles.map((nivel) => ({ z: Espacio.redondear(nivel.z * MPP, 4), libre: Espacio.redondear(nivel.libre * MPP, 4) })),
        techoCerrado: Boolean(TECHO_CERRADO[mueble.tipo]),
        solidos: objetos.filter((o) => o.muebleId === mueble.id).map((o) => solidoDeObjeto(datos, o))
      };
    }
    const lugar = buscarPorId(datos.lugares, contenedor.lugarId);
    if (!lugar || !lugar.plano) return null;
    return {
      tipo: 'lugar', ancho: lugar.plano.ancho, fondo: lugar.plano.fondo, alto: Espacio.ALTURA_LUGAR,
      solidos: objetos.filter((o) => o.lugarId === lugar.id && !o.muebleId).map((o) => solidoDeObjeto(datos, o))
        .concat(mueblesColocados(datos, lugar.id).map(solidoDeMueble))
    };
  }

  // Lista de objetos con los propuestos en lugar de sus versiones guardadas (o agregados)
  function conPropuestos(objetos, propuestos) {
    const porId = new Map(propuestos.map((o) => [o.id, o]));
    return (objetos || []).map((o) => porId.get(o.id) || o).concat(propuestos.filter((o) => !(objetos || []).some((x) => x.id === o.id)));
  }

  function revisarObjeto(datos, objeto, opciones) {
    const lista = conPropuestos(datos.objetos, [objeto]);
    const entorno = entornoDe(datos, objeto, lista);
    if (!entorno) return { nivel: 'error', problemas: [{ tipo: 'limite', grave: true, mensaje: 'Este lugar no tiene plano.' }] };
    return Espacio.revisar(Object.assign({}, objeto, { nombre: nombreDeObjeto(datos, objeto) }), entorno, opciones);
  }

  // Revisa varios objetos a la vez (los que se mueven juntos se ven unos a otros ya movidos)
  function revisarObjetos(datos, propuestos, opciones) {
    const lista = conPropuestos(datos.objetos, propuestos);
    const revisiones = {};
    let nivel = 'ok';
    propuestos.forEach((objeto) => {
      const entorno = entornoDe(datos, objeto, lista);
      const revision = entorno
        ? Espacio.revisar(Object.assign({}, objeto, { nombre: nombreDeObjeto(datos, objeto) }), entorno, opciones)
        : { nivel: 'error', problemas: [{ tipo: 'limite', grave: true, mensaje: 'Este lugar no tiene plano: créalo para acomodar objetos.' }] };
      revisiones[objeto.id] = revision;
      if (revision.nivel === 'error') nivel = 'error';
      else if (revision.nivel === 'aviso' && nivel === 'ok') nivel = 'aviso';
    });
    return { nivel: nivel, revisiones: revisiones };
  }

  // ---------- Validación ----------
  function numeroDe(valor) {
    if (typeof valor === 'number') return valor;
    if (typeof valor === 'string' && valor.trim() !== '') return Number(valor.trim().replace(',', '.'));
    return NaN;
  }

  // Figura, medidas, posición y giro: toma lo que trae "entrada" y completa con "base"
  function geometriaDe(entrada, base) {
    const figura = entrada.figura != null ? entrada.figura : base && base.figura;
    if (!FIGURAS_OBJETO[figura]) return fallo('Elige una figura.');
    const fuente = Object.assign({}, MEDIDAS_INICIALES[figura], base && base.medidas, entrada.medidas);
    const medidas = {};
    for (const clave of ['ancho', 'fondo', 'alto']) {
      const n = numeroDe(fuente[clave]);
      if (!Number.isFinite(n)) return fallo('Revisa las medidas: usa números, por ejemplo 0.65.');
      if (n < Espacio.MEDIDA_MINIMA || n > Espacio.MEDIDA_MAXIMA) {
        return fallo('Cada medida va de ' + Espacio.MEDIDA_MINIMA + ' a ' + Espacio.MEDIDA_MAXIMA + ' m.');
      }
      medidas[clave] = Espacio.redondear(n, 3);
    }
    const p = Object.assign({ x: 0, y: 0, z: 0 }, base && base.pos, entrada.pos);
    const pos = {};
    for (const clave of ['x', 'y', 'z']) {
      const n = numeroDe(p[clave]);
      if (!Number.isFinite(n) || Math.abs(n) > 100) return fallo('Revisa la posición: usa números, por ejemplo 2.35.');
      pos[clave] = Espacio.redondear(n, 4);
    }
    const r = Object.assign({ x: 0, y: 0, z: 0 }, base && base.rot, entrada.rot);
    const rot = {};
    for (const clave of ['x', 'y', 'z']) {
      const n = numeroDe(r[clave]);
      if (!Number.isFinite(n)) return fallo('Revisa el giro: usa grados, por ejemplo 90.');
      rot[clave] = Espacio.normalizarAngulo(n);
    }
    return { ok: true, valor: { figura: figura, medidas: medidas, pos: pos, rot: rot } };
  }

  const colorDeObjeto = (color) => (colorValido(color) ? color.toLowerCase() : null);

  // La base del objeto (punto más bajo) no cambia si cambian sus medidas o su giro
  function mismaBase(antes, despues) {
    const bajo = (o) => Espacio.limites(Espacio.formaDeChoque(o)).min[2];
    const ajuste = bajo(antes) - bajo(despues);
    return Object.assign({}, despues, { pos: Object.assign({}, despues.pos, { z: Espacio.redondear(despues.pos.z + ajuste, 4) }) });
  }

  function espacioDe(opciones) {
    return { permitirEncimar: Boolean(opciones && opciones.permitirEncimar) };
  }

  // Revisa los propuestos y arma el resultado (o el error del primero que no se puede guardar)
  function guardarObjetos(datos, propuestos, opciones, tipo, masCambios, extra) {
    const revision = revisarObjetos(datos, propuestos, espacioDe(opciones));
    if (revision.nivel === 'error' && !(opciones && opciones.sinRevisar)) {
      const malo = propuestos.find((o) => revision.revisiones[o.id].nivel === 'error');
      const problema = revision.revisiones[malo.id].problemas.find((p) => p.grave);
      return Object.assign(fallo((propuestos.length > 1 ? '«' + nombreDeObjeto(datos, malo) + '»: ' : '') + problema.mensaje),
        { revision: revision, objetoId: malo.id });
    }
    const cambios = propuestos.map((o) => ({ tabla: 'objetos', poner: o })).concat(masCambios || []);
    return exito(tipo, cambios, Object.assign({ objetos: propuestos, nivel: revision.nivel, revisiones: revision.revisiones }, extra || {}));
  }

  // Si se pide, baja (o sube) el conjunto hasta apoyarse, sin deshacer su forma
  function asentarConjunto(datos, propuestos) {
    const omitir = new Set(propuestos.map((o) => o.id));
    const porContenedor = new Map();
    propuestos.forEach((o) => {
      const clave = o.lugarId + '|' + (o.muebleId || '');
      if (!porContenedor.has(clave)) porContenedor.set(clave, []);
      porContenedor.get(clave).push(o);
    });
    const salida = [];
    porContenedor.forEach((grupo) => {
      const entorno = entornoDe(datos, grupo[0], null, omitir);
      const bajar = entorno ? Espacio.distanciaParaAsentar(grupo, entorno) : 0;
      grupo.forEach((o) => salida.push(Object.assign({}, o, { pos: Object.assign({}, o.pos, { z: Espacio.redondear(o.pos.z - bajar, 4) }) })));
    });
    return salida;
  }

  // Caja (en el marco de su contenedor) que envuelve a varios objetos
  function limitesDeConjunto(objetos) {
    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    objetos.forEach((o) => {
      const lim = Espacio.limites(Espacio.formaDeChoque(o));
      for (let i = 0; i < 3; i++) {
        min[i] = Math.min(min[i], lim.min[i]);
        max[i] = Math.max(max[i], lim.max[i]);
      }
    });
    return { min: min, max: max };
  }

  // Busca un sitio libre para un conjunto rígido de objetos (ya expresados en el marco del
  // destino) cerca de "preferido". Devuelve los objetos ya movidos o null.
  function acomodarConjunto(datos, objetos, preferido, lista) {
    const lim = limitesDeConjunto(objetos);
    const omitir = new Set(objetos.map((o) => o.id));
    const entorno = entornoDe(datos, objetos[0], lista, omitir);
    if (!entorno) return null;
    // Una caja que envuelve al conjunto busca hueco; después todos se mueven lo mismo que ella
    const envoltura = {
      id: '__conjunto', nombre: 'conjunto', figura: 'caja', rot: { x: 0, y: 0, z: 0 },
      medidas: { ancho: lim.max[0] - lim.min[0], fondo: lim.max[1] - lim.min[1], alto: lim.max[2] - lim.min[2] },
      pos: { x: (lim.min[0] + lim.max[0]) / 2, y: (lim.min[1] + lim.max[1]) / 2, z: (lim.min[2] + lim.max[2]) / 2 }
    };
    const sitio = Espacio.buscarHueco(envoltura, entorno, preferido);
    if (!sitio) return null;
    const d = [sitio.x - envoltura.pos.x, sitio.y - envoltura.pos.y, sitio.z - envoltura.pos.z];
    return objetos.map((o) => Object.assign({}, o, {
      pos: { x: Espacio.redondear(o.pos.x + d[0], 4), y: Espacio.redondear(o.pos.y + d[1], 4), z: Espacio.redondear(o.pos.z + d[2], 4) }
    }));
  }

  function revisarContenedor(datos, lugarId, muebleId) {
    const lugar = buscarPorId(datos.lugares, lugarId);
    if (!lugar) return fallo('Ese lugar ya no existe.');
    if (muebleId) {
      const mueble = buscarPorId(datos.muebles, muebleId);
      if (!mueble || mueble.lugarId !== lugarId) return fallo('Ese mueble ya no existe.');
    } else if (!lugar.plano) return fallo('Este lugar no tiene plano: créalo para acomodar objetos en el piso.');
    return { ok: true };
  }

  // ---------- Operaciones ----------
  // entrada: { lugarId, muebleId?, figura, medidas?, pos?, rot?, color?, nombre?, articuloId?,
  //            unidades?, cerca?: { x, y, nivel } }. Sin pos, busca el hueco libre más cercano a "cerca".
  function crearObjeto(datos, entrada, opciones, id) {
    const contenedor = revisarContenedor(datos, entrada.lugarId, entrada.muebleId || null);
    if (!contenedor.ok) return contenedor;
    if ((datos.objetos || []).length >= LIMITES.objetos) return fallo('Llegaste al máximo de ' + LIMITES.objetos + ' objetos 3D.');
    const geometria = geometriaDe(entrada, null);
    if (!geometria.ok) return geometria;
    const nombre = validarTexto(entrada.nombre || '', { campo: 'el nombre', minimo: 0, maximo: LIMITES.nombre });
    if (!nombre.ok) return nombre;
    const unidades = validarEntero(entrada.unidades == null ? 1 : entrada.unidades, { campo: 'Unidades', minimo: 1, maximo: LIMITES.cantidad });
    if (!unidades.ok) return unidades;
    let objeto = Object.assign({ id: id || nuevoId('obj'), lugarId: entrada.lugarId, muebleId: entrada.muebleId || null, nombre: nombre.valor },
      geometria.valor, {
        color: colorDeObjeto(entrada.color) || COLOR_OBJETO, articuloId: null, unidades: unidades.valor, grupoId: entrada.grupoId || null
      });
    if (!entrada.pos) {
      const colocado = acomodarConjunto(datos, [objeto], entrada.cerca || null, null);
      if (!colocado) return fallo('No hay un espacio libre para esa figura' + (objeto.muebleId ? ' en este mueble.' : '.'));
      objeto = colocado[0];
    } else if (opciones && opciones.asentar) objeto = asentarConjunto(datos, [objeto])[0];
    const masCambios = [];
    if (entrada.articuloId) {
      const enlace = vincularObjetos(conPropuestosEnDatos(datos, [objeto]), [objeto.id], entrada.articuloId, {});
      if (!enlace.ok) return enlace;
      objeto = enlace.cambios.find((c) => c.tabla === 'objetos' && c.poner && c.poner.id === objeto.id).poner;
      enlace.cambios.filter((c) => !(c.tabla === 'objetos' && c.poner && c.poner.id === objeto.id)).forEach((c) => masCambios.push(c));
    }
    return guardarObjetos(datos, [objeto], opciones, 'alta', masCambios, { objeto: objeto });
  }

  function conPropuestosEnDatos(datos, propuestos) {
    return Object.assign({}, datos, { objetos: conPropuestos(datos.objetos, propuestos) });
  }

  // cambios: { nombre, figura, medidas, pos, rot, color, unidades }. Si cambian las medidas o el
  // giro y no se da la posición, la base se queda donde estaba (no se hunde ni flota).
  function editarObjeto(datos, objetoId, cambios, opciones) {
    const antes = buscarPorId(datos.objetos || [], objetoId);
    if (!antes) return fallo('Ese objeto ya no existe.');
    const geometria = geometriaDe(cambios, antes);
    if (!geometria.ok) return geometria;
    let despues = Object.assign({}, antes, geometria.valor);
    if (!cambios.pos && (cambios.medidas || cambios.rot || cambios.figura)) despues = mismaBase(antes, despues);
    if (cambios.nombre != null) {
      const nombre = validarTexto(cambios.nombre, { campo: 'el nombre', minimo: 0, maximo: LIMITES.nombre });
      if (!nombre.ok) return nombre;
      despues.nombre = nombre.valor;
    }
    if (cambios.color != null) {
      if (!colorDeObjeto(cambios.color)) return fallo('Elige un color.');
      despues.color = colorDeObjeto(cambios.color);
    }
    if (cambios.unidades != null) {
      const unidades = validarEntero(cambios.unidades, { campo: 'Unidades', minimo: 1, maximo: LIMITES.cantidad });
      if (!unidades.ok) return unidades;
      if (antes.articuloId) {
        const articulo = buscarPorId(datos.articulos, antes.articuloId);
        const otras = unidadesRepresentadas(datos, antes.articuloId, new Set([objetoId]));
        if (articulo && otras + unidades.valor > totalDe(articulo)) {
          return fallo('«' + articulo.nombre + '» tiene ' + totalDe(articulo) + ' piezas: este objeto puede representar hasta ' + Math.max(0, totalDe(articulo) - otras) + '.');
        }
      }
      despues.unidades = unidades.valor;
    }
    if (opciones && opciones.asentar) despues = asentarConjunto(datos, [despues])[0];
    return guardarObjetos(datos, [despues], opciones, 'edicion', [], { objeto: despues });
  }

  // Mover / girar / escalar varios a la vez (lo que hace el manipulador 3D).
  // lista: [{ id, pos?, rot?, medidas? }]. opciones.asentar: el conjunto baja hasta apoyarse.
  function transformarObjetos(datos, lista, opciones) {
    const propuestos = [];
    for (const cambio of lista) {
      const antes = buscarPorId(datos.objetos || [], cambio.id);
      if (!antes) return fallo('Ese objeto ya no existe.');
      const geometria = geometriaDe({ pos: cambio.pos, rot: cambio.rot, medidas: cambio.medidas }, antes);
      if (!geometria.ok) return geometria;
      propuestos.push(Object.assign({}, antes, geometria.valor));
    }
    const finales = opciones && opciones.asentar ? asentarConjunto(datos, propuestos) : propuestos;
    return guardarObjetos(datos, finales, opciones, 'mover', []);
  }

  function asentarObjetos(datos, ids, opciones) {
    const objetos = ids.map((id) => buscarPorId(datos.objetos || [], id)).filter(Boolean);
    if (!objetos.length) return fallo('Ese objeto ya no existe.');
    return guardarObjetos(datos, asentarConjunto(datos, objetos), opciones, 'mover', []);
  }

  // Todos en el mismo contenedor (o el mensaje de por qué no)
  function delMismoContenedor(datos, ids) {
    const objetos = ids.map((id) => buscarPorId(datos.objetos || [], id));
    if (!objetos.length || objetos.some((o) => !o)) return fallo('Ese objeto ya no existe.');
    if (objetos.some((o) => !mismoContenedor(o, objetos[0]))) return fallo('Elige objetos que estén en el mismo sitio (el piso o un mismo mueble).');
    return { ok: true, objetos: objetos };
  }

  // modo 'encima': la copia queda sobre el original (apilar) · 'lado': junto al original
  function duplicarObjetos(datos, ids, modo, opciones) {
    const revision = delMismoContenedor(datos, ids);
    if (!revision.ok) return revision;
    const originales = revision.objetos;
    if ((datos.objetos || []).length + originales.length > LIMITES.objetos) return fallo('Llegaste al máximo de ' + LIMITES.objetos + ' objetos 3D.');
    const lim = limitesDeConjunto(originales);
    const grupos = new Map();
    const capacidad = new Map();
    const copias = originales.map((o) => {
      let articuloId = null;
      if (o.articuloId) {
        const articulo = buscarPorId(datos.articulos, o.articuloId);
        if (!capacidad.has(o.articuloId)) capacidad.set(o.articuloId, articulo ? totalDe(articulo) - unidadesRepresentadas(datos, o.articuloId) : 0);
        if (capacidad.get(o.articuloId) >= (o.unidades || 1)) {
          articuloId = o.articuloId;
          capacidad.set(o.articuloId, capacidad.get(o.articuloId) - (o.unidades || 1));
        }
      }
      let grupoId = null;
      if (o.grupoId) {
        if (!grupos.has(o.grupoId)) grupos.set(o.grupoId, nuevoId('grp'));
        grupoId = grupos.get(o.grupoId);
      }
      return Object.assign({}, o, { id: nuevoId('obj'), articuloId: articuloId, grupoId: grupoId, pos: Object.assign({}, o.pos) });
    });
    const sinEnlace = copias.filter((c, i) => originales[i].articuloId && !c.articuloId).length;
    const desplazar = (dx, dy, dz) => copias.map((c) => Object.assign({}, c, {
      pos: { x: Espacio.redondear(c.pos.x + dx, 4), y: Espacio.redondear(c.pos.y + dy, 4), z: Espacio.redondear(c.pos.z + dz, 4) }
    }));
    const ancho = lim.max[0] - lim.min[0] + 0.05;
    const fondo = lim.max[1] - lim.min[1] + 0.05;
    const intentos = modo === 'encima'
      ? [desplazar(0, 0, lim.max[2] - lim.min[2])]
      : [desplazar(ancho, 0, 0), desplazar(-ancho, 0, 0), desplazar(0, fondo, 0), desplazar(0, -fondo, 0)];
    let elegido = null;
    for (const intento of intentos) {
      if (revisarObjetos(datos, intento, espacioDe(opciones)).nivel !== 'error') {
        elegido = intento;
        break;
      }
    }
    if (!elegido && modo !== 'encima') {
      elegido = acomodarConjunto(datos, copias, { x: (lim.min[0] + lim.max[0]) / 2, y: (lim.min[1] + lim.max[1]) / 2 }, conPropuestos(datos.objetos, []));
    }
    if (!elegido) {
      return fallo(modo === 'encima' ? 'No cabe otro encima: choca o pasa del techo.' : 'No hay espacio libre para la copia.');
    }
    return guardarObjetos(datos, elegido, opciones, 'alta', [], { copias: elegido, sinEnlace: sinEnlace });
  }

  function borrarObjetos(datos, ids) {
    const existentes = ids.filter((id) => buscarPorId(datos.objetos || [], id));
    if (!existentes.length) return fallo('Ese objeto ya no existe.');
    return exito('borrado', existentes.map((id) => ({ tabla: 'objetos', borrar: id })), { borrados: existentes.length });
  }

  function agruparObjetos(datos, ids) {
    const revision = delMismoContenedor(datos, ids);
    if (!revision.ok) return revision;
    if (revision.objetos.length < 2) return fallo('Elige al menos dos objetos para agrupar.');
    const grupoId = nuevoId('grp');
    return exito('edicion', revision.objetos.map((o) => ({ tabla: 'objetos', poner: Object.assign({}, o, { grupoId: grupoId }) })), { grupoId: grupoId });
  }

  function desagruparObjetos(datos, ids) {
    const objetos = ids.map((id) => buscarPorId(datos.objetos || [], id)).filter((o) => o && o.grupoId);
    if (!objetos.length) return fallo('Esos objetos no están agrupados.');
    return exito('edicion', objetos.map((o) => ({ tabla: 'objetos', poner: Object.assign({}, o, { grupoId: null }) })));
  }

  // ---------- Objetos e inventario ----------
  // Enlaza objetos con un artículo. Si el artículo está en otro sitio y no tiene otras piezas
  // dibujadas allá, se trae al sitio de los objetos (así nunca quedan incoherentes).
  // opciones.unidades: cuántas piezas representa CADA objeto (si no, conserva las suyas).
  function vincularObjetos(datos, ids, articuloId, opciones) {
    const revision = delMismoContenedor(datos, ids);
    if (!revision.ok) return revision;
    const objetos = revision.objetos;
    let articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    let unidades = null;
    if (opciones && opciones.unidades != null) {
      const u = validarEntero(opciones.unidades, { campo: 'Unidades', minimo: 1, maximo: LIMITES.cantidad });
      if (!u.ok) return u;
      unidades = u.valor;
    }
    const enlazados = objetos.map((o) => Object.assign({}, o, { articuloId: articulo.id, unidades: unidades || o.unidades || 1 }));
    const ids2 = new Set(ids);
    const suma = enlazados.reduce((s, o) => s + o.unidades, 0);
    const otras = unidadesRepresentadas(datos, articulo.id, ids2);
    if (otras + suma > totalDe(articulo)) {
      const quedan = Math.max(0, totalDe(articulo) - otras);
      return fallo('«' + articulo.nombre + '» tiene ' + plural(totalDe(articulo), 'pieza') + (otras ? ' y ya hay ' + otras + ' dibujadas' : '') +
        ': ' + (quedan ? 'puedes representar ' + quedan + ' más' : 'no puedes representar más') + '. Súbele la cantidad con «Entrada» o usa menos objetos.');
    }
    const cambios = [];
    const contenedor = { lugarId: objetos[0].lugarId, muebleId: objetos[0].muebleId || null };
    if (!mismoContenedor(contenedorDeArticulo(datos, articulo), contenedor)) {
      const lejanos = objetosDeArticulo(datos, articulo.id).filter((o) => !ids2.has(o.id) && !mismoContenedor(o, contenedor));
      if (lejanos.length) return fallo('«' + articulo.nombre + '» ya tiene piezas dibujadas en otro sitio. Muévelas aquí primero o desenlázalas.');
      const movido = moverArticuloSolo(datos, articulo.id, destinoDe(contenedor));
      if (!movido.ok) return movido;
      movido.cambios.forEach((c) => cambios.push(c));
      if (movido.articulo.id !== articulo.id) {
        // Se juntó con otro igual que ya estaba aquí: los objetos quedan enlazados a ese
        const juntado = movido.articulo;
        const total = totalDe(juntado) - unidadesRepresentadas(datos, juntado.id);
        if (suma > total) return fallo('No alcanzan las piezas de «' + juntado.nombre + '».');
        enlazados.forEach((o) => { o.articuloId = juntado.id; });
        objetosDeArticulo(datos, articulo.id).filter((o) => !ids2.has(o.id)).forEach((o) => cambios.push({ tabla: 'objetos', poner: Object.assign({}, o, { articuloId: juntado.id }) }));
      }
      articulo = movido.articulo;
    }
    return exito('cambio-ubicacion', enlazados.map((o) => ({ tabla: 'objetos', poner: o })).concat(cambios), {
      articulo: articulo, objetos: enlazados
    });
  }

  function desvincularObjetos(datos, ids) {
    const objetos = ids.map((id) => buscarPorId(datos.objetos || [], id)).filter((o) => o && o.articuloId);
    if (!objetos.length) return fallo('Esos objetos no están enlazados a ningún artículo.');
    return exito('edicion', objetos.map((o) => ({ tabla: 'objetos', poner: Object.assign({}, o, { articuloId: null }) })));
  }

  // Crea un artículo nuevo a partir de objetos dibujados: tantas piezas como representan
  function registrarArticuloDesdeObjetos(datos, ids, entrada) {
    const revision = delMismoContenedor(datos, ids);
    if (!revision.ok) return revision;
    if (revision.objetos.some((o) => o.articuloId)) return fallo('Alguno ya está enlazado a un artículo. Desenlázalo primero.');
    const cantidad = revision.objetos.reduce((s, o) => s + (o.unidades || 1), 0);
    const contenedor = { lugarId: revision.objetos[0].lugarId, muebleId: revision.objetos[0].muebleId || null };
    const alta = crearArticulo(datos, Object.assign({}, entrada, { cantidad: cantidad, ubicacion: destinoDe(contenedor) }));
    if (!alta.ok) return alta;
    const articulo = alta.articulo || alta.cambios.find((c) => c.tabla === 'articulos').poner;
    const objetos = revision.objetos.map((o) => Object.assign({}, o, { articuloId: articulo.id, unidades: o.unidades || 1 }));
    return exito('alta', alta.cambios.concat(objetos.map((o) => ({ tabla: 'objetos', poner: o }))), { articulo: articulo, objetos: objetos, sumado: Boolean(alta.sumado) });
  }

  // Separa "cantidad" piezas de un artículo y las lleva a otro sitio (con las de buen estado
  // primero; las prestadas no se pueden separar). Si allá hay uno igual, se suman a ese.
  function separarArticulo(datos, articuloId, cantidad, destino) {
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo) return fallo('Ese artículo ya no existe.');
    if (cantidad >= totalDe(articulo)) return moverArticuloSolo(datos, articuloId, destino);
    const sitio = revisarUbicacion(datos, destino);
    if (!sitio.ok) return sitio;
    const toma = { bueno: 0, reparacion: 0, danado: 0 };
    let falta = cantidad;
    toma.bueno = Math.min(falta, Math.max(0, articulo.estados.bueno - prestadas(datos, articuloId)));
    falta -= toma.bueno;
    toma.reparacion = Math.min(falta, articulo.estados.reparacion);
    falta -= toma.reparacion;
    toma.danado = Math.min(falta, articulo.estados.danado);
    falta -= toma.danado;
    if (falta > 0) return fallo('No se pueden separar ' + cantidad + ' piezas de «' + articulo.nombre + '»: algunas están prestadas.');
    const restante = conEstados(articulo, {
      bueno: articulo.estados.bueno - toma.bueno, reparacion: articulo.estados.reparacion - toma.reparacion, danado: articulo.estados.danado - toma.danado
    });
    const igual = vecinosDe(datos, sitio.valor).find((otro) => normalizar(otro.nombre) === normalizar(articulo.nombre));
    let destinoArticulo;
    if (igual) {
      destinoArticulo = conEstados(igual, {
        bueno: igual.estados.bueno + toma.bueno, reparacion: igual.estados.reparacion + toma.reparacion, danado: igual.estados.danado + toma.danado
      });
    } else {
      destinoArticulo = Object.assign({}, clonar(articulo), sitio.valor, { id: nuevoId('art'), estados: toma });
      delete destinoArticulo.series;
    }
    return exito('cambio-ubicacion', [{ tabla: 'articulos', poner: restante }, { tabla: 'articulos', poner: destinoArticulo }], {
      articulo: destinoArticulo, restante: restante, separado: true, detalle: { cantidad: cantidad }
    });
  }

  // Saca objetos de un mueble al piso, los mete en un mueble o los pasa de un mueble a otro.
  // destino: { muebleId } o { lugarId } (piso). El conjunto conserva su forma; busca el hueco
  // libre más cercano. Sus artículos se mueven con ellos (o se separan las piezas que van).
  function moverObjetosA(datos, ids, destino, opciones) {
    const revision = delMismoContenedor(datos, ids);
    if (!revision.ok) return revision;
    const origen = revision.objetos[0];
    const lugarId = origen.lugarId;
    const muebleDestino = destino.muebleId ? buscarPorId(datos.muebles, destino.muebleId) : null;
    if (destino.muebleId && (!muebleDestino || muebleDestino.lugarId !== lugarId)) return fallo('Elige un mueble de este mismo lugar.');
    const contenedorDestino = { lugarId: lugarId, muebleId: muebleDestino ? muebleDestino.id : null };
    if (mismoContenedor(origen, contenedorDestino)) return fallo('Ya están ahí.');
    const revisado = revisarContenedor(datos, lugarId, contenedorDestino.muebleId);
    if (!revisado.ok) return revisado;
    // 1) Al marco del lugar (si venían de un mueble) y luego al del destino
    const muebleOrigen = origen.muebleId ? buscarPorId(datos.muebles, origen.muebleId) : null;
    if (muebleOrigen && !estaColocado(muebleOrigen)) return fallo('Coloca primero «' + muebleOrigen.nombre + '» en el plano.');
    if (muebleDestino && !estaColocado(muebleDestino)) return fallo('Coloca primero «' + muebleDestino.nombre + '» en el plano.');
    let enMundo = revision.objetos.map((o) => (muebleOrigen ? Espacio.objetoAMundo(Espacio.poseDeMueble(muebleOrigen), o) : o));
    const centro = limitesDeConjunto(enMundo);
    let preferido = { x: (centro.min[0] + centro.max[0]) / 2, y: (centro.min[1] + centro.max[1]) / 2 };
    let enDestino = enMundo;
    if (muebleDestino) {
      const pose = Espacio.poseDeMueble(muebleDestino);
      enDestino = enMundo.map((o) => Espacio.objetoALocal(pose, o));
      preferido = { x: 0, y: 0, nivel: opciones && opciones.nivel != null ? opciones.nivel : undefined };
    } else if (muebleOrigen) {
      // Al sacarlos de un mueble, quedan frente a él
      const pose = Espacio.poseDeMueble(muebleOrigen);
      const frente = medidasSinGiro(muebleOrigen).fondo / 2 + 0.45;
      preferido = Espacio.aMundo(pose, { x: 0, y: frente, z: 0 });
    }
    enDestino = enDestino.map((o) => Object.assign({}, o, { muebleId: contenedorDestino.muebleId }));
    const acomodados = acomodarConjunto(datos, enDestino, preferido, conPropuestos(datos.objetos, enDestino));
    if (!acomodados) return fallo(muebleDestino ? 'No caben en «' + muebleDestino.nombre + '».' : 'No hay espacio libre en el piso para sacarlos.');
    // 2) Los artículos acompañan a sus objetos
    const trabajo = Object.assign({}, datos, { articulos: datos.articulos.slice(), objetos: conPropuestos(datos.objetos, acomodados) });
    const cambios = [];
    const finales = new Map(acomodados.map((o) => [o.id, o]));
    const porArticulo = new Map();
    acomodados.filter((o) => o.articuloId).forEach((o) => {
      if (!porArticulo.has(o.articuloId)) porArticulo.set(o.articuloId, []);
      porArticulo.get(o.articuloId).push(o);
    });
    for (const [articuloId, movidos] of porArticulo) {
      const articulo = buscarPorId(trabajo.articulos, articuloId);
      if (!articulo || mismoContenedor(contenedorDeArticulo(trabajo, articulo), contenedorDestino)) continue;
      const quedan = objetosDeArticulo(datos, articuloId).filter((o) => !finales.has(o.id));
      const unidades = movidos.reduce((s, o) => s + (o.unidades || 1), 0);
      const paso = !quedan.length && unidades >= totalDe(articulo)
        ? moverArticuloSolo(trabajo, articuloId, destinoDe(contenedorDestino))
        : separarArticulo(trabajo, articuloId, unidades, destinoDe(contenedorDestino));
      if (!paso.ok) return paso;
      aplicarCambios(trabajo, paso.cambios);
      paso.cambios.forEach((c) => cambios.push(c));
      if (paso.articulo.id !== articuloId) {
        movidos.forEach((o) => finales.set(o.id, Object.assign({}, finales.get(o.id), { articuloId: paso.articulo.id })));
        // Si el artículo entero se juntó con otro, sus demás objetos también pasan a ese
        if (!buscarPorId(trabajo.articulos, articuloId)) {
          objetosDeArticulo(datos, articuloId).filter((o) => !finales.has(o.id))
            .forEach((o) => cambios.push({ tabla: 'objetos', poner: Object.assign({}, o, { articuloId: paso.articulo.id }) }));
        }
      }
    }
    const resultado = guardarObjetos(datos, Array.from(finales.values()), opciones, 'cambio-ubicacion', cambios);
    if (!resultado.ok) return resultado;
    resultado.destino = muebleDestino ? muebleDestino.nombre : 'el piso';
    return resultado;
  }

  // Un artículo de un mueble que se dibujaba solo (acomodo automático) pasa a ser un objeto
  // propio, en el mismo sitio, para poder moverlo, girarlo o cambiarle las medidas.
  function fijarAutomatico(datos, muebleId, articuloId, opciones) {
    const mueble = buscarPorId(datos.muebles, muebleId);
    if (!mueble) return fallo('Ese mueble ya no existe.');
    const articulo = buscarPorId(datos.articulos, articuloId);
    if (!articulo || articulo.muebleId !== muebleId) return fallo('Ese artículo ya no está en este mueble.');
    const auto = acomodoInterior(datos, mueble).objetos.find((o) => o.articuloId === articuloId);
    if (!auto) return fallo('Ese artículo no se está dibujando en el mueble.');
    const lado = Espacio.redondear(auto.lado, 3);
    const objeto = {
      id: nuevoId('obj'), lugarId: mueble.lugarId, muebleId: mueble.id, nombre: '', figura: auto.figura,
      medidas: { ancho: lado, fondo: lado, alto: lado },
      pos: { x: Espacio.redondear(auto.x, 4), y: Espacio.redondear(auto.y, 4), z: Espacio.redondear(auto.z * MPP + lado / 2, 4) },
      rot: { x: 0, y: 0, z: 0 }, color: colorDeObjeto(auto.color) || COLOR_OBJETO, articuloId: articulo.id,
      unidades: Math.max(1, totalDe(articulo) - unidadesRepresentadas(datos, articulo.id)), grupoId: null
    };
    return guardarObjetos(datos, [objeto], Object.assign({}, opciones, { sinRevisar: true }), 'alta', [], { objeto: objeto });
  }

  // ---------- Modelos (formas compuestas reutilizables) ----------
  function todosLosModelos(datos) {
    return MODELOS_BASE.map((m) => Object.assign({ base: true }, m)).concat((datos.modelos || []).map((m) => Object.assign({ base: false }, m)));
  }

  function guardarModelo(datos, ids, nombre, id) {
    const revision = delMismoContenedor(datos, ids);
    if (!revision.ok) return revision;
    if ((datos.modelos || []).length >= LIMITES.modelos) return fallo('Llegaste al máximo de ' + LIMITES.modelos + ' modelos.');
    if (revision.objetos.length > LIMITES.piezasModelo) return fallo('Un modelo puede tener hasta ' + LIMITES.piezasModelo + ' piezas.');
    const texto = validarTexto(nombre, { campo: 'el nombre del modelo', maximo: LIMITES.nombre });
    if (!texto.ok) return texto;
    if (nombreRepetido(todosLosModelos(datos), texto.valor)) return fallo('Ya hay un modelo con ese nombre.');
    const lim = limitesDeConjunto(revision.objetos);
    const cx = (lim.min[0] + lim.max[0]) / 2;
    const cy = (lim.min[1] + lim.max[1]) / 2;
    const modelo = {
      id: id || nuevoId('mod'), nombre: texto.valor,
      piezas: revision.objetos.map((o) => ({
        figura: o.figura, medidas: clonar(o.medidas), rot: clonar(o.rot), color: o.color,
        pos: { x: Espacio.redondear(o.pos.x - cx, 4), y: Espacio.redondear(o.pos.y - cy, 4), z: Espacio.redondear(o.pos.z - lim.min[2], 4) }
      }))
    };
    return exito('alta', [{ tabla: 'modelos', poner: modelo }], { modelo: modelo });
  }

  function borrarModelo(datos, modeloId) {
    if (!buscarPorId(datos.modelos || [], modeloId)) return fallo('Ese modelo ya no existe (los de la app no se borran).');
    return exito('borrado', [{ tabla: 'modelos', borrar: modeloId }]);
  }

  // Pone un modelo en el piso de un lugar o dentro de un mueble, en el hueco libre más cercano
  // a "cerca". Si tiene varias piezas, quedan agrupadas.
  function insertarModelo(datos, modeloId, contenedor, cerca, opciones) {
    const modelo = todosLosModelos(datos).find((m) => m.id === modeloId);
    if (!modelo) return fallo('Ese modelo ya no existe.');
    const revisado = revisarContenedor(datos, contenedor.lugarId, contenedor.muebleId || null);
    if (!revisado.ok) return revisado;
    if ((datos.objetos || []).length + modelo.piezas.length > LIMITES.objetos) return fallo('Llegaste al máximo de ' + LIMITES.objetos + ' objetos 3D.');
    const grupoId = modelo.piezas.length > 1 ? nuevoId('grp') : null;
    const objetos = modelo.piezas.map((p) => ({
      id: nuevoId('obj'), lugarId: contenedor.lugarId, muebleId: contenedor.muebleId || null, nombre: modelo.nombre,
      figura: p.figura, medidas: clonar(p.medidas), rot: clonar(p.rot), color: p.color, pos: clonar(p.pos),
      articuloId: null, unidades: 1, grupoId: grupoId
    }));
    const acomodados = acomodarConjunto(datos, objetos, cerca || null, conPropuestos(datos.objetos, objetos));
    if (!acomodados) return fallo('No hay un espacio libre para «' + modelo.nombre + '»' + (contenedor.muebleId ? ' en este mueble.' : '.'));
    return guardarObjetos(datos, acomodados, opciones, 'alta', [], { objetos: acomodados, modelo: modelo });
  }

  // ---------- Coherencia cuando cambia el inventario o los muebles ----------
  // Huellas de los objetos del piso: los muebles no se pueden poner encima de ellas
  function obstaculosDePiso(datos, lugarId) {
    return objetosEnPiso(datos, lugarId).map((o) => {
      const lim = Espacio.limites(Espacio.formaDeChoque(o));
      return { x0: lim.min[0], y0: lim.min[1], x1: lim.max[0], y1: lim.max[1], nombre: nombreDeObjeto(datos, o) };
    });
  }

  function obstaculoEn(rect, obstaculos) {
    const h = Espacio.HOLGURA;
    return (obstaculos || []).find((o) => rect.x < o.x1 - h && o.x0 < rect.x + rect.ancho - h && rect.y < o.y1 - h && o.y0 < rect.y + rect.fondo - h) || null;
  }

  // Si un artículo ya no tiene tantas piezas como objetos dibujados, se desenlazan los últimos
  function ajustarRepresentacion(datos, articulo, total) {
    let sobran = unidadesRepresentadas(datos, articulo.id) - total;
    const cambios = [];
    objetosDeArticulo(datos, articulo.id).slice().reverse().forEach((o) => {
      if (sobran <= 0) return;
      cambios.push({ tabla: 'objetos', poner: Object.assign({}, o, { articuloId: null }) });
      sobran -= o.unidades || 1;
    });
    return cambios;
  }

  // Cuando un artículo cambia de sitio desde la lista, sus objetos lo siguen si caben allá;
  // si no, se quedan donde estaban como figuras sin enlazar.
  function seguirAlArticulo(datos, articuloAntes, articuloDespues) {
    const objetos = objetosDeArticulo(datos, articuloAntes.id);
    if (!objetos.length) return { cambios: [], siguieron: 0, sueltos: 0 };
    const destino = contenedorDeArticulo(datos, articuloDespues);
    const soltar = () => ({ cambios: objetos.map((o) => ({ tabla: 'objetos', poner: Object.assign({}, o, { articuloId: null }) })), siguieron: 0, sueltos: objetos.length });
    if (!destino || destino.lugarId !== objetos[0].lugarId) return soltar();
    const enlazar = (lista) => lista.map((o) => Object.assign({}, o, { articuloId: articuloDespues.id }));
    if (objetos.every((o) => mismoContenedor(o, destino))) {
      return { cambios: enlazar(objetos).map((o) => ({ tabla: 'objetos', poner: o })), siguieron: objetos.length, sueltos: 0 };
    }
    const movido = moverObjetosA(datos, objetos.map((o) => o.id), destinoDe(destino), { permitirEncimar: false });
    if (!movido.ok) return soltar();
    const enObjetos = movido.cambios.filter((c) => c.tabla === 'objetos').map((c) => Object.assign({}, c.poner, { articuloId: articuloDespues.id }));
    return { cambios: enObjetos.map((o) => ({ tabla: 'objetos', poner: o })), siguieron: enObjetos.length, sueltos: 0 };
  }

  // =====================================================================
  // 8. HISTORIAL (movimientos)
  // =====================================================================
  // Cada operación trae su "tipo". Esta función agrega, por cada registro que cambia, un
  // movimiento con sus datos ANTES y DESPUÉS. La app guarda todo en la misma transacción:
  // no puede existir un cambio sin su historial. "autor" queda listo para cuando haya usuarios.
  const ENTIDADES = { lugares: 'lugar', muebles: 'mueble', articulos: 'articulo', prestamos: 'prestamo', categorias: 'categoria' };

  function conMovimientos(datos, resultado, momentoISO, operacionId) {
    const base = resultado.cambios.filter((cambio) => cambio.tabla !== 'movimientos');
    // Los objetos 3D y los modelos son representación: no se anotan uno por uno en el historial
    const conHistorial = base.filter((cambio) => cambio.tabla !== 'objetos' && cambio.tabla !== 'modelos');
    const movimientos = conHistorial.map((cambio, posicion) => {
      const id = cambio.poner ? cambio.poner.id : cambio.borrar;
      const antes = buscarPorId(datos[cambio.tabla], id);
      const despues = cambio.poner || null;
      const registro = despues || antes || {};
      return {
        tabla: 'movimientos',
        poner: {
          id: operacionId + '-' + posicion,
          momento: momentoISO,
          operacionId: operacionId,
          tipo: resultado.tipo || 'edicion',
          entidad: ENTIDADES[cambio.tabla] || cambio.tabla,
          entidadId: id,
          nombre: limpiarTexto(registro.nombre || registro.articuloNombre || ''),
          antes: clonar(antes),
          despues: clonar(despues),
          detalle: clonar(resultado.detalle) || null,
          autor: null
        }
      };
    });
    return base.concat(movimientos);
  }

  // Movimiento suelto (migración, restauración, reparación de datos)
  function movimientoGeneral(tipo, momentoISO, detalle) {
    return {
      id: 'mov-' + tipo + '-' + momentoISO, momento: momentoISO, operacionId: 'mov-' + tipo + '-' + momentoISO, tipo: tipo,
      entidad: 'inventario', entidadId: 'inventario', nombre: TIPOS_MOVIMIENTO[tipo] || tipo,
      antes: null, despues: null, detalle: clonar(detalle) || null, autor: null
    };
  }

  // Texto corto de un movimiento para el historial de la ficha
  function textoMovimiento(movimiento) {
    const tipo = TIPOS_MOVIMIENTO[movimiento.tipo] || movimiento.tipo;
    const d = movimiento.detalle || {};
    if (movimiento.tipo === 'entrada') return tipo + ': +' + d.cantidad;
    if (movimiento.tipo === 'cambio-estado') return d.cantidad + ' de «' + nombreEstado(d.de) + '» a «' + nombreEstado(d.a) + '»';
    if (movimiento.tipo === 'baja') return 'Baja de ' + d.cantidad + ' (' + d.motivo + ')';
    if (movimiento.tipo === 'devolucion' && d.danadas) return tipo + ' (' + plural(d.danadas, 'dañada') + ')';
    if (movimiento.tipo === 'cambio-ubicacion' && movimiento.despues) {
      const despues = movimiento.despues;
      return tipo + (despues.muebleId || despues.lugarId ? '' : ': a «Sin ubicación»');
    }
    return tipo;
  }

  // =====================================================================
  // 9. RESPALDO
  // =====================================================================
  // Formato 1 (hasta la Etapa 0): espacios, muebles, equipo y prestamos.
  // Formato 2 (Etapa 1A): las 6 tablas actuales. Los respaldos de formato 1 se convierten al abrirlos.
  const FORMATO_RESPALDO = 2;

  function crearRespaldo(datos, momento) {
    const respaldo = { app: 'ubica', formato: FORMATO_RESPALDO, exportado: momento || new Date().toISOString() };
    TABLAS.forEach((tabla) => {
      respaldo[tabla] = clonar(datos[tabla] || []);
    });
    return respaldo;
  }

  const esObjeto = (valor) => Boolean(valor) && typeof valor === 'object' && !Array.isArray(valor);

  // giro de un mueble antiguo: 0 si tiene las medidas de su tipo, 1 si estaba girado
  function inferirGiro(mueble) {
    const tipo = TIPOS_MUEBLE[mueble.tipo];
    if (!tipo || tipo.ancho === tipo.fondo) return 0;
    return mueble.ancho === tipo.fondo && mueble.fondo === tipo.ancho ? 1 : 0;
  }

  // Convierte un respaldo de formato 1 al 2. Solo cambia la FORMA de los datos: no valida,
  // no corrige y no borra nada (de eso se encarga prepararDatos, que avisa lo que hace).
  function convertirFormato1(objeto) {
    const lista = (tabla) => (Array.isArray(objeto[tabla]) ? objeto[tabla] : []);
    const convertir = (registro, funcion) => (esObjeto(registro) ? funcion(registro) : registro);
    return {
      app: 'ubica',
      formato: 2,
      exportado: objeto.exportado,
      lugares: lista('espacios').map((r) => convertir(r, (e) => ({
        id: e.id, nombre: e.nombre, tipo: e.tipo, plano: { ancho: e.ancho, fondo: e.fondo }
      }))),
      muebles: lista('muebles').map((r) => convertir(r, (m) => ({
        id: m.id, lugarId: m.espacioId, tipo: m.tipo, nombre: m.nombre,
        x: m.x, y: m.y, ancho: m.ancho, fondo: m.fondo, giro: inferirGiro(m)
      }))),
      articulos: lista('equipo').map((r) => convertir(r, (q) => ({
        id: q.id, nombre: q.nombre, categoriaId: ID_OTROS, codigo: q.codigo == null ? '' : q.codigo,
        notas: q.notas == null ? '' : q.notas, muebleId: q.muebleId == null ? null : q.muebleId, lugarId: null,
        estados: { bueno: q.cantidad, reparacion: 0, danado: 0 }, seguimiento: 'cantidad'
      }))),
      prestamos: lista('prestamos').map((r) => convertir(r, (p) => ({
        id: p.id, articuloId: p.equipoId, articuloNombre: p.equipoNombre, origen: p.origen, persona: p.persona,
        grupo: p.grupo, cantidad: p.cantidad, fechaSalida: p.fechaSalida, fechaLimite: p.fechaLimite,
        devuelto: p.devuelto == null ? null : p.devuelto, devueltasDanadas: 0, nota: p.nota
      }))),
      categorias: categoriasIniciales(),
      movimientos: []
    };
  }

  // ---------- Revisión y reparación segura ----------
  // prepararDatos revisa un respaldo (de archivo, de una copia, de la base vieja o de los datos
  // actuales) contra TODAS las reglas del modelo. Lo que no cumple se resuelve de la forma más
  // segura posible y QUEDA ANOTADO en "hallazgos" para mostrárselo a la persona:
  //   - Nunca se borra un lugar, mueble, artículo o préstamo para que las reglas "pasen".
  //     Un mueble encimado se mueve a una casilla libre (o queda «sin colocar»); un artículo cuyo
  //     mueble no existe pasa a «Sin ubicación»; un préstamo activo de un artículo inexistente
  //     recrea ese artículo; si lo prestado supera lo que hay en buen estado, se aumenta
  //     «buen estado» (se avisa, porque cambia una cantidad).
  //   - Solo se descarta lo que no es un registro (texto suelto, sin datos) o un registro
  //     repetido idéntico (mismo id y mismo contenido): eso también se anota.
  // Es determinista: con los mismos datos siempre da el mismo resultado (importante para la migración).
  function prepararDatos(objeto, opciones) {
    if (!esObjeto(objeto) || objeto.app !== 'ubica') return fallo('El archivo no es un respaldo de Ubica.');
    if (typeof objeto.formato !== 'number' || objeto.formato > FORMATO_RESPALDO) {
      return fallo('El respaldo es de una versión más nueva de Ubica. Actualiza la app.');
    }
    const hoyISO = (opciones && opciones.hoy) || fechaISO(new Date());
    const fuente = objeto.formato < 2 ? convertirFormato1(objeto) : objeto;
    const hallazgos = [];
    const anotar = (texto, extra) => hallazgos.push(Object.assign({ texto: texto, quita: false }, extra || {}));
    const ajustes = { piezasAgregadas: 0 };

    // Registros: solo objetos con id; repetidos idénticos se quitan, repetidos distintos reciben id nuevo
    function registros(tabla, etiqueta) {
      const vistos = new Map();
      const salida = [];
      (Array.isArray(fuente[tabla]) ? fuente[tabla] : []).forEach((registro, posicion) => {
        if (!esObjeto(registro)) {
          anotar('Se quitará un dato de «' + etiqueta + '» que no es un registro.', { quita: true });
          return;
        }
        const copia = clonar(registro);
        const valido = typeof copia.id === 'string' && copia.id.length > 0 && copia.id.length <= 80;
        if (valido && vistos.has(copia.id)) {
          if (JSON.stringify(vistos.get(copia.id)) === JSON.stringify(copia)) {
            anotar('Se quitará una copia repetida idéntica en «' + etiqueta + '» (' + copia.id + ').', { quita: true });
            return;
          }
        }
        if (!valido || vistos.has(copia.id)) {
          const anterior = copia.id;
          copia.id = 'rec-' + tabla + '-' + posicion;
          anotar('Un registro de «' + etiqueta + '» tenía un identificador ' + (valido ? 'repetido (' + anterior + ')' : 'inválido') +
            ': se le asigna uno nuevo.');
        }
        vistos.set(copia.id, registro);
        salida.push(copia);
      });
      return salida;
    }

    // Texto obligatorio: si falta se usa un nombre por defecto; si es muy largo se recorta
    function textoObligatorio(valor, maximo, porDefecto, que) {
      const texto = limpiarTexto(valor);
      if (!texto) {
        anotar(que + ' sin nombre: se llamará «' + porDefecto + '».');
        return porDefecto;
      }
      if (texto.length > maximo) {
        anotar(que + ' «' + texto.slice(0, 20) + '…»: el nombre se recorta a ' + maximo + ' caracteres.');
        return texto.slice(0, maximo).trim();
      }
      return texto;
    }

    function textoOpcional(valor, maximo, que) {
      const texto = limpiarTexto(valor);
      if (texto.length > maximo) {
        anotar(que + ': el texto se recorta a ' + maximo + ' caracteres.');
        return texto.slice(0, maximo).trim();
      }
      return texto;
    }

    // Nombre sin repetir dentro de un grupo: «Pipeta», «Pipeta (2)»…
    function sinRepetir(usados, nombre, que) {
      let final = nombre;
      let numero = 2;
      while (usados.has(normalizar(final))) {
        final = nombre.slice(0, LIMITES.nombre - 4) + ' (' + numero + ')';
        numero++;
      }
      if (final !== nombre) anotar(que + ' «' + nombre + '» estaba repetido: el segundo se llamará «' + final + '».');
      usados.add(normalizar(final));
      return final;
    }

    const limpio = datosVacios();

    // --- Categorías (primero: los artículos las necesitan) ---
    const nombresCategoria = new Set();
    registros('categorias', 'categorías').forEach((c) => {
      const nombre = sinRepetir(nombresCategoria, textoObligatorio(c.nombre, LIMITES.nombre, 'Categoría', 'Una categoría'), 'La categoría');
      limpio.categorias.push({
        id: c.id, nombre: nombre, color: colorValido(c.color) ? c.color.toLowerCase() : '#7b8794',
        orden: Number.isFinite(c.orden) ? c.orden : limpio.categorias.length, fija: c.id === ID_OTROS
      });
    });
    if (!buscarPorId(limpio.categorias, ID_OTROS)) {
      const otros = categoriasIniciales().find((c) => c.id === ID_OTROS);
      otros.nombre = sinRepetir(nombresCategoria, 'Otros', 'La categoría');
      limpio.categorias.push(otros);
      if ((fuente.categorias || []).length) anotar('Faltaba la categoría fija «Otros»: se agrega.');
    }
    const categoriaPorId = new Map(limpio.categorias.map((c) => [c.id, c]));

    // --- Lugares ---
    const nombresLugar = new Set();
    registros('lugares', 'lugares').forEach((l) => {
      const nombre = sinRepetir(nombresLugar, textoObligatorio(l.nombre, LIMITES.nombre, 'Lugar sin nombre', 'Un lugar'), 'El lugar');
      let tipo = l.tipo;
      if (!TIPOS_LUGAR[tipo]) {
        if (tipo != null && tipo !== '') anotar('El lugar «' + nombre + '» tenía un tipo desconocido: se marca como «Otro».');
        tipo = 'otro';
      }
      let plano = null;
      if (l.plano != null) {
        if (planoValido(l.plano)) plano = { ancho: l.plano.ancho, fondo: l.plano.fondo };
        else anotar('El lugar «' + nombre + '» tenía medidas no válidas: queda sin plano (sus muebles se conservan).');
      }
      const lugar = { id: l.id, nombre: nombre, tipo: tipo, plano: plano };
      if (VISTAS_LUGAR.includes(l.vista)) lugar.vista = l.vista;
      if (planoValido(l.planoAnterior) && !plano) lugar.planoAnterior = { ancho: l.planoAnterior.ancho, fondo: l.planoAnterior.fondo };
      limpio.lugares.push(lugar);
    });
    const lugarPorId = new Map(limpio.lugares.map((l) => [l.id, l]));
    let lugarRecuperado = null;
    function recuperarLugar() {
      if (!lugarRecuperado) {
        lugarRecuperado = { id: 'lugar-recuperado', nombre: sinRepetir(nombresLugar, 'Lugar recuperado', 'El lugar'), tipo: 'otro', plano: null };
        limpio.lugares.push(lugarRecuperado);
        lugarPorId.set(lugarRecuperado.id, lugarRecuperado);
      }
      return lugarRecuperado;
    }

    // --- Artículos en bruto (se necesitan para saber qué mueble tiene más cosas) ---
    const articulosCrudos = registros('articulos', 'artículos');
    const piezasCrudas = new Map();
    articulosCrudos.forEach((a) => {
      const estados = esObjeto(a.estados) ? a.estados : {};
      const total = ['bueno', 'reparacion', 'danado'].reduce((s, k) => s + (Number.isInteger(estados[k]) && estados[k] > 0 ? estados[k] : 0), 0);
      if (a.muebleId) piezasCrudas.set(a.muebleId, (piezasCrudas.get(a.muebleId) || 0) + total);
    });

    // --- Muebles ---
    const nombresMueblePorLugar = new Map();
    const crudosMuebles = registros('muebles', 'muebles');
    crudosMuebles.forEach((m, posicion) => {
      m.posicionOriginal = posicion;
    });
    const muebles = crudosMuebles.map((m) => {
      let lugar = lugarPorId.get(m.lugarId);
      const nombreBase = textoObligatorio(m.nombre, LIMITES.nombre, 'Mueble', 'Un mueble');
      if (!lugar) {
        lugar = recuperarLugar();
        anotar('El mueble «' + nombreBase + '» no tenía un lugar válido: pasa a «' + lugar.nombre + '» (sin colocar).');
        m.x = null;
        m.y = null;
      }
      if (!nombresMueblePorLugar.has(lugar.id)) nombresMueblePorLugar.set(lugar.id, new Set());
      const nombre = sinRepetir(nombresMueblePorLugar.get(lugar.id), nombreBase, 'El mueble');
      let tipo = m.tipo;
      if (!TIPOS_MUEBLE[tipo]) {
        anotar('El mueble «' + nombre + '» era de un tipo desconocido: se muestra como «Caja».');
        tipo = 'caja';
      }
      let ancho = m.ancho;
      let fondo = m.fondo;
      const medidaBien = (v) => Number.isInteger(v) && v >= 1 && v <= LIMITES.ladoMaximo;
      if (!medidaBien(ancho) || !medidaBien(fondo)) {
        anotar('El mueble «' + nombre + '» tenía medidas no válidas: toma las de su tipo.');
        ancho = TIPOS_MUEBLE[tipo].ancho;
        fondo = TIPOS_MUEBLE[tipo].fondo;
      }
      let x = m.x;
      let y = m.y;
      if (!(Number.isInteger(x) && Number.isInteger(y))) {
        if (x != null || y != null) anotar('El mueble «' + nombre + '» tenía una casilla no válida: queda sin colocar.');
        x = null;
        y = null;
      }
      const giro = [0, 1, 2, 3].includes(m.giro) ? m.giro : inferirGiro({ tipo: tipo, ancho: ancho, fondo: fondo });
      return { id: m.id, lugarId: lugar.id, tipo: tipo, nombre: nombre, x: x, y: y, ancho: ancho, fondo: fondo, giro: giro,
        orden: m.posicionOriginal };
    });
    // En cada lugar CON plano: los muebles colocados deben caber y no encimarse.
    // El que tiene más artículos conserva su casilla; los demás se mueven a una libre o quedan sin colocar.
    limpio.lugares.forEach((lugar) => {
      if (!lugar.plano) return;
      const colocados = [];
      muebles.filter((m) => m.lugarId === lugar.id && estaColocado(m))
        .sort((a, b) => ((piezasCrudas.get(b.id) || 0) - (piezasCrudas.get(a.id) || 0)) || (a.orden - b.orden))
        .forEach((m) => {
          if (cabe(m, lugar.plano, colocados)) {
            colocados.push(m);
            return;
          }
          const libre = primerLugarLibre(m, lugar.plano, colocados);
          if (libre) {
            anotar('«' + m.nombre + '» estaba encimado o fuera del plano de «' + lugar.nombre + '»: se mueve a una casilla libre.');
            m.x = libre.x;
            m.y = libre.y;
            colocados.push(m);
          } else {
            anotar('«' + m.nombre + '» estaba encimado o fuera del plano de «' + lugar.nombre + '» y no hay casilla libre: queda sin colocar.');
            m.x = null;
            m.y = null;
          }
        });
    });
    muebles.forEach((m) => {
      delete m.orden;
      limpio.muebles.push(m);
    });
    const mueblePorId = new Map(limpio.muebles.map((m) => [m.id, m]));

    // --- Artículos ---
    const nombresPorSitio = new Map();
    const articuloPorId = new Map();
    articulosCrudos.forEach((a) => {
      const nombreBase = textoObligatorio(a.nombre, LIMITES.nombre, '(sin nombre)', 'Un artículo');
      // Ubicación única
      let muebleId = a.muebleId || null;
      let lugarId = a.lugarId || null;
      if (muebleId && !mueblePorId.has(muebleId)) {
        muebleId = null;
        if (lugarId && lugarPorId.has(lugarId)) anotar('«' + nombreBase + '»: su mueble no existe; queda directo en su lugar.');
        else {
          lugarId = null;
          anotar('«' + nombreBase + '»: su mueble no existe; pasa a «Sin ubicación».');
        }
      }
      if (muebleId && lugarId) {
        anotar('«' + nombreBase + '» tenía dos ubicaciones: se conserva la del mueble.');
        lugarId = null;
      }
      if (lugarId && !lugarPorId.has(lugarId)) {
        anotar('«' + nombreBase + '»: su lugar no existe; pasa a «Sin ubicación».');
        lugarId = null;
      }
      // Categoría
      let categoriaId = a.categoriaId;
      if (!categoriaPorId.has(categoriaId)) {
        if (categoriaId) anotar('«' + nombreBase + '»: su categoría no existe; pasa a «Otros».');
        categoriaId = ID_OTROS;
      }
      // Existencias por estado
      const estadosCrudos = esObjeto(a.estados) ? a.estados : {};
      const estados = {};
      CLAVES_ESTADO.forEach((clave) => {
        const valor = estadosCrudos[clave];
        if (Number.isInteger(valor) && valor >= 0 && valor <= LIMITES.cantidad) estados[clave] = valor;
        else {
          estados[clave] = valor == null ? 0 : Math.max(0, Math.min(LIMITES.cantidad, Math.floor(Number(valor)) || 0));
          if (valor != null) anotar('«' + nombreBase + '»: la cantidad en «' + nombreEstado(clave) + '» no era válida; queda en ' + estados[clave] + '.');
        }
      });
      const sitio = muebleId ? 'm:' + muebleId : lugarId ? 'l:' + lugarId : 'sin';
      if (!nombresPorSitio.has(sitio)) nombresPorSitio.set(sitio, new Set());
      const nombre = sinRepetir(nombresPorSitio.get(sitio), nombreBase, 'El artículo');
      const articulo = {
        id: a.id, nombre: nombre, categoriaId: categoriaId,
        codigo: textoOpcional(a.codigo, LIMITES.codigo, '«' + nombre + '» (N.º de inventario)'),
        notas: textoOpcional(a.notas, LIMITES.notas, '«' + nombre + '» (notas)'),
        muebleId: muebleId, lugarId: lugarId, estados: estados, seguimiento: 'cantidad'
      };
      if (Array.isArray(a.series)) {
        const series = limpiarSeries(a.series).slice(0, LIMITES.cantidad);
        if (series.length) articulo.series = series;
      }
      const forma = limpiarForma(a.forma);
      if (forma) articulo.forma = forma;
      limpio.articulos.push(articulo);
      articuloPorId.set(articulo.id, articulo);
    });

    // --- Préstamos ---
    const recuperados = new Map();
    registros('prestamos', 'préstamos').forEach((p) => {
      const persona = textoObligatorio(p.persona, LIMITES.persona, '(sin nombre)', 'Un préstamo con la persona');
      let cantidad = p.cantidad;
      if (!Number.isInteger(cantidad) || cantidad < 1 || cantidad > LIMITES.cantidad) {
        anotar('Un préstamo a ' + persona + ' tenía una cantidad no válida: queda en 1.');
        cantidad = 1;
      }
      let fechaSalida = leerFechaISO(p.fechaSalida) ? p.fechaSalida : null;
      let fechaLimite = leerFechaISO(p.fechaLimite) ? p.fechaLimite : null;
      if (!fechaSalida || !fechaLimite) {
        fechaSalida = fechaSalida || fechaLimite || hoyISO;
        fechaLimite = fechaLimite || fechaSalida;
        anotar('Un préstamo a ' + persona + ' tenía fechas no válidas: se usan ' + fechaSalida + ' y ' + fechaLimite + '.');
      }
      let devuelto = p.devuelto == null || p.devuelto === '' ? null : p.devuelto;
      if (devuelto && !leerFechaISO(devuelto)) {
        anotar('Un préstamo a ' + persona + ' tenía una fecha de devolución no válida: se toma la fecha límite.');
        devuelto = fechaLimite;
      }
      const articuloNombre = textoObligatorio(p.articuloNombre || (articuloPorId.get(p.articuloId) || {}).nombre,
        LIMITES.nombre, 'Artículo', 'Un préstamo de artículo');
      let articuloId = typeof p.articuloId === 'string' ? p.articuloId : '';
      if (!articuloPorId.has(articuloId) && !devuelto) {
        // Préstamo activo de algo que ya no existe: se recrea el artículo para no perder el préstamo
        if (!recuperados.has(articuloId)) {
          const nuevo = {
            id: 'rec-articulo-' + (articuloId || p.id), nombre: articuloNombre.slice(0, LIMITES.nombre - 13) + ' (recuperado)',
            categoriaId: ID_OTROS, codigo: '', notas: 'Recreado al revisar los datos: tenía un préstamo activo.',
            muebleId: null, lugarId: null, estados: { bueno: 0, reparacion: 0, danado: 0 }, seguimiento: 'cantidad'
          };
          limpio.articulos.push(nuevo);
          articuloPorId.set(nuevo.id, nuevo);
          recuperados.set(articuloId, nuevo);
          anotar('Había un préstamo activo de «' + articuloNombre + '», que ya no existía: se recrea como «' + nuevo.nombre + '» en «Sin ubicación».');
        }
        articuloId = recuperados.get(articuloId).id;
      }
      let danadas = Number.isInteger(p.devueltasDanadas) && p.devueltasDanadas >= 0 && p.devueltasDanadas <= cantidad ? p.devueltasDanadas : 0;
      if (!devuelto) danadas = 0;
      limpio.prestamos.push({
        id: p.id, articuloId: articuloId, articuloNombre: articuloNombre,
        origen: textoOpcional(p.origen, LIMITES.nombre * 2 + 3, 'Un préstamo (origen)'),
        persona: persona, grupo: textoOpcional(p.grupo, LIMITES.grupo, 'Un préstamo (grupo)'), cantidad: cantidad,
        fechaSalida: fechaSalida, fechaLimite: fechaLimite, devuelto: devuelto, devueltasDanadas: danadas,
        nota: textoOpcional(p.nota, LIMITES.notas, 'Un préstamo (nota)')
      });
    });
    // Regla de oro: lo prestado no puede superar lo que hay en buen estado
    const prestadoPor = new Map();
    limpio.prestamos.filter((p) => !p.devuelto).forEach((p) => prestadoPor.set(p.articuloId, (prestadoPor.get(p.articuloId) || 0) + p.cantidad));
    prestadoPor.forEach((prestado, articuloId) => {
      const articulo = articuloPorId.get(articuloId);
      if (!articulo || prestado <= articulo.estados.bueno) return;
      const antes = articulo.estados.bueno;
      const total = totalDe(articulo) - antes + prestado;
      if (total > LIMITES.cantidad) return; // imposible en la práctica; verificarReglas lo reportaría
      articulo.estados.bueno = prestado;
      ajustes.piezasAgregadas += prestado - antes;
      if (!recuperados.has(articuloId) && !Array.from(recuperados.values()).some((r) => r.id === articuloId)) {
        anotar('«' + articulo.nombre + '» tiene ' + prestado + ' prestadas pero solo ' + antes + ' en buen estado: «Buen estado» sube a ' +
          prestado + ' (revisa la cantidad real).', { cantidad: true });
      }
    });

    // --- Objetos 3D y modelos ---
    // Un objeto sin lugar o con medidas imposibles se quita (es solo un dibujo, no inventario).
    // Si su mueble ya no existe queda en el piso; si su enlace con el artículo no es coherente
    // (otro sitio, o más piezas dibujadas que las que hay), queda como figura sin enlazar.
    const lugaresLimpios = new Map(limpio.lugares.map((l) => [l.id, l]));
    const mueblesLimpios = new Map(limpio.muebles.map((m) => [m.id, m]));
    const articulosLimpios = new Map(limpio.articulos.map((a) => [a.id, a]));
    const dibujadas = new Map();
    const geometriaCruda = (o) => geometriaDe({
      figura: FIGURAS_OBJETO[o.figura] ? o.figura : 'caja', medidas: esObjeto(o.medidas) ? o.medidas : {},
      pos: esObjeto(o.pos) ? o.pos : {}, rot: esObjeto(o.rot) ? o.rot : {}
    }, null);
    registros('objetos', 'objetos 3D').forEach((o) => {
      const lugar = lugaresLimpios.get(o.lugarId);
      if (!lugar) {
        anotar('Se quitará una figura 3D de un lugar que ya no existe.', { quita: true });
        return;
      }
      const geometria = geometriaCruda(o);
      if (!geometria.ok) {
        anotar('Se quitará una figura 3D de «' + lugar.nombre + '» con medidas o posición inválidas.', { quita: true });
        return;
      }
      const unidades = Number.isInteger(o.unidades) && o.unidades >= 1 && o.unidades <= LIMITES.cantidad ? o.unidades : 1;
      const objeto = Object.assign({ id: o.id, lugarId: lugar.id, muebleId: null, nombre: textoOpcional(o.nombre, LIMITES.nombre, 'Una figura 3D') },
        geometria.valor, {
          color: colorDeObjeto(o.color) || COLOR_OBJETO, articuloId: null, unidades: unidades,
          grupoId: typeof o.grupoId === 'string' && o.grupoId ? o.grupoId.slice(0, 80) : null
        });
      if (o.muebleId) {
        const mueble = mueblesLimpios.get(o.muebleId);
        if (mueble && mueble.lugarId === lugar.id) objeto.muebleId = mueble.id;
        else anotar('Una figura 3D estaba en un mueble que ya no existe: queda en el piso de «' + lugar.nombre + '».');
      }
      if (o.articuloId) {
        const articulo = articulosLimpios.get(o.articuloId);
        const mueble = articulo && articulo.muebleId ? mueblesLimpios.get(articulo.muebleId) : null;
        const donde = !articulo ? null : mueble ? { lugarId: mueble.lugarId, muebleId: mueble.id } : articulo.lugarId ? { lugarId: articulo.lugarId, muebleId: null } : null;
        const usadas = dibujadas.get(o.articuloId) || 0;
        if (!articulo) anotar('Una figura 3D estaba enlazada a un artículo que ya no existe: queda sin enlazar.');
        else if (!mismoContenedor(donde, objeto)) anotar('Una figura 3D de «' + articulo.nombre + '» no estaba donde está el artículo: queda sin enlazar.');
        else if (usadas + unidades > totalDe(articulo)) {
          anotar('«' + articulo.nombre + '» tenía más piezas dibujadas en 3D que en el inventario: se desenlazan las que sobran.');
        } else {
          objeto.articuloId = articulo.id;
          dibujadas.set(articulo.id, usadas + unidades);
        }
      }
      limpio.objetos.push(objeto);
    });
    registros('modelos', 'modelos 3D').forEach((m) => {
      const piezas = (Array.isArray(m.piezas) ? m.piezas : []).filter(esObjeto).slice(0, LIMITES.piezasModelo).map((p) => {
        const geometria = geometriaCruda(p);
        return geometria.ok ? Object.assign(geometria.valor, { color: colorDeObjeto(p.color) || COLOR_OBJETO }) : null;
      }).filter(Boolean);
      if (!piezas.length) {
        anotar('Se quitará un modelo 3D sin piezas válidas.', { quita: true });
        return;
      }
      limpio.modelos.push({ id: m.id, nombre: textoObligatorio(m.nombre, LIMITES.nombre, 'Modelo', 'Un modelo 3D'), piezas: piezas });
    });

    // --- Historial ---
    registros('movimientos', 'historial').forEach((m) => {
      if (typeof m.momento !== 'string' || typeof m.tipo !== 'string') {
        anotar('Se quitará un registro del historial incompleto (sin fecha o sin tipo).', { quita: true });
        return;
      }
      limpio.movimientos.push({
        id: m.id, momento: m.momento, operacionId: typeof m.operacionId === 'string' ? m.operacionId : m.id, tipo: m.tipo,
        entidad: typeof m.entidad === 'string' ? m.entidad : '', entidadId: typeof m.entidadId === 'string' ? m.entidadId : '',
        nombre: limpiarTexto(m.nombre).slice(0, 80), antes: m.antes == null ? null : m.antes, despues: m.despues == null ? null : m.despues,
        detalle: m.detalle == null ? null : m.detalle, autor: m.autor == null ? null : m.autor
      });
    });

    return {
      ok: true,
      datos: limpio,
      hallazgos: hallazgos,
      descartados: hallazgos.map((h) => h.texto), // nombre anterior, para compatibilidad
      ajustes: ajustes,
      formatoOriginal: objeto.formato
    };
  }

  // Compatibilidad: la app y las pruebas de la Etapa 0 llamaban validarRespaldo
  function validarRespaldo(objeto, opciones) {
    return prepararDatos(objeto, opciones);
  }

  // Todas las reglas del modelo. Devuelve la lista de problemas (vacía si todo está bien).
  // Se usa como comprobación final de la migración y en las pruebas.
  function verificarReglas(datos) {
    const problemas = [];
    TABLAS.forEach((tabla) => {
      const ids = new Set();
      (datos[tabla] || []).forEach((r) => {
        if (ids.has(r.id)) problemas.push('Id repetido en ' + tabla + ': ' + r.id);
        ids.add(r.id);
      });
    });
    const lugares = new Map(datos.lugares.map((l) => [l.id, l]));
    const muebles = new Map(datos.muebles.map((m) => [m.id, m]));
    const articulos = new Map(datos.articulos.map((a) => [a.id, a]));
    const categorias = new Map(datos.categorias.map((c) => [c.id, c]));
    if (!categorias.has(ID_OTROS)) problemas.push('Falta la categoría «Otros».');
    datos.lugares.forEach((l) => {
      if (!TIPOS_LUGAR[l.tipo]) problemas.push('Lugar con tipo inválido: ' + l.id);
      if (l.plano !== null && !planoValido(l.plano)) problemas.push('Lugar con plano inválido: ' + l.id);
    });
    datos.lugares.filter((l) => l.plano).forEach((l) => {
      const colocados = [];
      datos.muebles.filter((m) => m.lugarId === l.id && estaColocado(m)).forEach((m) => {
        if (!cabe(m, l.plano, colocados)) problemas.push('Mueble encimado o fuera del plano: ' + m.id);
        colocados.push(m);
      });
    });
    datos.muebles.forEach((m) => {
      if (!lugares.has(m.lugarId)) problemas.push('Mueble sin lugar: ' + m.id);
      if (!TIPOS_MUEBLE[m.tipo]) problemas.push('Mueble de tipo inválido: ' + m.id);
      if (![0, 1, 2, 3].includes(m.giro)) problemas.push('Mueble sin giro válido: ' + m.id);
    });
    const prestado = new Map();
    datos.prestamos.filter((p) => !p.devuelto).forEach((p) => {
      if (!articulos.has(p.articuloId)) problemas.push('Préstamo activo de un artículo que no existe: ' + p.id);
      prestado.set(p.articuloId, (prestado.get(p.articuloId) || 0) + p.cantidad);
    });
    datos.articulos.forEach((a) => {
      if (a.muebleId && a.lugarId) problemas.push('Artículo con dos ubicaciones: ' + a.id);
      if (a.muebleId && !muebles.has(a.muebleId)) problemas.push('Artículo en un mueble que no existe: ' + a.id);
      if (a.lugarId && !lugares.has(a.lugarId)) problemas.push('Artículo en un lugar que no existe: ' + a.id);
      if (!categorias.has(a.categoriaId)) problemas.push('Artículo con categoría inexistente: ' + a.id);
      if (!esObjeto(a.estados) || !CLAVES_ESTADO.every((k) => Number.isInteger(a.estados[k]) && a.estados[k] >= 0)) {
        problemas.push('Artículo con existencias inválidas: ' + a.id);
      } else if ((prestado.get(a.id) || 0) > a.estados.bueno) {
        problemas.push('Artículo con más prestadas que en buen estado: ' + a.id);
      }
      if (totalDe(a) > LIMITES.cantidad) problemas.push('Artículo con más de ' + LIMITES.cantidad + ' piezas: ' + a.id);
    });
    return problemas;
  }

  // Revisa los datos que ya están guardados con las mismas reglas.
  // Devuelve { datos: los datos ya corregidos, problemas: [textos] }. No cambia nada por sí sola.
  function revisarIntegridad(datos, opciones) {
    const revision = prepararDatos(crearRespaldo(datos, 'revision'), opciones);
    return { datos: revision.datos, problemas: revision.hallazgos.map((h) => h.texto), hallazgos: revision.hallazgos };
  }

  // Primera casilla (de atrás hacia adelante) donde cabe el mueble sin encimarse
  function primerLugarLibre(mueble, sala, colocados) {
    for (let y = 0; y + mueble.fondo <= sala.fondo; y++) {
      for (let x = 0; x + mueble.ancho <= sala.ancho; x++) {
        const lugar = { x: x, y: y, ancho: mueble.ancho, fondo: mueble.fondo };
        if (cabe(lugar, sala, colocados)) return lugar;
      }
    }
    return null;
  }

  // =====================================================================
  // 10. MIGRACIÓN DE LA BASE DE DATOS A LA VERSIÓN 3
  // =====================================================================
  // crudos: lo leído de la base vieja { espacios, muebles, equipo, prestamos }.
  // Devuelve el plan: los datos nuevos ya revisados, los hallazgos (que la persona debe aprobar
  // ANTES de migrar si hay alguno), la contabilidad de antes y después, y una "huella" para
  // confirmar que lo que se aplica es exactamente lo que se aprobó.
  function planDeMigracion(crudos, version, opciones) {
    const original = { app: 'ubica', formato: 1 };
    TABLAS_ANTIGUAS.forEach((tabla) => {
      original[tabla] = Array.isArray(crudos[tabla]) ? crudos[tabla] : [];
    });
    const preparado = prepararDatos(original, opciones);
    const datos = preparado.datos;
    const piezasViejas = original.equipo.reduce((suma, q) => suma + (Number.isInteger(q.cantidad) && q.cantidad > 0 ? q.cantidad : 0), 0);
    const prestadasViejas = original.prestamos.filter((p) => esObjeto(p) && !p.devuelto)
      .reduce((suma, p) => suma + (Number.isInteger(p.cantidad) ? p.cantidad : 0), 0);
    const antes = {
      lugares: original.espacios.length, muebles: original.muebles.length, articulos: original.equipo.length,
      prestamos: original.prestamos.length, piezas: piezasViejas, prestadas: prestadasViejas
    };
    const recreados = datos.articulos.filter((a) => a.id.startsWith('rec-articulo-')).length;
    const despues = {
      lugares: datos.lugares.length, muebles: datos.muebles.length, articulos: datos.articulos.length,
      prestamos: datos.prestamos.length, piezas: datos.articulos.reduce((s, a) => s + totalDe(a), 0),
      prestadas: datos.prestamos.filter((p) => !p.devuelto).reduce((s, p) => s + p.cantidad, 0)
    };
    // Comprobación: ningún registro se pierde. Solo pueden faltar los que prepararDatos anotó como
    // quitados (repetidos idénticos o datos que no son registros), y solo pueden sobrar los recuperados.
    const quitados = preparado.hallazgos.filter((h) => h.quita).length;
    const idsNuevos = new Set();
    TABLAS.forEach((tabla) => datos[tabla].forEach((r) => idsNuevos.add(tabla + ':' + r.id)));
    const perdidos = [];
    [['espacios', 'lugares'], ['muebles', 'muebles'], ['equipo', 'articulos'], ['prestamos', 'prestamos']].forEach(([vieja, nueva]) => {
      original[vieja].forEach((r) => {
        if (esObjeto(r) && typeof r.id === 'string' && !idsNuevos.has(nueva + ':' + r.id)) perdidos.push(vieja + ':' + r.id);
      });
    });
    const problemas = verificarReglas(datos);
    const cuadra = antes.piezas + preparado.ajustes.piezasAgregadas === despues.piezas;
    const comprobacion = {
      ok: perdidos.length <= quitados && problemas.length === 0 && cuadra &&
        despues.prestamos + quitados >= antes.prestamos && despues.articulos - recreados + quitados >= antes.articulos,
      perdidos: perdidos, problemas: problemas, piezasCuadran: cuadra
    };
    return {
      version: version, datos: datos, hallazgos: preparado.hallazgos, antes: antes, despues: despues,
      ajustes: preparado.ajustes, comprobacion: comprobacion,
      huella: huellaDe(datos) + '|' + preparado.hallazgos.map((h) => h.texto).join('|')
    };
  }

  // =====================================================================
  // 11. COPIAS DE SEGURIDAD, CSV Y EJEMPLO
  // =====================================================================
  // Una copia es una "foto" del inventario guardada dentro de la misma base de datos.
  // Protege de errores de uso (restaurar el archivo equivocado, borrar de más). NO protege si
  // se desinstala la app o se pierde el celular: para eso está el respaldo en archivo.
  const MAXIMO_COPIAS = 6;
  const MOTIVOS_COPIA = {
    diaria: 'Copia automática del día',
    'antes-de-restaurar': 'Antes de restaurar un respaldo',
    'antes-de-recuperar': 'Antes de recuperar otra copia',
    'antes-de-reparar': 'Antes de reparar los datos',
    'antes-de-migrar': 'Antes de actualizar los datos a la versión 3'
  };

  function estaVacio(datos) {
    return ['lugares', 'muebles', 'articulos', 'prestamos'].every((tabla) => !(datos[tabla] || []).length);
  }

  // Texto que permite saber si dos inventarios son iguales, sin importar el orden de los registros
  function huellaDe(datos) {
    return JSON.stringify(TABLAS.filter((tabla) => tabla !== 'movimientos').map((tabla) =>
      (datos[tabla] || []).map((registro) => JSON.stringify(registro, Object.keys(registro).sort())).sort()
    ));
  }

  function resumenCopia(datos) {
    return {
      lugares: datos.lugares.length,
      muebles: datos.muebles.length,
      piezas: datos.articulos.reduce((suma, articulo) => suma + totalDe(articulo), 0),
      prestamos: datos.prestamos.length
    };
  }

  // momentoISO: fecha y hora completas, por ejemplo '2026-11-10T09:30:00.000Z'
  function crearCopia(datos, motivo, momentoISO, diaISO) {
    return {
      id: 'copia-' + momentoISO + '-' + Math.random().toString(36).slice(2, 6),
      momento: momentoISO,
      dia: diaISO,
      motivo: motivo,
      resumen: resumenCopia(datos),
      datos: crearRespaldo(datos, momentoISO)
    };
  }

  // ¿Toca hacer la copia automática de hoy? Solo si hay datos, hoy no se ha hecho y algo
  // cambió desde la copia más reciente (no se llenan las 6 copias con lo mismo).
  function tocaCopiaDiaria(copias, datos, diaISO) {
    if (estaVacio(datos)) return false;
    if (copias.some((copia) => copia.motivo === 'diaria' && copia.dia === diaISO)) return false;
    const reciente = copiasOrdenadas(copias)[0];
    if (!reciente) return true;
    return huellaDe(reciente.datos) !== huellaDe(datos);
  }

  // La más nueva primero
  function copiasOrdenadas(copias) {
    return copias.slice().sort((a, b) => (a.momento < b.momento ? 1 : a.momento > b.momento ? -1 : 0));
  }

  // Ids de las copias más viejas que hay que borrar para que, al agregar una, no pasen del máximo
  function copiasQueSobran(copias, cuantasNuevas) {
    const permitidas = MAXIMO_COPIAS - (cuantasNuevas || 0);
    return copiasOrdenadas(copias).slice(Math.max(0, permitidas)).map((copia) => copia.id);
  }

  // Un campo de CSV. Si empieza con = + - @ se le antepone ' para que Excel no lo
  // ejecute como fórmula (es un ataque conocido: "inyección de CSV").
  function campoCSV(valor) {
    let texto = valor == null ? '' : String(valor);
    if (/^[=+\-@\t\r]/.test(texto)) texto = "'" + texto;
    return /[",\n\r]/.test(texto) ? '"' + texto.replace(/"/g, '""') + '"' : texto;
  }

  // Todo el inventario en una tabla que Excel abre directo (con BOM para los acentos).
  // Incluye los artículos directo en un lugar y los que no tienen ubicación.
  function inventarioCSV(datos) {
    const filas = [['Lugar', 'Tipo de lugar', 'Mueble', 'Tipo de mueble', 'Artículo', 'Categoría', 'N.º de inventario',
      'Total', 'Buen estado', 'En reparación', 'Dañado', 'Prestadas', 'Disponibles', 'Notas']];
    const fila = (lugar, mueble, articulo) => {
      filas.push([
        lugar ? lugar.nombre : 'Sin ubicación', lugar ? TIPOS_LUGAR[lugar.tipo].nombre : '',
        mueble ? mueble.nombre : '', mueble ? TIPOS_MUEBLE[mueble.tipo].nombre : '',
        articulo.nombre, categoriaDe(datos, articulo).nombre, articulo.codigo, totalDe(articulo),
        articulo.estados.bueno, articulo.estados.reparacion, articulo.estados.danado,
        prestadas(datos, articulo.id), disponibles(datos, articulo), articulo.notas
      ]);
    };
    datos.lugares.forEach((lugar) => {
      mueblesDe(datos, lugar.id).forEach((mueble) => articulosDe(datos, mueble.id).forEach((a) => fila(lugar, mueble, a)));
      articulosEnLugar(datos, lugar.id).forEach((a) => fila(lugar, null, a));
    });
    articulosSinUbicacion(datos).forEach((a) => fila(null, null, a));
    return '﻿' + filas.map((f) => f.map(campoCSV).join(',')).join('\r\n') + '\r\n';
  }

  // Un laboratorio y una bodega con plano, una dirección sin plano y artículos de todo tipo
  // (en muebles, directo en un lugar y sin ubicación), con dos préstamos (uno vencido).
  function datosDeEjemplo(hoyISO) {
    const datos = datosVacios();
    datos.categorias = categoriasIniciales();
    const lugar = (id, nombre, tipo, ancho, fondo) =>
      datos.lugares.push({ id: id, nombre: nombre, tipo: tipo, plano: ancho ? { ancho: ancho, fondo: fondo } : null });
    const mueble = (id, lugarId, tipo, nombre, x, y) => datos.muebles.push({
      id: id, lugarId: lugarId, tipo: tipo, nombre: nombre, x: x, y: y,
      ancho: TIPOS_MUEBLE[tipo].ancho, fondo: TIPOS_MUEBLE[tipo].fondo, giro: 0
    });
    const articulo = (id, sitio, nombre, cantidad, categoria, codigo, estados) => datos.articulos.push(Object.assign({
      id: id, nombre: nombre, categoriaId: 'cat-' + categoria, codigo: codigo || '', notas: '',
      muebleId: sitio.startsWith('mue') ? sitio : null, lugarId: sitio.startsWith('lug') || sitio.startsWith('esp') ? sitio : null,
      estados: Object.assign({ bueno: cantidad, reparacion: 0, danado: 0 }, estados || {}), seguimiento: 'cantidad'
    }, sitio === 'sin' ? { muebleId: null, lugarId: null } : {}));

    lugar('esp-ejemplo-lab', 'Laboratorio de Química', 'laboratorio', 8, 6);
    mueble('mue-ej-1', 'esp-ejemplo-lab', 'estante', 'Estante A', 0, 0);
    mueble('mue-ej-2', 'esp-ejemplo-lab', 'estante', 'Estante B', 1, 0);
    mueble('mue-ej-3', 'esp-ejemplo-lab', 'vitrina', 'Vitrina de reactivos', 4, 0);
    mueble('mue-ej-4', 'esp-ejemplo-lab', 'mesa', 'Mesa 1', 2, 3);
    mueble('mue-ej-5', 'esp-ejemplo-lab', 'mesa', 'Mesa 2', 5, 3);
    mueble('mue-ej-6', 'esp-ejemplo-lab', 'banco', 'Banco 1', 2, 4);
    mueble('mue-ej-7', 'esp-ejemplo-lab', 'banco', 'Banco 2', 3, 4);
    mueble('mue-ej-8', 'esp-ejemplo-lab', 'gabinete', 'Gabinete de seguridad', 0, 4);
    mueble('mue-ej-9', 'esp-ejemplo-lab', 'escritorio', 'Escritorio del profesor', 6, 5);
    articulo('eq-ej-1', 'mue-ej-1', 'Microscopio', 4, 'laboratorio', 'LAB-001', { reparacion: 1 });
    articulo('eq-ej-2', 'mue-ej-1', 'Portaobjetos', 40, 'consumibles');
    articulo('eq-ej-3', 'mue-ej-2', 'Multímetro', 3, 'laboratorio', 'LAB-014');
    articulo('eq-ej-4', 'mue-ej-3', 'Matraz Erlenmeyer', 12, 'laboratorio');
    articulo('eq-ej-5', 'mue-ej-3', 'Probeta 100 ml', 7, 'laboratorio', '', { danado: 1 });
    articulo('eq-ej-6', 'mue-ej-8', 'Lentes de seguridad', 20, 'seguridad');
    articulo('eq-ej-7', 'mue-ej-8', 'Bata', 15, 'seguridad');
    articulo('eq-ej-8', 'mue-ej-9', 'Proyector', 1, 'audiovisual', 'LAB-020');
    articulo('eq-ej-13', 'esp-ejemplo-lab', 'Extintor', 1, 'seguridad', 'SEG-002');

    lugar('esp-ejemplo-bod', 'Bodega', 'bodega', 6, 4);
    mueble('mue-ej-10', 'esp-ejemplo-bod', 'estante', 'Anaquel 1', 0, 0);
    mueble('mue-ej-11', 'esp-ejemplo-bod', 'estante', 'Anaquel 2', 1, 0);
    mueble('mue-ej-12', 'esp-ejemplo-bod', 'caja', 'Caja de cables', 4, 2);
    mueble('mue-ej-13', 'esp-ejemplo-bod', 'casillero', 'Casillero de deportes', 5, 0);
    articulo('eq-ej-9', 'mue-ej-10', 'Extensión eléctrica', 6, 'herramientas');
    articulo('eq-ej-10', 'mue-ej-11', 'Bocina portátil', 2, 'audiovisual', 'BOD-003');
    articulo('eq-ej-11', 'mue-ej-12', 'Cable HDMI', 10, 'computo');
    articulo('eq-ej-12', 'mue-ej-13', 'Balón de básquetbol', 8, 'deportes');

    lugar('lug-ejemplo-dir', 'Dirección', 'oficina', null, null);
    articulo('eq-ej-14', 'lug-ejemplo-dir', 'Engrapadora', 2, 'papeleria');
    articulo('eq-ej-16', 'lug-ejemplo-dir', 'Laptop', 3, 'computo', 'DIR-010', { reparacion: 1 });
    articulo('eq-ej-17', 'lug-ejemplo-dir', 'Hojas blancas (paquete)', 12, 'papeleria');
    articulo('eq-ej-15', 'sin', 'Cámara fotográfica', 1, 'audiovisual', 'AV-007');
    articulo('eq-ej-18', 'sin', 'Guantes de nitrilo (caja)', 6, 'consumibles');

    // Almacén general: el lugar grande, pensado para verse en 3D
    datos.lugares.unshift({ id: 'lug-ejemplo-alm', nombre: 'Almacén general', tipo: 'bodega', plano: { ancho: 12, fondo: 9 }, vista: '3d' });
    const girado = (id, lugarId, tipo, nombre, x, y) => {
      mueble(id, lugarId, tipo, nombre, x, y);
      const m = datos.muebles[datos.muebles.length - 1];
      Object.assign(m, { ancho: TIPOS_MUEBLE[tipo].fondo, fondo: TIPOS_MUEBLE[tipo].ancho, giro: 1 });
    };
    ['A', 'B', 'C', 'D', 'E', 'F'].forEach((letra, i) => mueble('mue-alm-a' + i, 'lug-ejemplo-alm', 'estante', 'Rack ' + letra, 1 + i, 0));
    ['G', 'H', 'I', 'J'].forEach((letra, i) => mueble('mue-alm-b' + i, 'lug-ejemplo-alm', 'estante', 'Rack ' + letra, 2 + i, 3));
    mueble('mue-alm-gab1', 'lug-ejemplo-alm', 'gabinete', 'Gabinete de herramientas', 9, 0);
    mueble('mue-alm-gab2', 'lug-ejemplo-alm', 'gabinete', 'Gabinete de limpieza', 10, 0);
    mueble('mue-alm-cas', 'lug-ejemplo-alm', 'casillero', 'Casilleros', 11, 3);
    mueble('mue-alm-vit', 'lug-ejemplo-alm', 'vitrina', 'Vitrina de audiovisual', 8, 3);
    girado('mue-alm-mesa', 'lug-ejemplo-alm', 'mesa', 'Mesa de recepción', 0, 5);
    mueble('mue-alm-esc', 'lug-ejemplo-alm', 'escritorio', 'Escritorio de control', 2, 7);
    mueble('mue-alm-ban', 'lug-ejemplo-alm', 'banco', 'Banco', 3, 8);
    mueble('mue-alm-c1', 'lug-ejemplo-alm', 'caja', 'Caja de refacciones', 7, 6);
    mueble('mue-alm-c2', 'lug-ejemplo-alm', 'caja', 'Caja de cables', 8, 6);
    mueble('mue-alm-c3', 'lug-ejemplo-alm', 'caja', 'Caja de papelería', 7, 7);
    articulo('art-alm-1', 'mue-alm-a0', 'Taladro', 4, 'herramientas', 'ALM-001', { reparacion: 1 });
    articulo('art-alm-2', 'mue-alm-a0', 'Juego de desarmadores', 8, 'herramientas');
    articulo('art-alm-3', 'mue-alm-a1', 'Proyector portátil', 3, 'audiovisual', 'ALM-014', { danado: 1 });
    articulo('art-alm-4', 'mue-alm-a2', 'Teclado USB', 15, 'computo');
    articulo('art-alm-5', 'mue-alm-a2', 'Mouse', 18, 'computo');
    articulo('art-alm-6', 'mue-alm-a3', 'Monitor 22 pulgadas', 6, 'computo', 'ALM-030');
    articulo('art-alm-7', 'mue-alm-a4', 'Balón de fútbol', 10, 'deportes');
    articulo('art-alm-8', 'mue-alm-a5', 'Conos de entrenamiento', 30, 'deportes');
    articulo('art-alm-9', 'mue-alm-b0', 'Resma de papel', 40, 'papeleria');
    articulo('art-alm-10', 'mue-alm-b1', 'Marcadores para pizarrón', 60, 'papeleria');
    articulo('art-alm-11', 'mue-alm-b2', 'Tóner para impresora', 5, 'consumibles', 'ALM-052');
    articulo('art-alm-12', 'mue-alm-b3', 'Foco LED', 24, 'refacciones');
    articulo('art-alm-13', 'mue-alm-gab1', 'Martillo', 5, 'herramientas');
    articulo('art-alm-14', 'mue-alm-gab1', 'Multímetro digital', 3, 'herramientas', 'ALM-060');
    articulo('art-alm-15', 'mue-alm-gab2', 'Cloro (galón)', 8, 'limpieza');
    articulo('art-alm-16', 'mue-alm-gab2', 'Trapeador', 6, 'limpieza', '', { danado: 2 });
    articulo('art-alm-17', 'mue-alm-vit', 'Micrófono inalámbrico', 4, 'audiovisual', 'ALM-071');
    articulo('art-alm-18', 'mue-alm-vit', 'Bocina con tripié', 2, 'audiovisual', 'ALM-072');
    articulo('art-alm-19', 'mue-alm-cas', 'Chaleco de seguridad', 12, 'seguridad');
    articulo('art-alm-20', 'mue-alm-c1', 'Fusibles', 50, 'refacciones');
    articulo('art-alm-21', 'mue-alm-c2', 'Cable de red (5 m)', 20, 'computo');
    articulo('art-alm-22', 'lug-ejemplo-alm', 'Escalera de aluminio', 2, 'herramientas', 'ALM-090');
    articulo('art-alm-23', 'lug-ejemplo-alm', 'Diablito de carga', 1, 'herramientas');
    datos.articulos.find((a) => a.id === 'art-alm-1').series = ['TAL-2291', 'TAL-2292', 'TAL-2305', 'TAL-2310'];
    datos.articulos.find((a) => a.id === 'art-alm-6').series = ['MON-A11', 'MON-A12', 'MON-A13'];
    // Objetos 3D del ejemplo, en el piso del almacén: cuatro llantas apiladas (figuras sin enlazar)
    // y las dos escaleras de aluminio, dibujadas acostadas y enlazadas a su artículo
    const objeto = (id, figura, medidas, pos, color, extra) => datos.objetos.push(Object.assign({
      id: id, lugarId: 'lug-ejemplo-alm', muebleId: null, nombre: '', figura: figura, medidas: medidas, pos: pos,
      rot: { x: 0, y: 0, z: 0 }, color: color, articuloId: null, unidades: 1, grupoId: null
    }, extra || {}));
    [0, 1, 2, 3].forEach((n) => objeto('obj-ej-llanta-' + (n + 1), 'aro', { ancho: 0.65, fondo: 0.65, alto: 0.22 },
      { x: 11.4, y: 4.5, z: Espacio.redondear(0.11 + n * 0.22, 4) }, '#2b2d33', { nombre: 'Llanta' }));
    [0, 1].forEach((n) => objeto('obj-ej-escalera-' + (n + 1), 'caja', { ancho: 0.45, fondo: 1.8, alto: 0.08 },
      { x: 10.3, y: 4.9, z: Espacio.redondear(0.04 + n * 0.08, 4) }, '#b8c0cc', { articuloId: 'art-alm-22' }));
    // Algunas formas propias para la vista 3D (el resto usa la caja del color de su categoría)
    const formasEjemplo = {
      0: ['cilindro', 2, '#e8a33d'], 1: ['esfera', 2, '#d9534f'], 2: ['prisma', 2, '#3fa7a3'], 3: ['piramide', 2, '#8e6bd1'],
      4: ['cilindro', 3, '#4a8fe0'], 5: ['caja', 3, '#5aa469']
    };
    datos.articulos.forEach((articulo, i) => {
      const forma = formasEjemplo[i % 8];
      if (forma) articulo.forma = { figura: forma[0], tamano: forma[1], color: forma[2] };
    });
    datos.lugares.find((l) => l.id === 'esp-ejemplo-lab').vista = '2.5d';

    datos.prestamos.push({
      id: 'pre-ej-3', articuloId: 'art-alm-3', articuloNombre: 'Proyector portátil', origen: 'Almacén general › Rack B',
      persona: 'Mtra. Rivera', grupo: '2.º A', cantidad: 1, fechaSalida: sumarDias(hoyISO, -1),
      fechaLimite: sumarDias(hoyISO, 2), devuelto: null, devueltasDanadas: 0, nota: 'Exposición de ciencias'
    });
    datos.prestamos.push({
      id: 'pre-ej-4', articuloId: 'art-alm-7', articuloNombre: 'Balón de fútbol', origen: 'Almacén general › Rack E',
      persona: 'Prof. Gómez', grupo: 'Deportes', cantidad: 4, fechaSalida: sumarDias(hoyISO, -6),
      fechaLimite: sumarDias(hoyISO, -1), devuelto: null, devueltasDanadas: 0, nota: 'Torneo interno'
    });
    datos.prestamos.push({
      id: 'pre-ej-5', articuloId: 'art-alm-1', articuloNombre: 'Taladro', origen: 'Almacén general › Rack A',
      persona: 'Mantenimiento', grupo: '', cantidad: 1, fechaSalida: sumarDias(hoyISO, -12),
      fechaLimite: sumarDias(hoyISO, -8), devuelto: sumarDias(hoyISO, -9), devueltasDanadas: 0, nota: ''
    });
    // El historial del ejemplo: el alta de cada artículo (registros reales, uno por artículo)
    datos.articulos.forEach((a, i) => {
      const momento = sumarDias(hoyISO, -20) + 'T' + dosDigitos(8 + (i % 9)) + ':' + dosDigitos((i * 7) % 60) + ':00.000Z';
      datos.movimientos.push({
        id: 'mov-ej-' + i, momento: momento, operacionId: 'mov-ej-' + i, tipo: 'alta', entidad: 'articulo', entidadId: a.id,
        nombre: a.nombre, antes: null, despues: clonar(a), detalle: null, autor: null
      });
    });

    datos.prestamos.push({
      id: 'pre-ej-1', articuloId: 'eq-ej-1', articuloNombre: 'Microscopio', origen: 'Laboratorio de Química › Estante A',
      persona: 'Ana López', grupo: '3.º B', cantidad: 2, fechaSalida: sumarDias(hoyISO, -3),
      fechaLimite: sumarDias(hoyISO, 4), devuelto: null, devueltasDanadas: 0, nota: 'Práctica de biología'
    });
    datos.prestamos.push({
      id: 'pre-ej-2', articuloId: 'eq-ej-10', articuloNombre: 'Bocina portátil', origen: 'Bodega › Anaquel 2',
      persona: 'Prof. Martínez', grupo: 'Dirección', cantidad: 1, fechaSalida: sumarDias(hoyISO, -9),
      fechaLimite: sumarDias(hoyISO, -2), devuelto: null, devueltasDanadas: 0, nota: ''
    });
    return datos;
  }

  const Nucleo = {
    LIMITES, TIPOS_LUGAR, TIPOS_MUEBLE, TABLAS, TABLA_COPIAS, TABLAS_ANTIGUAS, INDICES, PROPORCION, ALTO_PARED,
    ZOOM_MINIMO, ZOOM_MAXIMO, UMBRAL_TOQUE, ID_OTROS, CATEGORIAS_INICIALES, COLORES_CATEGORIA, ESTADOS, CLAVES_ESTADO,
    TIPOS_MOVIMIENTO, FORMATO_RESPALDO, MAXIMO_COPIAS, MOTIVOS_COPIA,
    normalizar, escaparHTML, nuevoId, fechaISO, leerFechaISO, sumarDias, diasEntre, fechaCorta, plural, clonar,
    proyectar, casillaEnPantalla, escalaParaSala, girarUnCuarto, girar, medidasVista, aVista, aMundo,
    rectAlTocar, seEnciman, estaColocado, cabe, estaDetras, ordenarDeAtrasHaciaAdelante, siluetaEnPantalla,
    mueblesQueTapan, altoDe,
    camaraInicial, limitarCamara, zoomEn, pantallaADibujo, crearGestos,
    datosVacios, categoriasIniciales, buscarPorId, mueblesDe, mueblesColocados, articulosDe, articulosEnLugar,
    articulosSinUbicacion, totalDe, piezasEnMueble, piezasEnLugar, prestamosActivosDe, prestadas, disponibles,
    ubicacion, textoUbicacion, categoriaDe, categoriasOrdenadas, articulosDeCategoria, movimientosDe, nombreEstado,
    estadoPrestamo, prestamosActivos, historialPrestamos, textoVencimiento, buscar, mueblesQueCoinciden, resumen,
    limpiarTexto, validarTexto, validarEntero, planoValido, validarLugar, validarDatosArticulo, validarPrestamo,
    aplicarCambios, invertirCambios, crearLugar, editarLugar, afectadosPorBorrarLugar, borrarLugar,
    colocarMueble, moverMueble, girarMueble, renombrarMueble, borrarMueble,
    crearArticulo, agregarArticulo, editarArticulo, agregarExistencias, cambiarEstado, darDeBaja, moverArticulo, borrarArticulo,
    prestar, devolver, crearCategoria, editarCategoria, borrarCategoria,
    conMovimientos, movimientoGeneral, textoMovimiento,
    crearRespaldo, convertirFormato1, inferirGiro, prepararDatos, validarRespaldo, verificarReglas, revisarIntegridad,
    primerLugarLibre, planDeMigracion,
    VISTAS_LUGAR, MEDIDA_MAXIMA_MUEBLE, consultarArticulos, movimientosRecientes, piezasMueble, medidasSinGiro,
    guardarSeries, redimensionarMueble, cambiarVistaLugar, vistaDeLugar,
    FIGURAS, TAMANOS_FORMA, limpiarForma, guardarForma, formaDe, nivelesInterior, acomodoInterior,
    huecoInterior, crearMueble, crearArticuloEnMuebleNuevo, moverArticulos, autoOrdenar, buscarSitio,
    Espacio, MODELOS_BASE, FIGURAS_OBJETO, MEDIDAS_INICIALES, COLOR_OBJETO,
    objetosEnLugar, objetosEnPiso, objetosEnMueble, objetosDeArticulo, unidadesRepresentadas, nombreDeObjeto,
    contenedorDeArticulo, entornoDe, revisarObjeto, revisarObjetos, crearObjeto, editarObjeto, transformarObjetos,
    asentarObjetos, duplicarObjetos, borrarObjetos, agruparObjetos, desagruparObjetos, vincularObjetos,
    desvincularObjetos, registrarArticuloDesdeObjetos, separarArticulo, moverObjetosA, fijarAutomatico,
    todosLosModelos, guardarModelo, borrarModelo, insertarModelo, obstaculosDePiso, moverArticuloSolo,
    estaVacio, huellaDe, crearCopia, tocaCopiaDiaria, copiasOrdenadas, copiasQueSobran,
    campoCSV, inventarioCSV, datosDeEjemplo
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Nucleo;
  else raiz.Nucleo = Nucleo;
})(typeof window !== 'undefined' ? window : globalThis);
