// Ubica · Service worker: hace que la versión web (iPhone y computadora) abra sin internet.
// Estrategia: red primero y, si no hay conexión, la copia guardada.
// Sube el número de VERSION cuando cambie la lista de archivos.
// En la app de Android no se usa (app.js no lo registra ahí).
const VERSION = 'ubica-v10';
const ARCHIVOS = [
  './',
  'index.html',
  'styles.css',
  'version.js',
  'novedades.js',
  'nucleo.js',
  'muestra.js',
  'basedatos.js',
  'compartir.js',
  'escena.js',
  'ui.js',
  'fichas.js',
  'vistas.js',
  'datos.js',
  'app.js',
  'escena3d.js',
  'espacio.js',
  'editor3d.js',
  'vendor/three.module.min.js',
  'vendor/TransformControls.js',
  'fuentes/Inter.woff2',
  'manifest.webmanifest',
  'icon-192.png',
  'icon-512.png',
  'apple-touch-icon.png'
];

self.addEventListener('install', (evento) =>
  evento.waitUntil(
    caches
      .open(VERSION)
      .then((cache) => cache.addAll(ARCHIVOS))
      .then(() => self.skipWaiting())
  )
);

self.addEventListener('activate', (evento) =>
  evento.waitUntil(
    caches
      .keys()
      .then((claves) => Promise.all(claves.filter((clave) => clave !== VERSION).map((clave) => caches.delete(clave))))
      .then(() => self.clients.claim())
  )
);

self.addEventListener('fetch', (evento) => {
  const pedido = evento.request;
  if (pedido.method !== 'GET' || !pedido.url.startsWith(self.location.origin)) return;
  evento.respondWith(
    fetch(pedido)
      .then((respuesta) => {
        const copia = respuesta.clone();
        caches.open(VERSION).then((cache) => cache.put(pedido, copia));
        return respuesta;
      })
      .catch(() =>
        caches.match(pedido, { ignoreSearch: true }).then((guardada) => guardada || caches.match('index.html'))
      )
  );
});
