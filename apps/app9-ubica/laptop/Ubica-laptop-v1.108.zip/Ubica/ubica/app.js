// Ubica · App: navegación entre secciones, botón Atrás, atajos de teclado e inicio.
// (El estado y los paneles están en ui.js; las pantallas en vistas.js, fichas.js y datos.js.)
(function () {
  'use strict';

  const U = window.Ubica;
  const { N, $, estado } = U;

  // =====================================================================
  // NAVEGACIÓN
  // =====================================================================
  U.irASeccion = (seccion) => {
    if (estado.seccion === seccion && seccion === 'lugares' && estado.lugarId) {
      U.salirDeLugar(); // tocar «Lugares» estando dentro de uno regresa a la lista de lugares
      return;
    }
    estado.seccion = seccion;
    estado.modo = null;
    estado.filasVisibles = U.FILAS_POR_TANDA;
    if (!U.esEscritorio() || seccion !== 'lugares') U.cerrarHojas();
    document.body.classList.remove('presentacion');
    U.render();
    $('principal').scrollTop = 0;
  };

  $('navegacion').addEventListener('click', (evento) => {
    const boton = evento.target.closest('[data-seccion]');
    if (boton) U.irASeccion(boton.dataset.seccion);
  });
  $('botonAtras').addEventListener('click', () => atras());

  // =====================================================================
  // BOTÓN ATRÁS (ANDROID Y WEB)
  // =====================================================================
  // En orden: salir de presentación, cerrar el panel de arriba, salir del modo colocar/mover,
  // quitar la selección, salir del lugar, volver al Inventario. Devuelve false si ya no hay nada.
  function atras() {
    if (document.body.classList.contains('presentacion')) U.presentacion(false);
    else if (U.pila.length) U.volverHoja();
    else if (estado.modo) {
      estado.modo = null;
      U.render();
    } else if (estado.seccion === 'lugares' && estado.lugarId) {
      if (estado.editor.seleccion.length) U.seleccionarObjetos([]);
      else if (estado.editor.interiorId) U.salirDelInterior();
      else if (estado.seleccionadoId) U.deseleccionar();
      else U.salirDeLugar();
    } else if (estado.seccion !== 'inventario') U.irASeccion('inventario');
    else return false;
    return true;
  }

  const hayAlgoQueCerrar = () => Boolean(U.pila.length || estado.modo || estado.seccion !== 'inventario' ||
    document.body.classList.contains('presentacion'));

  // App de Android: Capacitor avisa cuando se oprime el botón Atrás
  function prepararBotonAtras() {
    if (!window.Compartir.esNativa()) return;
    const capacitor = window.Capacitor;
    const app = (capacitor.Plugins && capacitor.Plugins.App) || capacitor.registerPlugin('App');
    app.addListener('backButton', () => {
      if (!atras()) app.exitApp();
    });
  }

  // Versión web: la primera vez que hay algo que cerrar se agrega una entrada "centinela" al
  // historial del navegador. Atrás la consume en lugar de salir de la app, y aquí se decide.
  let centinela = false;

  function sincronizarHistorial() {
    if (window.Compartir.esNativa() || centinela || !estado.listo || !hayAlgoQueCerrar()) return;
    try {
      history.pushState({ ubica: 'centinela' }, '');
      centinela = true;
    } catch (error) {
      // Sin historial, Atrás simplemente sale de la app
    }
  }

  window.addEventListener('popstate', () => {
    centinela = false;
    if (atras()) sincronizarHistorial();
    else history.back(); // no había nada que cerrar: el usuario quiere salir
  });

  U.alCambiarPaneles = sincronizarHistorial;

  // =====================================================================
  // ATAJOS DE TECLADO (complementan a los botones; nada depende de ellos)
  // =====================================================================
  //   /  buscar · N  nuevo · Esc  cerrar o volver · 1 2 3  Lista, 2.5D, 3D
  //   Con un mueble seleccionado: flechas lo mueven · R lo gira · Supr lo borra (con confirmación)
  //   Ctrl+Z  deshacer lo último (mientras el aviso sigue visible)
  document.addEventListener('keydown', (evento) => {
    const enCampo = /^(INPUT|TEXTAREA|SELECT)$/.test(evento.target.tagName);
    if (evento.key === 'Escape') {
      if (enCampo && evento.target.id === 'buscador') evento.target.blur();
      else if (atras()) evento.preventDefault();
      return;
    }
    const conControl = evento.ctrlKey || evento.metaKey;
    if (conControl && !enCampo && (evento.key.toLowerCase() === 'y' || (evento.key.toLowerCase() === 'z' && evento.shiftKey))) {
      evento.preventDefault();
      U.rehacer();
      return;
    }
    if (conControl && evento.key.toLowerCase() === 'z' && !enCampo) {
      evento.preventDefault();
      U.deshacer();
      return;
    }
    if (enCampo || evento.ctrlKey || evento.metaKey || evento.altKey || !estado.listo) return;
    const tecla = evento.key.toLowerCase();
    const enLugar = estado.seccion === 'lugares' && estado.lugarId;
    if (tecla === '/') {
      evento.preventDefault();
      if (estado.seccion !== 'inventario') U.irASeccion('inventario');
      $('buscador').focus();
    } else if (tecla === 'n') {
      evento.preventDefault();
      if (estado.seccion === 'lugares' && !estado.lugarId) U.abrirHojaUnica(() => U.pantallaLugar(null));
      else U.abrirHojaUnica(() => U.pantallaNuevoArticulo(enLugar ? 'l:' + estado.lugarId : 'sin'));
    } else if (enLugar && ['1', '2', '3'].includes(tecla)) {
      U.cambiarVista(['lista', '2.5d', '3d'][Number(tecla) - 1]);
    } else if (enLugar && estado.seleccionadoId && U.vistaActual() !== 'lista') {
      const mueble = N.buscarPorId(estado.datos.muebles, estado.seleccionadoId);
      const pasos = { arrowleft: [-1, 0], arrowright: [1, 0], arrowup: [0, -1], arrowdown: [0, 1] }[tecla];
      if (pasos && mueble && N.estaColocado(mueble)) {
        evento.preventDefault();
        const rect = { x: mueble.x + pasos[0], y: mueble.y + pasos[1], ancho: mueble.ancho, fondo: mueble.fondo };
        U.ejecutar(N.moverMueble(estado.datos, mueble.id, rect), { mensaje: 'Moviste «' + mueble.nombre + '»', deshacer: true });
      } else if (tecla === 'r') U.girarMueble(estado.seleccionadoId);
      else if (tecla === 'delete' || tecla === 'backspace') U.abrirMueble(estado.seleccionadoId);
    }
  });

  // =====================================================================
  // SIN INTERNET Y ERRORES
  // =====================================================================
  function registrarServiceWorker() {
    const esWeb = location.protocol === 'https:' || location.hostname === 'localhost';
    if (!('serviceWorker' in navigator) || !esWeb || window.Compartir.esNativa()) return;
    navigator.serviceWorker.register('sw.js').catch(() => {
      // Sin service worker la app funciona igual; solo necesita internet para abrir
    });
  }

  // Si algo falla donde no lo esperábamos, que no pase en silencio
  let ultimoErrorAvisado = 0;
  function avisarErrorInesperado(error) {
    if (/ResizeObserver/.test(String(error))) return; // aviso inofensivo del navegador
    console.error(error);
    if (Date.now() - ultimoErrorAvisado < 5000) return;
    ultimoErrorAvisado = Date.now();
    U.avisar('Algo falló. Lo que ya estaba guardado sigue a salvo; si se repite, cierra y abre Ubica.');
  }
  window.addEventListener('unhandledrejection', (evento) => avisarErrorInesperado(evento.reason));
  window.addEventListener('error', (evento) => avisarErrorInesperado(evento.error || evento.message));

  // Para las pruebas automáticas (Playwright): ver el estado sin tocar nada
  window.UbicaPruebas = {
    estado: () => estado, escena: U.escena, escena3d: () => U.escena3d,
    // Solo para las pruebas: el ejemplo anterior (almacén, laboratorio, bodega y dirección) en TU base
    cargarEjemplo: () => U.cargarEjemploDePrueba()
  };

  prepararBotonAtras();
  registrarServiceWorker();
  U.iniciar();
})();
