// Ubica · Espacio de muestra: «Laboratorio de Ciencias» de una preparatoria, con su bodega anexa.
//
// Sirve para enseñar la app en 30 segundos. Usa cada función al menos una vez: los 8 tipos de
// mueble (uno girado y con medidas cambiadas), puerta y pizarrón, artículos con los tres estados,
// números de serie, notas y número de inventario, préstamos en todos sus casos (activo, por
// vencer, vence hoy, vencido, devuelto y devuelto en parte), objetos 3D (una pila, un modelo
// guardado y objetos enlazados al inventario), un lugar sin plano y un artículo sin ubicación.
//
// Los datos se arman con las MISMAS operaciones que usa la app (crearArticulo, prestar, devolver,
// darDeBaja…), así el historial es real y todo cumple las reglas. Las fechas se calculan desde
// «hoy» para que los préstamos siempre se vean igual (uno vence mañana, otro está vencido…).
//
// Este archivo no sabe nada de la base de datos: solo devuelve los datos. Dónde se guardan lo
// decide datos.js (en la base «ubica-muestra», nunca en la tuya).
(function (raiz) {
  'use strict';

  const N = typeof module !== 'undefined' && module.exports ? require('./nucleo.js') : raiz.Nucleo;
  const LUGAR = 'mu-lab';
  const BODEGA = 'mu-bodega';

  function datosDeMuestra(hoyISO) {
    const datos = N.datosVacios();
    datos.categorias = N.categoriasIniciales();
    const dia = (desplazamiento) => N.sumarDias(hoyISO, desplazamiento);
    let paso = 0;

    // Aplica una operación como lo hace la app: con su registro en el historial y en una fecha
    function hacer(resultado, diasAtras, hora) {
      if (!resultado.ok) throw new Error('Muestra: ' + resultado.error);
      paso++;
      const momento = dia(-diasAtras) + 'T' + (hora || '09:00') + ':' + String(paso % 60).padStart(2, '0') + '.000Z';
      const cambios = resultado.sinHistorial ? resultado.cambios : N.conMovimientos(datos, resultado, momento, 'mu-op-' + paso);
      N.aplicarCambios(datos, cambios);
      return resultado;
    }

    // ---------- Lugares ----------
    datos.lugares.push({
      id: LUGAR, nombre: 'Laboratorio de Ciencias', tipo: 'laboratorio', plano: { ancho: 10, fondo: 8 }, vista: '3d',
      // Puerta y pizarrón en las dos paredes que se ven de frente en 2.5D
      // (la puerta va en la esquina: así ningún mueble la tapa en la vista isométrica)
      pared: { puerta: { lado: 'norte', desde: 9 }, pizarron: { lado: 'oeste', desde: 2.5 } }
    });
    datos.lugares.push({ id: BODEGA, nombre: 'Bodega del laboratorio', tipo: 'bodega', plano: null, vista: 'lista' });

    // ---------- Muebles (en tres zonas) ----------
    const mueble = (id, tipo, nombre, x, y, girado) => {
      const tipoDatos = N.TIPOS_MUEBLE[tipo];
      datos.muebles.push({
        id: id, lugarId: LUGAR, tipo: tipo, nombre: nombre, x: x, y: y,
        ancho: girado ? tipoDatos.fondo : tipoDatos.ancho, fondo: girado ? tipoDatos.ancho : tipoDatos.fondo, giro: girado ? 1 : 0
      });
    };
    // Fondo: todo lo que se guarda, contra la pared (deja libre el centro)
    mueble('mu-casillero', 'casillero', 'Casillero de batas', 0, 0);
    mueble('mu-estante-a', 'estante', 'Estante de microscopía', 1, 0);
    mueble('mu-estante-b', 'estante', 'Estante de medición', 2, 0);
    mueble('mu-estante-c', 'estante', 'Estante de física', 3, 0);
    mueble('mu-vitrina-r', 'vitrina', 'Vitrina de reactivos', 4, 0);
    mueble('mu-vitrina-c', 'vitrina', 'Vitrina de cristalería', 6, 0);
    mueble('mu-gabinete', 'gabinete', 'Gabinete de seguridad', 8, 0);
    // Frente del salón: escritorio del profesor delante del pizarrón (girado, mirando al grupo)
    mueble('mu-escritorio', 'escritorio', 'Escritorio del profesor', 1, 3, true);
    // Centro: cuatro mesas de trabajo en cuadrícula, con pasillos de un metro
    [['1', 4, 2], ['2', 4, 5], ['3', 7, 2], ['4', 7, 5]].forEach(([numero, x, y]) => {
      mueble('mu-mesa-' + numero, 'mesa', 'Mesa ' + numero, x, y, true);
      mueble('mu-banco-' + numero + 'a', 'banco', 'Banco ' + numero + 'A', x + 1, y);
      mueble('mu-banco-' + numero + 'b', 'banco', 'Banco ' + numero + 'B', x + 1, y + 1);
    });
    // Entrada: lo que acaba de llegar y falta acomodar
    mueble('mu-caja', 'caja', 'Caja · Material por clasificar', 9, 7);

    // ---------- Artículos (alta hace un mes) ----------
    const ids = {};
    const alta = (clave, sitio, nombre, cantidad, categoria, extra) => {
      const ubicacion = sitio === 'sin' ? null : sitio === 'bodega' ? { lugarId: BODEGA } : sitio === 'lab' ? { lugarId: LUGAR } : { muebleId: sitio };
      const resultado = hacer(N.crearArticulo(datos, Object.assign({
        nombre: nombre, cantidad: cantidad, categoriaId: 'cat-' + categoria, ubicacion: ubicacion, codigo: '', notas: ''
      }, extra || {}), 'mu-art-' + clave), 30, '15:' + String(10 + (paso % 40)).padStart(2, '0'));
      ids[clave] = resultado.articulo.id;
    };
    const forma = (clave, figura, tamano, color) => {
      const articulo = N.buscarPorId(datos.articulos, ids[clave]);
      articulo.forma = { figura: figura, tamano: tamano, color: color };
    };
    const series = (clave, lista) => hacer(N.guardarSeries(datos, ids[clave], lista.join('\n')), 29);

    // Estante A · Microscopía
    alta('microscopio', 'mu-estante-a', 'Microscopio óptico', 6, 'laboratorio',
      { codigo: 'LAB-MIC-01', notas: 'Limpiar las lentes con papel óptico después de cada práctica.' });
    alta('portaobjetos', 'mu-estante-a', 'Portaobjetos (caja de 50)', 10, 'consumibles');
    alta('cubreobjetos', 'mu-estante-a', 'Cubreobjetos (caja de 100)', 8, 'consumibles');
    alta('lupa', 'mu-estante-a', 'Lupa de mano', 12, 'laboratorio');
    // Estante B · Medición
    alta('balanza', 'mu-estante-b', 'Balanza digital 0.01 g', 3, 'laboratorio',
      { codigo: 'LAB-BAL-01', notas: 'Calibrar cada lunes con la pesa de 100 g.' });
    alta('multimetro', 'mu-estante-b', 'Multímetro digital', 5, 'laboratorio', { codigo: 'LAB-MUL-01' });
    alta('termometro', 'mu-estante-b', 'Termómetro digital', 10, 'laboratorio');
    alta('cronometro', 'mu-estante-b', 'Cronómetro', 8, 'laboratorio');
    // Estante C · Física
    alta('circuitos', 'mu-estante-c', 'Kit de circuitos eléctricos', 6, 'laboratorio');
    alta('fuente', 'mu-estante-c', 'Fuente de poder 0–30 V', 4, 'laboratorio', { codigo: 'LAB-FTE-01' });
    alta('pesas', 'mu-estante-c', 'Juego de pesas con gancho', 5, 'laboratorio');
    alta('dinamometro', 'mu-estante-c', 'Dinamómetro', 10, 'laboratorio');
    // Vitrina de reactivos
    alta('sulfato', 'mu-vitrina-r', 'Sulfato de cobre (frasco 500 g)', 4, 'consumibles',
      { notas: 'Usar guantes. La hoja de seguridad está en el gabinete.' });
    alta('cloruro', 'mu-vitrina-r', 'Cloruro de sodio (frasco 1 kg)', 6, 'consumibles');
    alta('fenolftaleina', 'mu-vitrina-r', 'Fenolftaleína (gotero)', 5, 'consumibles');
    alta('indicador', 'mu-vitrina-r', 'Papel indicador universal', 10, 'consumibles');
    // Vitrina de cristalería
    alta('vaso', 'mu-vitrina-c', 'Vaso de precipitados 250 ml', 20, 'laboratorio');
    alta('matraz', 'mu-vitrina-c', 'Matraz Erlenmeyer 250 ml', 15, 'laboratorio');
    alta('probeta', 'mu-vitrina-c', 'Probeta graduada 100 ml', 12, 'laboratorio');
    alta('tubos', 'mu-vitrina-c', 'Tubos de ensayo (gradilla de 10)', 8, 'laboratorio');
    alta('mechero', 'mu-vitrina-c', 'Mechero Bunsen', 6, 'laboratorio');
    // Gabinete de seguridad
    alta('lentes', 'mu-gabinete', 'Lentes de seguridad', 30, 'seguridad');
    alta('guantes', 'mu-gabinete', 'Guantes de nitrilo (caja de 100)', 8, 'consumibles');
    alta('botiquin', 'mu-gabinete', 'Botiquín de primeros auxilios', 1, 'seguridad',
      { codigo: 'SEG-BOT-01', notas: 'Revisar caducidades el primer lunes de cada mes.' });
    // Casillero de batas
    alta('bata-m', 'mu-casillero', 'Bata de laboratorio (talla M)', 20, 'seguridad');
    alta('bata-g', 'mu-casillero', 'Bata de laboratorio (talla G)', 15, 'seguridad');
    // Escritorio del profesor
    alta('proyector', 'mu-escritorio', 'Proyector', 1, 'audiovisual', { codigo: 'AV-LAB-01' });
    alta('laptop', 'mu-escritorio', 'Laptop del laboratorio', 1, 'computo', { codigo: 'CMP-LAB-01' });
    // Caja · Material por clasificar
    alta('caimanes', 'mu-caja', 'Cables caimán (bolsa de 10)', 6, 'refacciones');
    alta('imanes', 'mu-caja', 'Imanes de barra', 10, 'laboratorio');
    // Directo en el piso del laboratorio (se dibujan como objetos 3D)
    alta('extintor', 'lab', 'Extintor PQS 4.5 kg', 1, 'seguridad', { codigo: 'SEG-EXT-01', notas: 'Próxima recarga: marzo.' });
    alta('agua', 'lab', 'Agua destilada (garrafón 20 L)', 3, 'consumibles');
    alta('residuos', 'lab', 'Contenedor de residuos químicos', 1, 'seguridad', { notas: 'Vaciar con el servicio de recolección los viernes.' });
    // Bodega del laboratorio (sin plano: solo lista)
    alta('charolas', 'bodega', 'Charolas de plástico', 12, 'laboratorio');
    alta('filtro', 'bodega', 'Papel filtro (paquete)', 15, 'consumibles');
    alta('soporte', 'bodega', 'Soporte universal', 6, 'laboratorio');
    alta('estereo', 'bodega', 'Microscopio estereoscópico', 2, 'laboratorio', { codigo: 'LAB-MIC-02', notas: 'Para disección. Se sube al laboratorio cuando se pide.' });
    // Recién llegado: todavía sin lugar
    alta('infrarrojo', 'sin', 'Termómetro infrarrojo', 2, 'laboratorio', { notas: 'Llegó esta semana. Falta asignarle lugar.' });

    series('microscopio', ['MO-1101', 'MO-1102', 'MO-1103', 'MO-1104', 'MO-1105', 'MO-1106']);
    series('balanza', ['BD-0451', 'BD-0452', 'BD-0453']);
    series('laptop', ['5CG2381QWX']);

    // Formas en 3D: frascos y vasos redondos, cristalería cónica, cajas para lo demás
    forma('sulfato', 'cilindro', 2, '#2f6fd6');
    forma('cloruro', 'cilindro', 2, '#e9edf2');
    forma('fenolftaleina', 'cilindro', 1, '#d64a8c');
    forma('indicador', 'caja', 1, '#f0b429');
    forma('vaso', 'cilindro', 2, '#9fd3e6');
    forma('matraz', 'piramide', 2, '#a8dcec');
    forma('probeta', 'cilindro', 1, '#bfe4f0');
    forma('tubos', 'prisma', 2, '#8fc7da');
    forma('mechero', 'cilindro', 2, '#5f6b76');
    forma('microscopio', 'prisma', 3, '#3b4252');
    forma('lupa', 'esfera', 1, '#c9a227');
    forma('balanza', 'caja', 2, '#e6e9ef');
    forma('lentes', 'caja', 1, '#f2c94c');
    forma('botiquin', 'caja', 2, '#e5484d');
    forma('imanes', 'caja', 1, '#d63031');
    forma('bata-m', 'caja', 3, '#f7f8fa');
    forma('bata-g', 'caja', 3, '#e9ecf1');
    forma('proyector', 'caja', 2, '#2b2f3a');
    forma('laptop', 'caja', 1, '#8a93a3');

    // ---------- Lo que pasó este mes (queda en el historial) ----------
    hacer(N.cambiarEstado(datos, ids.microscopio, { de: 'bueno', a: 'reparacion', cantidad: 1 }), 12, '11:20');
    hacer(N.cambiarEstado(datos, ids.fuente, { de: 'bueno', a: 'reparacion', cantidad: 1 }), 9, '12:05');
    hacer(N.cambiarEstado(datos, ids.vaso, { de: 'bueno', a: 'danado', cantidad: 2 }), 8, '10:40');
    hacer(N.darDeBaja(datos, ids.matraz, { estado: 'bueno', cantidad: 1, motivo: 'Se rompió en la práctica de 4.º A' }), 4, '13:15');
    hacer(N.agregarExistencias(datos, ids.guantes, 4), 5, '08:30');

    // ---------- Préstamos: un caso de cada uno ----------
    const prestar = (clave, idPrestamo, salida, limite, persona, grupo, cantidad, nota) =>
      hacer(N.prestar(datos, ids[clave], { persona: persona, grupo: grupo, cantidad: cantidad, fechaLimite: dia(limite), nota: nota || '' },
        dia(salida), idPrestamo), -salida, '08:' + String(10 + cantidad).padStart(2, '0'));
    // Devuelto (hace una semana)
    prestar('balanza', 'mu-pre-devuelto', -14, -7, 'Tomás Rivera', 'Club de robótica', 1, 'Pesar piezas del robot');
    hacer(N.devolver(datos, 'mu-pre-devuelto', dia(-8)), 8, '14:00');
    // Vencido hace 3 días
    prestar('multimetro', 'mu-pre-vencido', -10, -3, 'Prof. Andrés Molina', 'Física', 1, 'Feria de ciencias');
    // Devuelto en parte: regresaron 5 de 6, una dañada; falta una (regresa en 2 días)
    prestar('probeta', 'mu-pre-parcial', -6, 2, 'Ximena Cruz', '4.º A', 6, 'Práctica de densidades');
    hacer(N.devolver(datos, 'mu-pre-parcial', dia(-1), { cantidad: 5, danadas: 1, id: 'mu-pre-parcial-devuelto' }), 1, '13:30');
    // Vence hoy
    prestar('lentes', 'mu-pre-hoy', -3, 0, 'Valeria Soto', '3.º A', 4, 'Práctica de titulación');
    // Por vencer (mañana)
    prestar('proyector', 'mu-pre-manana', -2, 1, 'Mtra. Lucía Herrera', 'Ciencias', 1, 'Clase muestra para padres de familia');
    // Activo, con tiempo
    prestar('microscopio', 'mu-pre-activo', -1, 5, 'Diego Ramírez', '5.º B', 2, 'Proyecto de biología celular');

    // ---------- Objetos 3D ----------
    const objeto = (id, entrada) => hacer(N.crearObjeto(datos, Object.assign({ lugarId: LUGAR }, entrada), { sinRevisar: false }, id), 3, '16:00');
    // Zona de seguridad junto a la puerta: extintor y contenedor de residuos, enlazados a su artículo
    objeto('mu-obj-extintor', {
      figura: 'cilindro', nombre: 'Extintor', medidas: { ancho: 0.18, fondo: 0.18, alto: 0.6 }, pos: { x: 8.75, y: 1.3, z: 0.3 }, color: '#d63031'
    });
    objeto('mu-obj-residuos', {
      figura: 'cilindro', nombre: 'Residuos químicos', medidas: { ancho: 0.45, fondo: 0.45, alto: 0.7 }, pos: { x: 9.55, y: 1.4, z: 0.35 }, color: '#f0b429'
    });
    hacer(N.vincularObjetos(datos, ['mu-obj-extintor'], ids.extintor, { unidades: 1 }), 3);
    hacer(N.vincularObjetos(datos, ['mu-obj-residuos'], ids.residuos, { unidades: 1 }), 3);
    // Tres garrafones de agua destilada contra la pared derecha: tres piezas, tres objetos
    ['1', '2', '3'].forEach((n, i) => objeto('mu-obj-agua-' + n, {
      figura: 'cilindro', nombre: 'Garrafón', medidas: { ancho: 0.3, fondo: 0.3, alto: 0.5 }, pos: { x: 9.7, y: 3.6 + i * 0.36, z: 0.25 }, color: '#7fb8d8'
    }));
    hacer(N.vincularObjetos(datos, ['mu-obj-agua-1', 'mu-obj-agua-2', 'mu-obj-agua-3'], ids.agua, { unidades: 1 }), 3);
    // Cajas de reposición apiladas en la esquina de enfrente (figuras: aún no cuentan en el inventario)
    [0, 1, 2].forEach((n) => objeto('mu-obj-pila-' + (n + 1), {
      figura: 'caja', nombre: 'Caja de reposición', medidas: { ancho: 0.5, fondo: 0.4, alto: 0.3 },
      pos: { x: 0.45, y: 7.4, z: N.Espacio.redondear(0.15 + n * 0.3, 4) }, color: '#c08a52'
    }));
    // Sobre la Mesa 1: un microscopio armado con tres piezas, agrupado y guardado como modelo
    const pieza = (id, figura, medidas, pos, color) => objeto(id, { muebleId: 'mu-mesa-1', figura: figura, nombre: 'Microscopio de demostración', medidas: medidas, pos: pos, color: color });
    const sobreMesa = N.entornoDe(datos, { lugarId: LUGAR, muebleId: 'mu-mesa-1' }).niveles[0].z;
    pieza('mu-obj-mic-base', 'caja', { ancho: 0.2, fondo: 0.26, alto: 0.04 }, { x: 0.5, y: 0, z: sobreMesa + 0.02 }, '#3b4252');
    pieza('mu-obj-mic-brazo', 'caja', { ancho: 0.05, fondo: 0.06, alto: 0.3 }, { x: 0.5, y: -0.09, z: sobreMesa + 0.19 }, '#3b4252');
    pieza('mu-obj-mic-tubo', 'cilindro', { ancho: 0.08, fondo: 0.08, alto: 0.2 }, { x: 0.5, y: 0.03, z: sobreMesa + 0.14 }, '#cfd5df');
    const piezasMicro = ['mu-obj-mic-base', 'mu-obj-mic-brazo', 'mu-obj-mic-tubo'];
    hacer(N.agruparObjetos(datos, piezasMicro), 3);
    // El grupo recibe un id al azar: se fija para que la muestra salga siempre igual
    datos.objetos.filter((o) => piezasMicro.includes(o.id)).forEach((o) => { o.grupoId = 'mu-grupo-microscopio'; });
    hacer(N.guardarModelo(datos, piezasMicro, 'Microscopio', 'mu-modelo-microscopio'), 3);

    return datos;
  }

  const Muestra = { datosDeMuestra, LUGAR_MUESTRA: LUGAR };
  if (typeof module !== 'undefined' && module.exports) module.exports = Muestra;
  else raiz.Muestra = Muestra;
})(typeof window !== 'undefined' ? window : globalThis);
