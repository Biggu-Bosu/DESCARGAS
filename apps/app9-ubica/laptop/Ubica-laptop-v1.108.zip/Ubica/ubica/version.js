window.APP_VERSION = { numero: '1.108', fecha: '2026-11-13', commit: 'eb9a71d' };
