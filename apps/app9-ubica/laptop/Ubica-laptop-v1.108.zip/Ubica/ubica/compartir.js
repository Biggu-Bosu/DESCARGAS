// Ubica · Compartir archivos (respaldo .json y lista para Excel .csv). Tomado de Garage (app8).
// - App de Android: en el WebView no existen <a download> ni navigator.share con archivos.
//   Se escribe el archivo un momento en la caché (@capacitor/filesystem) y se abre el menú
//   Compartir de Android (@capacitor/share): Drive, correo, WhatsApp, Archivos…
// - iPhone / navegador del celular: menú Compartir del navegador con el archivo.
// - Computadora: descarga normal.
(function (raiz) {
  'use strict';

  // Los archivos grandes se escriben por partes para no mandar un texto enorme de una vez
  // por el puente entre JavaScript y Android. 3 MB, múltiplo de 3 para que cada parte en
  // base64 quede completa (base64 convierte cada 3 bytes en 4 letras).
  const TAMANO_PARTE = 3 * 1024 * 1024;

  function esNativa() {
    const capacitor = raiz.Capacitor;
    return Boolean(capacitor && capacitor.isNativePlatform && capacitor.isNativePlatform());
  }

  function pluginNativo(nombre) {
    const capacitor = raiz.Capacitor;
    if (!esNativa()) return null;
    if (typeof capacitor.isPluginAvailable === 'function' && !capacitor.isPluginAvailable(nombre)) {
      return null;
    }
    try {
      return (capacitor.Plugins && capacitor.Plugins[nombre]) || capacitor.registerPlugin(nombre);
    } catch (error) {
      return null;
    }
  }

  function esCelular() {
    return /android|iphone|ipad|ipod/i.test(navigator.userAgent);
  }

  function puedeCompartirWeb(archivo) {
    try {
      return Boolean(navigator.canShare && navigator.canShare({ files: [archivo] }));
    } catch (error) {
      return false;
    }
  }

  function blobABase64(blob) {
    return new Promise((resolver, rechazar) => {
      const lector = new FileReader();
      lector.onload = () => resolver(String(lector.result).split(',')[1] || '');
      lector.onerror = () => rechazar(lector.error);
      lector.readAsDataURL(blob);
    });
  }

  async function escribirEnCache(blob, nombre) {
    const sistemaArchivos = pluginNativo('Filesystem');
    let ruta = null;
    for (let inicio = 0; inicio < blob.size || inicio === 0; inicio += TAMANO_PARTE) {
      const parte = await blobABase64(blob.slice(inicio, inicio + TAMANO_PARTE));
      if (inicio === 0) {
        const escrito = await sistemaArchivos.writeFile({ path: nombre, data: parte, directory: 'CACHE' });
        ruta = escrito.uri;
      } else {
        await sistemaArchivos.appendFile({ path: nombre, data: parte, directory: 'CACHE' });
      }
      if (blob.size === 0) break;
    }
    return ruta;
  }

  // Devuelve 'compartido', 'cancelado' o 'error'
  async function compartirArchivo(blob, nombre, titulo) {
    try {
      if (esNativa()) {
        const menu = pluginNativo('Share');
        if (!pluginNativo('Filesystem') || !menu) return 'error';
        const ruta = await escribirEnCache(blob, nombre);
        await menu.share({ title: titulo || nombre, files: [ruta], dialogTitle: 'Guardar o enviar' });
        return 'compartido';
      }
      const archivo = new File([blob], nombre, { type: blob.type || 'application/octet-stream' });
      if (puedeCompartirWeb(archivo)) {
        await navigator.share({ files: [archivo], title: titulo || nombre });
        return 'compartido';
      }
      if (esCelular()) return 'error';
      // Navegador de computadora: descarga normal
      const enlace = document.createElement('a');
      enlace.href = URL.createObjectURL(archivo);
      enlace.download = nombre;
      document.body.appendChild(enlace);
      enlace.click();
      setTimeout(() => {
        URL.revokeObjectURL(enlace.href);
        enlace.remove();
      }, 1000);
      return 'compartido';
    } catch (error) {
      const mensaje = String((error && (error.message || error.name)) || '');
      if (/cancel|abort/i.test(mensaje)) return 'cancelado';
      console.error('No se pudo compartir', error);
      return 'error';
    }
  }

  raiz.Compartir = { esNativa, compartirArchivo };
})(window);
