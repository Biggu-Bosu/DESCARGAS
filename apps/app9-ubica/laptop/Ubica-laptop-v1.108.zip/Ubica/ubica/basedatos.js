// Ubica · Base de datos (IndexedDB).
// IndexedDB es una base de datos que trae el navegador (y el WebView de Android). Vive en el
// celular, funciona sin internet y guarda mucho más que localStorage (unos 5 MB).
// Tiene "almacenes" que funcionan como las tablas de MySQL. Cada registro tiene una llave "id"
// y algunos almacenes tienen índices para buscar rápido. Todas las funciones devuelven promesas.
//
// Versiones de la base:
//   1 → espacios, muebles, equipo y prestamos.
//   2 → se agrega el almacén "copias" (copias de seguridad automáticas).
//   3 → modelo de la Etapa 1A: lugares, muebles, articulos, prestamos, categorias y movimientos.
//       Los datos de la 1 o la 2 se convierten DENTRO de la transacción de actualización:
//       si algo falla a la mitad, el navegador deshace todo y la base queda como estaba.
//       Antes de convertir, la app revisa los datos (Nucleo.planDeMigracion) y, si encontró algo
//       que corregir, se lo muestra a la persona. La conversión solo corre si el plan que se
//       calcula aquí es idéntico al que se aprobó (misma "huella").
(function (raiz) {
  'use strict';

  const NOMBRE_BD = 'ubica';
  // El espacio de muestra vive en OTRA base de IndexedDB, con la misma estructura. Así nunca se
  // mezcla con los datos reales. La app SIEMPRE arranca en la base real: en qué base se está
  // solo se recuerda en esta variable (en memoria), no en el disco.
  const NOMBRE_MUESTRA = 'ubica-muestra';
  let nombreActivo = NOMBRE_BD;
  // 3: lugares, muebles, artículos… · 4: agrega «objetos» y «modelos» (figuras 3D). Pasar de la 3 a
  // la 4 solo crea esas dos tablas vacías: no toca ningún dato, así que no necesita aprobación.
  const VERSION_BD = 4;
  const VERSION_SIN_CONVERSION = 3; // desde esta versión no hace falta convertir datos
  const Nucleo = raiz.Nucleo;
  const { TABLAS, TABLA_COPIAS, INDICES, TABLAS_ANTIGUAS } = Nucleo;

  let promesaBd = null;
  let huellaAprobada = null; // plan de migración que la persona aprobó (solo en esta sesión)

  // Errores con un código para que la app sepa qué pantalla mostrar
  function errorCon(codigo, mensaje) {
    const error = new Error(mensaje);
    error.codigo = codigo;
    return error;
  }

  function hoyLocal() {
    return Nucleo.fechaISO(new Date());
  }

  // Lee varios almacenes dentro de una transacción ya abierta y llama "listo" con los resultados
  function leerAlmacenes(tx, nombres, listo) {
    const resultado = {};
    let pendientes = nombres.length;
    if (!pendientes) {
      listo(resultado);
      return;
    }
    nombres.forEach((nombre) => {
      const pedido = tx.objectStore(nombre).getAll();
      pedido.onsuccess = () => {
        resultado[nombre] = pedido.result;
        pendientes--;
        if (!pendientes) listo(resultado);
      };
    });
  }

  function crearTablasNuevas(bd) {
    TABLAS.forEach((tabla) => {
      const almacen = bd.createObjectStore(tabla, { keyPath: 'id' });
      INDICES[tabla].forEach((campo) => almacen.createIndex(campo, campo));
    });
    if (!bd.objectStoreNames.contains(TABLA_COPIAS)) bd.createObjectStore(TABLA_COPIAS, { keyPath: 'id' });
  }

  // Convierte la base 1 o 2 a la 3. Corre dentro de la transacción "versionchange".
  function migrar(bd, tx, versionAnterior) {
    const viejas = TABLAS_ANTIGUAS.filter((tabla) => bd.objectStoreNames.contains(tabla));
    const conCopias = bd.objectStoreNames.contains(TABLA_COPIAS);
    leerAlmacenes(tx, viejas.concat(conCopias ? [TABLA_COPIAS] : []), (leido) => {
      const crudos = {};
      TABLAS_ANTIGUAS.forEach((tabla) => {
        crudos[tabla] = leido[tabla] || [];
      });
      const plan = Nucleo.planDeMigracion(crudos, versionAnterior, { hoy: hoyLocal() });
      // Doble seguro: lo que se va a aplicar debe ser EXACTAMENTE lo aprobado, y la comprobación
      // de que no se pierde nada debe pasar. Si no, se cancela y la base no cambia.
      if (plan.huella !== huellaAprobada || !plan.comprobacion.ok) {
        tx.abort();
        return;
      }
      const momento = new Date().toISOString();
      // 1) Copia de seguridad de los datos tal como estaban (formato 1), en la misma transacción
      const original = { app: 'ubica', formato: 1, exportado: momento };
      TABLAS_ANTIGUAS.forEach((tabla) => {
        original[tabla] = crudos[tabla];
      });
      const copia = {
        id: 'copia-' + momento + '-migracion',
        momento: momento,
        dia: hoyLocal(),
        motivo: 'antes-de-migrar',
        resumen: { lugares: plan.antes.lugares, muebles: plan.antes.muebles, piezas: plan.antes.piezas, prestamos: plan.antes.prestamos },
        datos: original
      };
      // 2) Se quitan las tablas viejas y se crean las nuevas
      viejas.forEach((tabla) => bd.deleteObjectStore(tabla));
      crearTablasNuevas(bd);
      const copias = tx.objectStore(TABLA_COPIAS);
      Nucleo.copiasQueSobran(leido[TABLA_COPIAS] || [], 1).forEach((id) => copias.delete(id));
      copias.put(copia);
      // 3) Se guardan los datos convertidos y un movimiento que deja constancia de la migración
      plan.datos.movimientos.push(Nucleo.movimientoGeneral('migracion', momento, {
        desdeVersion: versionAnterior, antes: plan.antes, despues: plan.despues,
        correcciones: plan.hallazgos.map((hallazgo) => hallazgo.texto)
      }));
      TABLAS.forEach((tabla) => {
        const almacen = tx.objectStore(tabla);
        plan.datos[tabla].forEach((registro) => almacen.put(registro));
      });
    });
  }

  function abrir() {
    if (promesaBd) return promesaBd;
    promesaBd = new Promise((resolver, rechazar) => {
      if (!raiz.indexedDB) {
        rechazar(errorCon('sin-indexeddb', 'Este navegador no tiene IndexedDB.'));
        return;
      }
      let sinAprobar = false;
      const nombre = nombreActivo;
      const pedido = raiz.indexedDB.open(nombre, VERSION_BD);
      pedido.onupgradeneeded = (evento) => {
        const bd = pedido.result;
        const tx = pedido.transaction;
        const versionAnterior = evento.oldVersion;
        if (versionAnterior === 0) {
          // Base nueva: tablas vacías y las categorías iniciales
          crearTablasNuevas(bd);
          const categorias = tx.objectStore('categorias');
          Nucleo.categoriasIniciales().forEach((categoria) => categorias.put(categoria));
          return;
        }
        if (versionAnterior >= VERSION_SIN_CONVERSION || nombre !== NOMBRE_BD) {
          // Solo faltan tablas nuevas (vacías): se crean sin tocar las demás
          TABLAS.forEach((tabla) => {
            if (bd.objectStoreNames.contains(tabla)) return;
            const almacen = bd.createObjectStore(tabla, { keyPath: 'id' });
            (INDICES[tabla] || []).forEach((indice) => almacen.createIndex(indice, indice));
          });
          return;
        }
        if (huellaAprobada == null) {
          // Nunca se migra sin que la app haya revisado (y, si hacía falta, la persona aprobado) el plan
          sinAprobar = true;
          tx.abort();
          return;
        }
        migrar(bd, tx, versionAnterior);
      };
      pedido.onsuccess = () => {
        const bd = pedido.result;
        // Si otra pestaña abre una versión nueva, esta se cierra para no bloquearla
        bd.onversionchange = () => {
          bd.close();
          promesaBd = null; // la próxima operación vuelve a abrirla
        };
        huellaAprobada = null;
        resolver(bd);
      };
      pedido.onerror = () => {
        const error = pedido.error;
        if (sinAprobar) rechazar(errorCon('migracion-pendiente', 'Hay que revisar los datos antes de actualizarlos.'));
        else if (error && error.name === 'VersionError') {
          rechazar(errorCon('version-nueva', 'Tus datos son de una versión más nueva de Ubica. Actualiza la app para abrirlos.'));
        } else if (error && error.name === 'AbortError') {
          rechazar(errorCon('migracion-cancelada', 'No se pudieron actualizar los datos. Tus datos siguen como estaban.'));
        } else rechazar(error || new Error('No se pudo abrir la base de datos.'));
      };
      pedido.onblocked = () => {
        rechazar(errorCon('bloqueada', 'La base de datos está ocupada. Cierra otras pestañas o ventanas de Ubica.'));
      };
    });
    // Si falla, la próxima llamada lo vuelve a intentar
    promesaBd.catch(() => {
      promesaBd = null;
    });
    return promesaBd;
  }

  // Mira la base SIN cambiarla: qué versión tiene y, si es vieja, sus datos.
  // Abrir sin número de versión abre la que exista. Si no existe ninguna, el navegador la
  // crearía vacía: se cancela para no dejar una base "versión 1" sin tablas.
  // Devuelve { version: 0 } (no hay base), { version: 3 } (al día) o
  // { version: 1|2, crudos: { espacios, muebles, equipo, prestamos } }.
  function inspeccionar() {
    return new Promise((resolver, rechazar) => {
      if (!raiz.indexedDB) {
        rechazar(errorCon('sin-indexeddb', 'Este navegador no tiene IndexedDB.'));
        return;
      }
      let nueva = false;
      const pedido = raiz.indexedDB.open(NOMBRE_BD);
      pedido.onupgradeneeded = () => {
        nueva = true;
        pedido.transaction.abort();
      };
      pedido.onerror = (evento) => {
        if (evento && evento.preventDefault) evento.preventDefault();
        if (nueva) resolver({ version: 0 });
        else rechazar(pedido.error || new Error('No se pudo revisar la base de datos.'));
      };
      pedido.onsuccess = () => {
        const bd = pedido.result;
        const version = bd.version;
        if (version >= VERSION_SIN_CONVERSION) {
          // Al día, o solo le faltan tablas nuevas vacías (se agregan solas al abrir)
          bd.close();
          resolver({ version: version });
          return;
        }
        const viejas = TABLAS_ANTIGUAS.filter((tabla) => bd.objectStoreNames.contains(tabla));
        if (!viejas.length) {
          bd.close();
          resolver({ version: version, crudos: {} });
          return;
        }
        const tx = bd.transaction(viejas, 'readonly');
        leerAlmacenes(tx, viejas, (leido) => {
          const crudos = {};
          TABLAS_ANTIGUAS.forEach((tabla) => {
            crudos[tabla] = leido[tabla] || [];
          });
          tx.oncomplete = () => {
            bd.close();
            resolver({ version: version, crudos: crudos });
          };
        });
        tx.onerror = () => {
          bd.close();
          rechazar(tx.error);
        };
      };
    });
  }

  // La app llama esto con la huella del plan revisado justo antes de abrir()
  function aprobarMigracion(huella) {
    huellaAprobada = huella;
  }

  // Ejecuta "accion" dentro de una transacción y espera a que quede escrita del todo
  // (oncomplete), no solo a que el pedido responda: así un cierre repentino no pierde datos.
  // Una transacción es "todo o nada": si algo falla a la mitad, no se guarda nada.
  function transaccion(tablas, modo, accion) {
    return abrir().then(
      (bd) =>
        new Promise((resolver, rechazar) => {
          const tx = bd.transaction(tablas, modo);
          let resultado;
          accion(tx, (valor) => {
            resultado = valor;
          });
          tx.oncomplete = () => resolver(resultado);
          tx.onerror = () => rechazar(tx.error);
          tx.onabort = () => rechazar(tx.error || new Error('No se guardó: la operación se canceló.'));
        })
    );
  }

  // Lee todas las tablas en una sola transacción (una "foto" consistente de los datos)
  function leerTodo() {
    return transaccion(TABLAS, 'readonly', (tx, guardarResultado) => {
      const datos = {};
      TABLAS.forEach((tabla) => {
        const pedido = tx.objectStore(tabla).getAll();
        pedido.onsuccess = () => {
          datos[tabla] = pedido.result;
        };
      });
      guardarResultado(datos);
    });
  }

  // Aplica varios cambios en una sola transacción.
  // cambios: [{ tabla, poner: registro } o { tabla, borrar: id }] (los que arma nucleo.js)
  function escribir(cambios) {
    if (!cambios.length) return Promise.resolve();
    const tablas = Array.from(new Set(cambios.map((cambio) => cambio.tabla)));
    return transaccion(tablas, 'readwrite', (tx) => {
      cambios.forEach((cambio) => {
        const almacen = tx.objectStore(cambio.tabla);
        if (cambio.poner) almacen.put(cambio.poner);
        else almacen.delete(cambio.borrar);
      });
    });
  }

  // Reemplaza TODO (al restaurar un respaldo o cargar el ejemplo). Todo o nada.
  // copia (opcional): copia de seguridad de lo que había, que se guarda EN LA MISMA transacción.
  // Así es imposible que se reemplacen los datos sin que la copia haya quedado guardada.
  // copiasABorrar (opcional): ids de copias viejas que salen para no pasar del máximo.
  function reemplazarTodo(datos, copia, copiasABorrar) {
    return transaccion(TABLAS.concat([TABLA_COPIAS]), 'readwrite', (tx) => {
      if (copia && !enMuestra()) {
        const copias = tx.objectStore(TABLA_COPIAS);
        (copiasABorrar || []).forEach((id) => copias.delete(id));
        copias.put(copia);
      }
      TABLAS.forEach((tabla) => {
        const almacen = tx.objectStore(tabla);
        almacen.clear();
        (datos[tabla] || []).forEach((registro) => almacen.put(registro));
      });
    });
  }

  // ---------- Copias de seguridad ----------
  function leerCopias() {
    return transaccion([TABLA_COPIAS], 'readonly', (tx, guardarResultado) => {
      const pedido = tx.objectStore(TABLA_COPIAS).getAll();
      pedido.onsuccess = () => guardarResultado(pedido.result);
    });
  }

  function guardarCopia(copia, copiasABorrar) {
    if (enMuestra()) return Promise.resolve(); // la muestra no guarda copias automáticas
    return transaccion([TABLA_COPIAS], 'readwrite', (tx) => {
      const copias = tx.objectStore(TABLA_COPIAS);
      (copiasABorrar || []).forEach((id) => copias.delete(id));
      copias.put(copia);
    });
  }

  // Salida de emergencia: si la app no puede abrir la base (versión más nueva, migración
  // cancelada…), lee TODO lo que haya, sea de la versión que sea, para descargarlo como respaldo.
  function exportarEmergencia() {
    return new Promise((resolver, rechazar) => {
      const pedido = raiz.indexedDB.open(NOMBRE_BD);
      pedido.onupgradeneeded = () => pedido.transaction.abort();
      pedido.onerror = (evento) => {
        if (evento && evento.preventDefault) evento.preventDefault();
        rechazar(pedido.error || new Error('No hay datos que exportar.'));
      };
      pedido.onsuccess = () => {
        const bd = pedido.result;
        const nombres = Array.from(bd.objectStoreNames).filter((nombre) => nombre !== TABLA_COPIAS);
        const respaldo = { app: 'ubica', formato: bd.version >= 3 ? 2 : 1, exportado: new Date().toISOString(), versionBase: bd.version };
        if (!nombres.length) {
          bd.close();
          resolver(respaldo);
          return;
        }
        const tx = bd.transaction(nombres, 'readonly');
        leerAlmacenes(tx, nombres, (leido) => {
          Object.assign(respaldo, leido);
        });
        tx.oncomplete = () => {
          bd.close();
          resolver(respaldo);
        };
        tx.onerror = () => {
          bd.close();
          rechazar(tx.error);
        };
      };
    });
  }

  // ---------- Espacio de muestra ----------
  const enMuestra = () => nombreActivo === NOMBRE_MUESTRA;

  // Cierra la conexión actual y hace que las siguientes operaciones usen otra base
  function cambiarDeBase(nombre) {
    const anterior = promesaBd;
    promesaBd = null;
    nombreActivo = nombre;
    return anterior ? anterior.then((bd) => bd.close(), () => {}) : Promise.resolve();
  }
  const usarMuestra = () => cambiarDeBase(NOMBRE_MUESTRA);
  const usarMisDatos = () => cambiarDeBase(NOMBRE_BD);

  // Borra la base de la muestra. Solo puede borrar ESA base (el nombre está escrito aquí, no
  // llega de fuera) y solo cuando la app ya regresó a tus datos.
  function borrarMuestra() {
    if (enMuestra()) return Promise.reject(new Error('Primero hay que regresar a tus datos.'));
    return new Promise((resolver, rechazar) => {
      const pedido = raiz.indexedDB.deleteDatabase(NOMBRE_MUESTRA);
      pedido.onsuccess = () => resolver();
      pedido.onerror = () => rechazar(pedido.error || new Error('No se pudo borrar la muestra.'));
    });
  }

  // ¿Existe esta base? Se abre sin número de versión; si el navegador iba a crearla, se cancela
  // (así no queda una base vacía nueva).
  function abrirSiExiste(nombre) {
    return new Promise((resolver, rechazar) => {
      let nueva = false;
      const pedido = raiz.indexedDB.open(nombre);
      pedido.onupgradeneeded = () => {
        nueva = true;
        pedido.transaction.abort();
      };
      pedido.onerror = (evento) => {
        if (evento && evento.preventDefault) evento.preventDefault();
        if (nueva) resolver(null);
        else rechazar(pedido.error || new Error('No se pudo abrir la base.'));
      };
      pedido.onsuccess = () => resolver(pedido.result);
    });
  }

  // Para el visor «Ver base de datos»: TODOS los almacenes de una base (tus datos o la muestra),
  // con su estructura y sus registros tal como están guardados. Solo lee: abre, lee y cierra.
  // Devuelve null si esa base no existe.
  async function describirBase(cual) {
    const nombre = cual === 'muestra' ? NOMBRE_MUESTRA : NOMBRE_BD;
    const bd = await abrirSiExiste(nombre);
    if (!bd) return null;
    const nombres = Array.from(bd.objectStoreNames);
    return new Promise((resolver, rechazar) => {
      const salida = { nombre: nombre, version: bd.version, tablas: [] };
      if (!nombres.length) {
        bd.close();
        resolver(salida);
        return;
      }
      const tx = bd.transaction(nombres, 'readonly');
      salida.tablas = nombres.map((almacenNombre) => {
        const almacen = tx.objectStore(almacenNombre);
        const info = {
          nombre: almacenNombre,
          llave: almacen.keyPath,
          detalleIndices: Array.from(almacen.indexNames).map((indice) => {
            const i = almacen.index(indice);
            return { nombre: indice, campo: i.keyPath, unico: i.unique, multiple: i.multiEntry };
          }),
          autoIncremento: almacen.autoIncrement,
          registros: []
        };
        const pedido = almacen.getAll();
        pedido.onsuccess = () => {
          info.registros = pedido.result;
        };
        return info;
      });
      tx.oncomplete = () => {
        bd.close();
        resolver(salida);
      };
      tx.onerror = () => {
        bd.close();
        rechazar(tx.error);
      };
    });
  }

  // ¿Quedó una muestra de antes (por ejemplo, si se cerró la app sin salir de ella)?
  async function hayMuestra() {
    const bd = await abrirSiExiste(NOMBRE_MUESTRA);
    if (bd) bd.close();
    return Boolean(bd);
  }

  // (Formato anterior del visor) estructura y contenido de las tablas de la base activa
  function describir() {
    return transaccion(TABLAS, 'readonly', (tx, guardarResultado) => {
      const tablas = TABLAS.map((nombre) => {
        const almacen = tx.objectStore(nombre);
        const info = {
          nombre: nombre,
          llave: almacen.keyPath,
          indices: Array.from(almacen.indexNames),
          // Para el visor: cada índice con el campo que ordena y si exige valores únicos
          detalleIndices: Array.from(almacen.indexNames).map((indice) => {
            const i = almacen.index(indice);
            return { nombre: indice, campo: i.keyPath, unico: i.unique, multiple: i.multiEntry };
          }),
          autoIncremento: almacen.autoIncrement,
          registros: []
        };
        const pedido = almacen.getAll();
        pedido.onsuccess = () => {
          info.registros = pedido.result;
        };
        return info;
      });
      guardarResultado({ nombre: nombreActivo, version: VERSION_BD, tablas: tablas });
    });
  }

  // Pide al sistema que no borre los datos de Ubica cuando falte espacio (si lo permite).
  function pedirQueNoSeBorre() {
    try {
      if (navigator.storage && navigator.storage.persist) return navigator.storage.persist();
    } catch (error) {
      // Algunos navegadores no lo permiten: no pasa nada
    }
    return Promise.resolve(false);
  }

  raiz.BaseDatos = {
    VERSION_BD, VERSION_SIN_CONVERSION, abrir, inspeccionar, aprobarMigracion, leerTodo, escribir, reemplazarTodo,
    leerCopias, guardarCopia, exportarEmergencia, describir, pedirQueNoSeBorre,
    NOMBRE_BD, NOMBRE_MUESTRA, enMuestra, usarMuestra, usarMisDatos, borrarMuestra, hayMuestra, describirBase
  };
})(window);
