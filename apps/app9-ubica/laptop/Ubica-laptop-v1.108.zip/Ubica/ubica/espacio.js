// Ubica · Espacio: geometría 3D y reglas espaciales de los objetos (sin pantalla ni Three.js).
// Se prueba con node igual que nucleo.js.
//
// Unidades y ejes (los mismos que el plano):
//   - Todo en METROS. Una casilla del plano mide 1 m.
//   - x = ancho (de izquierda a derecha), y = fondo (de atrás hacia adelante), z = altura.
//   - La altura de los muebles del catálogo viene en «pisos»: 1 piso = METROS_POR_PISO metros.
//
// Un objeto guarda:
//   pos     → el CENTRO de su caja (x, y, z), en metros.
//   medidas → { ancho, fondo, alto } de su caja SIN girar.
//   rot     → giros en grados alrededor de x, y, z. Se aplican en ese orden: primero x, luego y,
//             al final z (z es el giro «visto desde arriba»). Matriz: R = Rz · Ry · Rx.
// Un objeto dentro de un mueble guarda pos y rot RELATIVOS al mueble (centro de su huella, sin
// girar): si el mueble se mueve o gira, el objeto lo acompaña sin cambiar sus datos.
//
// Reglas (revisar):
//   - error  → no se guarda: atraviesa una pared, el piso, el techo o una repisa, o choca con
//              un mueble u otro objeto sólido (esto último se puede permitir en la configuración).
//   - aviso  → se guarda pero se marca: queda flotando o sobresale de su mueble.
(function (raiz) {
  'use strict';

  const METROS_POR_PISO = 1.15;  // lo mismo que usa la escena 3D para la altura de los muebles
  const ALTURA_LUGAR = 4;        // techo de un lugar (m)
  const HOLGURA = 0.002;         // 2 mm: tocarse no es chocar (las llantas apiladas se tocan)
  const TOLERANCIA_APOYO = 0.012; // a menos de 1.2 cm de una superficie, se considera apoyado
  const MEDIDA_MINIMA = 0.02;
  const MEDIDA_MAXIMA = 12;

  // Figuras disponibles. "redonda": su corte visto desde arriba es un círculo (si está de pie).
  const FIGURAS = {
    caja: { nombre: 'Caja', redonda: false },
    cilindro: { nombre: 'Cilindro', redonda: true },
    tubo: { nombre: 'Tubo hueco', redonda: true },
    esfera: { nombre: 'Esfera', redonda: true },
    cono: { nombre: 'Cono', redonda: true },
    aro: { nombre: 'Aro (llanta)', redonda: true },
    prisma: { nombre: 'Prisma triangular', redonda: false },
    piramide: { nombre: 'Pirámide', redonda: false }
  };

  const redondear = (valor, decimales) => {
    const factor = Math.pow(10, decimales == null ? 3 : decimales);
    return Math.round(valor * factor) / factor;
  };
  const radianes = (grados) => (grados * Math.PI) / 180;
  const grados = (rad) => (rad * 180) / Math.PI;

  // Lleva un ángulo a (-180, 180]
  function normalizarAngulo(angulo) {
    let a = Number(angulo) % 360;
    if (a <= -180) a += 360;
    if (a > 180) a -= 360;
    return redondear(a, 2) || 0; // sin «-0»
  }

  // ---------------------------------------------------------------------
  // Matrices de 3 × 3 (listas de filas)
  // ---------------------------------------------------------------------
  function multiplicar(a, b) {
    const r = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) r[i][j] = a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j];
    }
    return r;
  }

  function aplicar(m, v) {
    return [
      m[0][0] * v[0] + m[0][1] * v[1] + m[0][2] * v[2],
      m[1][0] * v[0] + m[1][1] * v[1] + m[1][2] * v[2],
      m[2][0] * v[0] + m[2][1] * v[1] + m[2][2] * v[2]
    ];
  }

  function giroZ(gradosZ) {
    const c = Math.cos(radianes(gradosZ));
    const s = Math.sin(radianes(gradosZ));
    return [[c, -s, 0], [s, c, 0], [0, 0, 1]];
  }

  // R = Rz · Ry · Rx
  function matrizRotacion(rot) {
    const r = rot || {};
    const [cx, sx] = [Math.cos(radianes(r.x || 0)), Math.sin(radianes(r.x || 0))];
    const [cy, sy] = [Math.cos(radianes(r.y || 0)), Math.sin(radianes(r.y || 0))];
    const rx = [[1, 0, 0], [0, cx, -sx], [0, sx, cx]];
    const ry = [[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]];
    return multiplicar(giroZ(r.z || 0), multiplicar(ry, rx));
  }

  // El giro (x, y, z en grados) que produce la matriz m (la inversa de matrizRotacion)
  function rotacionDesdeMatriz(m) {
    const senY = Math.max(-1, Math.min(1, -m[2][0]));
    let x;
    let z;
    const y = Math.asin(senY);
    if (Math.abs(senY) < 0.99999) {
      x = Math.atan2(m[2][1], m[2][2]);
      z = Math.atan2(m[1][0], m[0][0]);
    } else {
      // «Bloqueo de cardán»: x y z giran sobre el mismo eje; se pone todo en z
      x = 0;
      z = Math.atan2(-m[0][1], m[1][1]);
    }
    return { x: normalizarAngulo(grados(x)), y: normalizarAngulo(grados(y)), z: normalizarAngulo(grados(z)) };
  }

  // Three.js usa la altura como su eje Y. Cambiar y ↔ z convierte una matriz de un sistema al
  // otro (en los dos sentidos: la operación es su propia inversa).
  function cambiarEjesYZ(m) {
    const p = [0, 2, 1];
    return [0, 1, 2].map((i) => [0, 1, 2].map((j) => m[p[i]][p[j]]));
  }

  // ---------------------------------------------------------------------
  // Muebles: dónde está su "marco" (el centro de su huella y hacia dónde mira)
  // ---------------------------------------------------------------------
  // giro del mueble (0 a 3 cuartos de vuelta) → grados alrededor de z. Coincide con la escena 3D.
  function poseDeMueble(mueble) {
    return { x: mueble.x + mueble.ancho / 2, y: mueble.y + mueble.fondo / 2, giro: ((mueble.giro || 0) % 4) * 90 };
  }

  function aMundo(pose, punto) {
    const g = giroZ(pose.giro);
    const p = aplicar(g, [punto.x, punto.y, punto.z || 0]);
    return { x: p[0] + pose.x, y: p[1] + pose.y, z: p[2] };
  }

  function aLocal(pose, punto) {
    const g = giroZ(-pose.giro);
    const p = aplicar(g, [punto.x - pose.x, punto.y - pose.y, punto.z || 0]);
    return { x: p[0], y: p[1], z: p[2] };
  }

  // Un objeto del mueble, expresado en el marco del lugar
  function objetoAMundo(pose, objeto) {
    return Object.assign({}, objeto, {
      pos: aMundo(pose, objeto.pos),
      rot: rotacionDesdeMatriz(multiplicar(giroZ(pose.giro), matrizRotacion(objeto.rot)))
    });
  }

  // Un objeto del lugar, expresado en el marco de un mueble
  function objetoALocal(pose, objeto) {
    return Object.assign({}, objeto, {
      pos: aLocal(pose, objeto.pos),
      rot: rotacionDesdeMatriz(multiplicar(giroZ(-pose.giro), matrizRotacion(objeto.rot)))
    });
  }

  // ---------------------------------------------------------------------
  // Formas para los choques
  // ---------------------------------------------------------------------
  // Dos tipos:
  //   'cilindro' → figura redonda de pie (llanta, barril, tubo vertical): círculo × altura.
  //   'caja'     → caja orientada (centro, medias medidas y sus tres ejes). Sirve para todo lo demás
  //                (una figura redonda acostada se trata como la caja que la envuelve).
  const casiCero = (angulo) => Math.abs(normalizarAngulo(angulo)) < 0.5 || Math.abs(Math.abs(normalizarAngulo(angulo)) - 180) < 0.5;

  function formaDeChoque(objeto, id, nombre) {
    const m = objeto.medidas;
    const figura = FIGURAS[objeto.figura] || FIGURAS.caja;
    const rot = objeto.rot || {};
    if (figura.redonda && casiCero(rot.x || 0) && casiCero(rot.y || 0) && Math.abs(m.ancho - m.fondo) < Math.max(m.ancho, m.fondo) * 0.02) {
      const radio = Math.max(m.ancho, m.fondo) / 2;
      return {
        tipo: 'cilindro', id: id, nombre: nombre, x: objeto.pos.x, y: objeto.pos.y, radio: radio,
        z0: objeto.pos.z - m.alto / 2, z1: objeto.pos.z + m.alto / 2
      };
    }
    const r = matrizRotacion(rot);
    return {
      tipo: 'caja', id: id, nombre: nombre,
      centro: [objeto.pos.x, objeto.pos.y, objeto.pos.z],
      medias: [m.ancho / 2, m.fondo / 2, m.alto / 2],
      ejes: [[r[0][0], r[1][0], r[2][0]], [r[0][1], r[1][1], r[2][1]], [r[0][2], r[1][2], r[2][2]]]
    };
  }

  // Caja alineada a los ejes (por ejemplo, el cuerpo de un mueble)
  function cajaRecta(min, max, id, nombre, tipo) {
    return {
      tipo: 'caja', id: id, nombre: nombre, solido: tipo,
      centro: [(min[0] + max[0]) / 2, (min[1] + max[1]) / 2, (min[2] + max[2]) / 2],
      medias: [(max[0] - min[0]) / 2, (max[1] - min[1]) / 2, (max[2] - min[2]) / 2],
      ejes: [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
    };
  }

  // La caja alineada a los ejes que envuelve la forma
  function limites(forma) {
    if (forma.tipo === 'cilindro') {
      return { min: [forma.x - forma.radio, forma.y - forma.radio, forma.z0], max: [forma.x + forma.radio, forma.y + forma.radio, forma.z1] };
    }
    const extension = [0, 1, 2].map((i) => forma.ejes.reduce((suma, eje, k) => suma + Math.abs(eje[i]) * forma.medias[k], 0));
    return {
      min: forma.centro.map((c, i) => c - extension[i]),
      max: forma.centro.map((c, i) => c + extension[i])
    };
  }

  const punto = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cruz = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];

  // Teorema del eje separador: dos cajas orientadas NO se tocan si existe un eje donde sus
  // sombras quedan separadas. Se prueban 15 ejes (3 + 3 propios y sus 9 productos cruz).
  function cajasSeCruzan(a, b) {
    const t = [b.centro[0] - a.centro[0], b.centro[1] - a.centro[1], b.centro[2] - a.centro[2]];
    const ejes = a.ejes.concat(b.ejes);
    a.ejes.forEach((ea) => b.ejes.forEach((eb) => {
      const c = cruz(ea, eb);
      if (punto(c, c) > 1e-9) ejes.push(c);
    }));
    return ejes.every((eje) => {
      const largo = Math.sqrt(punto(eje, eje));
      const n = [eje[0] / largo, eje[1] / largo, eje[2] / largo];
      const ra = a.ejes.reduce((suma, e, k) => suma + Math.abs(punto(e, n)) * a.medias[k], 0);
      const rb = b.ejes.reduce((suma, e, k) => suma + Math.abs(punto(e, n)) * b.medias[k], 0);
      return Math.abs(punto(t, n)) < ra + rb - HOLGURA;
    });
  }

  const alturasSeCruzan = (a0, a1, b0, b1) => Math.min(a1, b1) - Math.max(a0, b0) > HOLGURA;

  // ¿Un círculo se encima con una caja que está de pie (sin inclinar)?
  function circuloYCajaDePie(cilindro, caja) {
    const dx = cilindro.x - caja.centro[0];
    const dy = cilindro.y - caja.centro[1];
    // Centro del círculo visto desde la caja
    const u = dx * caja.ejes[0][0] + dy * caja.ejes[0][1];
    const v = dx * caja.ejes[1][0] + dy * caja.ejes[1][1];
    const cu = Math.max(-caja.medias[0], Math.min(caja.medias[0], u));
    const cv = Math.max(-caja.medias[1], Math.min(caja.medias[1], v));
    return Math.hypot(u - cu, v - cv) < cilindro.radio - HOLGURA;
  }

  const cajaDePie = (caja) => Math.abs(caja.ejes[2][2]) > 0.9999;

  function comoCaja(cilindro) {
    return cajaRecta([cilindro.x - cilindro.radio, cilindro.y - cilindro.radio, cilindro.z0],
      [cilindro.x + cilindro.radio, cilindro.y + cilindro.radio, cilindro.z1], cilindro.id, cilindro.nombre);
  }

  // ¿Dos formas ocupan parte del mismo volumen? (tocarse no cuenta)
  function seCruzan(a, b) {
    if (a.tipo === 'cilindro' && b.tipo === 'cilindro') {
      return alturasSeCruzan(a.z0, a.z1, b.z0, b.z1) && Math.hypot(a.x - b.x, a.y - b.y) < a.radio + b.radio - HOLGURA;
    }
    if (a.tipo === 'cilindro' || b.tipo === 'cilindro') {
      const cilindro = a.tipo === 'cilindro' ? a : b;
      const caja = a.tipo === 'cilindro' ? b : a;
      if (cajaDePie(caja)) {
        const lim = limites(caja);
        return alturasSeCruzan(cilindro.z0, cilindro.z1, lim.min[2], lim.max[2]) && circuloYCajaDePie(cilindro, caja);
      }
      return cajasSeCruzan(comoCaja(cilindro), caja);
    }
    return cajasSeCruzan(a, b);
  }

  // ¿Sus huellas en el piso se enciman (con algo de área)? Sirve para saber qué está debajo.
  function huellasSeEnciman(a, b) {
    if (a.tipo === 'cilindro' && b.tipo === 'cilindro') return Math.hypot(a.x - b.x, a.y - b.y) < a.radio + b.radio - HOLGURA;
    if (a.tipo === 'cilindro' && b.tipo === 'caja' && cajaDePie(b)) return circuloYCajaDePie(a, b);
    if (b.tipo === 'cilindro' && a.tipo === 'caja' && cajaDePie(a)) return circuloYCajaDePie(b, a);
    const la = limites(a);
    const lb = limites(b);
    return Math.min(la.max[0], lb.max[0]) - Math.max(la.min[0], lb.min[0]) > HOLGURA &&
      Math.min(la.max[1], lb.max[1]) - Math.max(la.min[1], lb.min[1]) > HOLGURA;
  }

  // ---------------------------------------------------------------------
  // Revisar una colocación
  // ---------------------------------------------------------------------
  // entorno (lo arma nucleo.js con los datos):
  //   { tipo: 'lugar', ancho, fondo, alto, solidos: [forma…] }
  //   { tipo: 'mueble', nombre, hueco: { ancho, fondo }, niveles: [{ z, libre }…] (m),
  //     techoCerrado, solidos: [forma…] }
  // Cada sólido lleva id, nombre y "solido": 'objeto' | 'mueble'.
  // opciones: { permitirEncimar } → los choques entre objetos pasan de error a aviso.
  function nivelDe(entorno, base) {
    let indice = -1;
    entorno.niveles.forEach((nivel, i) => {
      if (nivel.z <= base + TOLERANCIA_APOYO) indice = i;
    });
    return indice;
  }

  // Altura de la superficie más alta que hay debajo de la base del objeto (piso, repisa u otro sólido)
  function apoyoDebajo(forma, entorno) {
    const lim = limites(forma);
    const base = lim.min[2];
    let apoyo = entorno.tipo === 'lugar' ? 0 : null;
    if (entorno.tipo === 'mueble') {
      const indice = nivelDe(entorno, base);
      if (indice >= 0) apoyo = entorno.niveles[indice].z;
    }
    entorno.solidos.forEach((solido) => {
      if (solido.id === forma.id) return;
      const tope = limites(solido).max[2];
      if (tope <= base + TOLERANCIA_APOYO && (apoyo == null || tope > apoyo) && huellasSeEnciman(forma, solido)) apoyo = tope;
    });
    return apoyo;
  }

  function revisar(objeto, entorno, opciones) {
    const ajustes = opciones || {};
    const forma = formaDeChoque(objeto, objeto.id, objeto.nombre);
    const lim = limites(forma);
    const problemas = [];
    const agregar = (tipo, grave, mensaje, conId) => problemas.push({ tipo: tipo, grave: grave, mensaje: mensaje, conId: conId || null });
    const sobra = (valor) => redondear(valor, 2).toFixed(2) + ' m';

    if (entorno.tipo === 'lugar') {
      if (lim.min[0] < -HOLGURA || lim.min[1] < -HOLGURA || lim.max[0] > entorno.ancho + HOLGURA || lim.max[1] > entorno.fondo + HOLGURA) {
        agregar('limite', true, 'Atraviesa una pared del lugar.');
      }
      if (lim.min[2] < -HOLGURA) agregar('limite', true, 'Queda por debajo del piso.');
      if (lim.max[2] > entorno.alto + HOLGURA) agregar('limite', true, 'Pasa del techo (' + entorno.alto + ' m).');
    } else {
      const indice = nivelDe(entorno, lim.min[2]);
      if (indice < 0) agregar('contenedor', true, 'Queda por debajo del piso de «' + entorno.nombre + '».');
      else {
        const nivel = entorno.niveles[indice];
        const tope = nivel.z + nivel.libre;
        if (lim.max[2] > tope + HOLGURA) {
          if (indice < entorno.niveles.length - 1) agregar('contenedor', true, 'Atraviesa la repisa de arriba (le sobran ' + sobra(lim.max[2] - tope) + ').');
          else if (entorno.techoCerrado) agregar('contenedor', true, 'No cabe: toca el techo de «' + entorno.nombre + '».');
          else agregar('sobresale', false, 'Sobresale por arriba de «' + entorno.nombre + '».');
        }
      }
      // Cada lado: si es pared (o vidrio, o la puerta) no se puede atravesar; si está abierto, solo sobresale
      const medioAncho = entorno.hueco.ancho / 2;
      const medioFondo = entorno.hueco.fondo / 2;
      const paredes = entorno.paredes || { costados: 'abierto', fondo: 'abierto', frente: 'abierto' };
      const QUE_ES = { pared: 'la pared', vidrio: 'el vidrio', puerta: 'la puerta' };
      const lados = [
        { fuera: lim.min[0] < -medioAncho - HOLGURA || lim.max[0] > medioAncho + HOLGURA, tipo: paredes.costados, por: 'por un costado', de: 'de un costado' },
        { fuera: lim.min[1] < -medioFondo - HOLGURA, tipo: paredes.fondo, por: 'por el fondo', de: 'del fondo' },
        { fuera: lim.max[1] > medioFondo + HOLGURA, tipo: paredes.frente, por: 'por el frente', de: 'del frente' }
      ];
      lados.filter((lado) => lado.fuera).forEach((lado) => {
        if (lado.tipo === 'abierto') agregar('sobresale', false, 'Sobresale ' + lado.por + ' de «' + entorno.nombre + '».');
        else if (lado.tipo === 'puerta') agregar('contenedor', true, 'Se sale por el frente: no dejaría cerrar la puerta de «' + entorno.nombre + '».');
        else agregar('contenedor', true, 'Atraviesa ' + QUE_ES[lado.tipo] + ' ' + lado.de + ' de «' + entorno.nombre + '».');
      });
    }

    entorno.solidos.forEach((solido) => {
      if (solido.id === objeto.id || problemas.filter((p) => p.tipo === 'colision').length >= 3) return;
      if (seCruzan(forma, solido)) {
        const contraMueble = solido.solido === 'mueble';
        agregar('colision', contraMueble || !ajustes.permitirEncimar,
          (contraMueble ? 'Atraviesa el mueble «' : 'Choca con «') + solido.nombre + '».', solido.id);
      }
    });

    if (!problemas.some((p) => p.grave)) {
      const apoyo = apoyoDebajo(forma, entorno);
      if (apoyo == null) agregar('flotando', false, 'Queda flotando.');
      else if (lim.min[2] - apoyo > TOLERANCIA_APOYO) agregar('flotando', false, 'Queda flotando ' + sobra(lim.min[2] - apoyo) + ' arriba de donde se apoya.');
    }
    const grave = problemas.some((p) => p.grave);
    return { nivel: grave ? 'error' : problemas.length ? 'aviso' : 'ok', problemas: problemas, limites: lim };
  }

  // Cuánto hay que bajar (o subir, si quedó metido en el piso) a un grupo de objetos para que
  // se apoye en lo que tiene debajo, sin deshacer su forma (todos se mueven lo mismo).
  function distanciaParaAsentar(objetos, entorno) {
    let bajar = null;
    objetos.forEach((objeto) => {
      const forma = formaDeChoque(objeto, objeto.id, objeto.nombre);
      const apoyo = apoyoDebajo(forma, entorno);
      if (apoyo == null) return;
      const hueco = limites(forma).min[2] - apoyo;
      if (bajar == null || hueco < bajar) bajar = hueco;
    });
    return bajar == null ? 0 : redondear(bajar, 4);
  }

  // Busca la posición libre más cercana a "preferido" (x, y) donde el objeto quede apoyado y sin
  // errores. En un mueble prueba sus niveles (empezando por "nivel" si se indica).
  function buscarHueco(objeto, entorno, preferido, opciones) {
    const base = Object.assign({}, objeto, { pos: Object.assign({}, objeto.pos) });
    const mitadAlto = medioAlto(base);
    const candidatosZ = entorno.tipo === 'lugar'
      ? [mitadAlto]
      : ordenarNiveles(entorno, preferido && preferido.nivel).map((nivel) => nivel.z + mitadAlto + 0.001);
    const lim = limites(formaDeChoque(base, base.id, base.nombre));
    const mediaX = (lim.max[0] - lim.min[0]) / 2;
    const mediaY = (lim.max[1] - lim.min[1]) / 2;
    const paso = entorno.tipo === 'lugar' ? 0.1 : 0.04;
    const [x0, x1, y0, y1] = entorno.tipo === 'lugar'
      ? [mediaX, entorno.ancho - mediaX, mediaY, entorno.fondo - mediaY]
      : [-entorno.hueco.ancho / 2 + mediaX, entorno.hueco.ancho / 2 - mediaX, -entorno.hueco.fondo / 2 + mediaY, entorno.hueco.fondo / 2 - mediaY];
    if (x1 < x0 - 1e-9 || y1 < y0 - 1e-9) return null;
    const centro = preferido && Number.isFinite(preferido.x) ? preferido : { x: (x0 + x1) / 2, y: (y0 + y1) / 2 };
    const candidatos = [];
    for (let x = x0; x <= x1 + 1e-9; x += paso) {
      for (let y = y0; y <= y1 + 1e-9; y += paso) candidatos.push({ x: redondear(x), y: redondear(y), d: Math.hypot(x - centro.x, y - centro.y) });
    }
    // También el punto preferido exacto, si cabe en los límites
    if (centro.x >= x0 - 1e-9 && centro.x <= x1 + 1e-9 && centro.y >= y0 - 1e-9 && centro.y <= y1 + 1e-9) candidatos.push({ x: centro.x, y: centro.y, d: -1 });
    candidatos.sort((a, b) => a.d - b.d);
    for (const z of candidatosZ) {
      for (const candidato of candidatos) {
        base.pos = { x: candidato.x, y: candidato.y, z: redondear(z, 4) };
        const revision = revisar(base, entorno, opciones);
        if (revision.nivel !== 'error' && !revision.problemas.some((p) => p.tipo === 'flotando' || p.tipo === 'colision')) {
          return Object.assign({}, base.pos);
        }
      }
    }
    return null;
  }

  function ordenarNiveles(entorno, preferido) {
    const lista = entorno.niveles.map((nivel, i) => Object.assign({ i: i }, nivel));
    if (preferido == null || !lista[preferido]) return lista;
    return [lista[preferido]].concat(lista.filter((nivel) => nivel.i !== preferido));
  }

  // La mitad de la altura que ocupa (girado)
  function medioAlto(objeto) {
    const lim = limites(formaDeChoque(objeto, objeto.id, objeto.nombre));
    return (lim.max[2] - lim.min[2]) / 2;
  }

  // ---------------------------------------------------------------------
  // Huella en el piso (para dibujar el objeto en el plano 2.5D)
  // ---------------------------------------------------------------------
  // Se toman puntos de la figura real (círculos para lo redondo, esquinas para lo demás), se
  // giran y se proyectan al piso; la huella es el contorno convexo de esos puntos.
  function puntosDeFigura(figura) {
    const puntos = [];
    const circulo = (z, radio) => {
      for (let i = 0; i < 16; i++) puntos.push([Math.cos((i / 16) * Math.PI * 2) * radio, Math.sin((i / 16) * Math.PI * 2) * radio, z]);
    };
    if (figura === 'cilindro' || figura === 'tubo' || figura === 'aro') {
      circulo(-0.5, 0.5);
      circulo(0.5, 0.5);
    } else if (figura === 'esfera') {
      [-0.35, 0, 0.35].forEach((z) => circulo(z, Math.sqrt(0.25 - z * z)));
      puntos.push([0, 0, 0.5], [0, 0, -0.5]);
    } else if (figura === 'cono') {
      circulo(-0.5, 0.5);
      puntos.push([0, 0, 0.5]);
    } else if (figura === 'prisma') {
      [-0.5, 0.5].forEach((z) => [[0, 0.5], [-0.433, -0.25], [0.433, -0.25]].forEach(([x, y]) => puntos.push([x, y, z])));
    } else if (figura === 'piramide') {
      [[-0.5, -0.5], [0.5, -0.5], [0.5, 0.5], [-0.5, 0.5]].forEach(([x, y]) => puntos.push([x, y, -0.5]));
      puntos.push([0, 0, 0.5]);
    } else {
      [-0.5, 0.5].forEach((x) => [-0.5, 0.5].forEach((y) => [-0.5, 0.5].forEach((z) => puntos.push([x, y, z]))));
    }
    return puntos;
  }

  function contornoConvexo(puntos) {
    const lista = puntos.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    if (lista.length < 3) return lista;
    const giro = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    const abajo = [];
    lista.forEach((p) => {
      while (abajo.length >= 2 && giro(abajo[abajo.length - 2], abajo[abajo.length - 1], p) <= 0) abajo.pop();
      abajo.push(p);
    });
    const arriba = [];
    lista.slice().reverse().forEach((p) => {
      while (arriba.length >= 2 && giro(arriba[arriba.length - 2], arriba[arriba.length - 1], p) <= 0) arriba.pop();
      arriba.push(p);
    });
    return abajo.slice(0, -1).concat(arriba.slice(0, -1));
  }

  // objeto en el marco del lugar → lista de puntos [x, y] de su huella
  function huellaEnPiso(objeto) {
    const r = matrizRotacion(objeto.rot);
    const m = objeto.medidas;
    const puntos = puntosDeFigura(objeto.figura).map((p) => {
      const girado = aplicar(r, [p[0] * m.ancho, p[1] * m.fondo, p[2] * m.alto]);
      return [redondear(girado[0] + objeto.pos.x, 4), redondear(girado[1] + objeto.pos.y, 4)];
    });
    return contornoConvexo(puntos);
  }

  function puntoEnPoligono(x, y, poligono) {
    let dentro = false;
    for (let i = 0, j = poligono.length - 1; i < poligono.length; j = i++) {
      const [xi, yi] = poligono[i];
      const [xj, yj] = poligono[j];
      if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) dentro = !dentro;
    }
    return dentro;
  }

  const Espacio = {
    METROS_POR_PISO, ALTURA_LUGAR, HOLGURA, TOLERANCIA_APOYO, MEDIDA_MINIMA, MEDIDA_MAXIMA, FIGURAS,
    redondear, normalizarAngulo, multiplicar, aplicar, giroZ, matrizRotacion, rotacionDesdeMatriz, cambiarEjesYZ,
    poseDeMueble, aMundo, aLocal, objetoAMundo, objetoALocal,
    formaDeChoque, cajaRecta, limites, seCruzan, huellasSeEnciman,
    revisar, apoyoDebajo, distanciaParaAsentar, buscarHueco, medioAlto,
    huellaEnPiso, contornoConvexo, puntoEnPoligono
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Espacio;
  else raiz.Espacio = Espacio;
})(typeof window !== 'undefined' ? window : globalThis);
