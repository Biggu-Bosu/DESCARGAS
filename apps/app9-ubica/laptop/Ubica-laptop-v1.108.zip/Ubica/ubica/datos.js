// Ubica · Tus datos: respaldo en archivo, copias automáticas, Excel, base de datos, ejemplo,
// revisión al abrir y actualización de datos de versiones anteriores.
(function () {
  'use strict';

  const U = window.Ubica;
  const { N, BD, e, $, estado } = U;
  const { cabeza, abrirHoja, cerrarHojas } = U;
  const CLAVE_RESPALDO = 'ubica.ultimoRespaldo';   // día del último respaldo en archivo
  const CLAVE_DESDE = 'ubica.conDatosDesde';       // primer día en que hubo datos
  const CLAVE_RECORDADO = 'ubica.recordatorio';    // último día en que se recordó respaldar
  const DIAS_SIN_RESPALDO = 14;

  // =====================================================================
  // RESPALDO EN ARCHIVO Y EXCEL
  // =====================================================================
  async function compartir(contenido, tipo, nombre, titulo, mensaje) {
    const resultado = await window.Compartir.compartirArchivo(new Blob([contenido], { type: tipo }), nombre, titulo);
    if (resultado === 'compartido') U.avisar(mensaje);
    else if (resultado === 'error') U.avisar('No se pudo compartir el archivo en este dispositivo.');
    return resultado;
  }

  U.guardarRespaldo = async () => {
    const texto = JSON.stringify(N.crearRespaldo(estado.datos), null, 2);
    const muestra = BD.enMuestra();
    const resultado = await compartir(texto, 'application/json', (muestra ? 'ubica-muestra-respaldo-' : 'ubica-respaldo-') + U.hoy() + '.json',
      muestra ? 'Respaldo de la muestra de Ubica' : 'Respaldo de Ubica', 'Respaldo listo');
    // El respaldo de la muestra no cuenta como respaldo de tus datos (no apaga el recordatorio)
    if (resultado === 'compartido' && !muestra) {
      U.guardarClave(CLAVE_RESPALDO, U.hoy());
      U.render();
    }
  };

  // Salida de emergencia: los datos tal como están en la base (sirve aunque la app no pueda abrirla)
  async function guardarRespaldoDeEmergencia() {
    try {
      const respaldo = await BD.exportarEmergencia();
      return compartir(JSON.stringify(respaldo, null, 2), 'application/json', 'ubica-respaldo-sin-cambios-' + U.hoy() + '.json',
        'Respaldo de Ubica (sin cambios)', 'Respaldo listo');
    } catch (error) {
      console.error(error);
      U.avisar('No se pudieron leer los datos para el respaldo.');
      return 'error';
    }
  }

  U.exportarCSV = () => compartir(N.inventarioCSV(estado.datos), 'text/csv', 'ubica-inventario-' + U.hoy() + '.csv',
    'Inventario de Ubica', 'Lista para Excel lista');

  function diasSinRespaldo() {
    const ultimo = U.leerClave(CLAVE_RESPALDO);
    return N.leerFechaISO(ultimo) ? N.diasEntre(ultimo, U.hoy()) : null;
  }

  U.textoUltimoRespaldo = () => {
    const dias = diasSinRespaldo();
    if (dias === null) return 'Aún no has guardado ninguno';
    if (dias <= 0) return 'Último respaldo: hoy';
    return 'Último respaldo: hace ' + N.plural(dias, 'día');
  };

  // Safari en iPhone/iPad sin instalar: ahí los datos de una página pueden borrarse solos
  U.convieneInstalarEnIphone = () => {
    const esApple = /iphone|ipad|ipod/i.test(navigator.userAgent);
    return esApple && !navigator.standalone && !window.Compartir.esNativa();
  };

  // ---------- Reemplazar todo el inventario, dejando antes una copia de seguridad ----------
  // La copia de lo que había se guarda en la MISMA transacción que el reemplazo.
  async function reemplazarInventario(nuevos, motivoCopia, detalle) {
    const hecho = await U.conCandado(async () => {
      const momento = new Date().toISOString();
      const datos = N.clonar(nuevos);
      if (motivoCopia) {
        const tipo = motivoCopia === 'antes-de-reparar' ? 'reparacion-datos' : 'restauracion';
        datos.movimientos.push(N.movimientoGeneral(tipo, momento, Object.assign({ motivo: motivoCopia }, detalle || {})));
      }
      try {
        let copia = null;
        let sobran = [];
        if (motivoCopia && !N.estaVacio(estado.datos)) {
          copia = N.crearCopia(estado.datos, motivoCopia, momento, U.hoy());
          sobran = N.copiasQueSobran(await BD.leerCopias(), 1);
        }
        await BD.reemplazarTodo(datos, copia, sobran);
      } catch (error) {
        console.error(error);
        return false;
      }
      estado.datos = datos;
      estado.version++;
      estado.lugarId = null;
      estado.modo = null;
      estado.seleccionadoId = null;
      estado.filasVisibles = U.FILAS_POR_TANDA;
      Object.assign(estado.filtros, { texto: '', categoriaId: '', estado: '', lugar: '' });
      return true;
    });
    if (hecho) {
      cerrarHojas();
      U.render();
    }
    return Boolean(hecho);
  }

  $('elegirRespaldo').addEventListener('change', async (evento) => {
    const archivo = evento.target.files[0];
    evento.target.value = ''; // para poder elegir el mismo archivo otra vez
    if (!archivo) return;
    if (archivo.size > 20 * 1024 * 1024) {
      U.avisar('El archivo es demasiado grande para ser un respaldo de Ubica.');
      return;
    }
    let objeto;
    try {
      objeto = JSON.parse(await archivo.text());
    } catch (error) {
      U.avisar('El archivo no es un respaldo de Ubica.');
      return;
    }
    const revision = N.prepararDatos(objeto, { hoy: U.hoy() });
    if (!revision.ok) {
      U.avisar(revision.error);
      return;
    }
    const nuevo = revision.datos;
    const piezas = nuevo.articulos.reduce((suma, articulo) => suma + N.totalDe(articulo), 0);
    U.abrirHojaUnica(() => ({
      html: cabeza('Restaurar respaldo', archivo.name) +
        '<p>El respaldo tiene ' + N.plural(nuevo.lugares.length, 'lugar', 'lugares') + ', ' + N.plural(nuevo.muebles.length, 'mueble') +
        ', ' + N.plural(nuevo.articulos.length, 'artículo') + ' (' + N.plural(piezas, 'pieza') + ') y ' + N.plural(nuevo.prestamos.length, 'préstamo') + '.' +
        (revision.formatoOriginal < 2 ? ' Es de una versión anterior: se convierte al formato actual.' : '') + '</p>' +
        listaHallazgos(revision.hallazgos) +
        (BD.enMuestra() ? '<p><strong>Estás en la muestra:</strong> el respaldo se carga en la muestra, no en tus datos. ' +
          'Al salir de la muestra se borra. Para restaurar tus datos, sal primero de la muestra.</p>' :
        !N.estaVacio(estado.datos) ? '<p><strong>Se reemplazará todo lo que hay ahora en Ubica.</strong> Antes se guarda ' +
          'sola una copia de seguridad de lo actual, por si te equivocas de archivo.</p>' : '') +
        '<div class="fila-botones"><button type="button" class="boton" data-accion="cerrar">Cancelar</button>' +
        '<button type="button" class="boton principal" data-accion="restaurar">Restaurar</button></div>',
      acciones: {
        restaurar: async () => {
          if (await reemplazarInventario(nuevo, 'antes-de-restaurar', { hallazgos: revision.hallazgos.length })) U.avisar('Respaldo restaurado');
          else U.avisar('No se pudo restaurar. Tus datos anteriores siguen igual.');
        }
      }
    }));
  });

  // ---------- Ejemplo de las pruebas y empezar de cero ----------
  // El ejemplo anterior ya no aparece en la app (lo reemplazó el espacio de muestra): solo lo
  // usan las pruebas automáticas, que lo cargan en una base vacía.
  U.cargarEjemploDePrueba = async () => {
    if (!N.estaVacio(estado.datos)) return;
    if (!(await reemplazarInventario(N.datosDeEjemplo(U.hoy()), null))) {
      U.avisar('No se pudo guardar el ejemplo.');
      return;
    }
    U.avisar('Ejemplo cargado. Explora el Inventario o abre un lugar en «Lugares».');
  };

  U.pantallaVaciar = () => {
    const r = N.resumen(estado.datos, U.hoy());
    return {
      html: cabeza('¿Empezar de cero?') +
        '<p>Se borrarán ' + N.plural(r.articulos, 'artículo') + ', ' + N.plural(r.lugares, 'lugar', 'lugares') + ', ' +
        N.plural(r.muebles, 'mueble') + ' y los préstamos. Las categorías se conservan.</p>' +
        '<p><strong>Antes se guarda sola una copia de seguridad</strong>: podrás recuperarla en «Copias de seguridad automáticas».</p>' +
        '<div class="fila-botones"><button type="button" class="boton" data-accion="cerrar">Cancelar</button>' +
        '<button type="button" class="boton peligro-lleno" data-accion="vaciar">Sí, borrar todo</button></div>',
      acciones: {
        vaciar: async () => {
          const vacio = N.datosVacios();
          vacio.categorias = N.clonar(estado.datos.categorias);
          if (await reemplazarInventario(vacio, 'antes-de-restaurar', { vaciado: true })) U.avisar('Inventario vacío. Se guardó una copia de lo anterior.');
          else U.avisar('No se pudo borrar. Tus datos siguen igual.');
        }
      }
    };
  };

  // =====================================================================
  // ESPACIO DE MUESTRA
  // =====================================================================
  // La muestra vive en otra base de IndexedDB («ubica-muestra»). Entrar cambia la base que usa la
  // app; salir regresa a la tuya y borra la de la muestra. Tus datos nunca se leen ni se escriben
  // mientras estás en la muestra, y al abrir la app siempre se empieza en tus datos.
  U.enMuestra = () => BD.enMuestra();

  function limpiarVista() {
    estado.version++;
    estado.lugarId = null;
    estado.modo = null;
    estado.seleccionadoId = null;
    estado.articuloResaltadoId = null;
    estado.editor.seleccion = [];
    estado.editor.interiorId = null;
    estado.filasVisibles = U.FILAS_POR_TANDA;
    Object.assign(estado.filtros, { texto: '', categoriaId: '', estado: '', lugar: '' });
    if ($('buscador')) $('buscador').value = '';
  }

  function pintarFranja() {
    const dentro = BD.enMuestra();
    document.body.classList.toggle('en-muestra', dentro);
    $('franjaMuestra').hidden = !dentro;
  }

  // opciones.reiniciar: vuelve a armarla desde cero (con las fechas de hoy)
  U.verMuestra = async (opciones) => {
    const reiniciar = Boolean(opciones && opciones.reiniciar);
    const yaEstaba = BD.enMuestra();
    const hecho = await U.conCandado(async () => {
      U.limpiarDeshacer();
      try {
        if (!yaEstaba) await BD.usarMuestra();
        let datos = Object.assign(N.datosVacios(), await BD.leerTodo());
        // Si quedó una muestra de antes (se cerró la app sin salir), se continúa con ella
        if (reiniciar || N.estaVacio(datos)) {
          datos = window.Muestra.datosDeMuestra(U.hoy());
          await BD.reemplazarTodo(datos, null);
        }
        estado.datos = datos;
        limpiarVista();
        return true;
      } catch (error) {
        console.error(error);
        if (!yaEstaba) await BD.usarMisDatos(); // tus datos siguen en memoria, sin cambios
        return false;
      }
    });
    pintarFranja();
    if (!hecho) {
      U.avisar('No se pudo abrir la muestra. Tus datos siguen igual.');
      return;
    }
    cerrarHojas();
    U.irALugar(window.Muestra.LUGAR_MUESTRA);
    U.avisar(reiniciar ? 'La muestra volvió a como estaba al abrirla.' : 'Estás en la muestra. Edita lo que quieras: tus datos no cambian.');
  };

  U.salirDeMuestra = async () => {
    if (!BD.enMuestra()) return;
    let error = null;
    const hecho = await U.conCandado(async () => {
      U.limpiarDeshacer();
      try {
        await BD.usarMisDatos();
        estado.datos = Object.assign(N.datosVacios(), await BD.leerTodo());
        limpiarVista();
      } catch (fallo) {
        console.error(fallo);
        error = fallo;
        return false;
      }
      try {
        await BD.borrarMuestra();
      } catch (fallo) {
        console.warn('No se pudo borrar la muestra', fallo); // se intentará otra vez al volver a salir
      }
      return true;
    });
    pintarFranja();
    cerrarHojas();
    estado.seccion = 'inventario';
    U.render();
    if (hecho) U.avisar('Volviste a tus datos. La muestra se borró.');
    else if (error) U.avisar('No se pudieron leer tus datos. Cierra y abre Ubica.');
  };

  $('salirMuestra').addEventListener('click', () => U.salirDeMuestra());

  // =====================================================================
  // COPIAS DE SEGURIDAD AUTOMÁTICAS
  // =====================================================================
  U.abrirCopias = async () => {
    try {
      const copias = N.copiasOrdenadas(await BD.leerCopias());
      U.abrirHojaUnica(() => pantallaCopias(copias));
    } catch (error) {
      U.avisar('No se pudieron leer las copias de seguridad.');
    }
  };

  // Las copias de versiones anteriores dicen «espacios» en lugar de «lugares»
  function textoResumen(resumen) {
    const lugares = resumen.lugares != null ? resumen.lugares : resumen.espacios || 0;
    return N.plural(lugares, 'lugar', 'lugares') + ', ' + N.plural(resumen.muebles, 'mueble') + ', ' +
      N.plural(resumen.piezas, 'pieza') + ' y ' + N.plural(resumen.prestamos, 'préstamo');
  }

  function pantallaCopias(copias) {
    return {
      html: cabeza('Copias de seguridad', 'Ubica guarda sola hasta ' + N.MAXIMO_COPIAS + ' copias en este dispositivo') +
        '<p class="nota">Sirven para regresar si algo sale mal. Se hace una al día si hubo cambios y otra antes de restaurar, ' +
        'vaciar o actualizar. <strong>No sustituyen al respaldo en archivo.</strong></p>' +
        (copias.length ? copias.map((copia) => '<article class="tarjeta"><h3>' + e(U.fechaYHora(copia.momento)) + '</h3>' +
          '<p class="detalle">' + e(N.MOTIVOS_COPIA[copia.motivo] || 'Copia') + '</p>' +
          '<p class="detalle">' + e(textoResumen(copia.resumen)) + '</p>' +
          '<div class="fila-botones"><button type="button" class="boton chico" data-accion="recuperar" data-id="' + e(copia.id) +
          '">Recuperar esta copia</button></div></article>').join('')
          : '<p class="vacio">Todavía no hay copias. La primera se hace sola cuando tengas datos.</p>'),
      acciones: {
        recuperar: (boton) => {
          const copia = copias.find((c) => c.id === boton.dataset.id);
          if (copia) abrirHoja(() => pantallaRecuperar(copia));
        }
      }
    };
  }

  // Lista de lo que la revisión ajusta (para restaurar, recuperar y reparar)
  function listaHallazgos(hallazgos) {
    if (!hallazgos.length) return '';
    return '<p>Al revisarlo encontramos ' + N.plural(hallazgos.length, 'cosa que se ajustará', 'cosas que se ajustarán') +
      ' (nada se borra salvo copias repetidas idénticas):</p><ul class="hallazgos">' +
      hallazgos.slice(0, 8).map((h) => '<li>' + e(h.texto) + '</li>').join('') + '</ul>' +
      (hallazgos.length > 8 ? '<p class="nota">…y ' + (hallazgos.length - 8) + ' más.</p>' : '');
  }

  function pantallaRecuperar(copia) {
    // La copia pasa por la misma revisión que un respaldo importado (también convierte las de formato 1)
    const revision = N.prepararDatos(copia.datos, { hoy: U.hoy() });
    if (!revision.ok) return { html: cabeza('No se puede recuperar') + '<p class="error">' + e(revision.error) + '</p>' };
    return {
      html: cabeza('¿Recuperar esta copia?', U.fechaYHora(copia.momento)) +
        '<p>La copia tiene ' + e(textoResumen(copia.resumen)) + '.</p>' + listaHallazgos(revision.hallazgos) +
        '<p><strong>Reemplazará lo que hay ahora.</strong> Antes se guarda una copia de lo actual, así que podrás regresar.</p>' +
        '<div class="fila-botones"><button type="button" class="boton" data-accion="volver">Cancelar</button>' +
        '<button type="button" class="boton principal" data-accion="recuperar">Recuperar</button></div>',
      acciones: {
        recuperar: async () => {
          if (await reemplazarInventario(revision.datos, 'antes-de-recuperar', { hallazgos: revision.hallazgos.length })) U.avisar('Copia recuperada');
          else U.avisar('No se pudo recuperar. Tus datos siguen igual.');
        }
      }
    };
  }

  // Al abrir la app: revisión de los datos, copia del día y recordatorio de respaldo.
  // Nada de esto corre dentro de la muestra.
  U.revisarDatosAlAbrir = async () => {
    if (BD.enMuestra() || N.estaVacio(estado.datos)) return;
    if (!U.leerClave(CLAVE_DESDE)) U.guardarClave(CLAVE_DESDE, U.hoy());

    // 1) ¿Hay datos que no cumplen las reglas?
    const revision = N.revisarIntegridad(estado.datos, { hoy: U.hoy() });
    if (revision.problemas.length) {
      U.abrirHojaUnica(() => pantallaReparar(revision));
      return; // la copia diaria se hará después de decidir, en la próxima apertura
    }
    // 2) Copia automática del día (si hubo cambios)
    try {
      const copias = await BD.leerCopias();
      if (N.tocaCopiaDiaria(copias, estado.datos, U.hoy())) {
        const copia = N.crearCopia(estado.datos, 'diaria', new Date().toISOString(), U.hoy());
        await U.conCandado(() => BD.guardarCopia(copia, N.copiasQueSobran(copias, 1)));
      }
    } catch (error) {
      console.warn('No se pudo hacer la copia automática', error);
    }
    // 3) Recordatorio de respaldo en archivo (una vez al día como máximo)
    const dias = diasSinRespaldo();
    const diasConDatos = N.diasEntre(U.leerClave(CLAVE_DESDE) || U.hoy(), U.hoy());
    const toca = dias === null ? diasConDatos >= 3 : dias >= DIAS_SIN_RESPALDO;
    if (toca && U.leerClave(CLAVE_RECORDADO) !== U.hoy() && !U.pila.length) {
      U.guardarClave(CLAVE_RECORDADO, U.hoy());
      U.avisar(dias === null
        ? 'Aún no tienes un respaldo en archivo. Ve a Más → «Guardar respaldo».'
        : 'Hace ' + N.plural(dias, 'día') + ' que no guardas un respaldo. Ve a Más → «Guardar respaldo».');
    }
  };

  function pantallaReparar(revision) {
    const total = revision.problemas.length;
    return {
      html: cabeza('Encontramos ' + N.plural(total, 'dato por corregir', 'datos por corregir')) +
        '<p>Al abrir, Ubica revisa sus datos. Esto no cumple las reglas y así se resolvería:</p>' +
        '<ul class="hallazgos">' + revision.problemas.slice(0, 6).map((problema) => '<li>' + e(problema) + '</li>').join('') + '</ul>' +
        (total > 6 ? '<p class="nota">…y ' + (total - 6) + ' más.</p>' : '') +
        '<p>«Reparar» aplica esos cambios sin borrar artículos. <strong>Antes se guarda una copia de seguridad</strong> de todo como está ahora.</p>' +
        '<div class="fila-botones"><button type="button" class="boton" data-accion="cerrar">Ahora no</button>' +
        '<button type="button" class="boton principal" data-accion="reparar">Reparar</button></div>',
      acciones: {
        reparar: async () => {
          if (await reemplazarInventario(revision.datos, 'antes-de-reparar', { correcciones: revision.problemas })) {
            U.avisar('Datos reparados. Se guardó una copia de cómo estaban.');
          } else U.avisar('No se pudo reparar. Tus datos siguen igual.');
        }
      }
    };
  }

  // =====================================================================
  // NOVEDADES Y BASE DE DATOS
  // =====================================================================
  U.pantallaNovedades = () => {
    const version = window.APP_VERSION || {};
    return {
      html: cabeza('Novedades', version.numero ? 'Versión ' + version.numero + ' · ' + version.fecha : 'Versión en desarrollo') +
        (window.NOVEDADES || []).map((entrada) => '<div class="novedad"><h3>' + e(N.fechaCorta(entrada.fecha)) + ' ' +
          e(entrada.fecha.slice(0, 4)) + '</h3><ul>' + entrada.cambios.map((cambio) => '<li>' + e(cambio) + '</li>').join('') +
          '</ul></div>').join('')
    };
  };

  // ---------- Configuración ----------
  U.pantallaConfiguracion = () => {
    const grupos = [];
    U.LISTA_AJUSTES.forEach((ajuste) => {
      if (!grupos.includes(ajuste[2])) grupos.push(ajuste[2]);
    });
    const interruptor = ([clave, , , titulo, detalle]) =>
      '<label class="interruptor"><span><strong>' + e(titulo) + '</strong><small>' + e(detalle) + '</small></span>' +
      '<input type="checkbox" role="switch" data-ajuste="' + clave + '"' + (U.ajustes[clave] ? ' checked' : '') + '></label>';
    return {
      html: cabeza('Configuración', 'Solo cambia cómo se ve la app en este dispositivo') +
        grupos.map((grupo) => '<h3>' + e(grupo) + '</h3>' +
          (grupo === 'Simplificar' ? '<p class="nota fija">Apaga lo que no uses. No se borra ningún dato: al volver a encenderlo, todo sigue ahí.</p>' : '') +
          U.LISTA_AJUSTES.filter((ajuste) => ajuste[2] === grupo).map(interruptor).join('')).join('') +
        '<div class="fila-botones"><button type="button" class="boton chico" data-accion="todas">Simplificar todo</button>' +
        '<button type="button" class="boton chico" data-accion="ninguna">Mostrar todo</button></div>',
      acciones: {
        todas: () => cambiarSimplificaciones(true),
        ninguna: () => cambiarSimplificaciones(false)
      }
    };
  };

  function cambiarSimplificaciones(valor) {
    U.LISTA_AJUSTES.filter((ajuste) => ajuste[2] === 'Simplificar').forEach(([clave]) => { U.ajustes[clave] = valor; });
    U.cambiarAjuste('menosTexto', valor);
    U.refrescarHoja();
  }

  // Los interruptores guardan al momento
  document.getElementById('hoja').addEventListener('change', (evento) => {
    const interruptor = evento.target.closest('[data-ajuste]');
    if (interruptor) U.cambiarAjuste(interruptor.dataset.ajuste, interruptor.checked);
  });

  // ---------- «Ver base de datos»: visor crudo de IndexedDB, solo lectura ----------
  // Lee directamente de IndexedDB (no de la copia en memoria de la app). Primero la lista de
  // almacenes con cuántos registros tiene cada uno; al tocar uno, una tabla: una fila por registro
  // y una columna por campo, con los valores tal como están guardados. No hay nada que edite.
  //   cual: 'mia' (base «ubica») o 'muestra' (base «ubica-muestra»)
  U.abrirBaseDatos = async (cual) => {
    const elegida = cual || (BD.enMuestra() ? 'muestra' : 'mia');
    try {
      const info = await BD.describirBase(elegida);
      U.abrirHojaUnica(() => pantallaBaseDatos({ cual: elegida, info: info, almacen: null, fila: null }));
    } catch (error) {
      console.error(error);
      U.avisar('No se pudo leer la base de datos.');
    }
  };

  // El esquema como el código de IndexedDB que lo crea
  function esquemaComoCodigo(info) {
    const lineas = ['// IndexedDB · base "' + info.nombre + '" · versión ' + info.version,
      'const pedido = indexedDB.open(' + JSON.stringify(info.nombre) + ', ' + info.version + ');', '',
      'pedido.onupgradeneeded = () => {', '  const db = pedido.result;'];
    info.tablas.forEach((tabla) => {
      lineas.push('', '  // ' + tabla.registros.length + ' registro' + (tabla.registros.length === 1 ? '' : 's'),
        '  const ' + tabla.nombre + ' = db.createObjectStore(' + JSON.stringify(tabla.nombre) + ', { keyPath: ' + JSON.stringify(tabla.llave) +
        (tabla.autoIncremento ? ', autoIncrement: true' : '') + ' });');
      (tabla.detalleIndices || []).forEach((indice) => {
        lineas.push('  ' + tabla.nombre + '.createIndex(' + JSON.stringify(indice.nombre) + ', ' + JSON.stringify(indice.campo) +
          ', { unique: ' + indice.unico + (indice.multiple ? ', multiEntry: true' : '') + ' });');
      });
    });
    lineas.push('};');
    return lineas.join('\n');
  }

  const LIMITE_FILAS = 200;
  const LIMITE_CELDA = 60;

  // Columnas: la llave primero y luego cada campo en el orden en que aparece
  function columnasDe(tabla) {
    const columnas = [tabla.llave];
    tabla.registros.forEach((registro) => Object.keys(registro).forEach((campo) => {
      if (!columnas.includes(campo)) columnas.push(campo);
    }));
    return columnas;
  }

  // Un valor tal como está guardado: texto tal cual, null como null, objetos y listas en JSON
  function celda(registro, campo, esLlave) {
    if (!(campo in registro)) return '<td class="ausente" title="Este registro no tiene el campo">—</td>';
    const valor = registro[campo];
    if (valor === null) return '<td class="nulo">null</td>';
    const texto = typeof valor === 'object' ? JSON.stringify(valor) : String(valor);
    const corto = texto.length > LIMITE_CELDA ? texto.slice(0, LIMITE_CELDA) + '…' : texto;
    return '<td class="' + (esLlave ? 'llave' : typeof valor) + '" title="' + e(texto.slice(0, 400)) + '">' + e(corto) + '</td>';
  }

  function pantallaBaseDatos(vista) {
    const { cual, info } = vista;
    const tabla = info && vista.almacen && vista.almacen !== '·esquema' ? info.tablas.find((t) => t.nombre === vista.almacen) : null;
    const otra = (cambios) => U.reemplazarHoja(() => pantallaBaseDatos(Object.assign({}, vista, cambios)));
    const selector = '<div class="segmentos" role="group" aria-label="Qué base ver">' +
      '<button type="button" data-accion="base" data-valor="mia" aria-pressed="' + (cual === 'mia') + '">Mis datos</button>' +
      '<button type="button" data-accion="base" data-valor="muestra" aria-pressed="' + (cual === 'muestra') + '">Muestra</button></div>';
    let cuerpo = '';
    let copiable = '';
    if (!info) {
      cuerpo = '<p class="nota fija">La base <code>' + e(cual === 'muestra' ? BD.NOMBRE_MUESTRA : BD.NOMBRE_BD) +
        '</code> no existe en este momento. ' + (cual === 'muestra' ? 'Se crea al entrar a la muestra y se borra al salir.' : '') + '</p>';
    } else {
      const peso = info.tablas.reduce((suma, t) => suma + JSON.stringify(t.registros).length, 0);
      cuerpo = '<p class="crudo-base"><code>indexedDB.open(' + e(JSON.stringify(info.nombre)) + ', ' + info.version + ')</code> · ' +
        N.plural(info.tablas.length, 'almacén', 'almacenes') + ' · ~' + Math.ceil(peso / 1024) + ' KB</p>';
      if (vista.almacen === '·esquema') {
        copiable = esquemaComoCodigo(info);
        cuerpo += '<button type="button" class="boton chico" data-accion="almacenes">← Almacenes</button>' +
          '<pre class="crudo" tabindex="0">' + e(copiable) + '</pre>';
      } else if (!tabla) {
        cuerpo += '<ul class="lista-almacenes">' + info.tablas.map((t) => '<li><button type="button" data-accion="almacen" data-valor="' + e(t.nombre) + '">' +
          '<code>' + e(t.nombre) + '</code><span class="cuenta">' + N.plural(t.registros.length, 'registro') + '</span>' +
          '<small>llave: ' + e(String(t.llave)) + (t.detalleIndices.length ? ' · índices: ' + e(t.detalleIndices.map((i) => i.nombre).join(', ')) : '') +
          '</small></button></li>').join('') + '</ul>' +
          '<button type="button" class="boton chico" data-accion="esquema">Ver el esquema como código</button>';
      } else {
        const columnas = columnasDe(tabla);
        const filas = tabla.registros.slice(0, LIMITE_FILAS);
        copiable = JSON.stringify(tabla.registros, null, 2);
        cuerpo += '<div class="fila-botones"><button type="button" class="boton chico" data-accion="almacenes">← Almacenes</button></div>' +
          '<p class="crudo-almacen"><code>' + e(tabla.nombre) + '</code> · ' + N.plural(tabla.registros.length, 'registro') + '</p>' +
          (filas.length ? '<div class="tabla-scroll tabla-cruda" tabindex="0" role="region" aria-label="Registros de ' + e(tabla.nombre) + '">' +
            '<table class="tabla-bd"><thead><tr><th scope="col">#</th>' + columnas.map((c) => '<th scope="col">' + e(c) + '</th>').join('') + '</tr></thead><tbody>' +
            filas.map((registro, i) => '<tr data-accion="fila" data-valor="' + i + '"' + (vista.fila === i ? ' class="abierta"' : '') + '><td class="numero">' + (i + 1) + '</td>' +
              columnas.map((c) => celda(registro, c, c === tabla.llave)).join('') + '</tr>').join('') + '</tbody></table></div>'
            : '<p class="nota fija">Este almacén está vacío.</p>') +
          (tabla.registros.length > LIMITE_FILAS ? '<p class="nota">Se muestran ' + LIMITE_FILAS + ' de ' + tabla.registros.length + ' registros.</p>' : '') +
          (vista.fila != null && filas[vista.fila] ? '<p class="nota fija">Registro ' + (vista.fila + 1) + ' completo:</p><pre class="crudo" tabindex="0">' +
            e(JSON.stringify(filas[vista.fila], null, 2)) + '</pre>' : '<p class="nota">Toca una fila para ver ese registro completo.</p>');
      }
    }
    return {
      html: cabeza('Ver base de datos', 'IndexedDB tal cual · solo lectura') + selector + cuerpo +
        '<div class="fila-botones">' + (copiable ? '<button type="button" class="boton chico" data-accion="copiar">Copiar</button>' : '') +
        '<button type="button" class="boton chico" data-accion="actualizar">Volver a leer</button></div>',
      acciones: {
        base: async (boton) => {
          try {
            const nueva = await BD.describirBase(boton.dataset.valor);
            otra({ cual: boton.dataset.valor, info: nueva, almacen: null, fila: null });
          } catch (error) {
            U.avisar('No se pudo leer esa base.');
          }
        },
        almacen: (boton) => otra({ almacen: boton.dataset.valor, fila: null }),
        almacenes: () => otra({ almacen: null, fila: null }),
        esquema: () => otra({ almacen: '·esquema', fila: null }),
        fila: (fila) => otra({ fila: vista.fila === Number(fila.dataset.valor) ? null : Number(fila.dataset.valor) }),
        copiar: async () => {
          try {
            await navigator.clipboard.writeText(copiable);
            U.avisar('Copiado.');
          } catch (error) {
            U.avisar('No se pudo copiar. Selecciona el texto a mano.');
          }
        },
        actualizar: async () => {
          const nueva = await BD.describirBase(cual);
          otra({ info: nueva, fila: null });
        }
      }
    };
  }

  // =====================================================================
  // INICIO Y ACTUALIZACIÓN DE LOS DATOS (MIGRACIÓN A LA VERSIÓN 3)
  // =====================================================================
  function pantallaCompleta(id) {
    document.body.dataset.pantalla = id;
    ['vistaInventario', 'vistaLugares', 'vistaLugar', 'vistaPrestamos', 'vistaMas', 'vistaError', 'vistaMigracion'].forEach((vista) => {
      $(vista).hidden = vista !== id;
    });
    $('titulo').textContent = 'Ubica';
    $('subtitulo').textContent = '';
    $('accionesBarra').innerHTML = '';
    $('botonAtras').hidden = true;
  }

  function mostrarErrorInicio(texto, conRespaldo) {
    $('textoError').textContent = texto;
    $('botonExportarEmergencia').hidden = !conRespaldo;
    pantallaCompleta('vistaError');
  }

  // Pantalla que explica la actualización y pide permiso cuando hay algo que corregir
  function mostrarMigracion(plan) {
    const a = plan.antes;
    const d = plan.despues;
    const fila = (que, antes, despues) => '<tr><th scope="row">' + que + '</th><td>' + antes + '</td><td>' + despues + '</td></tr>';
    $('contenidoMigracion').innerHTML =
      '<h2>Antes de actualizar tus datos</h2>' +
      '<p>Esta versión de Ubica organiza el inventario de otra forma: <strong>lugares</strong> (con plano opcional), ' +
      '<strong>artículos</strong> con categoría y estados, y un historial de movimientos. Tus artículos entran en la categoría «Otros».</p>' +
      '<p>Revisamos tus datos con las reglas nuevas y encontramos ' + N.plural(plan.hallazgos.length, 'cosa', 'cosas') +
      ' que hay que resolver. Así se resolverían (<strong>no se borra ningún registro</strong>):</p>' +
      '<ul class="hallazgos">' + plan.hallazgos.map((h) => '<li>' + e(h.texto) + '</li>').join('') + '</ul>' +
      '<table class="tabla-bd comparacion"><thead><tr><th></th><th scope="col">Ahora</th><th scope="col">Después</th></tr></thead><tbody>' +
      fila('Lugares', a.lugares, d.lugares) + fila('Muebles', a.muebles, d.muebles) + fila('Artículos', a.articulos, d.articulos) +
      fila('Piezas', a.piezas, d.piezas) + fila('Préstamos', a.prestamos, d.prestamos) + '</tbody></table>' +
      '<p class="nota">Al actualizar, Ubica guarda sola una copia de tus datos tal como están. ' +
      'Si prefieres, guarda también un respaldo en archivo antes. Si cierras la app sin decidir, tus datos no cambian.</p>';
    pantallaCompleta('vistaMigracion');
    $('botonActualizarDatos').onclick = async () => {
      $('botonActualizarDatos').disabled = true;
      BD.aprobarMigracion(plan.huella);
      await U.iniciar({ migracionAprobada: true });
      $('botonActualizarDatos').disabled = false;
    };
  }

  $('botonRespaldoMigracion').addEventListener('click', guardarRespaldoDeEmergencia);
  $('botonExportarEmergencia').addEventListener('click', guardarRespaldoDeEmergencia);

  U.iniciar = async (opciones) => {
    const aprobada = Boolean(opciones && opciones.migracionAprobada);
    let migro = false;
    try {
      // 1) ¿La base es de una versión anterior? Se revisa SIN cambiarla.
      if (!aprobada) {
        const info = await BD.inspeccionar();
        if (info.version >= 1 && info.version < BD.VERSION_SIN_CONVERSION) {
          const plan = N.planDeMigracion(info.crudos, info.version, { hoy: U.hoy() });
          if (!plan.comprobacion.ok) {
            console.error('Comprobación de la migración', plan.comprobacion);
            mostrarErrorInicio('No se pueden actualizar tus datos con seguridad. No se cambió nada. Descarga un respaldo y avísanos para revisarlo.', true);
            return;
          }
          if (plan.hallazgos.length) {
            mostrarMigracion(plan); // hay algo que corregir: la persona decide
            return;
          }
          BD.aprobarMigracion(plan.huella); // nada que corregir: se actualiza solo
          migro = true;
        }
      } else migro = true;
      // 2) Abrir (y, si se aprobó, migrar dentro de la misma transacción) y leer todo
      const leido = await BD.leerTodo();
      estado.datos = Object.assign(N.datosVacios(), leido);
      estado.version++;
    } catch (error) {
      console.error(error);
      const conRespaldo = error && ['version-nueva', 'migracion-cancelada', 'migracion-pendiente'].includes(error.codigo);
      mostrarErrorInicio((error && error.message) || 'Error desconocido.', conRespaldo);
      return;
    }
    estado.listo = true;
    U.render();
    if (migro && !N.estaVacio(estado.datos)) U.avisar('Datos actualizados a la versión nueva. Se guardó una copia de cómo estaban.');
    BD.pedirQueNoSeBorre();
    // La revisión de reglas recorre todo el inventario: se deja para después de pintar la pantalla
    setTimeout(U.revisarDatosAlAbrir, 250);
  };

  $('botonReintentar').addEventListener('click', () => U.iniciar());
})();
