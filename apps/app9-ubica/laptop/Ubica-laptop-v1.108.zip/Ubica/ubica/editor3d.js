// Ubica · Editor 3D: barra de herramientas, paneles de objetos, jerarquía y atajos de teclado.
// Las reglas (qué se puede guardar y cómo) están en nucleo.js y espacio.js; escena3d.js dibuja y
// avisa qué se tocó o se arrastró. Este archivo solo conecta una cosa con la otra.
(function () {
  'use strict';

  const U = window.Ubica;
  const { N, e, $, estado } = U;
  const { cabeza, valores, ejecutar, abrirHoja, abrirHojaUnica, volverHoja, cerrarHojas, refrescarHoja, ICONOS } = U;
  const E = window.Espacio;
  const datos = () => estado.datos;
  const editor = estado.editor;

  const opcionesEspacio = () => ({ permitirEncimar: Boolean(U.ajustes.permitirEncimar) });
  const numero = (texto) => Number(String(texto == null ? '' : texto).trim().replace(',', '.'));
  const objeto = (id) => N.buscarPorId(datos().objetos, id);
  const seleccionados = () => editor.seleccion.map(objeto).filter(Boolean);
  const nombreDe = (o) => N.nombreDeObjeto(datos(), o);

  const icono = (d) => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '"/></svg>';
  const I = {
    duplicar: icono('M16 1H4a2 2 0 0 0-2 2v14h2V3h12zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11z'),
    apilar: icono('M6 13h12v8H6zm2 2v4h8v-4zM6 3h12v8H6zm2 2v4h8V5z'),
    asentar: icono('M16 11h-3V3h-2v8H8l4 4zM4 19v2h16v-2z'),
    deshacer: icono('M12.5 8a10.4 10.4 0 0 0-6.9 2.6L2 7v9h9l-3.6-3.6A8 8 0 0 1 20.4 16l2.3-.8A10.5 10.5 0 0 0 12.5 8z'),
    rehacer: icono('M18.4 10.6A10.4 10.4 0 0 0 11.5 8 10.5 10.5 0 0 0 1.3 15.2l2.3.8a8 8 0 0 1 13-3.6L13 16h9V7z'),
    capas: icono('M3 4h7v4H3zm4 4h2v3h5V9h7v4h-7v-1H9v5h5v-2h7v4h-7v-1H7z'),
    escalar: icono('M21 11V3h-8l3.3 3.3-10 10L3 13v8h8l-3.3-3.3 10-10z'),
    iman: icono('M3 7v6a9 9 0 0 0 18 0V7h-6v6a3 3 0 0 1-6 0V7zm2 2h2v1.5H5zm12 0h2v1.5h-2z'),
    interior: icono('M4 3h16v18H4zm2 2v5h12V5zm0 7v7h12v-7zm3-5h6v1H9zm0 7h6v1H9z')
  };

  // Miniaturas de las figuras (solo trazo)
  const TRAZOS_FIGURA = {
    caja: 'M4 8l8-4 8 4v8l-8 4-8-4zM4 8l8 4 8-4M12 12v8',
    cilindro: 'M5 6c0-1.7 3.1-3 7-3s7 1.3 7 3v12c0 1.7-3.1 3-7 3s-7-1.3-7-3zM5 6c0 1.7 3.1 3 7 3s7-1.3 7-3',
    tubo: 'M5 6c0-1.7 3.1-3 7-3s7 1.3 7 3v12c0 1.7-3.1 3-7 3s-7-1.3-7-3zM9 6c0 .6 1.3 1 3 1s3-.4 3-1-1.3-1-3-1-3 .4-3 1',
    esfera: 'M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18M3 12c0 1.7 4 3 9 3s9-1.3 9-3',
    cono: 'M12 3 5 18c0 1.7 3.1 3 7 3s7-1.3 7-3zM5 18c0-1.7 3.1-3 7-3s7 1.3 7 3',
    aro: 'M2 12c0-2.8 4.5-5 10-5s10 2.2 10 5-4.5 5-10 5S2 14.8 2 12zm6 0c0 .8 1.8 1.5 4 1.5s4-.7 4-1.5-1.8-1.5-4-1.5-4 .7-4 1.5',
    prisma: 'M4 18 12 4l8 14zM12 4v10M4 18l8-4 8 4',
    piramide: 'M12 3 3 17l9 4 9-4zM12 3v18'
  };
  const miniatura = (figura) => '<svg class="miniatura" viewBox="0 0 24 24" aria-hidden="true"><path d="' + (TRAZOS_FIGURA[figura] || TRAZOS_FIGURA.caja) + '"/></svg>';
  const COLOR_FIGURA = {
    caja: '#c08a52', cilindro: '#4a7fc1', tubo: '#9aa1ad', esfera: '#e0a030', cono: '#f26b1d', aro: '#2b2d33', prisma: '#58a87a', piramide: '#a070c8'
  };

  // ---------- Selección ----------
  // Un objeto de un grupo trae a todo su grupo
  function conSuGrupo(ids) {
    const grupos = new Set(ids.map(objeto).filter((o) => o && o.grupoId).map((o) => o.grupoId));
    const todos = new Set(ids.filter(objeto));
    datos().objetos.forEach((o) => {
      if (o.grupoId && grupos.has(o.grupoId)) todos.add(o.id);
    });
    return Array.from(todos);
  }

  // opciones: { sumar: agrega o quita de la selección, panel: abre las propiedades }
  // Tocar un objeto solo lo selecciona (con el manipulador listo para moverlo): las propiedades se
  // abren con su botón de la barra, para que el panel no tape la escena cada vez que eliges algo.
  // Si el panel ya estaba abierto, se actualiza con lo nuevo.
  U.seleccionarObjetos = (ids, opciones) => {
    const ajustes = opciones || {};
    let lista = conSuGrupo(ids);
    if (ajustes.sumar) {
      const todosEstaban = lista.every((id) => editor.seleccion.includes(id));
      lista = todosEstaban ? editor.seleccion.filter((id) => !lista.includes(id)) : Array.from(new Set(editor.seleccion.concat(lista)));
    }
    editor.seleccion = lista;
    if (lista.length && !editor.interiorId) estado.seleccionadoId = null;
    U.render();
    U.redibujarEscenas();
    const panelAbierto = $('contenidoHoja').querySelector('[data-panel="objetos"]');
    if (lista.length && (ajustes.panel || panelAbierto)) abrirHojaUnica(pantallaObjetos);
    else if (!lista.length && panelAbierto) cerrarHojas();
  };

  function cambiarHerramienta(clave) {
    editor.herramienta = clave;
    pintarEditor();
    U.redibujarEscenas();
  }

  // Dónde se agregan las cosas nuevas: dentro del mueble que se edita o en el piso del lugar
  function contenedorActual() {
    const lugar = U.lugarAbierto();
    return { lugarId: lugar.id, muebleId: editor.interiorId || null };
  }

  function cercaActual() {
    if (editor.interiorId) return { x: 0, y: 0 };
    return U.escena3d ? U.escena3d.centroDeVista() : null;
  }

  // Guarda un cambio con «Deshacer» y vuelve a dibujar
  async function hacer(resultado, mensaje, opciones) {
    const ok = await ejecutar(resultado, Object.assign({ mensaje: mensaje, deshacer: true }, opciones || {}));
    U.redibujarEscenas();
    if (ok) refrescarHoja();
    return ok;
  }

  // «Listo.» o, si quedó con aviso, el aviso (se guarda igual)
  function conAviso(texto, resultado) {
    if (!resultado.ok || resultado.nivel !== 'aviso') return texto;
    const problema = Object.values(resultado.revisiones || {}).map((r) => r.problemas[0]).find(Boolean);
    return texto + '. Ojo: ' + (problema ? problema.mensaje.charAt(0).toLowerCase() + problema.mensaje.slice(1) : 'revisa su colocación.');
  }

  const listaDeNombres = (objetos) => (objetos.length === 1 ? '«' + nombreDe(objetos[0]) + '»' : N.plural(objetos.length, 'objeto'));

  // ---------- Lo que manda la escena 3D ----------
  // Mientras se arrastra con el manipulador: ¿la posición es válida? (pinta de rojo o ámbar)
  U.previsualizarObjetos = (propuestas) => {
    const objetos = propuestas.map((p) => {
      const o = objeto(p.id);
      return o ? Object.assign({}, o, { pos: p.pos, rot: p.rot, medidas: p.medidas }) : null;
    }).filter(Boolean);
    if (!objetos.length) return null;
    const revision = N.revisarObjetos(datos(), objetos, opcionesEspacio());
    const porId = {};
    let mensaje = '';
    Object.keys(revision.revisiones).forEach((id) => {
      const r = revision.revisiones[id];
      porId[id] = r.nivel;
      if (!mensaje && r.problemas.length) mensaje = (r.problemas.find((p) => p.grave) || r.problemas[0]).mensaje;
    });
    mostrarEstado(revision.nivel, objetos[0], mensaje);
    return { nivel: revision.nivel, porId: porId, mensaje: mensaje };
  };

  let temporizadorEstado = null;
  function mostrarEstado(nivel, o, mensaje) {
    const caja = $('estadoEditor');
    const lim = E.limites(E.formaDeChoque(o));
    const cifra = (n) => E.redondear(n, 2).toFixed(2);
    caja.className = 'estado-editor ' + nivel;
    caja.textContent = 'X ' + cifra(o.pos.x) + ' · Y ' + cifra(o.pos.y) + ' · Z ' + cifra(lim.min[2]) + ' m' + (mensaje ? ' — ' + mensaje : '');
    caja.hidden = false;
    clearTimeout(temporizadorEstado);
    temporizadorEstado = setTimeout(() => { caja.hidden = true; }, 2500);
  }

  // Al soltar el manipulador: se guarda (o se explica por qué no y regresa a donde estaba)
  U.transformarObjetos = async (propuestas, info) => {
    const asentar = Boolean(U.ajustes.asentarAlSoltar) && info.modo === 'translate' && !info.vertical;
    const resultado = N.transformarObjetos(datos(), propuestas, Object.assign({ asentar: asentar }, opcionesEspacio()));
    const objetos = propuestas.map((p) => objeto(p.id)).filter(Boolean);
    const verbo = info.modo === 'rotate' ? 'Giraste ' : info.modo === 'scale' ? 'Cambiaste las medidas de ' : 'Moviste ';
    await hacer(resultado, resultado.ok ? conAviso(verbo + listaDeNombres(objetos), resultado) : '');
  };

  U.fijarArticuloEnInterior = async (muebleId, articuloId) => {
    const resultado = N.fijarAutomatico(datos(), muebleId, articuloId, opcionesEspacio());
    const articulo = N.buscarPorId(datos().articulos, articuloId);
    if (await hacer(resultado, 'Ahora puedes mover «' + (articulo ? articulo.nombre : 'el artículo') + '» a mano')) U.seleccionarObjetos([resultado.objeto.id]);
  };

  // ---------- Editar el interior de un mueble ----------
  U.editarInterior = async (muebleId) => {
    const mueble = N.buscarPorId(datos().muebles, muebleId);
    if (!mueble) return;
    const lugar = N.buscarPorId(datos().lugares, mueble.lugarId);
    if (!N.estaColocado(mueble) || !lugar.plano) {
      U.avisar('Coloca primero «' + mueble.nombre + '» en el plano.');
      return;
    }
    if (estado.lugarId !== lugar.id) U.irALugar(lugar.id);
    if (U.vistaActual() !== '3d') await U.cambiarVista('3d');
    editor.interiorId = muebleId;
    editor.seleccion = [];
    estado.seleccionadoId = muebleId;
    if (!U.esEscritorio()) cerrarHojas();
    else abrirHojaUnica(() => pantallaJerarquia(muebleId));
    U.render();
    U.redibujarEscenas();
    U.avisar('Editando el interior de «' + mueble.nombre + '». Toca lo que guarda para moverlo, o «Agregar».');
  };

  // Lleva a la vista 3D y selecciona los objetos indicados (desde la ficha de un artículo).
  // Si están dentro de un mueble, entra a su interior para que se puedan mover.
  U.verObjetosEn3D = async (ids) => {
    const objetos = ids.map((id) => N.buscarPorId(datos().objetos, id)).filter(Boolean);
    if (!objetos.length) return;
    const primero = objetos[0];
    if (estado.lugarId !== primero.lugarId) U.irALugar(primero.lugarId);
    if (U.vistaActual() !== '3d') await U.cambiarVista('3d');
    cerrarHojas();
    if (primero.muebleId) await U.editarInterior(primero.muebleId);
    U.seleccionarObjetos(objetos.filter((o) => o.muebleId === primero.muebleId).map((o) => o.id));
  };

  U.salirDelInterior = () => {
    editor.interiorId = null;
    editor.seleccion = [];
    U.render();
    U.redibujarEscenas();
  };

  // ---------- Acciones ----------
  async function agregarFigura(figura) {
    const lugar = U.lugarAbierto();
    const contenedor = contenedorActual();
    const resultado = N.crearObjeto(datos(), {
      lugarId: lugar.id, muebleId: contenedor.muebleId, figura: figura, cerca: cercaActual(), color: COLOR_FIGURA[figura]
    }, opcionesEspacio());
    if (await hacer(resultado, 'Agregaste: ' + N.FIGURAS_OBJETO[figura].nombre.toLowerCase())) {
      editor.herramienta = 'mover';
      cerrarHojas();
      U.seleccionarObjetos([resultado.objeto.id]);
    }
  }

  async function agregarModelo(modeloId) {
    const resultado = N.insertarModelo(datos(), modeloId, contenedorActual(), cercaActual(), opcionesEspacio());
    if (await hacer(resultado, resultado.ok ? 'Agregaste: ' + resultado.modelo.nombre : '')) {
      editor.herramienta = 'mover';
      cerrarHojas();
      U.seleccionarObjetos(resultado.objetos.map((o) => o.id));
    }
  }

  async function duplicar(modo) {
    const objetos = seleccionados();
    if (!objetos.length) return;
    const resultado = N.duplicarObjetos(datos(), objetos.map((o) => o.id), modo, opcionesEspacio());
    let texto = '';
    if (resultado.ok) {
      texto = (modo === 'encima' ? 'Apilaste otra copia de ' : 'Duplicaste ') + listaDeNombres(objetos);
      if (resultado.sinEnlace) texto += '. La copia no cuenta en el inventario: ya están dibujadas todas sus piezas';
    }
    if (await hacer(resultado, conAviso(texto, resultado))) U.seleccionarObjetos(resultado.copias.map((o) => o.id));
  }

  async function asentar() {
    const objetos = seleccionados();
    if (!objetos.length) return;
    await hacer(N.asentarObjetos(datos(), objetos.map((o) => o.id), opcionesEspacio()), 'Asentaste ' + listaDeNombres(objetos));
  }

  async function borrar() {
    const objetos = seleccionados();
    if (!objetos.length) return;
    const enlazados = objetos.filter((o) => o.articuloId).length;
    const texto = 'Borraste ' + listaDeNombres(objetos) + (enlazados ? ' (el inventario no cambia)' : '');
    if (await hacer(N.borrarObjetos(datos(), objetos.map((o) => o.id)), texto)) U.seleccionarObjetos([]);
  }

  async function agrupar() {
    const objetos = seleccionados();
    if (await hacer(N.agruparObjetos(datos(), objetos.map((o) => o.id)), 'Agrupaste ' + listaDeNombres(objetos) + ': ahora se mueven juntos')) refrescarHoja();
  }

  async function desagrupar() {
    const objetos = seleccionados();
    await hacer(N.desagruparObjetos(datos(), objetos.map((o) => o.id)), 'Desagrupaste ' + listaDeNombres(objetos));
  }

  async function sacarAlPiso() {
    const objetos = seleccionados();
    const resultado = N.moverObjetosA(datos(), objetos.map((o) => o.id), { lugarId: estado.lugarId }, opcionesEspacio());
    if (await hacer(resultado, conAviso('Sacaste ' + listaDeNombres(objetos) + ' al piso', resultado))) {
      if (editor.interiorId) editor.interiorId = null;
      U.seleccionarObjetos(objetos.map((o) => o.id));
    }
  }

  // ---------- Paneles ----------
  function estadoRevision(revision) {
    if (revision.nivel === 'ok') return '<p class="revision ok">Bien colocado.</p>';
    return '<ul class="revision ' + revision.nivel + '">' + revision.problemas.map((p) => '<li>' + e(p.mensaje) + '</li>').join('') + '</ul>';
  }

  function campoNumero(nombre, etiqueta, valor, paso, clase) {
    return '<label class="campo campo-numero ' + (clase || '') + '"><span>' + etiqueta + '</span><input name="' + nombre +
      '" type="number" inputmode="decimal" step="' + paso + '" value="' + valor + '" required></label>';
  }

  let proporcionesFijas = false;

  // Objetos apilados con este: mismo contenedor y casi el mismo centro en el piso (±5 cm).
  // En el celular no hay Ctrl + clic: así se eligen de un toque las 4 llantas de una pila.
  function pilaDe(o) {
    return (datos().objetos || []).filter((x) => x.lugarId === o.lugarId && x.muebleId === o.muebleId &&
      Math.abs(x.pos.x - o.pos.x) < 0.05 && Math.abs(x.pos.y - o.pos.y) < 0.05).sort((a, b) => a.pos.z - b.pos.z);
  }

  function pantallaObjetos() {
    const objetos = seleccionados();
    if (!objetos.length) return null;
    if (objetos.length > 1) return pantallaVarios(objetos);
    const o = objetos[0];
    const lugar = N.buscarPorId(datos().lugares, o.lugarId);
    const mueble = o.muebleId ? N.buscarPorId(datos().muebles, o.muebleId) : null;
    const articulo = o.articuloId ? N.buscarPorId(datos().articulos, o.articuloId) : null;
    const revision = N.revisarObjeto(datos(), o, opcionesEspacio());
    const base = E.redondear(E.limites(E.formaDeChoque(o)).min[2], 3);
    const figuras = Object.keys(N.FIGURAS_OBJETO).map((clave) => '<option value="' + clave + '"' + (clave === o.figura ? ' selected' : '') + '>' +
      e(N.FIGURAS_OBJETO[clave].nombre) + '</option>').join('');
    const html = cabeza(nombreDe(o), (mueble ? 'Dentro de ' + mueble.nombre : 'En el piso de ' + lugar.nombre) + (o.grupoId ? ' · en un grupo' : '')) +
      '<div data-panel="objetos">' + estadoRevision(revision) +
      '<form data-form="objeto" class="form-objeto" novalidate><p class="error" role="alert" hidden></p>' +
      '<div class="campos-fila"><label class="campo">Nombre<input name="nombre" maxlength="' + N.LIMITES.nombre + '" value="' + e(o.nombre) +
      '" placeholder="' + e(articulo ? articulo.nombre : N.FIGURAS_OBJETO[o.figura].nombre) + '" autocomplete="off"></label>' +
      '<label class="campo campo-color">Color<input type="color" name="color" value="' + e(o.color) + '"></label></div>' +
      '<label class="campo">Figura<select name="figura">' + figuras + '</select></label>' +
      '<fieldset class="ejes"><legend>Medidas (m)</legend>' +
      campoNumero('ancho', 'Ancho', o.medidas.ancho, 0.01, 'eje-x') + campoNumero('fondo', 'Fondo', o.medidas.fondo, 0.01, 'eje-y') +
      campoNumero('alto', 'Alto', o.medidas.alto, 0.01, 'eje-z') +
      '<label class="casilla"><input type="checkbox" name="proporcion" value="si"' + (proporcionesFijas ? ' checked' : '') + '><span>Mantener proporciones</span></label>' +
      '<button type="button" class="boton chico restablecer" data-accion="restablecerMedidas"' + (medidasIniciales(o) ? '' : ' disabled') + '>Restablecer medidas</button></fieldset>' +
      '<fieldset class="ejes"><legend>Posición (m)' + (mueble ? ' · desde el centro del mueble' : '') + '</legend>' +
      campoNumero('x', 'X', o.pos.x, 0.01, 'eje-x') + campoNumero('y', 'Y', o.pos.y, 0.01, 'eje-y') + campoNumero('z', 'Z (base)', base, 0.01, 'eje-z') + '</fieldset>' +
      '<fieldset class="ejes"><legend>Giro (°)</legend>' +
      campoNumero('rx', 'X', o.rot.x, 1, 'eje-x') + campoNumero('ry', 'Y', o.rot.y, 1, 'eje-y') + campoNumero('rz', 'Z', o.rot.z, 1, 'eje-z') +
      '<button type="button" class="boton chico restablecer" data-accion="restablecerGiro"' + (o.rot.x || o.rot.y || o.rot.z ? '' : ' disabled') + '>Restablecer giro</button></fieldset>' +
      '<div class="fila-botones"><button type="button" class="boton chico" data-accion="girar90">Girar 90°</button>' +
      '<button type="button" class="boton chico" data-accion="acostar">' + (Math.abs(o.rot.x) > 45 ? 'Parar' : 'Acostar') + '</button>' +
      '<button class="boton principal chico">Aplicar</button></div></form>' +
      seccionInventario([o], articulo) +
      '<h3>Acciones</h3><div class="acciones-objeto">' +
      (pilaDe(o).length > 1 ? boton('pila', I.apilar, 'Elegir toda la pila (' + pilaDe(o).length + ')') : '') +
      boton('duplicar', I.duplicar, 'Duplicar') + boton('apilar', I.apilar, 'Apilar encima') + boton('asentar', I.asentar, 'Asentar') +
      (mueble ? boton('sacar', ICONOS.abrir, 'Sacar al piso') : boton('meter', I.interior, 'Meter en un mueble…')) +
      (o.grupoId ? boton('desagrupar', I.capas, 'Desagrupar') : '') + boton('modelo', ICONOS.guardar, 'Guardar como modelo…') +
      boton('borrar', ICONOS.borrar, 'Borrar', 'peligro') + '</div></div>';
    return { html: html, acciones: accionesComunes(objetos, { objeto: aplicarFormulario, pila: () => U.seleccionarObjetos(pilaDe(o).map((x) => x.id), { panel: true }) }) };
  }

  const boton = (accion, icono, texto, clase) => '<button type="button" class="boton chico ' + (clase || '') + '" data-accion="' + accion + '">' + icono + texto + '</button>';

  function seccionInventario(objetos, articulo) {
    if (articulo) {
      const dibujadas = N.unidadesRepresentadas(datos(), articulo.id);
      const aqui = objetos.reduce((s, o) => s + (o.unidades || 1), 0);
      return '<h3>Inventario</h3><p class="dato-inventario">' + (objetos.length === 1 ? 'Representa ' : 'Representan ') + '<strong>' + aqui + '</strong> de las <strong>' +
        N.totalDe(articulo) + '</strong> piezas de «' + e(articulo.nombre) + '»' + (dibujadas !== aqui ? ' (en 3D hay ' + dibujadas + ' dibujadas)' : '') + '.</p>' +
        (objetos.length === 1 ? '<form data-form="unidades" class="fila-botones" novalidate><p class="error" role="alert" hidden></p>' +
          U.campoContador('unidades', 'Piezas que representa', objetos[0].unidades || 1, 1, N.totalDe(articulo)) +
          '<button class="boton chico">Guardar</button></form>' : '') +
        '<div class="fila-botones"><button type="button" class="boton chico" data-accion="verArticulo">Ver el artículo</button>' +
        '<button type="button" class="boton chico" data-accion="desenlazar">Desenlazar</button></div>';
    }
    return '<h3>Inventario</h3><p class="nota fija">' + (objetos.length === 1 ? 'Es solo una figura' : 'Son solo figuras') + ': no cuenta en el inventario.</p>' +
      '<div class="fila-botones"><button type="button" class="boton chico" data-accion="enlazar">Enlazar a un artículo…</button>' +
      '<button type="button" class="boton chico" data-accion="registrar">Registrar como artículo…</button></div>';
  }

  function pantallaVarios(objetos) {
    const revision = N.revisarObjetos(datos(), objetos, opcionesEspacio());
    const mismoSitio = objetos.every((o) => o.lugarId === objetos[0].lugarId && (o.muebleId || null) === (objetos[0].muebleId || null));
    const grupo = objetos[0].grupoId && objetos.every((o) => o.grupoId === objetos[0].grupoId) ? objetos[0].grupoId : null;
    const articulos = Array.from(new Set(objetos.map((o) => o.articuloId)));
    const articulo = articulos.length === 1 && articulos[0] ? N.buscarPorId(datos().articulos, articulos[0]) : null;
    const malos = Object.values(revision.revisiones).filter((r) => r.nivel !== 'ok').length;
    const html = cabeza(N.plural(objetos.length, 'objeto') + ' seleccionados', grupo ? 'Forman un grupo: se mueven juntos' : 'Se mueven juntos mientras estén seleccionados') +
      '<div data-panel="objetos">' + (malos ? '<p class="revision aviso">' + N.plural(malos, 'objeto') + ' con aviso o error.</p>' : '<p class="revision ok">Bien colocados.</p>') +
      '<ul class="lista-simple">' + objetos.slice(0, 12).map((o) => '<li>' + e(nombreDe(o)) + (o.unidades > 1 ? ' ×' + o.unidades : '') + '</li>').join('') +
      (objetos.length > 12 ? '<li>…</li>' : '') + '</ul>' +
      (articulo || articulos.every((id) => !id) ? seccionInventario(objetos, articulo) : '<p class="nota fija">Representan artículos distintos.</p>') +
      '<h3>Acciones</h3><div class="acciones-objeto">' +
      boton('duplicar', I.duplicar, 'Duplicar') + boton('apilar', I.apilar, 'Apilar encima') + boton('asentar', I.asentar, 'Asentar') +
      (mismoSitio && !grupo ? boton('agrupar', I.capas, 'Agrupar') : '') + (grupo ? boton('desagrupar', I.capas, 'Desagrupar') : '') +
      (mismoSitio && objetos[0].muebleId ? boton('sacar', ICONOS.abrir, 'Sacar al piso') : '') +
      (mismoSitio && !objetos[0].muebleId ? boton('meter', I.interior, 'Meter en un mueble…') : '') +
      (mismoSitio ? boton('modelo', ICONOS.guardar, 'Guardar como modelo…') : '') + boton('borrar', ICONOS.borrar, 'Borrar', 'peligro') + '</div></div>';
    return { html: html, acciones: accionesComunes(objetos, {}) };
  }

  function accionesComunes(objetos, extra) {
    const ids = objetos.map((o) => o.id);
    return Object.assign({
      duplicar: () => duplicar('lado'),
      apilar: () => duplicar('encima'),
      asentar: asentar,
      agrupar: agrupar,
      desagrupar: desagrupar,
      sacar: sacarAlPiso,
      borrar: borrar,
      meter: () => abrirHoja(() => pantallaMeter(ids)),
      modelo: () => abrirHoja(() => pantallaModelo(ids)),
      enlazar: () => abrirHoja(() => pantallaEnlazar(ids)),
      registrar: () => abrirHoja(() => pantallaEnlazar(ids, true)),
      verArticulo: () => objetos[0].articuloId && U.abrirArticulo(objetos[0].articuloId),
      desenlazar: () => hacer(N.desvincularObjetos(datos(), ids), 'Desenlazaste ' + listaDeNombres(objetos) + ': quedan como figuras'),
      unidades: (form) => hacer(N.editarObjeto(datos(), ids[0], { unidades: valores(form).unidades }, opcionesEspacio()), 'Guardaste las piezas que representa', { form: form }),
      girar90: () => hacer(N.editarObjeto(datos(), ids[0], { rot: { z: E.normalizarAngulo(objetos[0].rot.z + 90) } }, opcionesEspacio()), 'Giraste «' + nombreDe(objetos[0]) + '»'),
      restablecerMedidas: () => restablecer(objetos[0], { medidas: Object.assign({}, N.MEDIDAS_INICIALES[objetos[0].figura]) }, 'Restableciste las medidas de'),
      restablecerGiro: () => restablecer(objetos[0], { rot: { x: 0, y: 0, z: 0 } }, 'Restableciste el giro de'),
      acostar: () => {
        const acostado = Math.abs(objetos[0].rot.x) > 45;
        hacer(N.editarObjeto(datos(), ids[0], { rot: { x: acostado ? 0 : 90 } }, opcionesEspacio()), (acostado ? 'Paraste' : 'Acostaste') + ' «' + nombreDe(objetos[0]) + '»');
      }
    }, extra);
  }

  // ¿Sus medidas ya no son las de fábrica de su figura? (si ya lo son, no hay nada que restablecer)
  function medidasIniciales(o) {
    const iniciales = N.MEDIDAS_INICIALES[o.figura];
    return iniciales && ['ancho', 'fondo', 'alto'].some((clave) => Math.abs(iniciales[clave] - o.medidas[clave]) > 1e-9);
  }

  // Regresa las medidas (a las de su figura) o el giro (a 0°) sin mover la base:
  // el objeto sigue apoyado donde estaba, con el mismo centro en el piso.
  function restablecer(o, cambio, texto) {
    const base = E.limites(E.formaDeChoque(o)).min[2];
    const nuevo = Object.assign({}, o, cambio, { pos: { x: 0, y: 0, z: 0 } });
    const bajo = E.limites(E.formaDeChoque(nuevo)).min[2];
    const pos = { x: o.pos.x, y: o.pos.y, z: E.redondear(base - bajo, 4) };
    const resultado = N.editarObjeto(datos(), o.id, Object.assign({}, cambio, { pos: pos }), opcionesEspacio());
    return hacer(resultado, conAviso(texto + ' «' + nombreDe(o) + '»', resultado));
  }

  // Aplica el formulario de propiedades (cada cambio se ve al momento)
  async function aplicarFormulario(form) {
    const o = seleccionados()[0];
    if (!o) return;
    const v = valores(form);
    proporcionesFijas = Boolean(v.proporcion);
    let medidas = { ancho: numero(v.ancho), fondo: numero(v.fondo), alto: numero(v.alto) };
    if (proporcionesFijas) {
      // La medida que cambió manda: las otras dos crecen o se encogen igual
      const cambiada = ['ancho', 'fondo', 'alto'].find((clave) => Math.abs(medidas[clave] - o.medidas[clave]) > 1e-9);
      if (cambiada && o.medidas[cambiada] > 0) {
        const factor = medidas[cambiada] / o.medidas[cambiada];
        medidas = { ancho: E.redondear(o.medidas.ancho * factor, 3), fondo: E.redondear(o.medidas.fondo * factor, 3), alto: E.redondear(o.medidas.alto * factor, 3) };
      }
    }
    const rot = { x: numero(v.rx), y: numero(v.ry), z: numero(v.rz) };
    if ([medidas.ancho, medidas.fondo, medidas.alto, rot.x, rot.y, rot.z, numero(v.x), numero(v.y), numero(v.z)].some((n) => !Number.isFinite(n))) {
      U.mostrarError(form, 'Usa números, por ejemplo 2.35.');
      return;
    }
    // La Z que se escribe es la de la base: el centro se calcula con la figura ya girada y medida
    const prueba = Object.assign({}, o, { figura: v.figura, medidas: medidas, rot: rot, pos: { x: 0, y: 0, z: 0 } });
    const bajo = E.limites(E.formaDeChoque(prueba)).min[2];
    const pos = { x: numero(v.x), y: numero(v.y), z: E.redondear(numero(v.z) - bajo, 4) };
    const resultado = N.editarObjeto(datos(), o.id, { nombre: v.nombre, color: v.color, figura: v.figura, medidas: medidas, rot: rot, pos: pos }, opcionesEspacio());
    await hacer(resultado, conAviso('Guardaste «' + (v.nombre || nombreDe(o)) + '»', resultado), { form: form });
  }

  // Cualquier cambio en el formulario se aplica al momento (con Enter o al salir del campo)
  $('contenidoHoja').addEventListener('change', (evento) => {
    const form = evento.target.closest('form[data-form="objeto"]');
    if (form && evento.target.name !== 'proporcion' && form.requestSubmit) form.requestSubmit();
  });

  function pantallaEnlazar(ids, registrar) {
    const objetos = ids.map(objeto).filter(Boolean);
    if (!objetos.length) return null;
    const contenedor = { lugarId: objetos[0].lugarId, muebleId: objetos[0].muebleId || null };
    const mismo = (a) => {
      const donde = N.contenedorDeArticulo(datos(), a);
      return donde && donde.lugarId === contenedor.lugarId && (donde.muebleId || null) === contenedor.muebleId;
    };
    const ordenados = datos().articulos.slice().sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'));
    const aqui = ordenados.filter(mismo);
    const otros = ordenados.filter((a) => !mismo(a));
    const opcion = (a) => '<option value="' + e(a.id) + '">' + e(a.nombre) + ' (' + N.totalDe(a) + ')</option>';
    const piezas = objetos.reduce((s, o) => s + (o.unidades || 1), 0);
    const sugerido = objetos[0].nombre || '';
    const html = cabeza(registrar ? 'Registrar en el inventario' : 'Enlazar a un artículo', listaDeNombres(objetos)) +
      (registrar ? '' :
        '<form data-form="enlazar" novalidate><p class="error" role="alert" hidden></p>' +
        '<label class="campo">Artículo<select name="articuloId">' +
        (aqui.length ? '<optgroup label="Aquí mismo">' + aqui.map(opcion).join('') + '</optgroup>' : '') +
        (otros.length ? '<optgroup label="En otro sitio (se trae aquí)">' + otros.map(opcion).join('') + '</optgroup>' : '') +
        '</select></label>' + U.campoContador('unidades', 'Piezas por objeto', 1, 1, N.LIMITES.cantidad) +
        '<p class="nota">Las piezas dibujadas no pueden pasar de las que tiene el artículo.</p>' +
        '<button class="boton principal">Enlazar</button></form><h3>O registra uno nuevo</h3>') +
      '<form data-form="registrar" novalidate><p class="error" role="alert" hidden></p>' +
      '<label class="campo">Nombre<input name="nombre" maxlength="' + N.LIMITES.nombre + '" value="' + e(sugerido) + '" placeholder="Ej. Llanta 205/55 R16" autocomplete="off" required></label>' +
      U.selectorCategoria(N.ID_OTROS) +
      '<p class="nota">Se crea con ' + N.plural(piezas, 'pieza') + ', aquí mismo.</p>' +
      '<button class="boton principal">Registrar (' + N.plural(piezas, 'pieza') + ')</button></form>';
    return {
      html: html,
      acciones: {
        enlazar: async (form) => {
          const v = valores(form);
          const resultado = N.vincularObjetos(datos(), ids, v.articuloId, { unidades: v.unidades });
          if (await hacer(resultado, resultado.ok ? 'Enlazaste ' + listaDeNombres(objetos) + ' a «' + resultado.articulo.nombre + '»' : '', { form: form })) volverHoja();
        },
        registrar: async (form) => {
          const v = valores(form);
          const resultado = N.registrarArticuloDesdeObjetos(datos(), ids, { nombre: v.nombre, categoriaId: v.categoriaId });
          const texto = resultado.ok ? (resultado.sumado ? 'Se sumaron ' + piezas + ' piezas a «' : 'Registraste «') + resultado.articulo.nombre + '»' : '';
          if (await hacer(resultado, texto, { form: form })) volverHoja();
        }
      }
    };
  }

  function pantallaMeter(ids) {
    const objetos = ids.map(objeto).filter(Boolean);
    if (!objetos.length) return null;
    const muebles = N.mueblesColocados(datos(), objetos[0].lugarId).filter((m) => m.id !== objetos[0].muebleId);
    return {
      html: cabeza('Meter en un mueble', listaDeNombres(objetos)) +
        (muebles.length ? '<ul class="lista-botones">' + muebles.map((m) => '<li><button type="button" data-accion="meterEn" data-valor="' + e(m.id) + '">' +
          U.iconoMueble(m.tipo) + '<span>' + e(m.nombre) + '</span><small>' + N.plural(N.objetosEnMueble(datos(), m.id).length, 'objeto') + '</small></button></li>').join('') + '</ul>'
          : '<p class="nota fija">No hay muebles colocados en este lugar.</p>') +
        '<p class="nota">Se acomoda en el primer hueco libre; si representa piezas del inventario, el artículo se va con él.</p>',
      acciones: {
        meterEn: async (botonElegido) => {
          const mueble = N.buscarPorId(datos().muebles, botonElegido.dataset.valor);
          const resultado = N.moverObjetosA(datos(), ids, { muebleId: mueble.id }, opcionesEspacio());
          if (await hacer(resultado, conAviso('Metiste ' + listaDeNombres(objetos) + ' en «' + mueble.nombre + '»', resultado))) {
            cerrarHojas();
            U.seleccionarObjetos(ids);
          }
        }
      }
    };
  }

  function pantallaModelo(ids) {
    const objetos = ids.map(objeto).filter(Boolean);
    if (!objetos.length) return null;
    return {
      html: cabeza('Guardar como modelo', listaDeNombres(objetos)) +
        '<form data-form="guardarModelo" novalidate><p class="error" role="alert" hidden></p>' +
        '<label class="campo">Nombre del modelo<input name="nombre" maxlength="' + N.LIMITES.nombre + '" value="' + e(objetos[0].nombre || '') +
        '" placeholder="Ej. Tarima con cajas" autocomplete="off" required></label>' +
        '<p class="nota">Después lo encuentras en «Agregar», para ponerlo en cualquier lugar o mueble.</p>' +
        '<button class="boton principal">Guardar modelo</button></form>',
      acciones: {
        guardarModelo: async (form) => {
          const resultado = N.guardarModelo(datos(), ids, valores(form).nombre);
          if (await hacer(resultado, resultado.ok ? 'Guardaste el modelo «' + resultado.modelo.nombre + '»' : '', { form: form })) volverHoja();
        }
      }
    };
  }

  function pantallaAgregar() {
    const lugar = U.lugarAbierto();
    if (!lugar) return null;
    const interior = editor.interiorId ? N.buscarPorId(datos().muebles, editor.interiorId) : null;
    const figuras = Object.keys(N.FIGURAS_OBJETO).map((clave) => '<button type="button" class="opcion-figura" data-accion="figura" data-valor="' + clave +
      '" style="--color-figura:' + COLOR_FIGURA[clave] + '">' + miniatura(clave) + '<span>' + e(N.FIGURAS_OBJETO[clave].nombre) + '</span></button>').join('');
    const modelos = N.todosLosModelos(datos()).map((m) => '<li><button type="button" data-accion="modelo" data-valor="' + e(m.id) + '">' +
      miniatura(m.piezas[0].figura) + '<span>' + e(m.nombre) + '</span><small>' + (m.base ? '' : 'Tuyo · ') + N.plural(m.piezas.length, 'pieza') + '</small></button>' +
      (m.base ? '' : '<button type="button" class="boton-icono" data-accion="borrarModelo" data-valor="' + e(m.id) + '" aria-label="Borrar el modelo ' + e(m.nombre) + '">' + ICONOS.borrar + '</button>') + '</li>').join('');
    return {
      html: cabeza('Agregar', interior ? 'Dentro de ' + interior.nombre : 'En el piso de ' + lugar.nombre) +
        '<h3>Figuras</h3><div class="rejilla-figuras">' + figuras + '</div>' +
        '<h3>Modelos</h3><ul class="lista-botones modelos">' + modelos + '</ul>' +
        '<p class="nota">Aparece en el hueco libre más cercano al centro de la vista. Luego la mueves, la giras o le cambias las medidas.</p>',
      acciones: {
        figura: (b) => agregarFigura(b.dataset.valor),
        modelo: (b) => agregarModelo(b.dataset.valor),
        borrarModelo: (b) => hacer(N.borrarModelo(datos(), b.dataset.valor), 'Borraste el modelo')
      }
    };
  }

  // Jerarquía: lo que hay en el piso y dentro de cada mueble (solo un mueble si se indica)
  function pantallaJerarquia(soloMuebleId) {
    const lugar = U.lugarAbierto();
    if (!lugar) return null;
    const fila = (o) => '<li><button type="button" data-accion="elegir" data-valor="' + e(o.id) + '"' + (editor.seleccion.includes(o.id) ? ' class="activo"' : '') + '>' +
      miniatura(o.figura) + '<span>' + e(nombreDe(o)) + (o.unidades > 1 ? ' ×' + o.unidades : '') + '</span><small>' + (o.articuloId ? 'Inventario' : 'Figura') + '</small></button></li>';
    const lista = (objetos) => {
      const sueltos = objetos.filter((o) => !o.grupoId);
      const grupos = new Map();
      objetos.filter((o) => o.grupoId).forEach((o) => {
        if (!grupos.has(o.grupoId)) grupos.set(o.grupoId, []);
        grupos.get(o.grupoId).push(o);
      });
      return '<ul class="lista-botones arbol">' + Array.from(grupos.values()).map((g) => '<li class="grupo-arbol"><button type="button" data-accion="elegir" data-valor="' + e(g[0].id) + '">' +
        I.capas + '<span>' + e(nombreDe(g[0])) + '</span><small>Grupo · ' + N.plural(g.length, 'pieza') + '</small></button></li>').join('') + sueltos.map(fila).join('') + '</ul>';
    };
    const muebles = N.mueblesColocados(datos(), lugar.id).filter((m) => !soloMuebleId || m.id === soloMuebleId);
    const piso = soloMuebleId ? [] : N.objetosEnPiso(datos(), lugar.id);
    const bloques = muebles.map((m) => {
      const fijos = N.objetosEnMueble(datos(), m.id);
      const auto = N.acomodoInterior(datos(), m);
      if (!fijos.length && !auto.objetos.length && !soloMuebleId) return '';
      return '<h3>' + e(m.nombre) + '</h3>' + (fijos.length ? lista(fijos) : '') +
        (auto.objetos.length ? '<p class="nota fija">' + N.plural(auto.objetos.length, 'artículo acomodado solo', 'artículos acomodados solos') +
          (editor.interiorId === m.id ? ': tócalos en la escena para moverlos a mano.' : '.') + '</p>' : '') +
        (!fijos.length && !auto.objetos.length ? '<p class="nota fija">Vacío.</p>' : '') +
        (editor.interiorId === m.id ? '' : '<button type="button" class="boton chico" data-accion="interior" data-valor="' + e(m.id) + '">' + I.interior + 'Editar el interior</button>');
    }).join('');
    return {
      html: cabeza(soloMuebleId ? 'Interior' : 'Objetos', lugar.nombre) +
        (soloMuebleId ? '<button type="button" class="boton chico principal" data-accion="agregar">' + ICONOS.mas + 'Agregar aquí</button>' : '') +
        (soloMuebleId ? '' : '<h3>En el piso</h3>' + (piso.length ? lista(piso) : '<p class="nota fija">Nada todavía. Usa «Agregar».</p>')) + bloques,
      acciones: {
        elegir: (b) => {
          const o = objeto(b.dataset.valor);
          if (!o) return;
          if (o.muebleId && editor.interiorId !== o.muebleId) editor.interiorId = o.muebleId;
          if (!o.muebleId && editor.interiorId) editor.interiorId = null;
          U.seleccionarObjetos([o.id], { panel: true });
        },
        interior: (b) => U.editarInterior(b.dataset.valor),
        agregar: () => abrirHoja(pantallaAgregar)
      }
    };
  }

  // ---------- Barra de herramientas (solo en la vista 3D) ----------
  function pintarEditor() {
    const barra = $('barraEditor');
    if (!barra) return;
    const lugar = U.lugarAbierto();
    // La selección se limpia si sus objetos ya no existen (por ejemplo, después de deshacer)
    editor.seleccion = editor.seleccion.filter((id) => {
      const o = objeto(id);
      return o && lugar && o.lugarId === lugar.id;
    });
    if (editor.interiorId && !N.buscarPorId(datos().muebles, editor.interiorId)) editor.interiorId = null;
    const visible = Boolean(lugar && lugar.plano && estado.seccion === 'lugares' && U.vistaActual() === '3d' &&
      !document.body.classList.contains('presentacion') && !estado.modo);
    barra.hidden = !visible;
    document.body.classList.toggle('editando-interior', Boolean(visible && editor.interiorId));
    if (!visible) {
      $('escenario').style.setProperty('--alto-barra-editor', '0px');
      return;
    }
    const hay = editor.seleccion.length;
    const herramienta = (clave, svg, texto, atajo) => '<button type="button" class="boton-editor' + (editor.herramienta === clave ? ' activo' : '') +
      '" data-editor="herramienta" data-valor="' + clave + '" aria-pressed="' + (editor.herramienta === clave) + '" title="' + texto + ' (' + atajo + ')">' + svg + '<span>' + texto + '</span></button>';
    const accion = (clave, svg, texto, deshabilitado, clase) => '<button type="button" class="boton-editor ' + (clase || '') + '" data-editor="' + clave + '" title="' + texto + '"' +
      (deshabilitado ? ' disabled' : '') + '>' + svg + '<span>' + texto + '</span></button>';
    const interior = editor.interiorId ? N.buscarPorId(datos().muebles, editor.interiorId) : null;
    barra.innerHTML =
      (interior ? '<div class="chip-interior">' + I.interior + '<span>Interior de <strong>' + e(interior.nombre) + '</strong></span>' +
        '<button type="button" class="boton chico" data-editor="salirInterior">Salir</button></div>' : '') +
      '<div class="grupo-editor">' + accion('agregar', ICONOS.mas, 'Agregar') + accion('jerarquia', I.capas, 'Objetos') + '</div>' +
      (hay ? '<div class="grupo-editor" role="group" aria-label="Herramienta del manipulador">' +
        herramienta('mover', ICONOS.mover, 'Mover', 'G') + herramienta('rotar', ICONOS.girar, 'Girar', 'R') +
        (hay === 1 ? herramienta('escalar', I.escalar, 'Medidas', 'S') : '') + '</div>' +
        '<div class="grupo-editor">' + accion('propiedades', ICONOS.editar, 'Propiedades') + accion('duplicar', I.duplicar, 'Duplicar') +
        accion('apilar', I.apilar, 'Apilar') + accion('asentar', I.asentar, 'Asentar') + accion('borrar', ICONOS.borrar, 'Borrar', false, 'peligro') +
        accion('soltar', ICONOS.cerrar, 'Soltar') + '</div>' : '') +
      '<div class="grupo-editor">' + accion('deshacer', I.deshacer, 'Deshacer', !U.puedeDeshacer()) + accion('rehacer', I.rehacer, 'Rehacer', !U.puedeRehacer()) +
      '<button type="button" class="boton-editor' + (U.ajustes.imanEditor ? ' activo' : '') + '" data-editor="iman" aria-pressed="' + Boolean(U.ajustes.imanEditor) +
      '" title="Imán: de 5 cm en 5 cm y de 15° en 15°">' + I.iman + '<span>Imán</span></button></div>';
    // El aviso de arriba de la escena («Elige un mueble…») se pone debajo de la barra, no detrás
    $('escenario').style.setProperty('--alto-barra-editor', (barra.offsetHeight + 8) + 'px');
  }

  $('barraEditor').addEventListener('click', (evento) => {
    const elegido = evento.target.closest('[data-editor]');
    if (!elegido || elegido.disabled) return;
    const accion = elegido.dataset.editor;
    if (accion === 'herramienta') cambiarHerramienta(elegido.dataset.valor);
    else if (accion === 'agregar') abrirHojaUnica(pantallaAgregar);
    else if (accion === 'jerarquia') abrirHojaUnica(() => pantallaJerarquia(null));
    else if (accion === 'propiedades') abrirHojaUnica(pantallaObjetos);
    else if (accion === 'duplicar') duplicar('lado');
    else if (accion === 'apilar') duplicar('encima');
    else if (accion === 'asentar') asentar();
    else if (accion === 'borrar') borrar();
    else if (accion === 'soltar') U.seleccionarObjetos([]);
    else if (accion === 'deshacer') U.deshacer();
    else if (accion === 'rehacer') U.rehacer();
    else if (accion === 'iman') {
      U.cambiarAjuste('imanEditor', !U.ajustes.imanEditor);
      U.redibujarEscenas();
    } else if (accion === 'salirInterior') U.salirDelInterior();
  });

  // Cada vez que se vuelve a pintar la app, la barra del editor también
  const renderAnterior = U.render;
  U.render = (...argumentos) => {
    const resultado = renderAnterior(...argumentos);
    pintarEditor();
    return resultado;
  };

  // ---------- Atajos de teclado (en la vista 3D) ----------
  //   A agregar · G mover · R girar · S medidas · Ctrl+D duplicar · Ctrl+G agrupar (Mayús: desagrupar)
  //   Supr borrar · I editar el interior del mueble seleccionado · Esc soltar la selección o salir del interior
  window.addEventListener('keydown', (evento) => {
    const enCampo = /^(INPUT|TEXTAREA|SELECT)$/.test(evento.target.tagName);
    if (enCampo || evento.altKey || !estado.listo) return;
    if (!(estado.seccion === 'lugares' && estado.lugarId && U.vistaActual() === '3d') || document.body.classList.contains('presentacion')) return;
    const tecla = evento.key.toLowerCase();
    const control = evento.ctrlKey || evento.metaKey;
    const hay = editor.seleccion.length > 0;
    let atendido = true;
    if (control && tecla === 'd' && hay) duplicar('lado');
    else if (control && tecla === 'g' && hay) evento.shiftKey ? desagrupar() : agrupar();
    else if (control) atendido = false;
    else if (tecla === 'g' && hay) cambiarHerramienta('mover');
    else if (tecla === 'r' && hay) cambiarHerramienta('rotar');
    else if (tecla === 's' && hay && editor.seleccion.length === 1) cambiarHerramienta('escalar');
    else if ((tecla === 'delete' || tecla === 'backspace') && hay) borrar();
    else if (tecla === 'a' && !estado.modo) abrirHojaUnica(pantallaAgregar);
    else if (tecla === 'i' && estado.seleccionadoId && !editor.interiorId) U.editarInterior(estado.seleccionadoId);
    else if (tecla === 'escape' && hay) U.seleccionarObjetos([]);
    else if (tecla === 'escape' && editor.interiorId && !U.pila.length) U.salirDelInterior();
    else atendido = false;
    if (atendido) {
      evento.preventDefault();
      evento.stopImmediatePropagation();
    }
  }, true);

  U.pantallaObjetos = pantallaObjetos;
  U.pantallaJerarquia = pantallaJerarquia;
  U.pantallaAgregarForma = pantallaAgregar;
})();
