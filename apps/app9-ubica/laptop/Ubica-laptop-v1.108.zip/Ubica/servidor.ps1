﻿# Ubica para laptop (Windows): sirve la carpeta "ubica" en http://localhost:8719 y abre el navegador.
# Hace falta un servidor (aunque sea local) porque el 3D carga módulos de JavaScript, y los
# navegadores no los cargan desde un archivo abierto con doble clic (file://).
# No instala nada y solo escucha en esta computadora (localhost). Para cerrarlo, cierra esta ventana.
$ErrorActionPreference = 'Stop'
$puerto = 8719
$raiz = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'ubica')) + [IO.Path]::DirectorySeparatorChar
$direccion = "http://localhost:$puerto/"
$tipos = @{
  '.html' = 'text/html; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'; '.css' = 'text/css; charset=utf-8'
  '.json' = 'application/json'; '.webmanifest' = 'application/manifest+json'; '.png' = 'image/png'
  '.svg' = 'image/svg+xml'; '.woff2' = 'font/woff2'; '.ico' = 'image/x-icon'; '.txt' = 'text/plain; charset=utf-8'
}
$escucha = New-Object System.Net.HttpListener
$escucha.Prefixes.Add($direccion)
try {
  $escucha.Start()
} catch {
  # El puerto ya está ocupado: casi siempre es porque Ubica ya está abierta en otra ventana
  Write-Host "Ubica ya esta abierta (o el puerto $puerto esta ocupado). Abriendo el navegador..."
  Start-Process ($direccion + 'index.html')
  Start-Sleep -Seconds 3
  exit
}
Write-Host "Ubica esta funcionando en $direccion"
Write-Host "Tus datos se guardan en el navegador de esta computadora."
Write-Host "No cierres esta ventana mientras uses Ubica. Para terminar, cierrala."
Start-Process ($direccion + 'index.html')
while ($escucha.IsListening) {
  $contexto = $escucha.GetContext()
  $respuesta = $contexto.Response
  try {
    $ruta = [Uri]::UnescapeDataString($contexto.Request.Url.AbsolutePath).TrimStart('/')
    if ($ruta -eq '') { $ruta = 'index.html' }
    $archivo = [IO.Path]::GetFullPath((Join-Path $raiz $ruta))
    # Solo se entregan archivos que están dentro de la carpeta "ubica"
    if (-not $archivo.StartsWith($raiz, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $archivo -PathType Leaf)) {
      $respuesta.StatusCode = 404
    } else {
      $extension = [IO.Path]::GetExtension($archivo).ToLower()
      $respuesta.ContentType = if ($tipos.ContainsKey($extension)) { $tipos[$extension] } else { 'application/octet-stream' }
      $respuesta.Headers.Add('Cache-Control', 'no-cache')
      $bytes = [IO.File]::ReadAllBytes($archivo)
      $respuesta.ContentLength64 = $bytes.Length
      $respuesta.OutputStream.Write($bytes, 0, $bytes.Length)
    }
  } catch {
    $respuesta.StatusCode = 500
  } finally {
    $respuesta.OutputStream.Close()
  }
}
