#!/bin/sh
# Ubica para laptop (Mac o Linux): sirve la carpeta "ubica" en http://localhost:8719 y abre el navegador.
# Necesita python3 (en Mac viene con las herramientas de desarrollo; en Linux casi siempre está).
cd "$(dirname "$0")" || exit 1
PUERTO=8719
DIRECCION="http://localhost:$PUERTO/index.html"
if ! command -v python3 >/dev/null 2>&1; then
  echo "No encontré python3. Usa la versión web: https://app9-ubica.vercel.app"
  exit 1
fi
python3 -m http.server "$PUERTO" --bind 127.0.0.1 --directory ubica >/dev/null 2>&1 &
SERVIDOR=$!
sleep 1
if [ "$(uname)" = "Darwin" ]; then open "$DIRECCION"
else xdg-open "$DIRECCION" >/dev/null 2>&1 || echo "Abre $DIRECCION en tu navegador"; fi
echo "Ubica está funcionando en $DIRECCION"
echo "No cierres esta ventana mientras la uses. Para terminar: Ctrl+C."
trap 'kill $SERVIDOR 2>/dev/null' INT TERM EXIT
wait $SERVIDOR
