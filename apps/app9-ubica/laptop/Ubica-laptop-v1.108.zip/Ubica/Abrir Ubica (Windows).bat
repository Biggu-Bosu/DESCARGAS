@echo off
rem Abre Ubica en el navegador. Deja abierta esta ventana mientras la usas.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor.ps1"
if errorlevel 1 pause
