// CiberEscudo · service worker: hace que la versión web (iPhone) abra sin internet.
// Estrategia: red primero y, si no hay conexión, la copia guardada.
// Sube el número de VERSION cuando cambie la lista de archivos.
// En la app de Android y al abrir index.html directo no se usa (app.js no lo registra).
const VERSION = 'ciberescudo-v13';
const ARCHIVOS = [
  './',
  'index.html',
  'manifest.webmanifest',
  'icon-192.png',
  'icon-512.png',
  'apple-touch-icon.png',
  'assets/css/styles.css',
  'assets/js/mascot.js',
  'assets/js/password.js',
  'assets/js/simulator.js',
  'assets/js/quiz.js',
  'assets/js/tasks.js',
  'assets/js/app.js'
];

self.addEventListener('install', evento =>
  evento.waitUntil(
    caches
      .open(VERSION)
      .then(cache => cache.addAll(ARCHIVOS))
      .then(() => self.skipWaiting())
  )
);

self.addEventListener('activate', evento =>
  evento.waitUntil(
    caches
      .keys()
      .then(claves => Promise.all(claves.filter(clave => clave !== VERSION).map(clave => caches.delete(clave))))
      .then(() => self.clients.claim())
  )
);

self.addEventListener('fetch', evento => {
  const pedido = evento.request;
  if (pedido.method !== 'GET' || !pedido.url.startsWith(self.location.origin)) return;
  evento.respondWith(
    fetch(pedido)
      .then(respuesta => {
        const copia = respuesta.clone();
        caches.open(VERSION).then(cache => cache.put(pedido, copia));
        return respuesta;
      })
      .catch(() => caches.match(pedido, { ignoreSearch: true }).then(guardada => guardada || caches.match('index.html')))
  );
});
