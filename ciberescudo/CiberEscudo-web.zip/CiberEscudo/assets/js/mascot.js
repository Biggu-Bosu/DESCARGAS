// CiberEscudo · mascot.js
// Dibujos en pixel art hechos con SVG: la mascota (flor con lentes y mariposa),
// el logo con letras pixeladas y los íconos pequeños de la app.
//
// Cómo funciona: cada dibujo es una lista de filas de texto. Cada letra es un
// "pixel" de un color (la paleta dice qué color es cada letra) y el punto "."
// es transparente. La función svgDeMapa() convierte esas letras en cuadritos
// <rect> de SVG. Así puedes editar el dibujo cambiando letras, sin programar.

(function (global) {
  'use strict';

  const SVG_NS = 'http://www.w3.org/2000/svg';

  // ---------- La mascota: 24 × 28 pixeles ----------
  // P/p pétalo y su borde · h brillo · Y/y centro amarillo y su borde
  // K lentes · W reflejo de los lentes · r mejillas
  // (la boca no está en el mapa: se dibuja aparte, abierta y cerrada, para poder cantar)
  // B/b/c alas de la mariposa · k cuerpo · a antenas · G/g tallo y hojas
  const MAPA_MASCOTA = [
    '..........ppp..a...a....',
    '.........phPPp..a.a.....',
    '........pPPPPPcBBkBBc...',
    '.....pp.pPPPPPBBBkBBB...',
    '...ppPPppPPPPPpbBkBb....',
    '..pPPPPPppyyyppPbkbPp...',
    '..pPhPPPyyYYYyyPPPhPp...',
    '..pPPPPyYYYYYYYyPPPPp...',
    '..pPPPKKKKKKKKKKKPPPp...',
    '...pPPKKWKKKKWKKKppp....',
    '....ppyKKKKYKKKKypp.....',
    '...pppyYKKYYYKKYyPPp....',
    '..pPPPPyrYYYYYYrPPPPp...',
    '..pPhPPyYYYYYYYyPPhPp...',
    '..pPPPPPyyYYYyyPPPPPp...',
    '..pPPPPPppyyyppPPPPPp...',
    '...ppPPppPPPPPppPPpp....',
    '.....pp.pPhPPPp.pp......',
    '........pPPPPPp.........',
    '.........pPPPp..........',
    '..........ppp...........',
    '...........Gg...........',
    '......gGGGGGg...........',
    '.....gGGGGGGg...........',
    '......gggg.GgGGGGg......',
    '...........GgGGGGGGg....',
    '...........Gg.gggg......',
    '...........Gg...........'
  ];

  // Cada letra tiene un color y una "capa". Las capas se vuelven grupos <g>
  // separados para poder animar solo una parte (por ejemplo, las alas).
  const PALETA_MASCOTA = {
    P: { color: '#ff3d9a', capa: 'petalos' },
    p: { color: '#a3125a', capa: 'petalos' },
    h: { color: '#ffb0d6', capa: 'petalos' },
    Y: { color: '#ffd93b', capa: 'centro' },
    y: { color: '#e09a00', capa: 'centro' },
    m: { color: '#5c2200', capa: 'boca' },
    o: { color: '#ff7ab8', capa: 'boca' },
    r: { color: '#ff7ab8', capa: 'centro' },
    K: { color: '#0d0717', capa: 'lentes' },
    W: { color: '#7df9ff', capa: 'lentes' },
    B: { color: '#2f8cff', capa: 'mariposa' },
    b: { color: '#1747a6', capa: 'mariposa' },
    c: { color: '#9be7ff', capa: 'mariposa' },
    k: { color: '#0d0717', capa: 'mariposa' },
    a: { color: '#1747a6', capa: 'mariposa' },
    G: { color: '#3ee38f', capa: 'tallo' },
    g: { color: '#138a55', capa: 'tallo' }
  };

  // Orden en que se dibujan las capas (la última queda encima).
  const ORDEN_CAPAS = ['tallo', 'petalos', 'centro', 'boca-cerrada', 'boca-abierta', 'lentes', 'lagrima', 'hojas', 'mariposa'];

  // Las dos bocas como listas de pixeles [x, y, letra]. Al cantar, CSS
  // alterna cuál se ve, como en los videojuegos de 8 bits.
  const BOCA_CERRADA = [
    [9, 12, 'm'], [14, 12, 'm'],
    [10, 13, 'm'], [11, 13, 'm'], [12, 13, 'm'], [13, 13, 'm']
  ];
  const BOCA_ABIERTA = [
    [9, 12, 'm'], [10, 12, 'm'], [11, 12, 'm'], [12, 12, 'm'], [13, 12, 'm'], [14, 12, 'm'],
    [10, 13, 'm'], [11, 13, 'o'], [12, 13, 'o'], [13, 13, 'm'],
    [11, 14, 'm'], [12, 14, 'm']
  ];

  // Convierte un mapa pequeño en pixeles [x, y, letra], movido a la posición (x0, y0).
  function pixelesDeMapa(filas, x0, y0) {
    const pixeles = [];
    filas.forEach(function (fila, y) {
      fila.split('').forEach(function (letra, x) {
        if (letra !== '.') pixeles.push([x0 + x, y0 + y, letra]);
      });
    });
    return pixeles;
  }

  // Gestos que se dibujan sobre la cara (ocultos hasta que CSS los muestra).
  // Dos hojas que tapan los lentes, como manos sobre los ojos.
  const HOJA = ['.gggg.', 'gGGGGg', 'gGGGGg', 'gGGGGg', 'gGGGGg', '.gggg.'];
  const HOJAS_TAPAN = pixelesDeMapa(HOJA, 5, 7).concat(pixelesDeMapa(HOJA, 12, 7));
  // Una lágrima que sale de debajo del lente izquierdo.
  const LAGRIMA = [[8, 12, 'W'], [8, 13, 'c']];

  // ---------- Letras pixeladas para el logo (5 × 7) ----------
  const LETRAS = {
    C: ['.###.', '#...#', '#....', '#....', '#....', '#...#', '.###.'],
    I: ['###', '.#.', '.#.', '.#.', '.#.', '.#.', '###'],
    B: ['####.', '#...#', '#...#', '####.', '#...#', '#...#', '####.'],
    E: ['#####', '#....', '#....', '####.', '#....', '#....', '#####'],
    R: ['####.', '#...#', '#...#', '####.', '#.#..', '#..#.', '#...#'],
    S: ['.####', '#....', '#....', '.###.', '....#', '....#', '####.'],
    U: ['#...#', '#...#', '#...#', '#...#', '#...#', '#...#', '.###.'],
    D: ['####.', '#...#', '#...#', '#...#', '#...#', '#...#', '####.'],
    O: ['.###.', '#...#', '#...#', '#...#', '#...#', '#...#', '.###.']
  };

  // ---------- Íconos de 9 × 9 (un solo color: el del texto) ----------
  const ICONOS = {
    rayo: [
      '.....##..', '....##...', '...##....', '..######.', '.######..',
      '....##...', '...##....', '..##.....', '.##......'
    ],
    fuego: [
      '....#....', '...##....', '...###...', '..####.#.', '.#######.',
      '.###.###.', '.##...##.', '..##.##..', '...###...'
    ],
    candado: [
      '...###...', '..#...#..', '..#...#..', '.#######.', '.#######.',
      '.###.###.', '.###.###.', '.#######.', '.#######.'
    ],
    ojo: [
      '.........', '...###...', '.##...##.', '#...#...#', '#..###..#',
      '#...#...#', '.##...##.', '...###...', '.........'
    ],
    chat: [
      '#########', '#.......#', '#.##.##.#', '#.......#', '#.#####.#',
      '#.......#', '#########', '.##......', '.#.......'
    ],
    chispa: [
      '....#....', '....#....', '...###...', '.#######.', '...###...',
      '....#....', '....#....', '.........', '.........'
    ],
    exclamacion: [
      '...###...', '...###...', '...###...', '...###...', '...###...',
      '....#....', '.........', '...###...', '...###...'
    ],
    zeta: [
      '.........', '.#######.', '.....##..', '....##...', '...##....',
      '..##.....', '.#######.', '.........', '.........'
    ],
    corazon: [
      '.##...##.', '####.####', '#########', '#########', '.#######.',
      '..#####..', '...###...', '....#....', '.........'
    ],
    estrella: [
      '....#....', '....#....', '...###...', '#########', '.#######.',
      '..#####..', '..##.##..', '.##...##.', '.#.....#.'
    ],
    lista: [
      '.........', '##.######', '##.......', '.........', '##.######',
      '##.......', '.........', '##.######', '##.......'
    ],
    alerta: [
      '....#....', '...###...', '...#.#...', '..##.##..', '..##.##..',
      '.###.###.', '.#######.', '####.####', '#########'
    ],
    casa: [
      '....#....', '...###...', '..#####..', '.#######.', '#########',
      '.##...##.', '.##.#.##.', '.##.#.##.', '.#######.'
    ],
    lapiz: [
      '......##.', '.....####', '....####.', '...####..', '..####...',
      '.####....', '.###.....', '##.......', '#........'
    ],
    basura: [
      '...###...', '#########', '.........', '.#######.', '.#.#.#.#.',
      '.#.#.#.#.', '.#.#.#.#.', '.#.#.#.#.', '..#####..'
    ],
    escudo: [
      '#########', '#########', '####.####', '###...###', '####.####',
      '.#######.', '..#####..', '...###...', '....#....'
    ],
    mas: [
      '###...###', '###...###', '###...###', '.........', '.........',
      '.........', '###...###', '###...###', '###...###'
    ],
    cerrar: [
      '##.....##', '###...###', '.###.###.', '..#####..', '...###...',
      '..#####..', '.###.###.', '###...###', '##.....##'
    ],
    nota: [
      '....###..', '....#.##.', '....#..#.', '....#....', '....#....',
      '.####....', '#####....', '#####....', '.###.....'
    ],
    palomita: [
      '.........', '........#', '.......##', '......##.', '#....##..',
      '##..##...', '.####....', '..##.....', '.........'
    ]
  };

  // Convierte un mapa de letras en rectángulos. Junta los pixeles seguidos del
  // mismo color de una fila en un solo <rect> para que el SVG pese menos.
  function rectangulosDeMapa(filas, paleta) {
    const rectangulos = [];
    filas.forEach(function (fila, y) {
      let x = 0;
      while (x < fila.length) {
        const letra = fila[x];
        if (!paleta[letra]) {
          x += 1;
          continue;
        }
        let ancho = 1;
        while (fila[x + ancho] === letra) ancho += 1;
        rectangulos.push({ x: x, y: y, ancho: ancho, letra: letra });
        x += ancho;
      }
    });
    return rectangulos;
  }

  function crearSvg(ancho, alto, clase, titulo) {
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('viewBox', '0 0 ' + ancho + ' ' + alto);
    svg.setAttribute('shape-rendering', 'crispEdges');
    if (clase) svg.setAttribute('class', clase);
    if (titulo) {
      svg.setAttribute('role', 'img');
      const elementoTitulo = document.createElementNS(SVG_NS, 'title');
      elementoTitulo.textContent = titulo;
      svg.appendChild(elementoTitulo);
    } else {
      svg.setAttribute('aria-hidden', 'true');
      svg.setAttribute('focusable', 'false');
    }
    return svg;
  }

  function crearRect(rectangulo, color) {
    const rect = document.createElementNS(SVG_NS, 'rect');
    rect.setAttribute('x', rectangulo.x);
    rect.setAttribute('y', rectangulo.y);
    rect.setAttribute('width', rectangulo.ancho);
    rect.setAttribute('height', 1);
    rect.setAttribute('fill', color);
    return rect;
  }

  // Dibuja la mascota completa con una capa <g> por parte.
  function svgMascota(titulo) {
    const ancho = MAPA_MASCOTA[0].length;
    const alto = MAPA_MASCOTA.length;
    const svg = crearSvg(ancho, alto, 'mascota__svg', titulo);
    const grupos = {};
    ORDEN_CAPAS.forEach(function (nombreCapa) {
      const grupo = document.createElementNS(SVG_NS, 'g');
      grupo.setAttribute('class', 'm-' + nombreCapa);
      grupos[nombreCapa] = grupo;
      svg.appendChild(grupo);
    });
    rectangulosDeMapa(MAPA_MASCOTA, PALETA_MASCOTA).forEach(function (rectangulo) {
      const estilo = PALETA_MASCOTA[rectangulo.letra];
      grupos[estilo.capa].appendChild(crearRect(rectangulo, estilo.color));
    });
    [['boca-cerrada', BOCA_CERRADA], ['boca-abierta', BOCA_ABIERTA], ['hojas', HOJAS_TAPAN], ['lagrima', LAGRIMA]].forEach(function (par) {
      par[1].forEach(function (pixel) {
        const rectangulo = { x: pixel[0], y: pixel[1], ancho: 1 };
        grupos[par[0]].appendChild(crearRect(rectangulo, PALETA_MASCOTA[pixel[2]].color));
      });
    });
    return svg;
  }

  // Ícono de un solo color: usa "currentColor", o sea, el color del texto.
  function icono(nombre) {
    const filas = ICONOS[nombre];
    const svg = crearSvg(9, 9, 'icono');
    rectangulosDeMapa(filas, { '#': true }).forEach(function (rectangulo) {
      svg.appendChild(crearRect(rectangulo, 'currentColor'));
    });
    return svg;
  }

  // Logo: "CIBER" en cian y "ESCUDO" en rosa, con una sombra amarilla
  // desplazada 1 pixel (efecto de videojuego retro).
  function svgLogo() {
    const palabra = 'CIBERESCUDO';
    const separacion = 2; // 2 pixeles: la sombra amarilla ocupa uno
    let anchoTotal = 0;
    for (const letra of palabra) anchoTotal += LETRAS[letra][0].length + separacion;
    const svg = crearSvg(anchoTotal + 1, 8, 'logo__svg', 'CiberEscudo');
    const sombra = document.createElementNS(SVG_NS, 'g');
    const frente = document.createElementNS(SVG_NS, 'g');
    sombra.setAttribute('transform', 'translate(1 1)');
    sombra.setAttribute('class', 'logo__sombra');
    let cursor = 0;
    palabra.split('').forEach(function (letra, indice) {
      const color = indice < 5 ? '#22e6f2' : '#ff3d9a';
      rectangulosDeMapa(LETRAS[letra], { '#': true }).forEach(function (rectangulo) {
        const movido = { x: rectangulo.x + cursor, y: rectangulo.y, ancho: rectangulo.ancho };
        sombra.appendChild(crearRect(movido, '#ffd93b'));
        frente.appendChild(crearRect(movido, color));
      });
      cursor += LETRAS[letra][0].length + separacion;
    });
    svg.appendChild(sombra);
    svg.appendChild(frente);
    return svg;
  }

  // Frases de la mascota.
  const FRASES_INICIO = [
    '¡Hola! Hoy es buen día para blindar tus cuentas.',
    'Una frase larga vale más que una contraseña rara y corta.',
    'Tus datos son tuyos. Vamos a cuidarlos juntos.',
    'Si un mensaje te mete prisa, respira y revisa dos veces.',
    'Cada reto que completas suma XP y mantiene tu racha.'
  ];

  const CONSEJOS = [
    'Activa la verificación en dos pasos: es como ponerle doble chapa a tu cuenta.',
    'Nunca compartas el código de 6 dígitos que te llega por SMS. Ni con amigos.',
    'Antes de subir una foto con otras personas, pregúntales si están de acuerdo.',
    'Usa una contraseña diferente para cada cuenta importante.',
    'Revisa qué dispositivos tienen tu cuenta abierta y cierra los que no reconozcas.',
    'Si alguien te presiona o te amenaza en línea, no es tu culpa. Pide ayuda.',
    'Desactiva la ubicación en tus publicaciones si no la necesitas.'
  ];

  function elegirAlAzar(lista) {
    return lista[Math.floor(Math.random() * lista.length)];
  }

  // Crea la mascota dentro de un contenedor.
  // opciones.tamano: 'grande' | 'mediana' | 'mini'
  function crear(contenedor, opciones) {
    const ajustes = opciones || {};
    const figura = document.createElement('div');
    figura.className = 'mascota mascota--' + (ajustes.tamano || 'mediana');
    // Con titulo: '' el dibujo es decorativo (lo describe el botón o el texto de al lado).
    const titulo = 'titulo' in ajustes
      ? ajustes.titulo
      : 'Mascota de CiberEscudo: una flor rosa con lentes oscuros y una mariposa azul';
    figura.appendChild(svgMascota(titulo));
    contenedor.appendChild(figura);
    return figura;
  }

  // Reacciones de un momento (cada una es una clase mascota--<nombre> con su animación en CSS):
  // 'hablar'  pequeño salto
  // 'feliz'   rebota, brilla, abre la boca y suelta chispas
  // 'triste'  se marchita y le cae una lágrima
  // 'alerta'  respingo y un «!» sobre la cabeza
  // 'mareo'   se tambalea con estrellitas que giran
  // 'bailar'  baila de lado a lado con notas
  const REACCIONES = ['hablar', 'feliz', 'triste', 'alerta', 'mareo', 'bailar'];

  function reaccionar(figura, estado) {
    if (!figura) return;
    REACCIONES.forEach(function (nombre) {
      figura.classList.remove('mascota--' + nombre);
    });
    // Leer offsetWidth obliga al navegador a "reiniciar" la animación.
    void figura.offsetWidth;
    figura.classList.add('mascota--' + estado);
    ponerAdornos(figura, estado);
  }

  // Un adorno pixelado (chispa, «!», «Z»…) alrededor de la mascota. Se borra solo al terminar.
  function soltarAdorno(figura, nombreIcono, clase, variables) {
    const adorno = document.createElement('span');
    adorno.className = 'adorno ' + clase;
    adorno.setAttribute('aria-hidden', 'true');
    Object.keys(variables || {}).forEach(function (nombre) {
      adorno.style.setProperty(nombre, variables[nombre]);
    });
    if (nombreIcono) adorno.appendChild(icono(nombreIcono));
    figura.appendChild(adorno);
    adorno.addEventListener('animationend', function (evento) {
      if (evento.target === adorno) adorno.remove();
    });
    return adorno;
  }

  function ponerAdornos(figura, estado) {
    if (movimientoReducido() || !figura.isConnected) return;
    if (estado === 'feliz') {
      [['8%', '30%', '0s'], ['40%', '-12%', '0.1s'], ['74%', '24%', '0.2s']].forEach(function (lugar) {
        soltarAdorno(figura, 'chispa', 'adorno--chispa', { '--x': lugar[0], '--y': lugar[1], '--retraso': lugar[2] });
      });
    } else if (estado === 'alerta') {
      soltarAdorno(figura, 'exclamacion', 'adorno--alerta');
    } else if (estado === 'mareo') {
      const mareo = soltarAdorno(figura, null, 'adorno--mareo');
      for (let indice = 0; indice < 3; indice += 1) mareo.appendChild(icono('estrella'));
    } else if (estado === 'bailar') {
      for (let indice = 0; indice < 5; indice += 1) {
        global.setTimeout(function () {
          soltarNota(figura);
        }, indice * 450);
      }
    }
  }

  // Muestra un texto en el globo de diálogo y anima a la mascota.
  function decir(figura, globo, texto, estado) {
    if (globo) globo.textContent = texto;
    reaccionar(figura, estado || 'hablar');
  }

  // ---------- Canto: notas que flotan ----------
  function movimientoReducido() {
    return !!(global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }

  const COLORES_NOTAS = ['nota-musical--rosa', 'nota-musical--cian', 'nota-musical--amarillo'];
  let intervaloNotas = null;

  // Una nota pixelada que sale de la boca, sube y desaparece.
  function soltarNota(figura) {
    if (!figura.isConnected || document.visibilityState === 'hidden') return;
    const nota = document.createElement('span');
    nota.className = 'nota-musical ' + elegirAlAzar(COLORES_NOTAS);
    nota.setAttribute('aria-hidden', 'true');
    nota.style.setProperty('--desvio', Math.round(Math.random() * 36) + 'px');
    nota.appendChild(icono('nota'));
    figura.appendChild(nota);
    nota.addEventListener('animationend', function () {
      nota.remove();
    });
  }

  // Modo canto: boca que se abre y cierra, balanceo y notas.
  // tempo: golpes por minuto de la canción que suena (sin tempo = canta en silencio).
  function cantar(figura, tempo) {
    if (!figura) return;
    figura.classList.add('mascota--canta');
    figura.classList.toggle('mascota--musica', !!tempo);
    // CSS usa --pulso para que el balanceo vaya al ritmo de la canción.
    if (tempo) figura.style.setProperty('--pulso', (60 / tempo).toFixed(3) + 's');
    global.clearInterval(intervaloNotas);
    if (movimientoReducido()) return;
    intervaloNotas = global.setInterval(function () {
      soltarNota(figura);
    }, tempo ? 260 : 1300);
  }

  function dejarDeCantar(figura) {
    global.clearInterval(intervaloNotas);
    intervaloNotas = null;
    if (figura) figura.classList.remove('mascota--canta', 'mascota--musica');
  }

  // ---------- Canciones ORIGINALES de 8 bits ----------
  // Compuestas para CiberEscudo: no copian ninguna canción.
  // Cada nota es [nombre, duración en corcheas]. null = silencio.
  // La melodía y el bajo de cada canción duran lo mismo (32 corcheas = 4 compases).
  const CANCIONES = [
    {
      id: 'neon',
      nombre: 'Neón',
      tempo: 128,
      formaMelodia: 'square',
      melodia: [
        ['A4', 1], ['C5', 1], ['E5', 1], ['A5', 1], ['G5', 1], ['E5', 1], ['C5', 1], ['E5', 1],
        ['F4', 1], ['A4', 1], ['C5', 1], ['F5', 1], ['E5', 1], ['C5', 1], ['A4', 1], ['C5', 1],
        ['G4', 1], ['C5', 1], ['E5', 1], ['G5', 1], ['A5', 1], ['G5', 1], ['E5', 1], ['D5', 1],
        ['D5', 1], ['B4', 1], ['G4', 1], ['B4', 1], ['E5', 2], ['A5', 2]
      ],
      bajo: [
        ['A2', 2], ['A2', 2], ['A3', 2], ['A2', 2],
        ['F2', 2], ['F2', 2], ['F3', 2], ['F2', 2],
        ['C3', 2], ['C3', 2], ['C4', 2], ['C3', 2],
        ['G2', 2], ['G2', 2], ['A2', 4]
      ]
    },
    {
      id: 'pixel-rush',
      nombre: 'Pixel Rush',
      tempo: 150,
      formaMelodia: 'square',
      melodia: [
        ['C5', 1], ['E5', 1], ['G5', 1], ['C6', 1], ['G5', 1], ['E5', 1], ['C5', 1], ['G4', 1],
        ['F5', 1], ['A5', 1], ['C6', 1], ['A5', 1], ['F5', 1], ['C5', 1], ['A4', 1], ['C5', 1],
        ['D5', 1], ['G5', 1], ['B5', 1], ['D6', 1], ['B5', 1], ['G5', 1], ['D5', 1], ['B4', 1],
        ['C5', 2], ['E5', 1], ['G5', 1], ['C6', 4]
      ],
      bajo: [
        ['C3', 2], ['C3', 2], ['G2', 2], ['C3', 2],
        ['F2', 2], ['F2', 2], ['C3', 2], ['F2', 2],
        ['G2', 2], ['G2', 2], ['D3', 2], ['G2', 2],
        ['C3', 2], ['G2', 2], ['C3', 4]
      ]
    },
    {
      id: 'lluvia-digital',
      nombre: 'Lluvia digital',
      tempo: 96,
      formaMelodia: 'triangle',
      melodia: [
        ['D5', 2], ['F5', 1], ['A5', 1], ['F5', 2], ['E5', 2],
        ['D5', 2], ['F5', 2], ['A#4', 2], ['D5', 2],
        ['E5', 2], ['G5', 1], ['C6', 1], ['G5', 2], ['E5', 2],
        ['C#5', 2], ['E5', 2], ['A5', 4]
      ],
      bajo: [
        ['D3', 4], ['D3', 4],
        ['A#2', 4], ['A#2', 4],
        ['C3', 4], ['C3', 4],
        ['A2', 8]
      ]
    },
    {
      // Melodía tradicional mexicana (Jesús González Rubio, siglo XIX): es de dominio público.
      // Está en compás de 6/8: cada compás tiene 6 corcheas. Empieza con 2 corcheas de anacrusa
      // (notas antes del primer compás completo). null = silencio.
      id: 'jarabe-tapatio',
      nombre: 'Jarabe Tapatío',
      tempo: 180, // en negras; en 6/8 se siente a 120 pulsos por minuto
      pulso: 120, // velocidad a la que la flor se mueve al cantar
      compas: 6,
      anacrusa: 2,
      formaMelodia: 'square',
      melodia: [
        // Primera parte (en Do)
        ['G5', 1], ['F#5', 1],
        ['G5', 1], ['E5', 1], ['D#5', 1], ['E5', 1], ['C5', 1], ['B4', 1],
        ['C5', 1], ['G4', 2], [null, 1], ['E4', 1], ['F4', 1],
        ['G4', 1], ['A4', 1], ['B4', 1], ['C5', 1], ['D5', 1], ['E5', 1],
        ['F5', 1], ['D5', 2], [null, 1], ['F5', 1], ['E5', 1],
        ['F5', 1], ['D5', 1], ['C#5', 1], ['D5', 1], ['B4', 1], ['A#4', 1],
        ['B4', 1], ['G4', 2], [null, 1], ['G5', 1], ['G5', 1],
        ['G5', 1], ['A5', 1], ['G5', 1], ['F5', 1], ['E5', 1], ['D5', 1],
        ['C5', 3], [null, 1], ['D5', 1], ['D5', 1],
        // Segunda parte (en Sol)
        ['D5', 1], ['A4', 1], ['A4', 1], ['A4', 1], ['C5', 1], ['C5', 1],
        ['C5', 1], ['B4', 2], [null, 1], ['D5', 1], ['D5', 1],
        ['D5', 1], ['C5', 1], ['C5', 1], ['C5', 1], ['E5', 1], ['E5', 1],
        ['E5', 1], ['D5', 2], [null, 1], ['D5', 1], ['D5', 1],
        ['D5', 1], ['A4', 1], ['A4', 1], ['A4', 1], ['C5', 1], ['C5', 1],
        ['C5', 1], ['B4', 2], [null, 1], ['D5', 1], ['D5', 1],
        ['D5', 1], ['E5', 1], ['D5', 1], ['C5', 1], ['B4', 1], ['A4', 1],
        ['G4', 4]
      ],
      // Bajo de guitarrón: la nota principal del acorde en el tiempo 1 y otra en el tiempo 2.
      bajo: [
        [null, 2],
        ['C3', 3], ['G2', 3], // Do
        ['C3', 3], ['G2', 3], // Do
        ['G2', 3], ['D3', 3], // Sol
        ['G2', 3], ['B2', 3], // Sol7
        ['G2', 3], ['D3', 3], // Sol7
        ['G2', 3], ['D3', 3], // Sol
        ['G2', 3], ['B2', 3], // Sol7
        ['C3', 3], ['G2', 3], // Do
        ['D3', 3], ['A2', 3], // Re7
        ['G2', 3], ['D3', 3], // Sol
        ['D3', 3], ['A2', 3], // Re7
        ['G2', 3], ['D3', 3], // Sol
        ['D3', 3], ['A2', 3], // Re7
        ['G2', 3], ['D3', 3], // Sol
        ['D3', 3], ['F#2', 3], // Re7
        ['G2', 4] // Sol
      ]
    }
  ];

  const SEMITONOS = { C: -9, D: -7, E: -5, F: -4, G: -2, A: 0, B: 2 };

  // "A4" → 440 Hz. Cada semitono multiplica la frecuencia por 2^(1/12).
  function frecuencia(nombre) {
    const letra = nombre[0];
    const octava = Number(nombre.slice(-1));
    const sostenido = nombre.includes('#') ? 1 : 0;
    const distancia = SEMITONOS[letra] + sostenido + (octava - 4) * 12;
    return 440 * Math.pow(2, distancia / 12);
  }

  function duracionCorchea(tempo) {
    return 60 / tempo / 2;
  }

  function duracionCancion(cancion) {
    const corcheas = cancion.melodia.reduce(function (total, nota) {
      return total + nota[1];
    }, 0);
    return corcheas * duracionCorchea(cancion.tempo);
  }

  // ---------- Motor de audio (Web Audio) ----------
  let contextoAudio = null;
  let sonidoActivado = true;
  let salidaMusica = null;
  let temporizadorFin = null;
  let alTerminarCancion = null;
  let indiceCancion = 0;

  function obtenerContexto() {
    const Contexto = global.AudioContext || global.webkitAudioContext;
    if (!Contexto) return null;
    // El navegador no deja sonar nada hasta que la persona toca la pantalla por primera vez.
    const activacion = global.navigator && global.navigator.userActivation;
    if (activacion && !activacion.hasBeenActive) return null;
    if (!contextoAudio) contextoAudio = new Contexto();
    if (contextoAudio.state === 'suspended') contextoAudio.resume();
    return contextoAudio;
  }

  // Un tono corto con envolvente. Si se da "hasta", la frecuencia se desliza (efecto de 8 bits).
  function tono(contexto, destino, opciones) {
    const oscilador = contexto.createOscillator();
    const envolvente = contexto.createGain();
    const inicio = opciones.inicio;
    const duracion = opciones.duracion;
    oscilador.type = opciones.forma || 'square';
    oscilador.frequency.setValueAtTime(opciones.frecuencia, inicio);
    if (opciones.hasta) oscilador.frequency.exponentialRampToValueAtTime(opciones.hasta, inicio + duracion);
    envolvente.gain.setValueAtTime(0.0001, inicio);
    envolvente.gain.exponentialRampToValueAtTime(opciones.volumen, inicio + 0.008);
    envolvente.gain.exponentialRampToValueAtTime(opciones.volumen * 0.5, inicio + duracion * 0.6);
    envolvente.gain.exponentialRampToValueAtTime(0.0001, inicio + duracion * 0.95);
    oscilador.connect(envolvente);
    envolvente.connect(destino);
    oscilador.start(inicio);
    oscilador.stop(inicio + duracion);
  }

  // Programa una voz (melodía o bajo) de una canción.
  function programarVoz(contexto, destino, notas, forma, volumen, inicio, tempo) {
    let tiempo = inicio;
    const corchea = duracionCorchea(tempo);
    notas.forEach(function (nota) {
      const duracion = nota[1] * corchea;
      if (nota[0]) {
        tono(contexto, destino, { frecuencia: frecuencia(nota[0]), inicio: tiempo, duracion: duracion, forma: forma, volumen: volumen });
      }
      tiempo += duracion;
    });
  }

  // ¿En qué corcheas suena el ritmo?
  // En 4/4: en cada contratiempo. En 6/8: "um-pa-pa" (corcheas 2, 3, 5 y 6 del compás),
  // como el rasgueo de la guitarra en el mariachi.
  function suenaRitmoEn(numeroCorchea, cancion) {
    if (cancion.compas === 6) {
      const lugar = (numeroCorchea - (cancion.anacrusa || 0) + 600) % 6;
      return lugar !== 0 && lugar !== 3;
    }
    return numeroCorchea % 2 === 1;
  }

  // Platillo suave (ruido) que marca el ritmo.
  function programarRitmo(contexto, destino, inicio, total, cancion) {
    const corchea = duracionCorchea(cancion.tempo);
    const muestras = Math.floor(contexto.sampleRate * 0.04);
    const ruido = contexto.createBuffer(1, muestras, contexto.sampleRate);
    const datos = ruido.getChannelData(0);
    for (let indice = 0; indice < muestras; indice += 1) datos[indice] = Math.random() * 2 - 1;
    const corcheas = Math.round(total / corchea);
    for (let numero = 0; numero < corcheas; numero += 1) {
      if (!suenaRitmoEn(numero, cancion)) continue;
      const tiempo = inicio + numero * corchea;
      const fuente = contexto.createBufferSource();
      const volumen = contexto.createGain();
      const filtro = contexto.createBiquadFilter();
      filtro.type = 'highpass';
      filtro.frequency.value = 6000;
      fuente.buffer = ruido;
      volumen.gain.setValueAtTime(0.08, tiempo);
      volumen.gain.exponentialRampToValueAtTime(0.0001, tiempo + 0.04);
      fuente.connect(filtro);
      filtro.connect(volumen);
      volumen.connect(destino);
      fuente.start(tiempo);
    }
  }

  function estaSonando() {
    return salidaMusica !== null;
  }

  function detenerCancion() {
    global.clearTimeout(temporizadorFin);
    if (salidaMusica && contextoAudio) {
      const ahora = contextoAudio.currentTime;
      salidaMusica.gain.cancelScheduledValues(ahora);
      salidaMusica.gain.setValueAtTime(salidaMusica.gain.value, ahora);
      salidaMusica.gain.linearRampToValueAtTime(0, ahora + 0.08);
      const salida = salidaMusica;
      global.setTimeout(function () {
        salida.disconnect();
      }, 120);
    }
    salidaMusica = null;
    const callback = alTerminarCancion;
    alTerminarCancion = null;
    if (callback) callback();
  }

  // Toca la siguiente canción de la lista (una vuelta).
  // Regresa la canción que suena, o null si el sonido está apagado o no hay audio web.
  function tocarCancion(alTerminar) {
    detenerCancion();
    if (!sonidoActivado) return null;
    const contexto = obtenerContexto();
    if (!contexto) return null;
    const cancion = CANCIONES[indiceCancion % CANCIONES.length];
    indiceCancion += 1;
    salidaMusica = contexto.createGain();
    salidaMusica.gain.value = 0.9;
    salidaMusica.connect(contexto.destination);
    const inicio = contexto.currentTime + 0.05;
    const total = duracionCancion(cancion);
    programarVoz(contexto, salidaMusica, cancion.melodia, cancion.formaMelodia, cancion.formaMelodia === 'square' ? 0.12 : 0.22, inicio, cancion.tempo);
    programarVoz(contexto, salidaMusica, cancion.bajo, 'triangle', 0.3, inicio, cancion.tempo);
    programarRitmo(contexto, salidaMusica, inicio, total, cancion);
    alTerminarCancion = alTerminar || null;
    temporizadorFin = global.setTimeout(detenerCancion, (total + 0.3) * 1000);
    return cancion;
  }

  // ---------- Efectos de sonido ----------
  // Cada efecto es una lista de tonos: [frecuencia, empieza (s), dura (s), forma, volumen, desliza hasta].
  const EFECTOS = {
    acierto: [[523, 0, 0.08, 'square', 0.1], [659, 0.07, 0.08, 'square', 0.1], [784, 0.14, 0.16, 'square', 0.1]],
    error: [[220, 0, 0.14, 'square', 0.08, 180], [165, 0.13, 0.22, 'square', 0.08, 120]],
    moneda: [[988, 0, 0.07, 'square', 0.08], [1319, 0.06, 0.2, 'square', 0.08]],
    nivel: [[523, 0, 0.1, 'square', 0.1], [659, 0.1, 0.1, 'square', 0.1], [784, 0.2, 0.1, 'square', 0.1], [1047, 0.3, 0.35, 'square', 0.1]],
    levantar: [[440, 0, 0.12, 'triangle', 0.18, 880]],
    soltar: [[660, 0, 0.1, 'triangle', 0.18, 330]],
    pop: [[300, 0, 0.08, 'triangle', 0.2, 900]],
    salto: [[330, 0, 0.12, 'square', 0.06, 660]],
    pum: [[140, 0, 0.09, 'triangle', 0.3, 70]]
  };

  function efecto(nombre) {
    if (!sonidoActivado || !EFECTOS[nombre]) return;
    const contexto = obtenerContexto();
    if (!contexto) return;
    const ahora = contexto.currentTime + 0.01;
    EFECTOS[nombre].forEach(function (parte) {
      tono(contexto, contexto.destination, {
        frecuencia: parte[0], inicio: ahora + parte[1], duracion: parte[2],
        forma: parte[3], volumen: parte[4], hasta: parte[5]
      });
    });
  }

  // ---------- Balbuceo: la flor "habla" con sonidos, sin palabras ----------
  // Cada vocal del texto se vuelve un "bip" con su propia altura,
  // así la misma frase siempre suena parecido (como en algunos videojuegos).
  const ALTURA_VOCAL = { a: 1, e: 1.12, i: 1.26, o: 0.9, u: 0.8 };
  const MAXIMO_SILABAS = 14;
  const DURACION_SILABA = 0.075;

  function silabasDe(texto) {
    const vocales = String(texto).toLowerCase()
      .normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/[^aeiou]/g, '');
    const silabas = [];
    for (let indice = 0; indice < vocales.length && silabas.length < MAXIMO_SILABAS; indice += 1) {
      silabas.push(ALTURA_VOCAL[vocales[indice]]);
    }
    if (silabas.length === 0) silabas.push(1);
    return silabas;
  }

  let salidaVoz = null;

  // Regresa cuánto dura el balbuceo en segundos (para mostrar el texto al mismo ritmo).
  function balbucear(texto) {
    const silabas = silabasDe(texto);
    const total = silabas.length * DURACION_SILABA;
    if (!sonidoActivado) return total;
    const contexto = obtenerContexto();
    if (!contexto) return total;
    if (salidaVoz) salidaVoz.disconnect();
    salidaVoz = contexto.createGain();
    salidaVoz.gain.value = 1;
    salidaVoz.connect(contexto.destination);
    const base = 520;
    const inicio = contexto.currentTime + 0.02;
    silabas.forEach(function (altura, indice) {
      // Un poco de azar para que suene vivo, y cada sílaba sube un poquito (curiosidad).
      const nota = base * altura * (0.95 + Math.random() * 0.1);
      tono(contexto, salidaVoz, {
        frecuencia: nota, hasta: nota * 1.18,
        inicio: inicio + indice * DURACION_SILABA, duracion: DURACION_SILABA * 0.8,
        forma: indice % 2 ? 'triangle' : 'square', volumen: indice % 2 ? 0.16 : 0.05
      });
    });
    return total;
  }

  function activarSonido(activo) {
    sonidoActivado = !!activo;
    if (!sonidoActivado) {
      detenerCancion();
      if (salidaVoz) salidaVoz.disconnect();
    }
  }

  // Si la app se va al fondo, se apaga la música.
  if (typeof document !== 'undefined') {
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'hidden') detenerCancion();
    });
  }

  // ---------- La compañera: florecita que te acompaña por la app ----------
  // Se puede arrastrar, tiene gravedad (cae y se para sobre las cosas), salta de
  // tarjeta en tarjeta, viaja con lo que pisa cuando haces scroll, "siente" qué
  // hay a su alrededor y habla con balbuceos.
  const FRASES_VISTA = {
    verificador: ['Prueba una contraseña parecida a la tuya, nunca la real.', 'Las frases largas son las más fuertes.'],
    privacidad: ['Cada lección que abras cuenta para tu certificado.', 'Lee con calma, aquí no hay prisa.'],
    convivencia: ['Aquí cuidamos a las personas, no solo las cuentas.', 'Pedir ayuda también es actuar.'],
    simulador: ['Lee con calma: las trampas siempre tienen prisa.', 'Busca las señales de alerta.'],
    retos: ['¡Tú puedes! Si fallas, también aprendes.', 'Elige un mundo y vamos.'],
    tareas: ['Las misiones se hacen en la vida real. ¡Vamos por una!', 'Cada misión te protege de verdad.'],
    incidentes: ['Si algo pasó, no es tu culpa. Respira.', 'Pedir ayuda es de valientes.']
  };
  const FRASES_ACIERTO = ['¡Eso!', '¡Bien visto!', '¡Lo detectaste!', '¡Crack!', '¡Así se hace!'];
  const FRASES_ERROR = ['¡Uy! Mira las señales.', 'Tranqui, así se aprende.', 'Casi. Lee la explicación.'];
  const FRASES_ARRASTRE = ['¡Wiii!', '¡Volandooo!', '¡Me mareo!'];
  const FRASES_MAREO = ['Uf… todo me da vueltas.', '¡Qué caída! Veo estrellitas.'];
  const FRASES_DESPERTAR = ['¡Ah! Me quedé dormida. ¿Seguimos?', '¡Ya desperté! ¿Qué hacemos?'];

  // Se marea si la sueltas desde más alto que esto (en px)
  // o si la arrastras de un lado a otro más de esta distancia (en px).
  const ALTURA_MAREO = 280;
  const RECORRIDO_MAREO = 1500;
  // Si pasa este tiempo sin que toques nada, se duerme.
  const TIEMPO_PARA_DORMIR = 40000;
  const FRASES_SIN_NADA = ['Aquí no hay nada… qué tranquilo.', 'Nada por aquí. ¿Me llevas a otro lado?'];

  const TAMANO_COMPANERA = 64;
  // Los pétalos de abajo se "hunden" un poquito en lo que pisa, para que se vea parada encima.
  const HUNDIMIENTO = 6;

  // ----- Funciones puras (se prueban con node) -----

  // Mantiene la posición dentro de un área (para que la flor no se salga de la pantalla).
  function limitarPosicion(x, y, area) {
    return {
      x: Math.round(Math.min(Math.max(x, area.izquierda), area.derecha)),
      y: Math.round(Math.min(Math.max(y, area.arriba), area.abajo))
    };
  }

  // En qué parte de la pantalla está un punto, dividiendo la pantalla en 3 × 3.
  function zonaDePantalla(x, y, ancho, alto) {
    const columna = x < ancho / 3 ? 'izquierda' : x > (ancho * 2) / 3 ? 'derecha' : 'centro';
    const fila = y < alto / 3 ? 'arriba' : y > (alto * 2) / 3 ? 'abajo' : 'medio';
    if (columna === 'centro' && fila === 'medio') return 'en el centro de la pantalla';
    const filas = { arriba: 'arriba', medio: 'a media altura', abajo: 'abajo' };
    const columnas = { izquierda: 'a la izquierda', derecha: 'a la derecha', centro: 'en medio' };
    return filas[fila] + ' ' + columnas[columna];
  }

  // Gravedad: dónde quedan los pies si la sueltas en la columna "centroX".
  // 1. Si sus pies quedaron DENTRO de una plataforma (la soltaste encima de una tarjeta),
  //    se sube a ella.
  // 2. Si no, cae a la plataforma más alta que tenga debajo; si no hay ninguna, al suelo.
  function elegirAterrizaje(centroX, pies, plataformas, suelo) {
    function tocaLaColumna(plataforma) {
      return centroX >= plataforma.izquierda + 8 && centroX <= plataforma.derecha - 8;
    }
    let subida = null;
    plataformas.forEach(function (plataforma, indice) {
      const piesAdentro = plataforma.arriba < pies - 2 && plataforma.abajo > pies;
      if (piesAdentro && tocaLaColumna(plataforma) && (!subida || plataforma.arriba > subida.pies)) {
        subida = { pies: plataforma.arriba, indice: indice };
      }
    });
    if (subida) return subida;
    let mejor = { pies: suelo, indice: -1 };
    plataformas.forEach(function (plataforma, indice) {
      const debajoDeLosPies = plataforma.arriba >= pies - 2;
      if (debajoDeLosPies && tocaLaColumna(plataforma) && plataforma.arriba < mejor.pies) {
        mejor = { pies: plataforma.arriba, indice: indice };
      }
    });
    return mejor;
  }

  // Arma la frase de "qué hay a mi alrededor" a partir de lo que percibió.
  // Prioridad: lo que pisa, lo que tapa, lo que tiene a los lados y lo que tiene arriba.
  // Lo que la flor va a comentar: lo que pisa o, si no tiene frase, lo más cercano.
  function objetoComentado(percepcion) {
    const cercanos = [percepcion.debajo, percepcion.centro, percepcion.izquierda, percepcion.derecha, percepcion.encima];
    for (let indice = 0; indice < cercanos.length; indice += 1) {
      if (cercanos[indice] && cercanos[indice].frase) return cercanos[indice];
    }
    return null;
  }

  function frasePercepcion(percepcion) {
    // Solo dice algo relacionado con lo que pisa (o con lo más cercano); no narra su posición.
    const objeto = objetoComentado(percepcion);
    if (objeto) return objeto.frase;
    // No hay nada conocido cerca: comenta según la zona de la pantalla.
    if (/^arriba/.test(percepcion.zona)) return 'Desde aquí arriba se ve todo.';
    if (/^abajo/.test(percepcion.zona)) return 'Aquí abajo estoy tranquila. ¿Me llevas a otro lado?';
    return FRASES_SIN_NADA[0];
  }

  // ----- Estado -----
  const companera = {
    raiz: null,
    flor: null,
    figura: null,
    globo: null,
    visible: false,
    habilitada: true,
    arrastrando: false,
    acabaDeArrastrar: false,
    enMovimiento: false,
    dormida: false,
    mareadaPorArrastre: false,
    despertoAlTocar: false,
    ultimaActividad: 0,
    intervaloZetas: null,
    ancla: null, // { elemento, desfaseX }: lo que está pisando
    toques: 0,
    temporizadorGlobo: null,
    temporizadorTexto: null,
    intervaloPaseo: null,
    vistasSaludadas: {},
    objetos: [],
    selectorPlataformas: '',
    alMover: null
  };

  // Zona donde puede estar: debajo de la cabecera y arriba de la barra de navegación.
  function areaPermitida() {
    const cabecera = document.querySelector('.cabecera');
    const barra = document.querySelector('.barra-nav');
    const arriba = (cabecera ? cabecera.getBoundingClientRect().bottom : 0) + 4;
    let abajo = global.innerHeight - TAMANO_COMPANERA - 6;
    let izquierda = 6;
    if (barra) {
      const caja = barra.getBoundingClientRect();
      // En el celular la barra está abajo; en computadora es un riel a la izquierda.
      if (caja.width > caja.height) abajo = caja.top - TAMANO_COMPANERA + 2;
      else izquierda = caja.right + 6;
    }
    return { izquierda: izquierda, derecha: global.innerWidth - TAMANO_COMPANERA - 6, arriba: arriba, abajo: Math.max(arriba, abajo) };
  }

  function posicionActual() {
    return { x: parseFloat(companera.raiz.style.left) || 0, y: parseFloat(companera.raiz.style.top) || 0 };
  }

  function colocar(x, y) {
    const posicion = limitarPosicion(x, y, areaPermitida());
    const anterior = posicionActual();
    if (Math.abs(posicion.x - anterior.x) > 1) {
      companera.raiz.classList.toggle('companera--volteada', posicion.x < anterior.x);
    }
    companera.raiz.style.left = posicion.x + 'px';
    companera.raiz.style.top = posicion.y + 'px';
    // El globo va del lado donde hay más espacio.
    companera.raiz.classList.toggle('companera--derecha', posicion.x > global.innerWidth / 2);
    companera.raiz.classList.toggle('companera--abajo', posicion.y < global.innerHeight / 3);
    return posicion;
  }

  // ----- Percepción: qué hay alrededor -----
  function reconocer(elemento) {
    for (let indice = 0; indice < companera.objetos.length; indice += 1) {
      const objeto = companera.objetos[indice];
      const encontrado = elemento.closest(objeto.selector);
      if (encontrado) {
        const descripcion = objeto.describir(encontrado) || {};
        return { elemento: encontrado, nombre: descripcion.nombre, frase: descripcion.frase, alerta: !!descripcion.alerta };
      }
    }
    return null;
  }

  // Lo que hay en un punto de la pantalla, sin contar a la propia flor.
  function objetoEn(x, y) {
    if (x < 0 || y < 0 || x > global.innerWidth || y > global.innerHeight) return null;
    const pila = document.elementsFromPoint(x, y);
    for (let indice = 0; indice < pila.length; indice += 1) {
      if (pila[indice].closest('.companera')) continue;
      const conocido = reconocer(pila[indice]);
      if (conocido && conocido.nombre) return conocido;
    }
    return null;
  }

  // "Tantea" 5 puntos alrededor de su cuerpo: abajo de los pies, arriba de la cabeza,
  // el centro (lo que está tapando) y a cada lado.
  function percibir() {
    const caja = companera.raiz.getBoundingClientRect();
    const centroX = caja.left + caja.width / 2;
    const centroY = caja.top + caja.height / 2;
    return {
      zona: zonaDePantalla(centroX, centroY, global.innerWidth, global.innerHeight),
      // Si ya sabe qué pisa (su ancla), eso es lo de abajo; si no, tantea bajo sus pies.
      debajo: (companera.ancla && reconocer(companera.ancla.elemento)) || objetoEn(centroX, caja.bottom + 4),
      encima: objetoEn(centroX, caja.top - 8),
      centro: objetoEn(centroX, centroY),
      izquierda: objetoEn(caja.left - 12, centroY),
      derecha: objetoEn(caja.right + 12, centroY)
    };
  }

  // Comenta lo que tiene cerca. Si es algo peligroso (un enlace falso), se alerta.
  function comentarEntorno() {
    const percepcion = percibir();
    const objeto = objetoComentado(percepcion);
    hablar(frasePercepcion(percepcion), objeto && objeto.alerta ? 'alerta' : 'hablar');
  }

  // ----- Física: gravedad, saltos y viajar con lo que pisa -----
  function plataformasVisibles() {
    if (!companera.selectorPlataformas) return [];
    const area = areaPermitida();
    const lista = [];
    document.querySelectorAll(companera.selectorPlataformas).forEach(function (elemento) {
      if (elemento.closest('.companera, [hidden], dialog')) return;
      const caja = elemento.getBoundingClientRect();
      if (caja.width < 40 || caja.height < 16) return;
      // Solo cuenta si la flor cabría parada encima dentro del área.
      const topeFlor = caja.top - TAMANO_COMPANERA + HUNDIMIENTO;
      if (topeFlor < area.arriba || topeFlor > area.abajo) return;
      lista.push({ elemento: elemento, izquierda: caja.left, derecha: caja.right, arriba: caja.top, abajo: caja.bottom });
    });
    return lista;
  }

  function soltarAncla() {
    companera.ancla = null;
  }

  function anclarA(elemento) {
    if (!elemento) {
      soltarAncla();
      return;
    }
    const caja = elemento.getBoundingClientRect();
    companera.ancla = { elemento: elemento, desfaseX: posicionActual().x - caja.left };
  }

  function aterrizar(plataforma, comentar) {
    companera.raiz.classList.remove('companera--aterriza');
    void companera.raiz.offsetWidth;
    companera.raiz.classList.add('companera--aterriza');
    efecto('pum');
    anclarA(plataforma ? plataforma.elemento : null);
    // Si la página se movió mientras caía, se acomoda donde está su piso ahora.
    if (plataforma) seguirAncla();
    if (comentar) global.setTimeout(comentarEntorno, 120);
  }

  // Cae con gravedad hasta lo primero que haya debajo (o hasta el suelo).
  // Al terminar de caer: si está mareada lo dice; si no, comenta lo que pisa (si se pidió).
  function decirAlCaer(comentar, mareada) {
    if (mareada) {
      global.setTimeout(function () {
        hablar(elegirAlAzar(FRASES_MAREO), 'mareo');
      }, 150);
    } else if (comentar) {
      global.setTimeout(comentarEntorno, 120);
    }
  }

  function caer(comentar) {
    if (!companera.visible) return;
    const mareadaPorArrastre = companera.mareadaPorArrastre;
    companera.mareadaPorArrastre = false;
    const area = areaPermitida();
    const inicio = posicionActual();
    const centroX = inicio.x + TAMANO_COMPANERA / 2;
    const plataformas = plataformasVisibles();
    const destino = elegirAterrizaje(centroX, inicio.y + TAMANO_COMPANERA - HUNDIMIENTO,
      plataformas.map(function (plataforma) {
        return { izquierda: plataforma.izquierda, derecha: plataforma.derecha, arriba: plataforma.arriba, abajo: plataforma.abajo };
      }), area.abajo + TAMANO_COMPANERA - HUNDIMIENTO);
    const plataforma = destino.indice >= 0 ? plataformas[destino.indice] : null;
    const yFinal = Math.max(area.arriba, Math.min(destino.pies - TAMANO_COMPANERA + HUNDIMIENTO, area.abajo));
    // Ya estaba parada ahí: solo recuerda qué pisa (sin "¡pum!").
    if (Math.abs(yFinal - inicio.y) < 2) {
      colocar(inicio.x, yFinal);
      anclarA(plataforma ? plataforma.elemento : null);
      decirAlCaer(comentar, comentar && mareadaPorArrastre);
      return;
    }
    // Se sube a la tarjeta donde la soltaste (va hacia arriba) o el celular pide menos movimiento.
    if (yFinal < inicio.y || movimientoReducido()) {
      colocar(inicio.x, yFinal);
      aterrizar(plataforma, false);
      decirAlCaer(comentar, comentar && mareadaPorArrastre);
      return;
    }
    // Animación de caída: la velocidad crece cada cuadro (aceleración = gravedad).
    companera.enMovimiento = true;
    let y = inicio.y;
    let velocidad = 0;
    let anterior = null;
    function cuadro(tiempo) {
      if (anterior === null) anterior = tiempo;
      const segundos = Math.min(0.05, (tiempo - anterior) / 1000);
      anterior = tiempo;
      velocidad += 2600 * segundos;
      y = Math.min(yFinal, y + velocidad * segundos);
      // Redondear a 4 px da el movimiento "a saltos" de los videojuegos de pixeles.
      colocar(inicio.x, Math.round(y / 4) * 4);
      if (y < yFinal) {
        global.requestAnimationFrame(cuadro);
      } else {
        colocar(inicio.x, yFinal);
        companera.enMovimiento = false;
        aterrizar(plataforma, false);
        decirAlCaer(comentar, comentar && (mareadaPorArrastre || yFinal - inicio.y > ALTURA_MAREO));
      }
    }
    global.requestAnimationFrame(cuadro);
  }

  // Salto en arco (parábola) hasta un punto.
  function saltarA(xFinal, yFinal, alTerminar) {
    const inicio = posicionActual();
    if (movimientoReducido()) {
      colocar(xFinal, yFinal);
      if (alTerminar) alTerminar();
      return;
    }
    companera.enMovimiento = true;
    companera.raiz.classList.add('companera--saltando');
    efecto('salto');
    const altura = 40 + Math.min(80, Math.abs(xFinal - inicio.x) / 3);
    const duracion = 650;
    let comienzo = null;
    function cuadro(tiempo) {
      if (comienzo === null) comienzo = tiempo;
      const avance = Math.min(1, (tiempo - comienzo) / duracion);
      const x = inicio.x + (xFinal - inicio.x) * avance;
      const y = inicio.y + (yFinal - inicio.y) * avance - altura * 4 * avance * (1 - avance);
      colocar(Math.round(x / 4) * 4, Math.round(y / 4) * 4);
      if (avance < 1) {
        global.requestAnimationFrame(cuadro);
      } else {
        colocar(xFinal, yFinal);
        companera.enMovimiento = false;
        companera.raiz.classList.remove('companera--saltando');
        if (alTerminar) alTerminar();
      }
    }
    global.requestAnimationFrame(cuadro);
  }

  // Si la flor está parada sobre algo y haces scroll, viaja con eso.
  // Si lo que pisa se va de la pantalla, se cae.
  let esperandoCuadro = false;
  function seguirAncla() {
    esperandoCuadro = false;
    if (!companera.visible || !companera.ancla || companera.arrastrando || companera.enMovimiento) return;
    const elemento = companera.ancla.elemento;
    const caja = elemento.getBoundingClientRect();
    if (!elemento.isConnected || caja.width === 0) {
      soltarAncla();
      caer(false);
      return;
    }
    const area = areaPermitida();
    const x = caja.left + companera.ancla.desfaseX;
    const y = caja.top - TAMANO_COMPANERA + HUNDIMIENTO;
    if (y < area.arriba || y > area.abajo) {
      // Se le fue el piso: se suelta y cae.
      soltarAncla();
      colocar(x, Math.max(area.arriba, Math.min(y, area.abajo)));
      caer(false);
      return;
    }
    colocar(x, y);
  }

  function alHacerScroll() {
    if (esperandoCuadro) return;
    esperandoCuadro = true;
    global.requestAnimationFrame(seguirAncla);
  }

  // ----- Dormir: si no tocas nada en un rato, se duerme -----
  function dormir() {
    if (!companera.visible || companera.dormida || companera.arrastrando || companera.enMovimiento) return;
    if (!companera.globo.hidden) return;
    companera.dormida = true;
    companera.figura.classList.add('mascota--dormida');
    if (movimientoReducido()) return;
    companera.intervaloZetas = global.setInterval(function () {
      soltarAdorno(companera.figura, 'zeta', 'adorno--zeta');
    }, 1100);
  }

  function despertar() {
    if (!companera.dormida) return;
    companera.dormida = false;
    global.clearInterval(companera.intervaloZetas);
    companera.figura.classList.remove('mascota--dormida');
    if (companera.visible) reaccionar(companera.figura, 'hablar');
  }

  // Cualquier toque, tecla o scroll cuenta como actividad (y la despierta).
  function registrarActividad(evento) {
    companera.ultimaActividad = Date.now();
    if (!companera.dormida) return;
    const objetivo = evento && evento.target;
    if (objetivo && objetivo.closest && objetivo.closest('.companera__flor')) companera.despertoAlTocar = true;
    despertar();
  }

  function revisarSueno() {
    if (Date.now() - companera.ultimaActividad > TIEMPO_PARA_DORMIR) dormir();
  }

  // De vez en cuando salta a otra tarjeta, botón u opción cercana.
  function pasear() {
    if (!companera.visible || companera.arrastrando || companera.enMovimiento || companera.dormida) return;
    if (document.visibilityState === 'hidden' || movimientoReducido() || !companera.globo.hidden) return;
    const actual = posicionActual();
    const candidatas = plataformasVisibles().filter(function (plataforma) {
      const lejosDeAqui = !companera.ancla || plataforma.elemento !== companera.ancla.elemento;
      const cerca = Math.abs(plataforma.arriba - (actual.y + TAMANO_COMPANERA)) < 320;
      return lejosDeAqui && cerca;
    });
    if (candidatas.length === 0) return;
    const destino = elegirAlAzar(candidatas);
    const margen = 12;
    const minimo = destino.izquierda + margen;
    const maximo = Math.max(minimo, destino.derecha - TAMANO_COMPANERA - margen);
    const xFinal = minimo + Math.random() * (maximo - minimo);
    const yFinal = destino.arriba - TAMANO_COMPANERA + HUNDIMIENTO;
    soltarAncla();
    saltarA(xFinal, yFinal, function () {
      aterrizar(destino, Math.random() < 0.35);
    });
  }

  // ----- Hablar -----
  function hablar(texto, estado) {
    if (!companera.visible) return;
    global.clearTimeout(companera.temporizadorGlobo);
    global.clearInterval(companera.temporizadorTexto);
    const globo = companera.globo;
    const duracion = balbucear(texto);
    reaccionar(companera.figura, estado || 'hablar');
    companera.raiz.classList.add('companera--hablando');
    globo.hidden = false;
    // El texto aparece letra por letra, al ritmo del balbuceo.
    if (movimientoReducido()) {
      globo.textContent = texto;
    } else {
      let letras = 0;
      const paso = Math.max(12, (duracion * 1000) / texto.length);
      globo.textContent = '';
      companera.temporizadorTexto = global.setInterval(function () {
        letras += 1;
        globo.textContent = texto.slice(0, letras);
        if (letras >= texto.length) global.clearInterval(companera.temporizadorTexto);
      }, paso);
    }
    companera.temporizadorGlobo = global.setTimeout(function () {
      globo.hidden = true;
      companera.raiz.classList.remove('companera--hablando');
    }, Math.max(2800, texto.length * 70));
  }

  // ----- Arrastrar y tocar -----
  function prepararArrastre() {
    const flor = companera.flor;
    let inicioX = 0;
    let inicioY = 0;
    let desfaseX = 0;
    let desfaseY = 0;
    let presionado = false;
    let ultimoX = 0;
    let ultimoY = 0;
    let recorrido = 0; // cuánto la has movido en este arrastre (para saber si se marea)

    flor.addEventListener('pointerdown', function (evento) {
      if (companera.enMovimiento) return;
      presionado = true;
      companera.arrastrando = false;
      inicioX = evento.clientX;
      inicioY = evento.clientY;
      ultimoX = evento.clientX;
      ultimoY = evento.clientY;
      recorrido = 0;
      const caja = companera.raiz.getBoundingClientRect();
      desfaseX = evento.clientX - caja.left;
      desfaseY = evento.clientY - caja.top;
      flor.setPointerCapture(evento.pointerId);
    });

    flor.addEventListener('pointermove', function (evento) {
      if (!presionado) return;
      const distancia = Math.abs(evento.clientX - inicioX) + Math.abs(evento.clientY - inicioY);
      if (!companera.arrastrando && distancia > 8) {
        companera.arrastrando = true;
        companera.despertoAlTocar = false;
        soltarAncla();
        companera.raiz.classList.add('companera--arrastrando');
        efecto('levantar');
        hablar(elegirAlAzar(FRASES_ARRASTRE), 'feliz');
      }
      if (companera.arrastrando) {
        recorrido += Math.abs(evento.clientX - ultimoX) + Math.abs(evento.clientY - ultimoY);
        colocar(evento.clientX - desfaseX, evento.clientY - desfaseY);
      }
      ultimoX = evento.clientX;
      ultimoY = evento.clientY;
    });

    function terminar() {
      if (!presionado) return;
      presionado = false;
      if (!companera.arrastrando) return;
      companera.arrastrando = false;
      companera.acabaDeArrastrar = true;
      companera.raiz.classList.remove('companera--arrastrando');
      efecto('soltar');
      // Al soltarla cae con gravedad y comenta lo que pisa (o dice que está mareada).
      companera.mareadaPorArrastre = recorrido > RECORRIDO_MAREO;
      caer(true);
      if (companera.alMover) global.setTimeout(function () {
        companera.alMover(posicionActual());
      }, 900);
    }
    flor.addEventListener('pointerup', terminar);
    flor.addEventListener('pointercancel', terminar);

    // Tocarla (o Enter con el teclado): una vez cuenta qué hay a su alrededor y otra da un consejo.
    flor.addEventListener('click', function () {
      if (companera.acabaDeArrastrar) {
        companera.acabaDeArrastrar = false;
        return;
      }
      if (companera.despertoAlTocar) {
        companera.despertoAlTocar = false;
        hablar(elegirAlAzar(FRASES_DESPERTAR), 'feliz');
        return;
      }
      companera.toques += 1;
      if (companera.toques % 2 === 1) comentarEntorno();
      else hablar(elegirAlAzar(CONSEJOS), 'feliz');
    });
  }

  // Después de un toque la página puede cambiar (se abre un mundo, desaparece una tarjeta).
  // La flor revisa si su piso sigue ahí; si no, cae.
  function revisarPiso() {
    if (!companera.visible || companera.arrastrando || companera.enMovimiento) return;
    const ancla = companera.ancla;
    if (ancla && ancla.elemento.isConnected && ancla.elemento.getBoundingClientRect().width > 0) {
      seguirAncla();
      return;
    }
    soltarAncla();
    caer(false);
  }

  // Si tocas lo que la flor está pisando, da un brinquito.
  function prepararReaccionesAlEntorno(selectorPrivado) {
    document.addEventListener('click', function () {
      global.setTimeout(revisarPiso, 500);
    });
    document.addEventListener('click', function (evento) {
      if (!companera.visible || !companera.ancla || companera.enMovimiento) return;
      if (evento.target.closest('.companera')) return;
      if (!companera.ancla.elemento.contains(evento.target)) return;
      const posicion = posicionActual();
      saltarA(posicion.x, posicion.y, function () {
        aterrizar(companera.ancla ? { elemento: companera.ancla.elemento } : null, false);
      });
      // En las opciones ya reacciona a la respuesta; en lo demás comenta el temblor.
      if (!evento.target.closest('.opcion')) hablar('¡Uy! Se movió el piso.', 'feliz');
    }, true);

    // Cuando escribes una contraseña, se tapa los ojos con sus hojas.
    if (!selectorPrivado) return;
    document.addEventListener('focusin', function (evento) {
      if (!companera.visible || !evento.target.matches(selectorPrivado)) return;
      companera.figura.classList.add('mascota--tapada');
      hablar('Me tapo los ojos: no veo tu contraseña.', 'hablar');
    });
    document.addEventListener('focusout', function (evento) {
      if (evento.target.matches && evento.target.matches(selectorPrivado)) {
        companera.figura.classList.remove('mascota--tapada');
      }
    });
  }

  // opciones: { habilitada, posicion, alMover, objetos, selectorPlataformas, selectorPrivado }
  function iniciarCompanera(opciones) {
    const ajustes = opciones || {};
    const raiz = document.createElement('div');
    raiz.className = 'companera';
    raiz.hidden = true;
    const flor = document.createElement('button');
    flor.type = 'button';
    flor.className = 'companera__flor';
    flor.setAttribute('aria-label', 'Florecita compañera. Tócala para que te diga qué hay cerca o te dé un consejo; arrástrala para moverla.');
    const globo = document.createElement('p');
    globo.className = 'companera__globo';
    globo.setAttribute('aria-live', 'polite');
    globo.hidden = true;
    raiz.appendChild(globo);
    raiz.appendChild(flor);
    document.body.appendChild(raiz);

    companera.raiz = raiz;
    companera.flor = flor;
    companera.globo = globo;
    companera.figura = crear(flor, { tamano: 'compa', titulo: '' });
    companera.habilitada = ajustes.habilitada !== false;
    companera.alMover = ajustes.alMover || null;
    companera.objetos = ajustes.objetos || [];
    companera.selectorPlataformas = ajustes.selectorPlataformas || '';
    prepararArrastre();
    prepararReaccionesAlEntorno(ajustes.selectorPrivado);

    // Posición guardada o, si no hay, abajo a la derecha.
    const area = areaPermitida();
    const guardada = ajustes.posicion;
    colocar(guardada ? guardada.x : area.derecha, guardada ? guardada.y : area.abajo);

    global.addEventListener('scroll', alHacerScroll, { passive: true });
    global.addEventListener('resize', function () {
      if (!companera.visible) return;
      const posicion = posicionActual();
      colocar(posicion.x, posicion.y);
      alHacerScroll();
    });
    companera.intervaloPaseo = global.setInterval(pasear, 9000);

    companera.ultimaActividad = Date.now();
    document.addEventListener('pointerdown', registrarActividad, true);
    document.addEventListener('keydown', registrarActividad, true);
    global.addEventListener('scroll', registrarActividad, { passive: true });
    global.setInterval(revisarSueno, 5000);
  }

  function mostrarCompanera(nombreVista) {
    if (!companera.raiz) return;
    if (!companera.habilitada) {
      ocultarCompanera();
      return;
    }
    const estabaVisible = companera.visible;
    companera.visible = true;
    companera.raiz.hidden = false;
    // Lo que decía era sobre la sección anterior: el globo se cierra.
    global.clearTimeout(companera.temporizadorGlobo);
    global.clearInterval(companera.temporizadorTexto);
    companera.globo.hidden = true;
    companera.raiz.classList.remove('companera--hablando');
    companera.figura.classList.remove('mascota--tapada');
    // Lo que pisaba era de la pantalla anterior: se suelta y cae sobre la nueva.
    soltarAncla();
    const posicion = posicionActual();
    colocar(posicion.x, posicion.y);
    if (!estabaVisible) {
      companera.raiz.classList.remove('companera--aparece');
      void companera.raiz.offsetWidth;
      companera.raiz.classList.add('companera--aparece');
      efecto('pop');
    }
    // Espera a que la sección termine de aparecer antes de caer sobre ella.
    global.setTimeout(function () {
      caer(false);
    }, 380);
    // Saluda con un tip la primera vez que entras a cada sección.
    const frases = FRASES_VISTA[nombreVista];
    if (frases && !companera.vistasSaludadas[nombreVista]) {
      companera.vistasSaludadas[nombreVista] = true;
      global.setTimeout(function () {
        hablar(elegirAlAzar(frases));
      }, 900);
    }
  }

  function ocultarCompanera() {
    if (!companera.raiz) return;
    companera.visible = false;
    despertar();
    soltarAncla();
    companera.raiz.hidden = true;
    companera.globo.hidden = true;
  }

  function habilitarCompanera(activa, nombreVista) {
    companera.habilitada = !!activa;
    if (companera.habilitada && nombreVista) mostrarCompanera(nombreVista);
    else ocultarCompanera();
  }

  // Reacciona a una respuesta del simulador o de los retos.
  function reaccionarCompanera(acerto) {
    if (!companera.visible) return;
    hablar(elegirAlAzar(acerto ? FRASES_ACIERTO : FRASES_ERROR), acerto ? 'feliz' : 'triste');
  }

  const Mascota = {
    MAPA_MASCOTA: MAPA_MASCOTA,
    BOCA_CERRADA: BOCA_CERRADA,
    BOCA_ABIERTA: BOCA_ABIERTA,
    HOJAS_TAPAN: HOJAS_TAPAN,
    LAGRIMA: LAGRIMA,
    REACCIONES: REACCIONES,
    PALETA_MASCOTA: PALETA_MASCOTA,
    LETRAS: LETRAS,
    ICONOS: ICONOS,
    FRASES_INICIO: FRASES_INICIO,
    CONSEJOS: CONSEJOS,
    CANCIONES: CANCIONES,
    EFECTOS: EFECTOS,
    FRASES_VISTA: FRASES_VISTA,
    rectangulosDeMapa: rectangulosDeMapa,
    elegirAlAzar: elegirAlAzar,
    crear: crear,
    reaccionar: reaccionar,
    decir: decir,
    icono: icono,
    svgLogo: svgLogo,
    frecuencia: frecuencia,
    duracionCancion: duracionCancion,
    suenaRitmoEn: suenaRitmoEn,
    cantar: cantar,
    dejarDeCantar: dejarDeCantar,
    tocarCancion: tocarCancion,
    detenerCancion: detenerCancion,
    estaSonando: estaSonando,
    efecto: efecto,
    silabasDe: silabasDe,
    balbucear: balbucear,
    activarSonido: activarSonido,
    sonidoActivado: function () {
      return sonidoActivado;
    },
    limitarPosicion: limitarPosicion,
    zonaDePantalla: zonaDePantalla,
    elegirAterrizaje: elegirAterrizaje,
    frasePercepcion: frasePercepcion,
    Companera: {
      iniciar: iniciarCompanera,
      mostrar: mostrarCompanera,
      ocultar: ocultarCompanera,
      habilitar: habilitarCompanera,
      hablar: hablar,
      reaccionar: reaccionarCompanera,
      percibir: function () {
        return percibir();
      },
      comentarEntorno: comentarEntorno,
      dormir: dormir
    }
  };

  if (typeof module === 'object' && module.exports) module.exports = Mascota;
  else global.Mascota = Mascota;
})(this);
