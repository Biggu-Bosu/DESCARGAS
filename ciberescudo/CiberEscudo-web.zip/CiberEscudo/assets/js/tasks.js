// CiberEscudo · tasks.js
// Plan de acción, en dos partes:
//   1. Misiones de seguridad: 20 acciones cruciales ya cargadas. Solo se marcan
//      (no se editan ni se borran) y cada una da +5 XP la primera vez.
//   2. Tareas personales: las que escribe la persona. Se pueden crear, editar,
//      borrar y completar, pero NO dan XP (si no, cualquiera inventaría tareas
//      para ganar puntos).
// Todo se guarda en localStorage.
//
// Las funciones de arriba son "puras": reciben datos y regresan datos nuevos,
// sin tocar la pantalla ni el almacenamiento. Así se pueden probar con node.

(function (global) {
  'use strict';

  const CLAVE_TAREAS = 'ciberescudo.tareas.v1';
  const CLAVE_MISIONES = 'ciberescudo.misiones.v1';
  const LARGO_MAXIMO = 80;
  const XP_POR_MISION = 5;

  const CATEGORIAS = [
    { id: 'cuentas', nombre: 'Cuentas', icono: 'candado' },
    { id: 'celular', nombre: 'Celular', icono: 'escudo' },
    { id: 'redes', nombre: 'Redes y privacidad', icono: 'ojo' },
    { id: 'apoyo', nombre: 'Apoyo', icono: 'chat' }
  ];

  // "anteriores": textos de las sugerencias de la versión pasada, para convertirlas.
  const MISIONES = [
    {
      id: 'whatsapp-2fa', categoria: 'cuentas',
      texto: 'Activar la verificación en dos pasos de WhatsApp',
      como: 'Ajustes → Cuenta → Verificación en dos pasos → crea un PIN de 6 dígitos.',
      anteriores: ['Activar la verificación en dos pasos en WhatsApp']
    },
    {
      id: 'correo-2fa', categoria: 'cuentas',
      texto: 'Activar la verificación en dos pasos en tu correo',
      como: 'Tu correo es la llave de todo: si lo roban, pueden recuperar tus demás cuentas.'
    },
    {
      id: 'redes-2fa', categoria: 'cuentas',
      texto: 'Activar la verificación en dos pasos en tus redes sociales',
      como: 'Búscala en Configuración → Seguridad de Instagram, TikTok o la red que más uses.'
    },
    {
      id: 'contrasena-correo', categoria: 'cuentas',
      texto: 'Cambiar la contraseña del correo por una frase larga y única',
      como: 'Por ejemplo, 4 palabras sin relación. Pruébala antes en el Verificador.'
    },
    {
      id: 'no-repetir', categoria: 'cuentas',
      texto: 'Dejar de repetir la misma contraseña en varias cuentas',
      como: 'Empieza por las importantes: correo, redes y cualquier app con dinero.',
      anteriores: ['Cambiar una contraseña que repito en varias cuentas']
    },
    {
      id: 'datos-recuperacion', categoria: 'cuentas',
      texto: 'Revisar el correo y el teléfono de recuperación de tus cuentas',
      como: 'Deben ser tuyos y estar al día, para que puedas recuperarlas si pasa algo.'
    },
    {
      id: 'cerrar-sesiones', categoria: 'cuentas',
      texto: 'Cerrar sesiones abiertas en dispositivos que no reconoces',
      como: 'En cada app: Configuración → Seguridad → Dispositivos o «Dónde iniciaste sesión».',
      anteriores: ['Cerrar sesiones abiertas en dispositivos que no uso']
    },
    {
      id: 'codigos-respaldo', categoria: 'cuentas',
      texto: 'Guardar en un lugar seguro los códigos de respaldo del 2FA',
      como: 'Te sirven si pierdes el celular. Nunca los subas en una foto ni los compartas.'
    },
    {
      id: 'bloqueo-celular', categoria: 'celular',
      texto: 'Poner bloqueo con PIN, patrón o huella al celular',
      como: 'Evita fechas de cumpleaños y patrones fáciles como una «L» o una «Z».'
    },
    {
      id: 'actualizar', categoria: 'celular',
      texto: 'Actualizar el sistema y las apps del celular',
      como: 'Las actualizaciones tapan agujeros de seguridad. Actívalas en automático.'
    },
    {
      id: 'permisos-apps', categoria: 'celular',
      texto: 'Quitar permisos que tus apps no necesitan',
      como: 'Revisa ubicación, micrófono, cámara y contactos en la configuración del celular.'
    },
    {
      id: 'apps-desconocidas', categoria: 'celular',
      texto: 'Borrar apps que no usas o que no vienen de la tienda oficial',
      como: 'Menos apps, menos puertas abiertas a tus datos.'
    },
    {
      id: 'cuenta-privada', categoria: 'redes',
      texto: 'Revisar quién puede ver tus publicaciones (cuenta privada)',
      como: 'Configuración → Privacidad. Decide si tu cuenta es pública o solo para quien aceptas.',
      anteriores: ['Revisar la privacidad de mi Instagram']
    },
    {
      id: 'etiquetas', categoria: 'redes',
      texto: 'Configurar quién puede etiquetarte y mencionarte',
      como: 'Así nadie te etiqueta en fotos sin que lo apruebes primero.',
      anteriores: ['Configurar quién puede etiquetarme en fotos']
    },
    {
      id: 'mensajes-directos', categoria: 'redes',
      texto: 'Limitar quién puede enviarte mensajes directos',
      como: 'Que solo te escriban personas que sigues o tus contactos.'
    },
    {
      id: 'ubicacion', categoria: 'redes',
      texto: 'Quitar la ubicación de tus publicaciones e historias',
      como: 'Y no compartas tu ubicación en tiempo real con quien no conoces en persona.',
      anteriores: ['Quitar la ubicación de mis publicaciones']
    },
    {
      id: 'seguidores', categoria: 'redes',
      texto: 'Quitar de tus seguidores a quien no conoces',
      como: 'Si no sabes quién es, no tiene por qué ver tu vida.'
    },
    {
      id: 'buscarte', categoria: 'redes',
      texto: 'Buscar tu nombre en internet y revisar qué aparece',
      como: 'Prueba con tu nombre completo y tu usuario. Pide quitar lo que no quieras público.'
    },
    {
      id: 'adulto-confianza', categoria: 'apoyo',
      texto: 'Platicar con un adulto de confianza sobre qué hacer si algo sale mal en línea',
      como: 'Puede ser tu familia, orientación educativa o un profesor. Saber a quién acudir ayuda.'
    },
    {
      id: 'numeros-ayuda', categoria: 'apoyo',
      texto: 'Guardar en tus contactos el 089 y la Línea de la Vida (800 911 2000)',
      como: 'El 089 es para denuncias anónimas; la Línea de la Vida da apoyo emocional gratis.'
    }
  ];

  // ---------- Objetivos de convivencia ----------
  // Se completan SOLOS cuando haces la actividad dentro de la app (leer una lección
  // o elegir la opción más segura en un escenario o reto). No se marcan a mano,
  // no dan XP extra y nunca piden datos de personas reales.
  // requisitos: lista de { tipo: 'leccion' | 'escenario' | 'reto', id }
  const OBJETIVOS_CONVIVENCIA = [
    {
      id: 'obj-senales', nombre: 'Identificar señales de ciberacoso',
      como: 'Lee la lección «Ciberacoso y hostigamiento digital».', destino: '#convivencia',
      requisitos: [{ tipo: 'leccion', id: 'conv-ciberacoso' }]
    },
    {
      id: 'obj-consentimiento', nombre: 'Entender el consentimiento digital',
      como: 'Lee la lección «Fotos, videos y consentimiento».', destino: '#convivencia',
      requisitos: [{ tipo: 'leccion', id: 'conv-fotos' }]
    },
    {
      id: 'obj-stickers', nombre: 'No compartir stickers humillantes',
      como: 'Simulador, paquete 4: el sticker de Luis.', destino: '#simulador',
      requisitos: [{ tipo: 'escenario', id: 'conv-sticker-companero' }]
    },
    {
      id: 'obj-apoyar', nombre: 'Apoyar a una persona afectada',
      como: 'Simulador, paquete 5: ayudar a Emi sin ponerte en peligro.', destino: '#simulador',
      requisitos: [{ tipo: 'escenario', id: 'conv-apoyar-amigo' }]
    },
    {
      id: 'obj-reportar', nombre: 'Reportar una publicación',
      como: 'Simulador, paquete 3: la cuenta de rumores.', destino: '#simulador',
      requisitos: [{ tipo: 'escenario', id: 'conv-cuenta-rumores' }]
    },
    {
      id: 'obj-adulto', nombre: 'Saber cuándo acudir a un adulto',
      como: 'Lee «¿Qué hago si soy testigo?» y resuelve la agresión en el recreo (paquete 5).', destino: '#convivencia',
      requisitos: [{ tipo: 'leccion', id: 'conv-testigo' }, { tipo: 'escenario', id: 'conv-recreo-agresion' }]
    },
    {
      id: 'obj-amenaza', nombre: 'Actuar ante una amenaza',
      como: 'Simulador, paquete 3: la amenaza con capturas.', destino: '#simulador',
      requisitos: [{ tipo: 'escenario', id: 'conv-amenaza-capturas' }]
    },
    {
      id: 'obj-broma', nombre: 'Distinguir una broma de una humillación',
      como: 'Lee «¿Broma, conflicto o acoso?» y responde el reto de la broma (Mundo Convivencia).', destino: '#convivencia',
      requisitos: [{ tipo: 'leccion', id: 'conv-distinguir' }, { tipo: 'reto', id: 'conv-q-broma' }]
    },
    {
      id: 'obj-no-grabar', nombre: 'No grabar ni reenviar una agresión',
      como: 'Simulador, paquete 5: la pelea a la salida.', destino: '#simulador',
      requisitos: [{ tipo: 'escenario', id: 'conv-pelea-grabar' }]
    },
    {
      id: 'obj-provocacion', nombre: 'Responder con respeto a una provocación',
      como: 'Simulador, paquete 3: el comentario en tu video.', destino: '#simulador',
      requisitos: [{ tipo: 'escenario', id: 'conv-provocacion' }]
    }
  ];

  // estaDominado(tipo, id) → true/false. Devuelve cada objetivo con «hecho».
  function revisarObjetivos(estaDominado) {
    return OBJETIVOS_CONVIVENCIA.map(function (objetivo) {
      const hecho = objetivo.requisitos.every(function (requisito) {
        return estaDominado(requisito.tipo, requisito.id);
      });
      return Object.assign({}, objetivo, { hecho: hecho });
    });
  }

  function limpiarTexto(texto) {
    return String(texto || '').replace(/\s+/g, ' ').trim();
  }

  function mismoTexto(a, b) {
    return limpiarTexto(a).toLowerCase() === limpiarTexto(b).toLowerCase();
  }

  // Busca si un texto corresponde a una misión oficial (por su texto o por uno anterior).
  function misionPorTexto(texto) {
    return MISIONES.find(function (mision) {
      return mismoTexto(mision.texto, texto) || (mision.anteriores || []).some(function (anterior) {
        return mismoTexto(anterior, texto);
      });
    }) || null;
  }

  // ---------- Misiones oficiales ----------
  // Se guardan como la lista de ids completadas.
  function normalizarMisiones(datos) {
    if (!Array.isArray(datos)) return [];
    const validas = MISIONES.map(function (mision) {
      return mision.id;
    });
    return validas.filter(function (id) {
      return datos.includes(id);
    });
  }

  function alternarMision(completadas, id) {
    const estaba = completadas.includes(id);
    const nuevas = estaba
      ? completadas.filter(function (otra) {
        return otra !== id;
      })
      : completadas.concat([id]);
    return { completadas: nuevas, completada: !estaba };
  }

  // ---------- Tareas personales ----------
  // Revisa el texto de una tarea. idIgnorado sirve al editar (no se compara consigo misma).
  function validarTexto(lista, texto, idIgnorado) {
    const limpio = limpiarTexto(texto);
    if (!limpio) return { ok: false, error: 'Escribe qué quieres hacer.' };
    if (limpio.length > LARGO_MAXIMO) {
      return { ok: false, error: 'Máximo ' + LARGO_MAXIMO + ' caracteres.' };
    }
    if (misionPorTexto(limpio)) {
      return { ok: false, error: 'Esa ya es una misión de seguridad: márcala en la lista de misiones.' };
    }
    const repetida = lista.some(function (tarea) {
      return tarea.id !== idIgnorado && mismoTexto(tarea.texto, limpio);
    });
    if (repetida) return { ok: false, error: 'Esa tarea ya está en tu plan.' };
    return { ok: true, texto: limpio };
  }

  function nuevoId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function agregar(lista, texto, id) {
    const revision = validarTexto(lista, texto);
    if (!revision.ok) return { lista: lista, error: revision.error };
    const tarea = { id: id || nuevoId(), texto: revision.texto, hecha: false };
    return { lista: lista.concat([tarea]), tarea: tarea };
  }

  function editar(lista, id, texto) {
    const revision = validarTexto(lista, texto, id);
    if (!revision.ok) return { lista: lista, error: revision.error };
    return {
      lista: lista.map(function (tarea) {
        return tarea.id === id ? Object.assign({}, tarea, { texto: revision.texto }) : tarea;
      })
    };
  }

  function borrar(lista, id) {
    return lista.filter(function (tarea) {
      return tarea.id !== id;
    });
  }

  function alternar(lista, id) {
    return lista.map(function (tarea) {
      return tarea.id === id ? Object.assign({}, tarea, { hecha: !tarea.hecha }) : tarea;
    });
  }

  // Si los datos guardados están dañados, se queda solo con lo que tiene sentido.
  function normalizarLista(datos) {
    if (!Array.isArray(datos)) return [];
    return datos
      .filter(function (tarea) {
        return tarea && typeof tarea.id === 'string' && typeof tarea.texto === 'string' && limpiarTexto(tarea.texto);
      })
      .map(function (tarea) {
        return {
          id: tarea.id,
          texto: limpiarTexto(tarea.texto).slice(0, LARGO_MAXIMO),
          hecha: tarea.hecha === true
        };
      });
  }

  // Versión anterior: las sugerencias se agregaban como tareas normales.
  // Las que coinciden con una misión se convierten en esa misión (conservando si estaba hecha).
  // "renombres" dice qué XP ya se había dado con el texto viejo, para no darlo dos veces.
  function migrar(lista, completadas) {
    let nuevasCompletadas = completadas.slice();
    const renombres = [];
    const restantes = [];
    lista.forEach(function (tarea) {
      const mision = misionPorTexto(tarea.texto);
      if (!mision) {
        restantes.push(tarea);
        return;
      }
      if (tarea.hecha && !nuevasCompletadas.includes(mision.id)) nuevasCompletadas.push(mision.id);
      renombres.push({ anterior: tarea.texto.toLowerCase(), id: mision.id });
    });
    nuevasCompletadas = normalizarMisiones(nuevasCompletadas);
    return { lista: restantes, completadas: nuevasCompletadas, renombres: renombres };
  }

  // ---------- Parte visual ----------
  let tareas = [];
  let misionesHechas = [];
  let idEditando = null;
  let elementos = null;
  // Recuerda qué categorías abrió o cerró la persona, para no cambiarlas al redibujar.
  const gruposAbiertos = {};

  function crear(etiqueta, clase, texto) {
    const elemento = document.createElement(etiqueta);
    if (clase) elemento.className = clase;
    if (texto !== undefined) elemento.textContent = texto;
    return elemento;
  }

  function cargar() {
    const lista = normalizarLista(Almacen.leer(CLAVE_TAREAS, []));
    const completadas = normalizarMisiones(Almacen.leer(CLAVE_MISIONES, []));
    const migrado = migrar(lista, completadas);
    tareas = migrado.lista;
    misionesHechas = migrado.completadas;
    if (migrado.renombres.length) {
      migrado.renombres.forEach(function (renombre) {
        Progreso.renombrarLogro('tarea', renombre.anterior, renombre.id);
      });
      Almacen.guardar(CLAVE_TAREAS, tareas);
      Almacen.guardar(CLAVE_MISIONES, misionesHechas);
    }
  }

  function guardar() {
    const ok = Almacen.guardar(CLAVE_TAREAS, tareas) && Almacen.guardar(CLAVE_MISIONES, misionesHechas);
    if (!ok) mostrarError('No se pudo guardar en este celular. Revisa que tenga espacio libre.');
    document.dispatchEvent(new CustomEvent('tareas-cambio'));
    return ok;
  }

  function mostrarError(texto) {
    elementos.error.textContent = texto || '';
    elementos.error.hidden = !texto;
  }

  // hechas = misiones oficiales completadas (lo que cuenta para el certificado).
  function resumen() {
    return {
      hechas: misionesHechas.length,
      total: MISIONES.length,
      personales: tareas.length,
      personalesHechas: tareas.filter(function (tarea) {
        return tarea.hecha;
      }).length
    };
  }

  // Casilla grande reutilizable (misiones y tareas personales).
  function casillaConTexto(texto, marcada, alCambiar) {
    const etiqueta = crear('label', 'tarea__check');
    const casilla = crear('input', 'tarea__casilla');
    casilla.type = 'checkbox';
    casilla.checked = marcada;
    const caja = crear('span', 'tarea__caja');
    caja.setAttribute('aria-hidden', 'true');
    caja.appendChild(Mascota.icono('palomita'));
    etiqueta.appendChild(casilla);
    etiqueta.appendChild(caja);
    etiqueta.appendChild(crear('span', 'tarea__texto', texto));
    casilla.addEventListener('change', alCambiar);
    return etiqueta;
  }

  function dibujarMision(mision) {
    const hecha = misionesHechas.includes(mision.id);
    const xpGanado = Progreso.estaDominado('tarea', mision.id);
    const elemento = crear('li', 'tarea tarea--mision' + (hecha ? ' tarea--hecha' : ''));
    elemento.dataset.id = mision.id;
    const cuerpo = crear('div', 'mision-tarea');
    cuerpo.appendChild(casillaConTexto(mision.texto, hecha, function () {
      const resultado = alternarMision(misionesHechas, mision.id);
      misionesHechas = resultado.completadas;
      guardar();
      // XP solo la primera vez que se completa (lo controla Progreso por id).
      if (resultado.completada) {
        Progreso.registrarRespuesta('tarea', mision.id, true, XP_POR_MISION);
        Mascota.efecto('acierto');
        Mascota.Companera.hablar('¡Una misión menos! Ya estás más protegido.', 'feliz');
      }
      dibujar(mision.id);
    }));
    cuerpo.appendChild(crear('p', 'mision-tarea__como', mision.como));
    elemento.appendChild(cuerpo);
    elemento.appendChild(crear('span', 'mision-tarea__xp' + (xpGanado ? ' mision-tarea__xp--ganado' : ''),
      xpGanado ? '✓ ' + XP_POR_MISION + ' XP' : '+' + XP_POR_MISION + ' XP'));
    return elemento;
  }

  function dibujarMisiones() {
    elementos.misiones.textContent = '';
    // Por defecto solo se abre la primera categoría con misiones pendientes,
    // para que la lista no sea larguísima en el celular.
    const primeraPendiente = CATEGORIAS.find(function (categoria) {
      return MISIONES.some(function (mision) {
        return mision.categoria === categoria.id && !misionesHechas.includes(mision.id);
      });
    });
    CATEGORIAS.forEach(function (categoria) {
      const delGrupo = MISIONES.filter(function (mision) {
        return mision.categoria === categoria.id;
      });
      const hechas = delGrupo.filter(function (mision) {
        return misionesHechas.includes(mision.id);
      }).length;
      const grupo = crear('details', 'acordeon acordeon--misiones');
      grupo.open = categoria.id in gruposAbiertos
        ? gruposAbiertos[categoria.id]
        : !!primeraPendiente && primeraPendiente.id === categoria.id;
      grupo.addEventListener('toggle', function () {
        gruposAbiertos[categoria.id] = grupo.open;
      });
      const titulo = crear('summary');
      const icono = crear('span', 'acordeon__icono');
      icono.appendChild(Mascota.icono(categoria.icono));
      titulo.appendChild(icono);
      titulo.appendChild(crear('span', 'acordeon__nombre', categoria.nombre));
      titulo.appendChild(crear('span', 'acordeon__cuenta', hechas + '/' + delGrupo.length));
      grupo.appendChild(titulo);
      const lista = crear('ul', 'lista-tareas lista-tareas--misiones');
      delGrupo.forEach(function (mision) {
        lista.appendChild(dibujarMision(mision));
      });
      grupo.appendChild(lista);
      elementos.misiones.appendChild(grupo);
    });
    elementos.contadorMisiones.textContent = misionesHechas.length + ' de ' + MISIONES.length + ' misiones completadas';
    elementos.barraMisiones.style.width = Math.round((misionesHechas.length / MISIONES.length) * 100) + '%';
  }

  function botonIcono(nombreIcono, etiqueta, clase) {
    const boton = crear('button', 'boton-icono' + (clase ? ' ' + clase : ''));
    boton.type = 'button';
    boton.setAttribute('aria-label', etiqueta);
    boton.appendChild(Mascota.icono(nombreIcono));
    return boton;
  }

  function dibujarTarea(tarea) {
    const elemento = crear('li', 'tarea' + (tarea.hecha ? ' tarea--hecha' : ''));
    elemento.dataset.id = tarea.id;

    if (tarea.id === idEditando) {
      const formulario = crear('form', 'tarea__edicion');
      const campo = crear('input', 'campo');
      campo.type = 'text';
      campo.value = tarea.texto;
      campo.maxLength = LARGO_MAXIMO;
      campo.setAttribute('aria-label', 'Nuevo texto de la tarea');
      campo.setAttribute('enterkeyhint', 'done');
      const acciones = crear('div', 'tarea__acciones-edicion');
      const guardarBoton = crear('button', 'boton boton--primario', 'Guardar');
      guardarBoton.type = 'submit';
      const cancelar = crear('button', 'boton', 'Cancelar');
      cancelar.type = 'button';
      acciones.appendChild(guardarBoton);
      acciones.appendChild(cancelar);
      formulario.appendChild(campo);
      formulario.appendChild(acciones);

      formulario.addEventListener('submit', function (evento) {
        evento.preventDefault();
        const resultado = editar(tareas, tarea.id, campo.value);
        if (resultado.error) {
          mostrarError(resultado.error);
          campo.focus();
          return;
        }
        tareas = resultado.lista;
        idEditando = null;
        mostrarError('');
        guardar();
        dibujar(tarea.id);
      });
      cancelar.addEventListener('click', function () {
        idEditando = null;
        mostrarError('');
        dibujar(tarea.id);
      });
      campo.addEventListener('keydown', function (evento) {
        if (evento.key === 'Escape') cancelar.click();
      });
      elemento.appendChild(formulario);
      return elemento;
    }

    elemento.appendChild(casillaConTexto(tarea.texto, tarea.hecha, function () {
      // Las tareas personales no dan XP ni cuentan para la racha.
      tareas = alternar(tareas, tarea.id);
      guardar();
      dibujar(tarea.id);
    }));

    const editarBoton = botonIcono('lapiz', 'Editar: ' + tarea.texto);
    editarBoton.addEventListener('click', function () {
      idEditando = tarea.id;
      mostrarError('');
      dibujar();
      const campo = elementos.lista.querySelector('.tarea__edicion .campo');
      if (campo) {
        campo.focus();
        campo.setSelectionRange(campo.value.length, campo.value.length);
      }
    });

    const borrarBoton = botonIcono('basura', 'Borrar: ' + tarea.texto, 'boton-icono--peligro');
    borrarBoton.addEventListener('click', function () {
      if (!global.confirm('¿Borrar la tarea «' + tarea.texto + '»?')) return;
      tareas = borrar(tareas, tarea.id);
      guardar();
      dibujar();
      Interfaz.anunciar('Tarea borrada');
      elementos.campo.focus();
    });

    elemento.appendChild(editarBoton);
    elemento.appendChild(borrarBoton);
    return elemento;
  }

  function dibujarPersonales() {
    elementos.lista.textContent = '';
    tareas.forEach(function (tarea) {
      elementos.lista.appendChild(dibujarTarea(tarea));
    });
    const cuenta = resumen();
    elementos.vacio.hidden = cuenta.personales > 0;
    elementos.contador.textContent = cuenta.personales === 0
      ? ''
      : cuenta.personalesHechas + ' de ' + cuenta.personales + ' tareas personales hechas';
  }

  // idParaEnfocar: después de un cambio, regresa el foco a esa tarea o misión.
  function dibujar(idParaEnfocar) {
    dibujarMisiones();
    dibujarPersonales();
    if (idParaEnfocar) {
      const control = document.querySelector('#vista-tareas [data-id="' + idParaEnfocar + '"] .boton-icono, #vista-tareas [data-id="' + idParaEnfocar + '"] .tarea__casilla');
      if (control) control.focus({ preventScroll: true });
    }
  }

  // Dibuja los objetivos en la sección Convivencia y el resumen en el Plan de acción.
  function dibujarObjetivos() {
    const lista = document.getElementById('lista-objetivos');
    if (!lista || !global.Progreso) return;
    const objetivos = revisarObjetivos(global.Progreso.estaDominado);
    const hechos = objetivos.filter(function (objetivo) {
      return objetivo.hecho;
    }).length;
    const texto = hechos + ' de ' + objetivos.length + ' objetivos cumplidos';
    document.getElementById('contador-objetivos').textContent = texto;
    document.getElementById('barra-objetivos').style.width = Math.round((hechos / objetivos.length) * 100) + '%';
    const resumenTareas = document.getElementById('resumen-objetivos');
    if (resumenTareas) resumenTareas.textContent = texto + ' · Se completan solos al aprender';

    lista.textContent = '';
    objetivos.forEach(function (objetivo) {
      const elemento = crear('li', 'objetivo' + (objetivo.hecho ? ' objetivo--hecho' : ''));
      const marca = crear('span', 'objetivo__marca');
      marca.setAttribute('aria-hidden', 'true');
      if (objetivo.hecho) marca.appendChild(Mascota.icono('palomita'));
      elemento.appendChild(marca);
      const textos = crear('div', 'objetivo__textos');
      textos.appendChild(crear('span', 'objetivo__nombre', objetivo.nombre));
      textos.appendChild(crear('span', 'objetivo__como', objetivo.hecho ? '¡Cumplido!' : objetivo.como));
      elemento.appendChild(textos);
      if (!objetivo.hecho) {
        const ir = crear('a', 'boton boton--chico objetivo__ir', 'Ir');
        ir.href = objetivo.destino;
        ir.setAttribute('aria-label', 'Ir a cumplir: ' + objetivo.nombre);
        elemento.appendChild(ir);
      }
      elemento.setAttribute('aria-label', objetivo.nombre + (objetivo.hecho ? ': cumplido' : ': pendiente'));
      lista.appendChild(elemento);
    });
  }

  function iniciar() {
    // Los objetivos se recalculan cada vez que cambia el progreso.
    dibujarObjetivos();
    document.addEventListener('progreso-cambio', dibujarObjetivos);

    elementos = {
      formulario: document.getElementById('form-tarea'),
      campo: document.getElementById('campo-tarea'),
      error: document.getElementById('error-tarea'),
      lista: document.getElementById('lista-tareas'),
      vacio: document.getElementById('tareas-vacio'),
      contador: document.getElementById('contador-tareas'),
      misiones: document.getElementById('lista-misiones'),
      contadorMisiones: document.getElementById('contador-misiones'),
      barraMisiones: document.getElementById('barra-misiones')
    };
    if (!elementos.formulario) return;
    elementos.campo.maxLength = LARGO_MAXIMO;

    elementos.formulario.addEventListener('submit', function (evento) {
      evento.preventDefault();
      const resultado = agregar(tareas, elementos.campo.value);
      if (resultado.error) {
        mostrarError(resultado.error);
        elementos.campo.focus();
        return;
      }
      tareas = resultado.lista;
      elementos.campo.value = '';
      mostrarError('');
      guardar();
      dibujar();
      Interfaz.anunciar('Tarea agregada: ' + resultado.tarea.texto);
    });

    // Al reiniciar el progreso cambian los sellos de XP ganado.
    document.addEventListener('progreso-cambio', dibujarMisiones);

    cargar();
    dibujar();
  }

  const Tareas = {
    CLAVE_TAREAS: CLAVE_TAREAS,
    CLAVE_MISIONES: CLAVE_MISIONES,
    LARGO_MAXIMO: LARGO_MAXIMO,
    XP_POR_MISION: XP_POR_MISION,
    CATEGORIAS: CATEGORIAS,
    MISIONES: MISIONES,
    OBJETIVOS_CONVIVENCIA: OBJETIVOS_CONVIVENCIA,
    revisarObjetivos: revisarObjetivos,
    misionPorTexto: misionPorTexto,
    normalizarMisiones: normalizarMisiones,
    alternarMision: alternarMision,
    validarTexto: validarTexto,
    agregar: agregar,
    editar: editar,
    borrar: borrar,
    alternar: alternar,
    normalizarLista: normalizarLista,
    migrar: migrar,
    resumen: function () {
      return resumen();
    },
    iniciar: iniciar
  };

  if (typeof module === 'object' && module.exports) module.exports = Tareas;
  else global.Tareas = Tareas;
})(this);
