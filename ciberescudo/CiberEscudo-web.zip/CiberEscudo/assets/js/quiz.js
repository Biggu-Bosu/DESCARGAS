// CiberEscudo · quiz.js
// Retos: 40 preguntas de opción múltiple repartidas en 4 mundos de 10
// (3 de seguridad digital y 1 de convivencia).
// Cada respuesta correcta da +15 XP solo la primera vez (la pregunta queda
// "dominada"). Cuando ya dominaste una pregunta, repetirla es repaso: no da XP.
// Al final de cada mundo, la mascota reacciona según tu resultado.

(function (global) {
  'use strict';

  const XP_POR_ACIERTO = 15;

  const MUNDOS = [
    { id: 'cuentas', nombre: 'Contraseñas y cuentas', descripcion: 'Contraseñas, 2FA y sesiones', icono: 'candado', color: 'cian', grupo: 'Seguridad digital' },
    { id: 'redes', nombre: 'Redes y privacidad', descripcion: 'Huella digital, fotos y ubicación', icono: 'ojo', color: 'rosa', grupo: 'Seguridad digital' },
    { id: 'estafas', nombre: 'Estafas y engaños', descripcion: 'Phishing, perfiles falsos y fraudes', icono: 'alerta', color: 'amarillo', grupo: 'Seguridad digital' },
    { id: 'convivencia', nombre: 'Convivencia y respeto', descripcion: 'Bromas, consentimiento, testigos y pedir ayuda', icono: 'corazon', color: 'naranja', grupo: 'Convivencia' }
  ];

  // "correcta" es la posición de la respuesta buena (0 = la primera).
  // Los ids de las 8 preguntas originales no cambian, para conservar el progreso.
  const PREGUNTAS = [
    // ---------- Mundo 1: Contraseñas y cuentas ----------
    {
      id: 'contrasena-segura', mundo: 'cuentas',
      pregunta: '¿Cuál de estas contraseñas es más segura?',
      opciones: ['Maria2008', 'qwerty123', 'tortuga-cometa-faro-elote', 'P@ss'],
      correcta: 2,
      explicacion: 'Una frase larga de palabras sin relación es difícil de adivinar y fácil de recordar. Los nombres con años y las secuencias de teclado se adivinan rápido.'
    },
    {
      id: 'que-es-2fa', mundo: 'cuentas',
      pregunta: '¿Qué es la verificación en dos pasos (2FA)?',
      opciones: [
        'Escribir la contraseña dos veces',
        'Un segundo candado: además de la contraseña, se pide un código o una confirmación en tu celular',
        'Tener dos cuentas en la misma red social',
        'Cambiar la contraseña cada dos días'
      ],
      correcta: 1,
      explicacion: 'Con 2FA, aunque alguien consiga tu contraseña, no puede entrar sin el segundo paso que solo tú tienes.'
    },
    {
      id: 'codigo-sms', mundo: 'cuentas',
      pregunta: 'Te llega un código de 6 dígitos que no pediste y alguien te lo pide por mensaje. ¿Qué haces?',
      opciones: [
        'Se lo paso si es una amistad',
        'Lo publico en mis historias para preguntar qué es',
        'Lo mando al grupo del salón',
        'No lo comparto con nadie'
      ],
      correcta: 3,
      explicacion: 'Ese código es la llave para abrir tu cuenta en otro dispositivo. Si alguien te lo pide, es casi seguro que quiere robarla.'
    },
    {
      id: 'gestor-contrasenas', mundo: 'cuentas',
      pregunta: '¿Qué es un gestor de contraseñas?',
      opciones: [
        'Una app que crea y guarda contraseñas seguras por ti, protegida con una contraseña maestra',
        'Una persona que adivina contraseñas',
        'Una lista en las notas del celular',
        'El botón de «Olvidé mi contraseña»'
      ],
      correcta: 0,
      explicacion: 'Con un gestor solo recuerdas una contraseña fuerte, y él se encarga de tener una distinta para cada cuenta. Las notas del celular no están protegidas igual.'
    },
    {
      id: 'repetir-contrasena', mundo: 'cuentas',
      pregunta: '¿Por qué es peligroso usar la misma contraseña en todas tus cuentas?',
      opciones: [
        'Porque se desgasta con el uso',
        'Porque las apps lo prohíben',
        'Porque si se filtra en un sitio, pueden entrar a todas tus demás cuentas',
        'No es peligroso si es larga'
      ],
      correcta: 2,
      explicacion: 'Cuando una página sufre una filtración, los delincuentes prueban esa contraseña en otras apps. Si es la misma, caen todas como dominó.'
    },
    {
      id: 'contrasena-pareja', mundo: 'cuentas',
      pregunta: 'Tu novio o novia te pide tu contraseña «como prueba de confianza». ¿Qué es lo más sano?',
      opciones: [
        'Dársela para que no se enoje',
        'No compartirla: la confianza no se demuestra dando acceso a tus cuentas',
        'Cambiarla por una más fácil para los dos',
        'Dársela solo los fines de semana'
      ],
      correcta: 1,
      explicacion: 'Tus cuentas son tuyas. Pedir contraseñas para vigilar no es confianza, es control. Puedes decir que no sin dar explicaciones.'
    },
    {
      id: 'sesion-compartida', mundo: 'cuentas',
      pregunta: 'Usaste una computadora de la biblioteca para entrar a tu correo. ¿Qué debes hacer al terminar?',
      opciones: [
        'Cerrar sesión y no dejar que el navegador guarde tu contraseña',
        'Solo cerrar la pestaña',
        'Apagar el monitor',
        'Dejarla abierta para la próxima vez'
      ],
      correcta: 0,
      explicacion: 'Cerrar la pestaña no cierra la sesión. La siguiente persona podría entrar a tu cuenta sin saber tu contraseña.'
    },
    {
      id: 'codigos-respaldo', mundo: 'cuentas',
      pregunta: 'Al activar 2FA te dan «códigos de respaldo». ¿Para qué sirven?',
      opciones: [
        'Para compartirlos con tus amigos',
        'Para ganar puntos en la app',
        'No sirven para nada',
        'Para entrar a tu cuenta si pierdes tu celular; se guardan en un lugar seguro'
      ],
      correcta: 3,
      explicacion: 'Si pierdes el celular donde llegan los códigos, los de respaldo te dejan entrar. Guárdalos en papel o en tu gestor, nunca en una foto pública.'
    },
    {
      id: 'alerta-inicio-sesion', mundo: 'cuentas',
      pregunta: 'La app oficial te avisa: «Nuevo inicio de sesión desde otra ciudad». No fuiste tú. ¿Qué haces primero?',
      opciones: [
        'Ignorarlo',
        'Desde la app oficial: cambiar la contraseña y cerrar las sesiones que no reconozcas',
        'Contestar el aviso con tu contraseña',
        'Borrar la app del celular'
      ],
      correcta: 1,
      explicacion: 'Actuar rápido desde la app (no desde un enlace) saca al intruso. Después activa 2FA si no lo tenías.'
    },
    {
      id: 'bloqueo-celular', mundo: 'cuentas',
      pregunta: '¿Por qué conviene ponerle bloqueo (PIN, patrón o huella) a tu celular?',
      opciones: [
        'Porque se ve más bonito',
        'Para que la batería dure más',
        'Porque si lo pierdes o alguien lo toma, no puede entrar a tus apps ni a tus fotos',
        'No sirve si tienes funda'
      ],
      correcta: 2,
      explicacion: 'Tu celular tiene tus chats, fotos y cuentas abiertas. El bloqueo es la primera puerta que protege todo eso.'
    },

    // ---------- Mundo 2: Redes y privacidad ----------
    {
      id: 'huella-digital', mundo: 'redes',
      pregunta: '¿Qué es tu huella digital?',
      opciones: [
        'La marca de tu dedo en la pantalla',
        'Todo el rastro que dejas en internet: fotos, comentarios, «me gusta» y búsquedas',
        'La contraseña de tu celular',
        'Un programa antivirus'
      ],
      correcta: 1,
      explicacion: 'Lo que publicas puede quedarse mucho tiempo y lo pueden ver personas que no imaginas. Por eso conviene pensar antes de publicar.'
    },
    {
      id: 'foto-sin-permiso', mundo: 'redes',
      pregunta: 'Una amiga sube una foto tuya del convivio que no te gusta. ¿Qué es lo más adecuado?',
      opciones: [
        'Entrar a su cuenta para borrarla',
        'Subir una foto fea de ella',
        'Pedirle con respeto que la quite; si no lo hace, reportarla en la red social',
        'Quedarte con la molestia y no decir nada'
      ],
      correcta: 2,
      explicacion: 'Tienes derecho a decidir sobre tu imagen. Hablarlo es el primer paso, y las redes permiten reportar fotos tuyas publicadas sin permiso.'
    },
    {
      id: 'foto-intima', mundo: 'redes',
      pregunta: 'Si alguien difunde una foto íntima de otra persona sin su permiso, ¿qué es cierto?',
      opciones: [
        'Es culpa de quien aparece en la foto',
        'No se puede hacer nada',
        'Hay que pagar para que la borren',
        'Es un delito en México (Ley Olimpia) y la víctima puede pedir ayuda y denunciar'
      ],
      correcta: 3,
      explicacion: 'La responsabilidad es de quien difunde, nunca de la víctima. Se guardan pruebas, se reporta, se pide apoyo a un adulto de confianza y se denuncia. Compartirla también hace daño: no la reenvíes.'
    },
    {
      id: 'ubicacion-en-vivo', mundo: 'redes',
      pregunta: 'Subes una historia en el momento, con la ubicación de tu casa. ¿Cuál es el riesgo?',
      opciones: [
        'Que gente que no conoces sepa dónde vives y cuándo estás ahí',
        'Ninguno, es una historia',
        'Que gaste más datos',
        'Que la foto salga borrosa'
      ],
      correcta: 0,
      explicacion: 'La ubicación en tiempo real dice dónde estás ahora mismo. Mejor publica después de irte y sin etiquetar tu casa o tu escuela.'
    },
    {
      id: 'cuenta-privada', mundo: 'redes',
      pregunta: '¿Qué logras al poner tu cuenta en privado?',
      opciones: [
        'Que nadie te pueda hablar nunca',
        'Que tus fotos se borren',
        'Que tengas más seguidores',
        'Que solo las personas que aceptas vean tus publicaciones'
      ],
      correcta: 3,
      explicacion: 'Una cuenta privada no te hace invisible, pero decide quién ve tu contenido. Revisa también a quién aceptas.'
    },
    {
      id: 'desconocido-amable', mundo: 'redes',
      pregunta: 'Alguien que no conoces te escribe muy amable, te hace muchos cumplidos y pronto te pide fotos o que lo guarden en secreto. ¿Qué haces?',
      opciones: [
        'Le sigo la plática porque es amable',
        'Me alejo, lo bloqueo, lo reporto y se lo cuento a un adulto de confianza',
        'Le mando una foto para no ser grosero',
        'Le paso mi número para hablar mejor'
      ],
      correcta: 1,
      explicacion: 'Pedir secretos y fotos a alguien joven es una señal de alarma. Nadie que te respete te pide ocultar algo a las personas que te cuidan.'
    },
    {
      id: 'foto-uniforme', mundo: 'redes',
      pregunta: 'Subes una foto con el uniforme y el nombre de tu escuela. ¿Qué información das sin darte cuenta?',
      opciones: [
        'Ninguna',
        'Tu contraseña',
        'Dónde estudias y en qué horario podrías estar ahí',
        'Tu talla de ropa'
      ],
      correcta: 2,
      explicacion: 'Uniformes, letreros, placas o la vista desde tu ventana revelan dónde estás. Revisa el fondo de tus fotos antes de publicarlas.'
    },
    {
      id: 'borrar-publicacion', mundo: 'redes',
      pregunta: 'Borraste una publicación a los 5 minutos. ¿Ya desapareció para siempre?',
      opciones: [
        'No necesariamente: alguien pudo tomarle captura o descargarla',
        'Sí, borrar es definitivo',
        'Solo si nadie le dio «me gusta»',
        'Sí, si era una historia'
      ],
      correcta: 0,
      explicacion: 'Internet no tiene botón de deshacer. Piensa antes de publicar: si no lo dirías en voz alta frente a todos, mejor no lo subas.'
    },
    {
      id: 'permisos-apps', mundo: 'redes',
      pregunta: 'Una app de linterna te pide acceso a tus contactos y al micrófono. ¿Qué haces?',
      opciones: [
        'Acepto todo, si no, no funciona',
        'Le doy mi contraseña para que funcione mejor',
        'Niego los permisos que no tienen sentido para lo que hace la app',
        'La comparto con mis amigos'
      ],
      correcta: 2,
      explicacion: 'Una linterna no necesita tus contactos. Muchas apps piden datos de más para venderlos. Revisa los permisos en la configuración del celular.'
    },
    {
      id: 'wifi-publico', mundo: 'redes',
      pregunta: 'Estás conectado a un wifi gratis de una plaza. ¿Qué es mejor evitar?',
      opciones: [
        'Ver un video',
        'Revisar el clima',
        'Leer noticias',
        'Entrar a tu banco o escribir contraseñas importantes'
      ],
      correcta: 3,
      explicacion: 'En una red abierta otras personas podrían espiar o imitar la red. Para cosas importantes usa tus datos móviles.'
    },

    // ---------- Mundo 3: Estafas y engaños ----------
    {
      id: 'que-es-phishing', mundo: 'estafas',
      pregunta: '¿Qué es el phishing?',
      opciones: [
        'Un engaño que imita a una empresa o persona para robar tus datos',
        'Un juego de pesca en línea',
        'Un virus que solo afecta a las computadoras',
        'Una red social nueva'
      ],
      correcta: 0,
      explicacion: 'Viene de «fishing» (pescar): lanzan un anzuelo (un mensaje o una página falsa) para que «muerdas» y entregues tus datos.'
    },
    {
      id: 'senal-falsa', mundo: 'estafas',
      pregunta: '¿Cuál es la señal más clara de un mensaje falso?',
      opciones: [
        'Te mete prisa y te pide datos, códigos o dinero',
        'Trae muchos emojis',
        'Es un mensaje largo',
        'Llega en la noche'
      ],
      correcta: 0,
      explicacion: 'La prisa sirve para que no pienses. Si un mensaje te presiona para dar datos o dinero, detente y verifica por otro medio.'
    },
    {
      id: 'revisar-enlace', mundo: 'estafas',
      pregunta: '¿Cómo puedes revisar un enlace antes de abrirlo?',
      opciones: [
        'Abriéndolo rápido para ver qué es',
        'Preguntándole a quien lo mandó si es seguro',
        'Manteniéndolo presionado para ver la dirección completa y fijarte si es del sitio oficial',
        'Reenviándolo a un amigo para que lo pruebe'
      ],
      correcta: 2,
      explicacion: 'Las páginas falsas usan nombres parecidos al original con letras de más o dominios raros. Si dudas, entra tú mismo desde la app oficial.'
    },
    {
      id: 'perfil-falso', mundo: 'estafas',
      pregunta: '¿Qué señal indica que un perfil podría ser falso?',
      opciones: [
        'Tiene foto de perfil',
        'Publica memes',
        'Sigue a tus amigos',
        'Es nuevo, tiene pocas publicaciones, sigue a muchísima gente y te pide algo rápido'
      ],
      correcta: 3,
      explicacion: 'Los perfiles falsos se crean rápido y en masa. Que siga a tus amigos no prueba nada: a veces los aceptaron sin revisar.'
    },
    {
      id: 'soporte-falso', mundo: 'estafas',
      pregunta: 'Un «agente de soporte» te escribe por mensaje directo para ayudarte con un problema que no reportaste. ¿Qué es lo más probable?',
      opciones: [
        'Que sea un engaño para robar tu cuenta',
        'Que la empresa te aprecie mucho',
        'Que ganaste un premio',
        'Que van a verificar tu cuenta'
      ],
      correcta: 0,
      explicacion: 'Las plataformas no te escriben por mensaje directo para pedirte datos. El soporte real está dentro de la app, en Configuración o Ayuda.'
    },
    {
      id: 'codigo-qr', mundo: 'estafas',
      pregunta: 'Encuentras un código QR pegado en un poste que promete datos gratis. ¿Qué haces?',
      opciones: [
        'Lo escaneo y doy mis datos',
        'Desconfío: un QR puede llevar a una página falsa igual que un enlace',
        'Lo comparto en el grupo',
        'Le tomo foto para escanearlo después'
      ],
      correcta: 1,
      explicacion: 'Un QR es solo un enlace disfrazado. Cualquiera puede pegar uno encima de otro. Si lo escaneas, revisa la dirección antes de escribir algo.'
    },
    {
      id: 'archivo-apk', mundo: 'estafas',
      pregunta: 'Un mensaje te dice que instales un archivo «fotos.apk» para ver unas fotos. ¿Qué haces?',
      opciones: [
        'Lo instalo, solo son fotos',
        'Lo reenvío para que otros lo vean',
        'Lo abro en el celular de mi hermano',
        'No lo instalo: las fotos no vienen en apps y las apps solo se instalan desde la tienda oficial'
      ],
      correcta: 3,
      explicacion: 'Un .apk es un programa. Las «fotos» que piden instalar algo suelen ser apps espía o que roban cuentas.'
    },
    {
      id: 'oferta-increible', mundo: 'estafas',
      pregunta: 'Ves tenis de marca con 90 % de descuento en una página que no conoces y solo aceptan transferencia. ¿Qué piensas?',
      opciones: [
        'Es una ganga, compro ya',
        'Compro dos pares',
        'Si es demasiado bueno para ser verdad, probablemente es una estafa',
        'Pago con la tarjeta de alguien más sin avisar'
      ],
      correcta: 2,
      explicacion: 'Las tiendas falsas usan precios imposibles y piden transferencias porque no se pueden reclamar. Busca opiniones y paga con métodos que tengan protección.'
    },
    {
      id: 'cadena-miedo', mundo: 'estafas',
      pregunta: 'Te llega: «Reenvía esto a 10 contactos o tu cuenta de WhatsApp será cobrada». ¿Qué es?',
      opciones: [
        'Un mensaje falso que usa el miedo para volverse viral',
        'Un aviso oficial de WhatsApp',
        'Un virus que ya tienes',
        'Una promoción'
      ],
      correcta: 0,
      explicacion: 'Las cadenas no son avisos oficiales. No las reenvíes: así ayudas a que los engaños se detengan.'
    },
    {
      id: 'llamada-falsa', mundo: 'estafas',
      pregunta: 'Te llaman diciendo que un familiar está detenido y piden dinero urgente sin que cuelgues. ¿Qué haces?',
      opciones: [
        'Deposito rápido',
        'Cuelgo y llamo a mi familiar o a otro adulto a su número de siempre',
        'Doy mis datos para ayudar',
        'Le paso el teléfono a un amigo'
      ],
      correcta: 1,
      explicacion: 'Que no te dejen colgar es la trampa: quieren que no compruebes nada. Cuelga, verifica y repórtalo al 089 de forma anónima.'
    },

    // ---------- Mundo 4: Convivencia y respeto ----------
    {
      id: 'conv-q-broma', mundo: 'convivencia',
      pregunta: '¿Cuándo una broma deja de ser broma?',
      opciones: [
        'Cuando alguien se enoja un poquito',
        'Cuando la persona de quien se trata no se ríe, pide que paren o se repite para humillarla',
        'Nunca: las bromas son bromas',
        'Solo cuando hay golpes'
      ],
      correcta: 1,
      explicacion: 'Una broma lo es cuando todos se ríen de verdad, incluida la persona. Si pide que paren o se usa para humillarla una y otra vez, ya es acoso.'
    },
    {
      id: 'conv-q-reenviar', mundo: 'convivencia',
      pregunta: 'Te llega un meme que humilla a un compañero. ¿Reenviarlo también hace daño?',
      opciones: [
        'No, yo no lo hice',
        'Solo si lo mando a más de cinco personas',
        'Sí: cada reenvío y cada reacción hacen que llegue a más gente',
        'No, si se lo mando solo a mis amigos de confianza'
      ],
      correcta: 2,
      explicacion: 'No hace falta crear el contenido para ser parte: reenviar, guardar «para reírte después» o reaccionar lo amplifica.'
    },
    {
      id: 'conv-q-foto', mundo: 'convivencia',
      pregunta: 'Tu amiga aceptó que le tomaras una foto. ¿Eso significa que la puedes publicar?',
      opciones: [
        'No: aceptar la foto no es aceptar que se publique; hay que preguntarle',
        'Sí, ya dio permiso',
        'Sí, si sale bien en la foto',
        'Sí, si no la etiqueto'
      ],
      correcta: 0,
      explicacion: 'El consentimiento es específico: decir que sí a una foto no es decir que sí a publicarla. Preguntar antes evita problemas.'
    },
    {
      id: 'conv-q-amenaza', mundo: 'convivencia',
      pregunta: 'Un compañero te escribe una sola vez: «Mañana te espero a la salida para golpearte». ¿Qué es lo correcto?',
      opciones: [
        'Como fue una sola vez, no pasa nada',
        'Esperar a que se repita para avisar',
        'Responderle con otra amenaza',
        'Guardar el mensaje y avisar hoy mismo a un adulto'
      ],
      correcta: 3,
      explicacion: 'Una amenaza merece atención aunque pase una sola vez. Guardar el mensaje y avisar a un adulto ayuda a evitar que se cumpla.'
    },
    {
      id: 'conv-q-testigo', mundo: 'convivencia',
      pregunta: 'En el recreo ves que molestan a alguien y parece que habrá golpes. ¿Qué es lo más seguro?',
      opciones: [
        'Meterme a pelear para defenderlo',
        'Alejarme y avisar de inmediato a un adulto de la escuela',
        'Grabar con el celular para tener pruebas',
        'Animar para que termine rápido'
      ],
      correcta: 1,
      explicacion: 'Tu seguridad es primero. Avisar a un adulto es la forma más rápida y segura de detenerlo; grabar o animar le da público.'
    },
    {
      id: 'conv-q-poder', mundo: 'convivencia',
      pregunta: '¿Qué hace que un pleito se parezca más a acoso?',
      opciones: [
        'Que se repita y haya desequilibrio de poder: varios contra uno o alguien con más fuerza o popularidad',
        'Que dos personas discutan una vez',
        'Que pase en el chat y no en persona',
        'Que lo vea un profesor'
      ],
      correcta: 0,
      explicacion: 'Un conflicto entre iguales puede pasar. Cuando se repite, hay desequilibrio de poder y busca humillar, ya es acoso, en línea o en persona.'
    },
    {
      id: 'conv-q-silencio', mundo: 'convivencia',
      pregunta: 'Le preguntas a alguien si puedes subir un video donde sale y no te contesta. ¿Qué haces?',
      opciones: [
        'Lo subo: el que calla otorga',
        'No lo subo: no contestar no es decir que sí',
        'Lo subo solo a mis historias',
        'Lo subo y, si se queja, lo borro'
      ],
      correcta: 1,
      explicacion: 'El silencio no es consentimiento: alguien puede no contestar por pena o porque no lo vio. Sin un sí claro, no se publica.'
    },
    {
      id: 'conv-q-disculpa', mundo: 'convivencia',
      pregunta: 'Hiciste un comentario que lastimó a alguien. ¿Cuál es una buena disculpa?',
      opciones: [
        '«Perdón si te ofendiste, pero era broma»',
        '«Perdón. Ya lo borré y no se va a repetir»',
        '«Te pido perdón, así que tienes que perdonarme»',
        '«Todos lo dicen, no exageres»'
      ],
      correcta: 1,
      explicacion: 'Una buena disculpa no pone excusas, repara lo que se puede y no obliga a perdonar. La otra persona decide si quiere hablar.'
    },
    {
      id: 'conv-q-evidencia', mundo: 'convivencia',
      pregunta: '¿Cuál es una forma segura de guardar evidencia de ciberacoso?',
      opciones: [
        'Reenviar los mensajes al grupo del salón para que todos vean',
        'Publicar las capturas en mis redes',
        'Entrar a la cuenta de quien me molesta para buscar más',
        'Captura con fecha, plataforma y usuario, guardada en mi celular para mostrarla a un adulto'
      ],
      correcta: 3,
      explicacion: 'La evidencia es para pedir ayuda, no para exhibir. Guárdala sin difundirla y nunca entres a cuentas ajenas.'
    },
    {
      id: 'conv-q-represalias', mundo: 'convivencia',
      pregunta: 'Después de que Ana avisó a orientación, el grupo empezó a decirle «chismosa». ¿Qué le conviene hacer?',
      opciones: [
        'Volver a avisar: las represalias también se atienden',
        'Quedarse callada para que se calme',
        'Vengarse del grupo',
        'Cambiarse de escuela sin decirle a nadie'
      ],
      correcta: 0,
      explicacion: 'Las represalias por pedir ayuda son otra forma de acoso. Pedir ayuda no es ser chismosa: es cuidarse.'
    }
  ];

  function preguntasDeMundo(idMundo) {
    return PREGUNTAS.filter(function (pregunta) {
      return pregunta.mundo === idMundo;
    });
  }

  // Mensaje final según cuántas acertaste.
  function evaluarResultado(aciertos, total) {
    const proporcion = total === 0 ? 0 : aciertos / total;
    if (proporcion >= 0.85) return { estado: 'feliz', mensaje: '¡Eres un auténtico CiberEscudo! Nada te engaña.' };
    if (proporcion >= 0.5) return { estado: 'hablar', mensaje: '¡Bien! Ya sabes mucho. Repasa las que fallaste.' };
    return { estado: 'triste', mensaje: 'No pasa nada: equivocarse aquí es la mejor forma de aprender. ¡Inténtalo otra vez!' };
  }

  // ---------- Parte visual ----------
  let contenedor = null;
  let mundoActual = null;
  let preguntasActuales = [];
  let indiceActual = 0;
  let aciertos = 0;

  function crear(etiqueta, clase, texto) {
    const elemento = document.createElement(etiqueta);
    if (clase) elemento.className = clase;
    if (texto !== undefined) elemento.textContent = texto;
    return elemento;
  }

  // Pantalla para elegir mundo, con lo que llevas dominado de cada uno.
  function dibujarMundos() {
    mundoActual = null;
    contenedor.textContent = '';
    contenedor.appendChild(Interfaz.selectorMisiones({
      tipo: 'reto',
      misiones: MUNDOS.map(function (mundo) {
        const ids = preguntasDeMundo(mundo.id).map(function (pregunta) {
          return pregunta.id;
        });
        return Object.assign({}, mundo, { ids: ids, unidad: 'preguntas dominadas' });
      }),
      alElegir: empezarMundo
    }));
    Interfaz.animarEntrada(contenedor);
  }

  function empezarMundo(idMundo) {
    mundoActual = MUNDOS.find(function (mundo) {
      return mundo.id === idMundo;
    });
    preguntasActuales = preguntasDeMundo(idMundo);
    indiceActual = 0;
    aciertos = 0;
    dibujarPregunta();
    Interfaz.subirAlInicio(contenedor);
  }

  function dibujarPregunta() {
    const pregunta = preguntasActuales[indiceActual];
    contenedor.textContent = '';
    contenedor.appendChild(Interfaz.barraJuego(mundoActual.nombre, dibujarMundos));
    contenedor.appendChild(Interfaz.barraProgreso(indiceActual, preguntasActuales.length, 'Pregunta'));
    if (Progreso.estaDominado('reto', pregunta.id)) {
      contenedor.appendChild(crear('p', 'etiqueta-repaso', 'Repaso · ya la dominas'));
    }
    contenedor.appendChild(crear('h3', 'juego__pregunta juego__pregunta--grande', pregunta.pregunta));

    const opciones = crear('div', 'opciones');
    const letras = ['A', 'B', 'C', 'D'];
    pregunta.opciones.forEach(function (texto, indice) {
      const boton = crear('button', 'opcion');
      boton.type = 'button';
      boton.appendChild(crear('span', 'opcion__letra', letras[indice]));
      boton.appendChild(crear('span', 'opcion__texto', texto));
      boton.addEventListener('click', function () {
        responder(indice, opciones);
      });
      opciones.appendChild(boton);
    });
    contenedor.appendChild(opciones);
    Interfaz.animarEntrada(contenedor);
  }

  function responder(indiceElegido, opciones) {
    const pregunta = preguntasActuales[indiceActual];
    const acerto = indiceElegido === pregunta.correcta;
    opciones.querySelectorAll('.opcion').forEach(function (boton, indice) {
      boton.disabled = true;
      if (indice === pregunta.correcta) boton.classList.add('opcion--correcta');
      else if (indice === indiceElegido) boton.classList.add('opcion--incorrecta');
    });

    if (acerto) aciertos += 1;
    const ganado = Progreso.registrarRespuesta('reto', pregunta.id, acerto, XP_POR_ACIERTO);
    const esUltima = indiceActual === preguntasActuales.length - 1;

    contenedor.appendChild(Interfaz.panelRetro({
      acerto: acerto,
      xpGanado: ganado,
      xpPosible: XP_POR_ACIERTO,
      mensaje: acerto ? '¡Correcto!' : 'La respuesta correcta era: ' + pregunta.opciones[pregunta.correcta],
      explicacion: pregunta.explicacion,
      textoBoton: esUltima ? 'Ver resultados' : 'Siguiente pregunta',
      alContinuar: function () {
        if (esUltima) dibujarResultados();
        else {
          indiceActual += 1;
          dibujarPregunta();
          Interfaz.subirAlInicio(contenedor);
        }
      }
    }));
  }

  function dibujarResultados() {
    contenedor.textContent = '';
    const evaluacion = evaluarResultado(aciertos, preguntasActuales.length);
    const ids = preguntasActuales.map(function (pregunta) {
      return pregunta.id;
    });
    const dominadas = Progreso.contarDominados('reto', ids);
    contenedor.appendChild(Interfaz.panelResultados({
      titulo: mundoActual.nombre,
      aciertos: aciertos,
      total: preguntasActuales.length,
      estado: evaluacion.estado,
      mensaje: dominadas === ids.length ? '¡Dominaste este mundo completo! ' + evaluacion.mensaje : evaluacion.mensaje,
      detalle: 'Dominadas en este mundo: ' + dominadas + ' de ' + ids.length,
      celebrar: dominadas === ids.length,
      textoRepetir: 'Repetir mundo',
      alRepetir: function () {
        empezarMundo(mundoActual.id);
      },
      textoVolver: 'Elegir otro mundo',
      alVolver: function () {
        dibujarMundos();
        Interfaz.subirAlInicio(contenedor);
      }
    }));
    Interfaz.subirAlInicio(contenedor);
  }

  function iniciar() {
    contenedor = document.getElementById('retos-juego');
    if (!contenedor) return;
    dibujarMundos();
    // Si cambia el progreso (por ejemplo, al reiniciar), se actualiza el selector.
    document.addEventListener('progreso-cambio', function () {
      if (!mundoActual) dibujarMundos();
    });
  }

  const Retos = {
    MUNDOS: MUNDOS,
    PREGUNTAS: PREGUNTAS,
    XP_POR_ACIERTO: XP_POR_ACIERTO,
    preguntasDeMundo: preguntasDeMundo,
    evaluarResultado: evaluarResultado,
    iniciar: iniciar
  };

  if (typeof module === 'object' && module.exports) module.exports = Retos;
  else global.Retos = Retos;
})(this);
