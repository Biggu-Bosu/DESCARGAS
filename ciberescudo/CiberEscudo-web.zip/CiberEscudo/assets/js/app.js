// CiberEscudo · app.js
// Archivo principal. Se carga al final y contiene:
//   1. Almacen: leer y guardar en localStorage sin que un error rompa la app.
//   2. Progreso: XP, nivel, racha, lecciones leídas, maestría y certificado
//      (lo único, junto con las tareas, que se guarda).
//   3. Interfaz: piezas visuales compartidas (paneles, selector de misiones,
//      animaciones de entrada, confeti).
//   4. Navegación por hash (#inicio, #retos…), hoja «Más» y botón Atrás de Android.
//   5. Pantalla de Inicio.
//   6. Certificado final.
//   7. Ajustes: sonido y compañera (se recuerdan entre visitas).

(function (global) {
  'use strict';

  // ================= 1. Almacen =================
  // localStorage puede fallar (modo privado, memoria llena), por eso todo va en try/catch.
  const Almacen = {
    leer: function (clave, valorPorDefecto) {
      try {
        const texto = global.localStorage.getItem(clave);
        if (texto === null) return valorPorDefecto;
        return JSON.parse(texto);
      } catch (error) {
        // Si el dato está dañado, se guarda una copia para no perderlo del todo.
        try {
          const dañado = global.localStorage.getItem(clave);
          if (dañado !== null) global.localStorage.setItem(clave + '.danado', dañado);
        } catch (errorCopia) {
          // No hay nada más que hacer.
        }
        return valorPorDefecto;
      }
    },
    guardar: function (clave, valor) {
      try {
        global.localStorage.setItem(clave, JSON.stringify(valor));
        return true;
      } catch (error) {
        return false;
      }
    },
    borrar: function (clave) {
      try {
        global.localStorage.removeItem(clave);
      } catch (error) {
        // Ignorar: si no se puede borrar, tampoco se podía leer.
      }
    }
  };

  // ================= 2. Progreso =================
  const CLAVE_PROGRESO = 'ciberescudo.progreso.v1';
  // Misiones de seguridad oficiales que pide el certificado (de 20).
  const TAREAS_REQUERIDAS = 5;

  // Niveles por XP. El sexto, «Maestro CiberEscudo», no se gana con XP:
  // solo con el certificado (dominar todo).
  const NIVELES = [
    { xp: 0, nombre: 'Novato digital' },
    { xp: 60, nombre: 'Explorador' },
    { xp: 150, nombre: 'Protector' },
    { xp: 280, nombre: 'Guardián' },
    { xp: 420, nombre: 'Experto' }
  ];
  const NIVEL_MAESTRO = 'Maestro CiberEscudo';

  // Las 14 lecciones de las guías (privacidad, incidentes y convivencia).
  // El id coincide con data-leccion en index.html.
  // Si agregas una lección, el certificado la pide sola (se calcula con esta lista).
  const LECCIONES = [
    { id: 'huella', nombre: 'Huella digital' },
    { id: 'redes', nombre: 'Configuración de redes sociales' },
    { id: 'consentimiento', nombre: 'Consentimiento y fotos' },
    { id: 'ingenieria', nombre: 'Ingeniería social' },
    { id: 'cuenta-robada', nombre: 'Me robaron una cuenta' },
    { id: 'datos-expuestos', nombre: 'Se expusieron mis datos' },
    { id: 'fotos-difundidas', nombre: 'Difundieron fotos sin consentimiento' },
    { id: 'conv-distinguir', nombre: '¿Broma, conflicto o acoso?' },
    { id: 'conv-ciberacoso', nombre: 'Ciberacoso y hostigamiento digital' },
    { id: 'conv-stickers', nombre: 'Stickers, memes y montajes' },
    { id: 'conv-fotos', nombre: 'Fotos, videos y consentimiento' },
    { id: 'conv-presencial', nombre: 'Bullying en la escuela' },
    { id: 'conv-limites', nombre: 'Límites, responsabilidad y reparar el daño' },
    { id: 'conv-testigo', nombre: '¿Qué hago si soy testigo?' }
  ];

  function estadoVacio() {
    return {
      version: 1,
      xp: 0,
      racha: 0,
      mejorRacha: 0,
      ultimoDia: null,
      certificado: null,
      logros: { escenario: [], reto: [], tarea: [], leccion: [] }
    };
  }

  function esFecha(texto) {
    return typeof texto === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(texto);
  }

  function numeroValido(valor) {
    return typeof valor === 'number' && isFinite(valor) && valor >= 0 ? Math.floor(valor) : 0;
  }

  // Revisa lo leído de localStorage: si algo no tiene sentido, usa el valor inicial.
  // Los datos guardados por versiones anteriores (sin lecciones ni certificado) también sirven.
  function normalizarProgreso(datos) {
    const base = estadoVacio();
    if (!datos || typeof datos !== 'object') return base;
    const logros = datos.logros && typeof datos.logros === 'object' ? datos.logros : {};
    Object.keys(base.logros).forEach(function (tipo) {
      base.logros[tipo] = Array.isArray(logros[tipo])
        ? logros[tipo].filter(function (id) {
          return typeof id === 'string';
        })
        : [];
    });
    base.xp = numeroValido(datos.xp);
    base.racha = numeroValido(datos.racha);
    base.mejorRacha = Math.max(numeroValido(datos.mejorRacha), base.racha);
    base.ultimoDia = esFecha(datos.ultimoDia) ? datos.ultimoDia : null;
    base.certificado = esFecha(datos.certificado) ? datos.certificado : null;
    return base;
  }

  // Fecha local en formato AAAA-MM-DD (la de tu celular, no la de Greenwich).
  function fechaLocal(fecha) {
    const dia = fecha || new Date();
    const mes = String(dia.getMonth() + 1).padStart(2, '0');
    const numeroDia = String(dia.getDate()).padStart(2, '0');
    return dia.getFullYear() + '-' + mes + '-' + numeroDia;
  }

  function diasEntre(desde, hasta) {
    const inicio = Date.UTC(+desde.slice(0, 4), +desde.slice(5, 7) - 1, +desde.slice(8, 10));
    const fin = Date.UTC(+hasta.slice(0, 4), +hasta.slice(5, 7) - 1, +hasta.slice(8, 10));
    return Math.round((fin - inicio) / 86400000);
  }

  // La racha "vigente": si pasó más de un día sin actividad, ya se perdió.
  function rachaVigente(estado, hoy) {
    if (!estado.ultimoDia) return 0;
    const diferencia = diasEntre(estado.ultimoDia, hoy);
    return diferencia <= 1 ? estado.racha : 0;
  }

  // Anota que hoy hubo actividad (responder un reto, un escenario o completar una tarea).
  function anotarActividad(estado, hoy) {
    const nuevo = normalizarProgreso(estado);
    if (nuevo.ultimoDia === hoy) return nuevo;
    const diferencia = nuevo.ultimoDia ? diasEntre(nuevo.ultimoDia, hoy) : null;
    if (diferencia === 1) nuevo.racha += 1;
    // Diferencia negativa: el reloj o la zona horaria del celular cambió. No se castiga.
    else if (diferencia !== null && diferencia < 0) nuevo.racha = Math.max(1, nuevo.racha);
    else nuevo.racha = 1;
    nuevo.mejorRacha = Math.max(nuevo.mejorRacha, nuevo.racha);
    nuevo.ultimoDia = hoy;
    return nuevo;
  }

  // Suma XP solo si ese logro (tipo + id) no se había ganado antes.
  function sumarLogro(estado, tipo, id, cantidad) {
    const nuevo = normalizarProgreso(estado);
    const lista = nuevo.logros[tipo];
    if (!lista || lista.includes(id)) return { estado: nuevo, ganado: 0 };
    lista.push(id);
    nuevo.xp += cantidad;
    return { estado: nuevo, ganado: cantidad };
  }

  function calcularNivel(xp, certificado) {
    if (certificado) {
      return { numero: NIVELES.length + 1, nombre: NIVEL_MAESTRO, siguiente: null, faltan: 0, porcentaje: 100, maestro: true };
    }
    let indice = 0;
    NIVELES.forEach(function (nivel, posicion) {
      if (xp >= nivel.xp) indice = posicion;
    });
    const actual = NIVELES[indice];
    const siguiente = NIVELES[indice + 1] || null;
    const porcentaje = siguiente
      ? Math.round(((xp - actual.xp) / (siguiente.xp - actual.xp)) * 100)
      : 100;
    return {
      numero: indice + 1,
      nombre: actual.nombre,
      siguiente: siguiente,
      faltan: siguiente ? siguiente.xp - xp : 0,
      porcentaje: porcentaje,
      maestro: false
    };
  }

  // XP más alto que se puede tener: el XP no crece para siempre.
  // Solo las misiones oficiales dan XP (las tareas personales no).
  function xpMaximo(contenido) {
    return contenido.retos.length * contenido.xpReto
      + contenido.escenarios.length * contenido.xpEscenario
      + contenido.misiones.length * contenido.xpMision;
  }

  // Cambia el id de un logro sin dar XP otra vez (se usa al convertir datos viejos).
  function renombrarEnEstado(estado, tipo, anterior, nuevoId) {
    const nuevo = normalizarProgreso(estado);
    const lista = nuevo.logros[tipo];
    const posicion = lista.indexOf(anterior);
    if (posicion === -1) return nuevo;
    lista.splice(posicion, 1);
    if (!lista.includes(nuevoId)) lista.push(nuevoId);
    return nuevo;
  }

  // Cuánto falta para «saber de seguridad»: retos y escenarios dominados,
  // lecciones leídas y misiones de seguridad completadas. Al 100 % se gana el certificado.
  function calcularMaestria(estado, contenido, tareasHechas) {
    function contar(tipo, ids) {
      return ids.filter(function (id) {
        return estado.logros[tipo].includes(id);
      }).length;
    }
    const partes = {
      retos: { hechos: contar('reto', contenido.retos), total: contenido.retos.length },
      escenarios: { hechos: contar('escenario', contenido.escenarios), total: contenido.escenarios.length },
      lecciones: { hechos: contar('leccion', contenido.lecciones), total: contenido.lecciones.length },
      tareas: { hechos: Math.min(tareasHechas, TAREAS_REQUERIDAS), total: TAREAS_REQUERIDAS }
    };
    let hechos = 0;
    let total = 0;
    Object.keys(partes).forEach(function (clave) {
      hechos += partes[clave].hechos;
      total += partes[clave].total;
    });
    return {
      partes: partes,
      hechos: hechos,
      total: total,
      porcentaje: total ? Math.floor((hechos / total) * 100) : 0,
      completo: total > 0 && hechos === total
    };
  }

  // Lista de ids del contenido actual (en el navegador vienen de los otros archivos).
  function contenidoActual() {
    return {
      retos: Retos.PREGUNTAS.map(function (pregunta) {
        return pregunta.id;
      }),
      escenarios: Simulador.ESCENARIOS.map(function (escenario) {
        return escenario.id;
      }),
      lecciones: LECCIONES.map(function (leccion) {
        return leccion.id;
      }),
      misiones: Tareas.MISIONES.map(function (mision) {
        return mision.id;
      }),
      xpReto: Retos.XP_POR_ACIERTO,
      xpEscenario: Simulador.XP_POR_ACIERTO,
      xpMision: Tareas.XP_POR_MISION
    };
  }

  let estadoProgreso = null;

  function guardarProgreso() {
    if (!Almacen.guardar(CLAVE_PROGRESO, estadoProgreso)) {
      Interfaz.aviso('No se pudo guardar tu progreso en este celular.');
    }
  }

  const Progreso = {
    NIVELES: NIVELES,
    NIVEL_MAESTRO: NIVEL_MAESTRO,
    LECCIONES: LECCIONES,
    TAREAS_REQUERIDAS: TAREAS_REQUERIDAS,
    estadoVacio: estadoVacio,
    normalizarProgreso: normalizarProgreso,
    fechaLocal: fechaLocal,
    diasEntre: diasEntre,
    rachaVigente: rachaVigente,
    anotarActividad: anotarActividad,
    sumarLogro: sumarLogro,
    calcularNivel: calcularNivel,
    calcularMaestria: calcularMaestria,
    xpMaximo: xpMaximo,
    renombrarEnEstado: renombrarEnEstado,

    renombrarLogro: function (tipo, anterior, nuevoId) {
      if (!estadoProgreso) Progreso.cargar();
      estadoProgreso = renombrarEnEstado(estadoProgreso, tipo, anterior, nuevoId);
      guardarProgreso();
    },

    cargar: function () {
      estadoProgreso = normalizarProgreso(Almacen.leer(CLAVE_PROGRESO, null));
      return estadoProgreso;
    },

    actual: function () {
      if (!estadoProgreso) Progreso.cargar();
      const contenido = contenidoActual();
      return {
        xp: estadoProgreso.xp,
        xpMaximo: xpMaximo(contenido),
        racha: rachaVigente(estadoProgreso, fechaLocal()),
        mejorRacha: estadoProgreso.mejorRacha,
        certificado: estadoProgreso.certificado,
        nivel: calcularNivel(estadoProgreso.xp, estadoProgreso.certificado),
        maestria: calcularMaestria(estadoProgreso, contenido, Tareas.resumen().hechas)
      };
    },

    estaDominado: function (tipo, id) {
      if (!estadoProgreso) Progreso.cargar();
      return estadoProgreso.logros[tipo].includes(id);
    },

    contarDominados: function (tipo, ids) {
      if (!estadoProgreso) Progreso.cargar();
      return ids.filter(function (id) {
        return estadoProgreso.logros[tipo].includes(id);
      }).length;
    },

    // Lo llaman el simulador, los retos y las misiones. Regresa el XP ganado (0 si ya se había ganado).
    registrarRespuesta: function (tipo, id, acerto, cantidad) {
      if (!estadoProgreso) Progreso.cargar();
      const hoy = fechaLocal();
      let nuevo = anotarActividad(estadoProgreso, hoy);
      let ganado = 0;
      if (acerto) {
        const resultado = sumarLogro(nuevo, tipo, id, cantidad);
        nuevo = resultado.estado;
        ganado = resultado.ganado;
      }
      const nivelAntes = calcularNivel(estadoProgreso.xp, estadoProgreso.certificado).numero;
      estadoProgreso = nuevo;
      guardarProgreso();
      if (ganado > 0) Interfaz.mostrarXp(ganado);
      const nivelDespues = calcularNivel(estadoProgreso.xp, estadoProgreso.certificado);
      if (nivelDespues.numero > nivelAntes) {
        Interfaz.aviso('¡Subiste a nivel ' + nivelDespues.numero + ': ' + nivelDespues.nombre + '!');
        Interfaz.confeti();
        global.setTimeout(function () {
          Mascota.efecto('nivel');
          Mascota.Companera.hablar('¡Subiste a ' + nivelDespues.nombre + '! ¡Wooo!', 'bailar');
        }, 600);
      }
      document.dispatchEvent(new CustomEvent('progreso-cambio'));
      Progreso.revisarCertificado();
      return ganado;
    },

    // Abrir una lección de las guías la marca como leída (no da XP).
    registrarLectura: function (id) {
      if (!estadoProgreso) Progreso.cargar();
      if (estadoProgreso.logros.leccion.includes(id)) return false;
      estadoProgreso.logros.leccion.push(id);
      guardarProgreso();
      document.dispatchEvent(new CustomEvent('progreso-cambio'));
      Progreso.revisarCertificado();
      return true;
    },

    // Si ya se dominó todo, se entrega el certificado (una sola vez, con la fecha).
    revisarCertificado: function () {
      if (!estadoProgreso || estadoProgreso.certificado) return false;
      const maestria = calcularMaestria(estadoProgreso, contenidoActual(), Tareas.resumen().hechas);
      if (!maestria.completo) return false;
      estadoProgreso.certificado = fechaLocal();
      guardarProgreso();
      Interfaz.aviso('¡Desbloqueaste tu Certificado CiberEscudo! Ve a «Más → Certificado».');
      Interfaz.confeti();
      Mascota.efecto('nivel');
      document.dispatchEvent(new CustomEvent('progreso-cambio'));
      return true;
    },

    reiniciar: function () {
      estadoProgreso = estadoVacio();
      Almacen.borrar(CLAVE_PROGRESO);
      document.dispatchEvent(new CustomEvent('progreso-cambio'));
    }
  };

  // ================= 3. Interfaz =================
  function crear(etiqueta, clase, texto) {
    const elemento = document.createElement(etiqueta);
    if (clase) elemento.className = clase;
    if (texto !== undefined) elemento.textContent = texto;
    return elemento;
  }

  let temporizadorAviso = null;

  // Elementos que entran escalonados (uno tras otro) cuando aparece una pantalla.
  const SELECTOR_ANIMABLES = '.tarjeta, .atajo, .acordeon, .mision, .chat, .opcion, .requisito, .certificado, .tarea, .ayuda';

  const COLORES_ICONO = {
    cian: 'var(--cian)', rosa: 'var(--rosa)', amarillo: 'var(--amarillo)',
    verde: 'var(--verde)', rojo: 'var(--rojo)', naranja: 'var(--naranja)'
  };

  const Interfaz = {
    crear: crear,

    movimientoReducido: function () {
      return !!(global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches);
    },

    // Texto que solo escuchan los lectores de pantalla.
    anunciar: function (texto) {
      const region = document.getElementById('anuncios');
      if (!region) return;
      region.textContent = '';
      global.setTimeout(function () {
        region.textContent = texto;
      }, 50);
    },

    // Mensaje corto que aparece arriba unos segundos.
    aviso: function (texto) {
      const caja = document.getElementById('aviso');
      if (!caja) return;
      caja.textContent = texto;
      caja.hidden = false;
      caja.classList.remove('aviso--visible');
      void caja.offsetWidth;
      caja.classList.add('aviso--visible');
      global.clearTimeout(temporizadorAviso);
      temporizadorAviso = global.setTimeout(function () {
        caja.hidden = true;
      }, 3600);
    },

    // "+10 XP" que sube y desaparece, y el marcador de arriba da un brinco.
    mostrarXp: function (cantidad) {
      const capa = document.getElementById('capa-xp');
      if (capa) {
        const etiqueta = crear('span', 'xp-flotante', '+' + cantidad + ' XP');
        etiqueta.setAttribute('aria-hidden', 'true');
        capa.appendChild(etiqueta);
        global.setTimeout(function () {
          etiqueta.remove();
        }, 1400);
      }
      global.setTimeout(function () {
        Mascota.efecto('moneda');
      }, 260);
      const marcador = document.querySelector('.hud__dato--xp');
      if (marcador) {
        marcador.classList.remove('hud__dato--brinca');
        void marcador.offsetWidth;
        marcador.classList.add('hud__dato--brinca');
      }
      Interfaz.anunciar('Ganaste ' + cantidad + ' puntos de experiencia');
    },

    // Lluvia de cuadritos de colores (pixel art). Se borra sola.
    confeti: function () {
      if (Interfaz.movimientoReducido()) return;
      const capa = document.getElementById('capa-confeti');
      if (!capa) return;
      const colores = ['var(--rosa)', 'var(--cian)', 'var(--amarillo)', 'var(--verde)'];
      for (let numero = 0; numero < 36; numero += 1) {
        const cuadro = crear('span', 'confeti');
        cuadro.style.left = Math.round(Math.random() * 100) + '%';
        cuadro.style.background = colores[numero % colores.length];
        cuadro.style.animationDelay = Math.round(Math.random() * 400) + 'ms';
        cuadro.style.setProperty('--caida', (60 + Math.round(Math.random() * 40)) + 'vh');
        cuadro.style.setProperty('--giro', (Math.random() > 0.5 ? 1 : -1) * (90 + Math.round(Math.random() * 270)) + 'deg');
        capa.appendChild(cuadro);
        global.setTimeout(function () {
          cuadro.remove();
        }, 2200);
      }
    },

    // Hace que los elementos de un bloque aparezcan uno tras otro.
    animarEntrada: function (bloque) {
      if (!bloque || Interfaz.movimientoReducido()) return;
      const elementos = bloque.querySelectorAll(SELECTOR_ANIMABLES);
      elementos.forEach(function (elemento, indice) {
        elemento.style.setProperty('--orden', String(Math.min(indice, 10)));
        elemento.classList.remove('entra');
        void elemento.offsetWidth;
        elemento.classList.add('entra');
      });
    },

    // Barra de arriba dentro de un juego: botón para volver y nombre del mundo o paquete.
    barraJuego: function (titulo, alVolver) {
      const barra = crear('div', 'barra-juego');
      const volver = crear('button', 'boton boton--chico', '← Volver');
      volver.type = 'button';
      volver.addEventListener('click', function () {
        alVolver();
        Interfaz.subirAlInicio(barra.parentElement || barra);
      });
      barra.appendChild(volver);
      barra.appendChild(crear('span', 'barra-juego__titulo', titulo));
      return barra;
    },

    // Tarjetas para elegir un mundo (retos) o un paquete (simulador).
    selectorMisiones: function (opciones) {
      const lista = crear('div', 'misiones');
      let grupoAnterior = null;
      opciones.misiones.forEach(function (mision) {
        // Si las misiones vienen por grupos (por ejemplo «Seguridad digital» y «Convivencia»),
        // se pone un subtítulo cada vez que empieza un grupo.
        if (mision.grupo && mision.grupo !== grupoAnterior) {
          lista.appendChild(crear('h3', 'subtitulo-chico misiones__grupo', mision.grupo));
          grupoAnterior = mision.grupo;
        }
        const dominados = Progreso.contarDominados(opciones.tipo, mision.ids);
        const total = mision.ids.length;
        const completa = dominados === total;
        const boton = crear('button', 'mision' + (completa ? ' mision--completa' : ''));
        boton.type = 'button';
        boton.style.setProperty('--color', COLORES_ICONO[mision.color] || 'var(--cian)');
        const cabeza = crear('span', 'mision__cabeza');
        const icono = crear('span', 'mision__icono');
        icono.appendChild(Mascota.icono(mision.icono));
        cabeza.appendChild(icono);
        cabeza.appendChild(crear('span', 'mision__nombre', mision.nombre));
        if (completa) cabeza.appendChild(crear('span', 'mision__sello', 'Dominado'));
        boton.appendChild(cabeza);
        boton.appendChild(crear('span', 'mision__texto', mision.descripcion));
        const barra = crear('span', 'barra');
        barra.setAttribute('aria-hidden', 'true');
        const relleno = crear('span', 'barra__relleno');
        relleno.style.width = Math.round((dominados / total) * 100) + '%';
        barra.appendChild(relleno);
        boton.appendChild(barra);
        boton.appendChild(crear('span', 'mision__cuenta', dominados + ' / ' + total + ' ' + mision.unidad));
        boton.setAttribute('aria-label', mision.nombre + '. ' + dominados + ' de ' + total + ' ' + mision.unidad + (completa ? '. Dominado' : ''));
        boton.addEventListener('click', function () {
          opciones.alElegir(mision.id);
        });
        lista.appendChild(boton);
      });
      return lista;
    },

    barraProgreso: function (indice, total, nombre) {
      const bloque = crear('div', 'progreso-juego');
      bloque.appendChild(crear('span', 'progreso-juego__texto', nombre + ' ' + (indice + 1) + ' de ' + total));
      const barra = crear('div', 'barra');
      barra.setAttribute('role', 'progressbar');
      barra.setAttribute('aria-label', 'Avance');
      barra.setAttribute('aria-valuemin', '0');
      barra.setAttribute('aria-valuemax', String(total));
      barra.setAttribute('aria-valuenow', String(indice));
      const relleno = crear('span', 'barra__relleno');
      relleno.style.width = Math.round((indice / total) * 100) + '%';
      barra.appendChild(relleno);
      bloque.appendChild(barra);
      return bloque;
    },

    // Panel que aparece después de responder (acierto o error).
    panelRetro: function (opciones) {
      const panel = crear('section', 'retro ' + (opciones.acerto ? 'retro--bien' : 'retro--mal'));
      panel.setAttribute('aria-labelledby', 'retro-titulo');
      const cabecera = crear('div', 'retro__cabecera');
      const mascota = Mascota.crear(cabecera, { tamano: 'mini', titulo: '' });
      const textos = crear('div', 'retro__textos');
      const titulo = crear('h3', 'retro__titulo', opciones.acerto
        ? (opciones.tituloBien || '¡Bien hecho!')
        : (opciones.tituloMal || 'Ups, era una trampa'));
      titulo.id = 'retro-titulo';
      titulo.tabIndex = -1;
      textos.appendChild(titulo);
      let textoXp = '';
      if (opciones.acerto && opciones.xpGanado > 0) textoXp = '+' + opciones.xpGanado + ' XP';
      else if (opciones.acerto) textoXp = 'Repaso: estos ' + opciones.xpPosible + ' XP ya los habías ganado';
      if (textoXp) textos.appendChild(crear('p', 'retro__xp', textoXp));
      cabecera.appendChild(textos);
      panel.appendChild(cabecera);

      panel.appendChild(crear('p', 'retro__mensaje', opciones.mensaje));
      panel.appendChild(crear('p', 'retro__explicacion', opciones.explicacion));

      // Si elegiste otra, se muestra cuál era la opción más segura y por qué.
      if (opciones.correcta) {
        panel.appendChild(crear('h4', 'retro__subtitulo', 'La opción más segura'));
        const segura = crear('div', 'retro__segura');
        segura.appendChild(crear('p', 'retro__segura-texto', opciones.correcta.texto));
        segura.appendChild(crear('p', '', opciones.correcta.retro));
        panel.appendChild(segura);
      }

      if (opciones.senales && opciones.senales.length) {
        panel.appendChild(crear('h4', 'retro__subtitulo', 'Señales de alerta'));
        const lista = crear('ul', 'lista-senales');
        opciones.senales.forEach(function (senal) {
          lista.appendChild(crear('li', '', senal));
        });
        panel.appendChild(lista);
      }

      // Por qué las otras opciones pueden empeorar el problema.
      if (opciones.otras && opciones.otras.length) {
        panel.appendChild(crear('h4', 'retro__subtitulo', 'Por qué las otras opciones no ayudan'));
        const lista = crear('ul', 'lista-otras');
        opciones.otras.forEach(function (opcion) {
          const elemento = crear('li');
          elemento.appendChild(crear('span', 'lista-otras__opcion', '«' + opcion.texto + '»'));
          elemento.appendChild(document.createTextNode(' ' + opcion.retro));
          lista.appendChild(elemento);
        });
        panel.appendChild(lista);
      }

      if (opciones.recomendacion) {
        const consejo = crear('div', 'retro__bloque retro__bloque--consejo');
        consejo.appendChild(crear('h4', 'retro__subtitulo', 'Recomendación'));
        consejo.appendChild(crear('p', '', opciones.recomendacion));
        panel.appendChild(consejo);
      }

      if (opciones.ayuda) {
        const ayuda = crear('div', 'retro__bloque retro__bloque--ayuda');
        ayuda.appendChild(crear('h4', 'retro__subtitulo', '¿Cuándo pedir ayuda?'));
        ayuda.appendChild(crear('p', '', opciones.ayuda));
        panel.appendChild(ayuda);
      }

      const boton = crear('button', 'boton boton--primario boton--ancho', opciones.textoBoton);
      boton.type = 'button';
      boton.addEventListener('click', opciones.alContinuar);
      panel.appendChild(boton);

      // En los temas delicados la flor reacciona con calma: sin festejo, sin lágrimas ni sonido de error.
      let reaccionMini = opciones.acerto ? 'feliz' : 'triste';
      if (opciones.calma) {
        reaccionMini = 'hablar';
        Mascota.Companera.hablar(opciones.acerto
          ? 'Gracias por cuidarla. Eso es lo correcto.'
          : 'Respira. Lo importante es no difundirlo y pedir ayuda.', 'hablar');
      } else {
        Mascota.efecto(opciones.acerto ? 'acierto' : 'error');
        Mascota.Companera.reaccionar(opciones.acerto);
      }
      global.setTimeout(function () {
        Mascota.reaccionar(mascota, reaccionMini);
        titulo.focus({ preventScroll: true });
        panel.scrollIntoView({ behavior: Interfaz.movimientoReducido() ? 'auto' : 'smooth', block: 'start' });
      }, 30);
      return panel;
    },

    // Pantalla final de un mundo de retos o de un paquete del simulador.
    panelResultados: function (opciones) {
      const proporcion = opciones.total ? opciones.aciertos / opciones.total : 0;
      let estado = opciones.estado;
      let mensaje = opciones.mensaje;
      if (!estado) {
        if (proporcion >= 0.85) {
          estado = 'feliz';
          mensaje = '¡Excelente! Detectaste casi todas las trampas.';
        } else if (proporcion >= 0.5) {
          estado = 'hablar';
          mensaje = 'Vas bien. Repasa las señales de alerta de las que fallaste.';
        } else {
          estado = 'triste';
          mensaje = 'Estas trampas engañan a mucha gente. Inténtalo otra vez, ya sabes más que antes.';
        }
      }

      const panel = crear('section', 'resultados');
      panel.setAttribute('aria-labelledby', 'resultados-titulo');
      const titulo = crear('h3', 'resultados__titulo', opciones.titulo);
      titulo.id = 'resultados-titulo';
      titulo.tabIndex = -1;
      panel.appendChild(titulo);

      const escena = crear('div', 'resultados__escena');
      const mascota = Mascota.crear(escena, { tamano: 'mediana' });
      escena.appendChild(crear('p', 'globo', mensaje));
      panel.appendChild(escena);

      const marcador = crear('p', 'resultados__marcador');
      marcador.appendChild(crear('strong', '', opciones.aciertos + ' / ' + opciones.total));
      marcador.appendChild(document.createTextNode(' respuestas correctas'));
      panel.appendChild(marcador);
      if (opciones.detalle) panel.appendChild(crear('p', 'resultados__detalle', opciones.detalle));

      const progreso = Progreso.actual();
      panel.appendChild(crear('p', 'resultados__xp',
        progreso.xp + ' de ' + progreso.xpMaximo + ' XP · ' + progreso.nivel.nombre + ' · Maestría ' + progreso.maestria.porcentaje + ' %'));

      const acciones = crear('div', 'acciones');
      const repetir = crear('button', 'boton', opciones.textoRepetir);
      repetir.type = 'button';
      repetir.addEventListener('click', opciones.alRepetir);
      acciones.appendChild(repetir);
      if (opciones.alVolver) {
        const volver = crear('button', 'boton boton--primario', opciones.textoVolver);
        volver.type = 'button';
        volver.addEventListener('click', opciones.alVolver);
        acciones.appendChild(volver);
      }
      panel.appendChild(acciones);

      global.setTimeout(function () {
        Mascota.reaccionar(mascota, estado);
        if (opciones.celebrar) Interfaz.confeti();
        titulo.focus({ preventScroll: true });
      }, 30);
      return panel;
    },

    subirAlInicio: function (elemento) {
      const vista = elemento.closest('.vista') || elemento;
      const cabecera = document.querySelector('.cabecera');
      const alto = cabecera ? cabecera.offsetHeight : 0;
      const destino = vista.getBoundingClientRect().top + global.scrollY - alto;
      global.scrollTo({ top: Math.max(0, destino), behavior: 'auto' });
    }
  };

  // ================= 4. Navegación =================
  const VISTAS = {
    inicio: 'Inicio',
    verificador: 'Verificador de contraseñas',
    privacidad: 'Guía de privacidad',
    convivencia: 'Laboratorio de convivencia',
    simulador: 'Simulador',
    retos: 'Retos',
    tareas: 'Plan de acción',
    incidentes: 'Guía de incidentes',
    certificado: 'Certificado'
  };

  // Secciones que en el celular viven dentro de la hoja «Más».
  const VISTAS_EN_MAS = ['verificador', 'privacidad', 'incidentes', 'certificado'];

  let vistaActual = null;

  function vistaDesdeHash() {
    const nombre = (global.location.hash || '').replace('#', '');
    return Object.prototype.hasOwnProperty.call(VISTAS, nombre) ? nombre : null;
  }

  function mostrarVista(nombre, enfocar) {
    if (vistaActual === 'verificador' && nombre !== 'verificador') Verificador.limpiar();
    if (vistaActual === 'inicio' && nombre !== 'inicio') Inicio.alSalir();
    if (vistaActual === 'certificado' && nombre !== 'certificado') Certificado.alSalir();
    cerrarHojaMas();

    Object.keys(VISTAS).forEach(function (clave) {
      const seccion = document.getElementById('vista-' + clave);
      if (seccion) seccion.hidden = clave !== nombre;
    });
    document.querySelectorAll('.barra-nav a, .hoja-mas a').forEach(function (enlace) {
      if (enlace.getAttribute('href') === '#' + nombre) enlace.setAttribute('aria-current', 'page');
      else enlace.removeAttribute('aria-current');
    });
    const botonMas = document.getElementById('boton-mas');
    if (botonMas) botonMas.classList.toggle('activo', VISTAS_EN_MAS.includes(nombre));
    document.title = VISTAS[nombre] + ' · CiberEscudo';
    global.scrollTo(0, 0);

    const anterior = vistaActual;
    vistaActual = nombre;
    if (nombre === 'inicio') Inicio.alEntrar(anterior !== null);
    if (nombre === 'certificado') Certificado.actualizar();
    // En Inicio y en el certificado está la flor grande; en lo demás te acompaña la florecita.
    if (nombre === 'inicio' || nombre === 'certificado') Mascota.Companera.ocultar();
    else Mascota.Companera.mostrar(nombre);

    // Animación de entrada: la sección aparece con un pequeño glitch
    // y sus tarjetas entran una tras otra.
    const seccion = document.getElementById('vista-' + nombre);
    if (seccion && !Interfaz.movimientoReducido()) {
      seccion.classList.remove('vista--entrando');
      void seccion.offsetWidth;
      seccion.classList.add('vista--entrando');
      Interfaz.animarEntrada(seccion);
    }

    if (enfocar) {
      const titulo = document.querySelector('#vista-' + nombre + ' h2');
      if (titulo) titulo.focus({ preventScroll: true });
    }
  }

  function alCambiarHash() {
    const nombre = vistaDesdeHash();
    if (!nombre) {
      global.history.replaceState(null, '', '#inicio');
      mostrarVista('inicio', false);
      return;
    }
    mostrarVista(nombre, true);
  }

  // ---- Hoja «Más» (sube desde abajo) ----
  function hojaMas() {
    return document.getElementById('hoja-mas');
  }

  function hojaAbierta() {
    const hoja = hojaMas();
    return !!(hoja && hoja.open);
  }

  function abrirHojaMas() {
    const hoja = hojaMas();
    if (!hoja || hoja.open) return;
    if (typeof hoja.showModal === 'function') hoja.showModal();
    else hoja.setAttribute('open', '');
    document.getElementById('boton-mas').setAttribute('aria-expanded', 'true');
    Interfaz.animarEntrada(hoja);
  }

  function cerrarHojaMas() {
    const hoja = hojaMas();
    if (!hoja || !hoja.open) return;
    if (typeof hoja.close === 'function') hoja.close();
    else hoja.removeAttribute('open');
  }

  function prepararHojaMas() {
    const hoja = hojaMas();
    const boton = document.getElementById('boton-mas');
    if (!hoja || !boton) return;
    boton.addEventListener('click', abrirHojaMas);
    document.getElementById('cerrar-hoja-mas').addEventListener('click', cerrarHojaMas);
    // Tocar fuera del panel (en el fondo oscuro) la cierra.
    hoja.addEventListener('click', function (evento) {
      if (evento.target === hoja) cerrarHojaMas();
    });
    hoja.addEventListener('close', function () {
      boton.setAttribute('aria-expanded', 'false');
      boton.focus({ preventScroll: true });
    });
    // Un enlace al hash en el que ya estás no cambia nada: solo cierra.
    hoja.querySelectorAll('a').forEach(function (enlace) {
      enlace.addEventListener('click', function () {
        if (enlace.getAttribute('href') === '#' + vistaActual) cerrarHojaMas();
      });
    });
  }

  // Botón Atrás de Android (solo dentro de la app instalada con Capacitor).
  function complementoApp() {
    const capacitor = global.Capacitor;
    if (!capacitor || !capacitor.isNativePlatform || !capacitor.isNativePlatform()) return null;
    return capacitor.Plugins && capacitor.Plugins.App ? capacitor.Plugins.App : null;
  }

  function prepararBotonAtras() {
    const app = complementoApp();
    if (!app) return;
    app.addListener('backButton', function (evento) {
      if (hojaAbierta()) {
        cerrarHojaMas();
      } else if (vistaActual !== 'inicio') {
        if (evento && evento.canGoBack) global.history.back();
        else global.location.hash = '#inicio';
      } else {
        app.exitApp();
      }
    });
  }

  // La versión web (iPhone, Vercel) funciona sin internet gracias al service worker.
  // Dentro de la app de Android o abriendo el archivo directo no hace falta.
  function registrarServiceWorker() {
    const esWeb = global.location.protocol === 'https:' || global.location.hostname === 'localhost';
    const esNativa = !!complementoApp() || (global.Capacitor && global.Capacitor.isNativePlatform && global.Capacitor.isNativePlatform());
    if (!('serviceWorker' in navigator) || !esWeb || esNativa) return;
    navigator.serviceWorker.register('sw.js').catch(function () {
      // Sin service worker la app funciona igual, solo necesita internet la primera vez.
    });
  }

  // Con el teclado abierto se esconde la barra de abajo para que no tape el campo.
  function prepararTeclado() {
    document.addEventListener('focusin', function (evento) {
      if (evento.target.matches('input[type="text"], input[type="password"], textarea')) {
        document.body.classList.add('teclado-abierto');
      }
    });
    document.addEventListener('focusout', function () {
      global.setTimeout(function () {
        const activo = document.activeElement;
        if (!activo || !activo.matches('input[type="text"], input[type="password"], textarea')) {
          document.body.classList.remove('teclado-abierto');
        }
      }, 100);
    });
  }

  // Las lecciones están en Privacidad, Convivencia e Incidentes: lleva a la primera que tenga una sin leer.
  function seccionConLeccionPendiente() {
    const pendiente = document.querySelector('details[data-leccion]:not(.acordeon--leido)');
    const vista = pendiente && pendiente.closest('.vista');
    return vista ? '#' + vista.id.replace('vista-', '') : '#privacidad';
  }

  // Lecciones: abrir un acordeón de las guías la marca como leída.
  function prepararLecciones() {
    document.querySelectorAll('details[data-leccion]').forEach(function (detalle) {
      detalle.addEventListener('toggle', function () {
        if (detalle.open && Progreso.registrarLectura(detalle.dataset.leccion)) {
          Interfaz.anunciar('Lección leída');
        }
      });
    });
    marcarLecciones();
    document.addEventListener('progreso-cambio', marcarLecciones);
  }

  function marcarLecciones() {
    document.querySelectorAll('details[data-leccion]').forEach(function (detalle) {
      const leida = Progreso.estaDominado('leccion', detalle.dataset.leccion);
      detalle.classList.toggle('acordeon--leido', leida);
      let sello = detalle.querySelector('.sello-leido');
      if (leida && !sello) {
        sello = crear('span', 'sello-leido', 'Leído');
        detalle.querySelector('summary').appendChild(sello);
      } else if (!leida && sello) {
        sello.remove();
      }
    });
  }

  // ================= 5. Inicio =================
  let ultimoXpVisto = null;
  let mascotaInicio = null;

  const Inicio = {
    iniciar: function () {
      const boton = document.getElementById('mascota-inicio');
      const globo = document.getElementById('globo-inicio');
      mascotaInicio = Mascota.crear(boton, { tamano: 'grande', titulo: '' });
      const diaDelAno = Math.floor(Date.now() / 86400000);
      globo.textContent = Mascota.FRASES_INICIO[diaDelAno % Mascota.FRASES_INICIO.length];

      // Tocar la flor: canta la siguiente canción y da un consejo.
      // Tocarla mientras suena, la calla.
      boton.addEventListener('click', function () {
        if (Mascota.estaSonando()) {
          Mascota.detenerCancion();
          return;
        }
        const cancion = Mascota.tocarCancion(function () {
          Mascota.cantar(mascotaInicio, 0);
          boton.setAttribute('aria-pressed', 'false');
        });
        const consejo = Mascota.elegirAlAzar(Mascota.CONSEJOS);
        if (cancion) {
          Mascota.cantar(mascotaInicio, cancion.pulso || cancion.tempo);
          boton.setAttribute('aria-pressed', 'true');
          Mascota.decir(mascotaInicio, globo, '♪ «' + cancion.nombre + '» · ' + consejo, 'feliz');
        } else {
          Mascota.decir(mascotaInicio, globo, consejo + ' (El sonido está apagado: actívalo en «Más».)', 'feliz');
        }
      });

      document.getElementById('boton-reiniciar').addEventListener('click', function () {
        const seguro = global.confirm('¿Reiniciar tu XP, tu racha, tu maestría y tu certificado? Tus tareas no se borran.');
        if (!seguro) return;
        Progreso.reiniciar();
        ultimoXpVisto = 0;
        Interfaz.aviso('Progreso reiniciado.');
      });

      document.addEventListener('progreso-cambio', Inicio.actualizar);
      document.addEventListener('tareas-cambio', function () {
        Inicio.actualizar();
        Progreso.revisarCertificado();
      });
      Inicio.actualizar();
    },

    actualizar: function () {
      const progreso = Progreso.actual();
      const tareas = Tareas.resumen();
      const maestria = progreso.maestria;
      document.querySelectorAll('[data-dato="xp"]').forEach(function (lugar) {
        lugar.textContent = progreso.xp;
      });
      document.querySelectorAll('[data-dato="racha"]').forEach(function (lugar) {
        lugar.textContent = progreso.racha;
      });
      document.getElementById('xp-maximo').textContent = 'de ' + progreso.xpMaximo;
      document.getElementById('nivel-nombre').textContent = progreso.nivel.maestro
        ? 'Rango máximo: ' + progreso.nivel.nombre
        : 'Nivel ' + progreso.nivel.numero + ': ' + progreso.nivel.nombre;
      let textoFaltan;
      if (progreso.nivel.maestro) textoFaltan = '¡Dominaste CiberEscudo! Ahora todo es repaso.';
      else if (progreso.nivel.siguiente) textoFaltan = 'Te faltan ' + progreso.nivel.faltan + ' XP para «' + progreso.nivel.siguiente.nombre + '»';
      else textoFaltan = 'Domina todo para ser «' + Progreso.NIVEL_MAESTRO + '».';
      document.getElementById('nivel-faltan').textContent = textoFaltan;
      const barra = document.getElementById('barra-nivel');
      barra.style.width = progreso.nivel.porcentaje + '%';
      barra.parentElement.setAttribute('aria-valuenow', String(progreso.nivel.porcentaje));

      document.getElementById('racha-texto').textContent = progreso.racha === 0
        ? 'Completa un reto hoy para empezar tu racha.'
        : (progreso.racha === 1 ? '1 día seguido' : progreso.racha + ' días seguidos') + ' · récord: ' + progreso.mejorRacha;
      document.getElementById('tareas-resumen').textContent = 'Misiones: ' + tareas.hechas + ' de ' + tareas.total
        + (tareas.personales ? ' · Personales: ' + tareas.personalesHechas + ' de ' + tareas.personales : '');

      document.getElementById('maestria-porcentaje').textContent = maestria.porcentaje;
      const barraMaestria = document.getElementById('barra-maestria');
      barraMaestria.style.width = maestria.porcentaje + '%';
      barraMaestria.parentElement.setAttribute('aria-valuenow', String(maestria.porcentaje));
      // Quien ganó el certificado antes de que llegara Convivencia lo conserva,
      // pero se le avisa que hay contenido nuevo.
      const contenidoNuevo = progreso.certificado && maestria.porcentaje < 100
        ? ' Hay contenido nuevo de convivencia: llevas ' + maestria.porcentaje + ' %.'
        : '';
      document.getElementById('maestria-detalle').textContent = progreso.certificado
        ? '¡Certificado obtenido! Eres ' + Progreso.NIVEL_MAESTRO + '.' + contenidoNuevo
        : 'Retos ' + maestria.partes.retos.hechos + '/' + maestria.partes.retos.total
          + ' · Escenarios ' + maestria.partes.escenarios.hechos + '/' + maestria.partes.escenarios.total
          + ' · Lecciones ' + maestria.partes.lecciones.hechos + '/' + maestria.partes.lecciones.total
          + ' · Misiones ' + maestria.partes.tareas.hechos + '/' + maestria.partes.tareas.total;
      document.getElementById('tarjeta-maestria').classList.toggle('tarjeta--lograda', !!progreso.certificado);
    },

    // Al volver a Inicio, si ganaste XP desde la última vez, la mascota celebra.
    alEntrar: function (vieneDeOtraVista) {
      const progreso = Progreso.actual();
      const globo = document.getElementById('globo-inicio');
      if (vieneDeOtraVista && ultimoXpVisto !== null && progreso.xp > ultimoXpVisto) {
        Mascota.decir(mascotaInicio, globo, '¡Ganaste ' + (progreso.xp - ultimoXpVisto) + ' XP! Ya llevas ' + progreso.xp + '. ¡Sigue así!', 'feliz');
      } else if (mascotaInicio) {
        Mascota.reaccionar(mascotaInicio, 'hablar');
      }
      ultimoXpVisto = progreso.xp;
      // En Inicio la flor siempre "canta" en silencio.
      if (mascotaInicio && !Mascota.estaSonando()) Mascota.cantar(mascotaInicio, 0);
    },

    // Al salir de Inicio se apaga la música y la flor deja de cantar (ahorra batería).
    alSalir: function () {
      Mascota.detenerCancion();
      Mascota.dejarDeCantar(mascotaInicio);
      const boton = document.getElementById('mascota-inicio');
      if (boton) boton.setAttribute('aria-pressed', 'false');
    }
  };

  // ================= 6. Certificado =================
  // El nombre que escribes en el certificado NO se guarda: solo se muestra
  // mientras estás en esta pantalla (para tomar una captura).
  let mascotaCertificado = null;

  function formatoFecha(fecha) {
    const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    return Number(fecha.slice(8, 10)) + ' de ' + meses[Number(fecha.slice(5, 7)) - 1] + ' de ' + fecha.slice(0, 4);
  }

  const Certificado = {
    iniciar: function () {
      const campo = document.getElementById('nombre-certificado');
      campo.addEventListener('input', function () {
        const nombre = campo.value.replace(/\s+/g, ' ').trim();
        document.getElementById('certificado-nombre').textContent = nombre || 'Agente CiberEscudo';
      });
      document.getElementById('boton-celebrar').addEventListener('click', function () {
        Interfaz.confeti();
        const cancion = Mascota.tocarCancion(function () {
          Mascota.cantar(mascotaCertificado, 0);
        });
        if (cancion) Mascota.cantar(mascotaCertificado, cancion.pulso || cancion.tempo);
        Mascota.reaccionar(mascotaCertificado, 'feliz');
      });
      document.addEventListener('progreso-cambio', function () {
        if (vistaActual === 'certificado') Certificado.actualizar();
      });
    },

    actualizar: function () {
      const progreso = Progreso.actual();
      const obtenido = !!progreso.certificado;
      document.getElementById('certificado-bloqueado').hidden = obtenido;
      document.getElementById('certificado-obtenido').hidden = !obtenido;

      if (obtenido) {
        document.getElementById('certificado-fecha').textContent = 'Obtenido el ' + formatoFecha(progreso.certificado);
        // El texto dice lo que de verdad dominaste: si lo ganaste antes de Convivencia,
        // no presume ese contenido y te avisa que puedes completarlo.
        const completo = progreso.maestria.completo;
        const partesHechas = progreso.maestria.partes;
        document.getElementById('certificado-logros').textContent = completo
          ? 'por dominar ' + partesHechas.retos.total + ' retos, ' + partesHechas.escenarios.total + ' escenarios, '
            + partesHechas.lecciones.total + ' lecciones y ' + partesHechas.tareas.total
            + ' misiones de seguridad digital y convivencia.'
          : 'por dominar el contenido de seguridad digital de CiberEscudo.';
        document.getElementById('certificado-nuevo').hidden = completo;
        document.getElementById('certificado-nuevo-texto').textContent =
          'Llevas ' + progreso.maestria.porcentaje + ' % de maestría. Complétalo para sumarlo a tu certificado.';
        const lugar = document.getElementById('mascota-certificado');
        if (!mascotaCertificado) mascotaCertificado = Mascota.crear(lugar, { tamano: 'mediana', titulo: '' });
        Mascota.cantar(mascotaCertificado, 0);
        return;
      }

      const partes = progreso.maestria.partes;
      document.getElementById('certificado-porcentaje').textContent = progreso.maestria.porcentaje + ' %';
      const requisitos = [
        { nombre: 'Retos dominados', parte: partes.retos, destino: '#retos', icono: 'estrella' },
        { nombre: 'Escenarios dominados', parte: partes.escenarios, destino: '#simulador', icono: 'chat' },
        { nombre: 'Lecciones leídas', parte: partes.lecciones, destino: seccionConLeccionPendiente(), icono: 'ojo' },
        { nombre: 'Misiones de seguridad', parte: partes.tareas, destino: '#tareas', icono: 'lista' }
      ];
      const lista = document.getElementById('lista-requisitos');
      lista.textContent = '';
      requisitos.forEach(function (requisito) {
        const listo = requisito.parte.hechos === requisito.parte.total;
        const elemento = crear('li', 'requisito' + (listo ? ' requisito--listo' : ''));
        const enlace = crear('a', 'requisito__enlace');
        enlace.href = requisito.destino;
        const icono = crear('span', 'requisito__icono');
        icono.appendChild(Mascota.icono(listo ? 'palomita' : requisito.icono));
        enlace.appendChild(icono);
        const textos = crear('span', 'requisito__textos');
        textos.appendChild(crear('span', 'requisito__nombre', requisito.nombre));
        const barra = crear('span', 'barra');
        barra.setAttribute('aria-hidden', 'true');
        const relleno = crear('span', 'barra__relleno');
        relleno.style.width = Math.round((requisito.parte.hechos / requisito.parte.total) * 100) + '%';
        barra.appendChild(relleno);
        textos.appendChild(barra);
        enlace.appendChild(textos);
        enlace.appendChild(crear('span', 'requisito__cuenta', requisito.parte.hechos + '/' + requisito.parte.total));
        enlace.setAttribute('aria-label', requisito.nombre + ': ' + requisito.parte.hechos + ' de ' + requisito.parte.total + (listo ? ', completo' : ''));
        elemento.appendChild(enlace);
        lista.appendChild(elemento);
      });
    },

    alSalir: function () {
      const campo = document.getElementById('nombre-certificado');
      campo.value = '';
      document.getElementById('certificado-nombre').textContent = 'Agente CiberEscudo';
      Mascota.detenerCancion();
      Mascota.dejarDeCantar(mascotaCertificado);
    }
  };

  // ================= 6b. Lo que la florecita reconoce de la página =================
  // Cada objeto tiene un selector CSS y una función que dice cómo se llama y qué comentar.
  // La flor solo dice la frase (algo relacionado con lo que pisa); el nombre sirve para depurar.
  // alerta: true hace que la flor dé un respingo y muestre un «!» al comentarlo.
  // El orden importa: va primero lo más específico (un enlace falso antes que el mensaje).
  function textoDe(elemento, selector) {
    const parte = selector ? elemento.querySelector(selector) : elemento;
    return parte ? parte.textContent.replace(/\s+/g, ' ').trim() : '';
  }

  // Elige una frase al azar para que no repita siempre lo mismo.
  function unaDe(frases) {
    return frases[Math.floor(Math.random() * frases.length)];
  }

  const OBJETOS_DE_LA_PAGINA = [
    { selector: '.enlace-falso', describir: function () {
      return { nombre: 'un enlace falso', alerta: true, frase: unaDe([
        '¡No lo toques! Fíjate en la dirección rara.',
        'Ese enlace no es del sitio oficial. ¿Lo notaste?'
      ]) };
    } },
    { selector: '.chat', describir: function () {
      return { nombre: 'el mensaje', alerta: true, frase: unaDe([
        'Mmm… ¿tiene prisa o pide datos? Sospechoso.',
        '¿Quién lo manda de verdad? Revisa el nombre y el enlace.',
        'Si te mete miedo para que actúes rápido, es mala señal.'
      ]) };
    } },
    { selector: '.opcion', describir: function (elemento) {
      // En los retos la letra está escrita; en el simulador se calcula por su lugar.
      const hermanas = Array.prototype.slice.call(elemento.parentElement.querySelectorAll(':scope > .opcion'));
      const letra = textoDe(elemento, '.opcion__letra') || 'ABCDEF'.charAt(hermanas.indexOf(elemento));
      const nombre = letra ? 'la opción ' + letra : 'una opción';
      if (elemento.classList.contains('opcion--correcta')) {
        return { nombre: nombre, frase: unaDe(['¡Esta era la buena!', 'Esta es la segura. ¡Bien visto!']) };
      }
      if (elemento.classList.contains('opcion--incorrecta')) {
        return { nombre: nombre, frase: unaDe(['Esta era la trampa. Ya la conoces.', 'Uf, esta era la peligrosa.']) };
      }
      return { nombre: nombre, frase: unaDe([
        '¿Cuál eliges? Lee todas antes de tocar.',
        '¿Esta es la segura? Piénsalo bien.',
        'Tómate tu tiempo para responder.',
        '¿Y si fuera una trampa? Lee con calma.'
      ]) };
    } },
    // ----- Convivencia -----
    { selector: '.escena-caso', describir: function () {
      return { nombre: 'la situación', frase: unaDe(['¿Qué es lo más seguro aquí? Piénsalo.', 'Primero la seguridad de todos.']) };
    } },
    { selector: '.paso-c--identificar', describir: function () {
      return { nombre: 'el paso Identificar', frase: unaDe(['¿Se repite? ¿Hay varios contra uno? Fíjate bien.', 'Reconocerlo a tiempo evita que crezca.']) };
    } },
    { selector: '.paso-c--prevenir', describir: function () {
      return { nombre: 'el paso Prevenir', frase: unaDe(['Sin risas ni reenvíos, el acoso pierde fuerza.', 'Pregunta antes de publicar a alguien.']) };
    } },
    { selector: '.paso-c--actuar', describir: function () {
      return { nombre: 'el paso Actuar', frase: unaDe(['Pedir ayuda también es actuar.', 'Primero tu seguridad, luego avisa a un adulto.']) };
    } },
    { selector: '.objetivo', describir: function (elemento) {
      return elemento.classList.contains('objetivo--hecho')
        ? { nombre: 'un objetivo cumplido', frase: '¡Este ya lo cumpliste!' }
        : { nombre: 'un objetivo', frase: 'Este se cumple solo cuando lo practicas.' };
    } },
    { selector: '#vista-incidentes .acordeon--naranja', describir: function () {
      return { nombre: 'un procedimiento', frase: unaDe(['Paso a paso y con calma. No estás solo.', 'No tienes que resolverlo sin ayuda.']) };
    } },
    { selector: '.evidencia', describir: function () {
      return { nombre: 'la guía de evidencia', frase: 'Guarda lo esencial, sin reenviarlo.' };
    } },
    { selector: '.retro', describir: function (elemento) {
      if (elemento.classList.contains('retro--bien')) {
        return { nombre: 'la explicación', frase: unaDe(['¡Lo hiciste bien! Lee por qué.', '¡Bien! ¿Seguimos con la siguiente?']) };
      }
      return { nombre: 'la explicación', frase: unaDe(['Aquí está el truco. Léelo con calma.', 'Lee las señales: la próxima no te engañan.']) };
    } },
    { selector: '.mision', describir: function (elemento) {
      return { nombre: '«' + textoDe(elemento, '.mision__nombre') + '»', frase: unaDe([
        '¿Jugamos este? Llevas ' + textoDe(elemento, '.mision__cuenta') + '.',
        '¿Entramos aquí? ¡Tú puedes!'
      ]) };
    } },
    { selector: '.tarea--mision', describir: function (elemento) {
      const nombre = 'la misión «' + textoDe(elemento, '.tarea__texto') + '»';
      if (elemento.classList.contains('tarea--hecha')) {
        return { nombre: nombre, frase: unaDe(['¡Esta ya la hiciste!', 'Misión cumplida. ¡Qué orgullo!']) };
      }
      return { nombre: nombre, frase: unaDe(['¿La hacemos hoy?', 'Esta te protege de verdad. ¿Le entramos?']) };
    } },
    { selector: '.tarea', describir: function () {
      return { nombre: 'tu tarea personal', frase: unaDe(['Esta no da XP, pero te organiza.', '¿Ya la terminaste? ¡Márcala!']) };
    } },
    { selector: '#campo-contrasena, #vista-verificador .campo-grupo', describir: function () {
      return { nombre: 'el campo de contraseña', frase: unaDe(['No miro, ¡lo prometo!', 'Prueba una parecida, nunca tu contraseña real.']) };
    } },
    { selector: '.medidor, .nivel-contrasena', describir: function () {
      const nivel = textoDe(document, '#nivel-contrasena');
      return { nombre: 'el medidor', frase: nivel ? nivel + '.' : 'Escribe algo y el medidor se llena.' };
    } },
    { selector: '.bloque-frase', describir: function () {
      return { nombre: 'la frase de ejemplo', frase: 'Varias palabras juntas son más fuertes que una palabra rara.' };
    } },
    // El aviso de privacidad es un acordeón, pero no es lección: no cuenta para el certificado.
    { selector: '.pie .acordeon', describir: function (elemento) {
      return { nombre: 'el aviso de privacidad', frase: elemento.open
        ? 'Aquí dice qué guarda la app y qué no.'
        : '¿Lo abres? Ahí dice qué guarda la app y qué no.' };
    } },
    { selector: '.acordeon[data-leccion]', describir: function (elemento) {
      const nombre = '«' + textoDe(elemento, 'summary').replace(/Leído$/, '').trim() + '»';
      if (elemento.classList.contains('acordeon--leido')) {
        return { nombre: nombre, frase: unaDe(['Esta lección ya la leíste. ¡Bien!', '¿Le das un repaso?']) };
      }
      if (elemento.open) return { nombre: nombre, frase: 'Léela con calma, vale la pena.' };
      return { nombre: nombre, frase: unaDe(['¿La abrimos? Cuenta para tu certificado.', '¿La leemos juntas?']) };
    } },
    { selector: '.requisito', describir: function (elemento) {
      return { nombre: '«' + textoDe(elemento, '.requisito__nombre') + '»', frase: 'Aquí vas ' + textoDe(elemento, '.requisito__cuenta') + '. ¡Sigue!' };
    } },
    { selector: '.certificado', describir: function () {
      return { nombre: 'el certificado', frase: unaDe(['¡Qué bonito certificado!', 'Esto es lo que ganas al final.']) };
    } },
    { selector: '.ayuda', describir: function () {
      return { nombre: 'los teléfonos de ayuda', frase: unaDe(['Si los necesitas, tócalos para llamar.', 'Pedir ayuda es de valientes.']) };
    } },
    { selector: '.atajo', describir: function () {
      return { nombre: 'un acceso directo', frase: unaDe(['¿Vamos para allá?', '¿Entramos?']) };
    } },
    { selector: '.resultados', describir: function (elemento) {
      return { nombre: 'tus resultados', frase: 'Sacaste ' + textoDe(elemento, '.resultados__marcador strong') + '. ¿Otra ronda?' };
    } },
    { selector: '.barra-juego', describir: function () {
      return { nombre: 'la barra del juego', frase: unaDe(['¿Cómo vamos?', 'Una pregunta a la vez.']) };
    } },
    { selector: '.campo', describir: function () {
      return { nombre: 'un campo para escribir', frase: 'Recuerda: nada de contraseñas ni datos personales.' };
    } },
    { selector: '.nota', describir: function () {
      return { nombre: 'una nota', frase: unaDe(['Esta nota es importante. ¿La leíste?', 'Léela, vale la pena.']) };
    } },
    { selector: '.boton, button', describir: function () {
      return { nombre: 'un botón', frase: unaDe(['¿Lo presionamos?', 'Ojo, no me vayas a aplastar.']) };
    } },
    { selector: '.tarjeta', describir: function () {
      return { nombre: 'una tarjeta', frase: unaDe(['Aquí estoy cómoda.', 'Buen lugar para leer.']) };
    } },
    { selector: '.titulo-vista', describir: function () {
      return { nombre: 'el título', frase: 'Desde aquí arriba se ve todo.' };
    } },
    { selector: '.pie', describir: function () {
      return { nombre: 'el pie de página', frase: 'Abajo está el aviso de privacidad.' };
    } },
    { selector: '.barra-nav', describir: function () {
      return { nombre: 'la barra de secciones', frase: '¿A dónde vamos ahora?' };
    } },
    { selector: '.cabecera', describir: function () {
      return { nombre: 'la cabecera', frase: 'Desde aquí veo tu XP: ' + Progreso.actual().xp + '.' };
    } }
  ];

  // Dónde se puede parar (plataformas para la gravedad y los saltos).
  const PLATAFORMAS = '.tarjeta, .mision, .opcion, .chat, .acordeon, .tarea, .atajo, .retro, .requisito, '
    + '.certificado, .ayuda, .medidor, .bloque-frase, .nota, .campo-grupo, .barra-juego, .resultados__escena, '
    + '.paso-c, .escena-caso, .objetivo, .evidencia';

  // ================= 7. Ajustes =================
  // Preferencias de la app (no son datos personales): sonido, compañera y dónde la dejaste.
  const CLAVE_AJUSTES = 'ciberescudo.ajustes.v1';

  function leerAjustes() {
    const datos = Almacen.leer(CLAVE_AJUSTES, {}) || {};
    const posicion = datos.posicion && typeof datos.posicion.x === 'number' && typeof datos.posicion.y === 'number'
      ? { x: datos.posicion.x, y: datos.posicion.y }
      : null;
    return { sonido: datos.sonido !== false, companera: datos.companera !== false, posicion: posicion };
  }

  let ajustes = null;

  function guardarAjustes() {
    Almacen.guardar(CLAVE_AJUSTES, ajustes);
  }

  function pintarAjustes() {
    const botonSonido = document.getElementById('ajuste-sonido');
    const botonCompanera = document.getElementById('ajuste-companera');
    botonSonido.setAttribute('aria-pressed', String(ajustes.sonido));
    botonSonido.querySelector('.ajuste__valor').textContent = ajustes.sonido ? 'Sí' : 'No';
    botonCompanera.setAttribute('aria-pressed', String(ajustes.companera));
    botonCompanera.querySelector('.ajuste__valor').textContent = ajustes.companera ? 'Visible' : 'Oculta';
  }

  function prepararAjustes() {
    ajustes = leerAjustes();
    Mascota.activarSonido(ajustes.sonido);
    Mascota.Companera.iniciar({
      habilitada: ajustes.companera,
      posicion: ajustes.posicion,
      objetos: OBJETOS_DE_LA_PAGINA,
      selectorPlataformas: PLATAFORMAS,
      selectorPrivado: '#campo-contrasena',
      alMover: function (posicion) {
        ajustes.posicion = posicion;
        guardarAjustes();
      }
    });
    document.getElementById('ajuste-sonido').addEventListener('click', function () {
      ajustes.sonido = !ajustes.sonido;
      Mascota.activarSonido(ajustes.sonido);
      if (ajustes.sonido) Mascota.efecto('acierto');
      guardarAjustes();
      pintarAjustes();
      Interfaz.anunciar(ajustes.sonido ? 'Sonido activado' : 'Sonido apagado');
    });
    document.getElementById('ajuste-companera').addEventListener('click', function () {
      ajustes.companera = !ajustes.companera;
      const enVistaConFlorGrande = vistaActual === 'inicio' || vistaActual === 'certificado';
      Mascota.Companera.habilitar(ajustes.companera, enVistaConFlorGrande ? null : vistaActual);
      guardarAjustes();
      pintarAjustes();
      Interfaz.anunciar(ajustes.companera ? 'Compañera visible' : 'Compañera oculta');
    });
    pintarAjustes();
  }

  // ================= Arranque =================
  function arrancar() {
    Progreso.cargar();
    prepararAjustes();
    Verificador.iniciar();
    Simulador.iniciar();
    Retos.iniciar();
    Tareas.iniciar();
    Inicio.iniciar();
    Certificado.iniciar();
    prepararLecciones();
    prepararHojaMas();

    const logo = document.getElementById('logo');
    if (logo) logo.appendChild(Mascota.svgLogo());
    // Íconos pixelados de la navegación, el HUD, los accesos y la hoja «Más».
    document.querySelectorAll('[data-icono]').forEach(function (lugar) {
      if (!lugar.firstChild) lugar.appendChild(Mascota.icono(lugar.dataset.icono));
    });

    // "Saltar al contenido" mueve el foco sin cambiar el hash (que es la navegación).
    const saltar = document.querySelector('.saltar');
    if (saltar) {
      saltar.addEventListener('click', function (evento) {
        evento.preventDefault();
        document.getElementById('contenido').focus();
      });
    }

    global.addEventListener('hashchange', alCambiarHash);
    const inicial = vistaDesdeHash() || 'inicio';
    if (!vistaDesdeHash()) global.history.replaceState(null, '', '#inicio');
    mostrarVista(inicial, false);
    // Por si alguien ya cumplía todo antes de esta versión.
    Progreso.revisarCertificado();

    prepararBotonAtras();
    prepararTeclado();
    registrarServiceWorker();
  }

  const exportado = {
    Almacen: Almacen,
    Progreso: Progreso,
    Interfaz: Interfaz,
    VISTAS: VISTAS,
    VISTAS_EN_MAS: VISTAS_EN_MAS
  };

  if (typeof module === 'object' && module.exports) {
    module.exports = exportado;
  } else {
    global.Almacen = Almacen;
    global.Progreso = Progreso;
    global.Interfaz = Interfaz;
    arrancar();
  }
})(this);
