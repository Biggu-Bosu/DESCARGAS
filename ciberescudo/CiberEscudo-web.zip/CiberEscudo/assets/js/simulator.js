// CiberEscudo · simulator.js
// Simulador gamificado: 30 situaciones ficticias en 5 paquetes de 6.
// Paquetes 1 y 2: seguridad digital (phishing, suplantación, estafas).
// Paquetes 3 a 5: convivencia (ciberacoso, fotos y consentimiento, bullying en la escuela).
// Eliges qué harías. Si aciertas ganas +10 XP (solo la
// primera vez por escenario: queda "dominado") y la mascota celebra; si fallas,
// ves la explicación y las señales de alerta.
// Los "enlaces" son texto falso con dominios ".ejemplo": no se pueden abrir.

(function (global) {
  'use strict';

  const XP_POR_ACIERTO = 10;

  const PAQUETES = [
    { id: 'clasicos', nombre: 'Paquete 1: Clásicos', descripcion: 'Phishing, códigos y premios falsos', icono: 'chat', color: 'rosa', grupo: 'Seguridad digital' },
    { id: 'avanzado', nombre: 'Paquete 2: Avanzado', descripcion: 'Tiendas, QR, apps y ciberacoso', icono: 'alerta', color: 'cian', grupo: 'Seguridad digital' },
    {
      id: 'conv-redes', nombre: 'Paquete 3: Chats y redes', descripcion: 'Ciberacoso, cuentas falsas y amenazas',
      icono: 'chat', color: 'naranja', grupo: 'Convivencia', convivencia: true
    },
    {
      id: 'conv-fotos', nombre: 'Paquete 4: Fotos y consentimiento', descripcion: 'Stickers, videos, capturas y presión',
      icono: 'ojo', color: 'naranja', grupo: 'Convivencia', convivencia: true
    },
    {
      id: 'conv-escuela', nombre: 'Paquete 5: En la escuela', descripcion: 'Recreo, salón, testigos y reparar el daño',
      icono: 'corazon', color: 'naranja', grupo: 'Convivencia', convivencia: true
    }
  ];

  // Nombres que se muestran para cada uno de los 3 pasos.
  const PASOS = { identificar: 'Identificar', prevenir: 'Prevenir', actuar: 'Actuar' };

  // En los mensajes, lo que va entre [[ ]] se muestra como un enlace falso.
  const ESCENARIOS = [
    {
      id: 'insta-phishing',
      paquete: 'clasicos',
      canal: 'Instagram · Mensaje directo',
      remitente: 'Soporte.Instagram.Oficial ✔',
      mensajes: [
        '⚠ Tu cuenta será eliminada en 24 horas por infringir derechos de autor.',
        'Si no fuiste tú, verifica tu identidad aquí: [[insta-soporte-verifica.ejemplo/login]]'
      ],
      opciones: [
        {
          texto: 'Entro al enlace y pongo mi usuario y contraseña para que no borren mi cuenta.',
          correcta: false,
          retro: 'Esa página es falsa: lo que escribas le llega directo a quien quiere robar tu cuenta.'
        },
        {
          texto: 'No toco el enlace. Reviso en la app oficial, en Configuración, si hay un aviso real, y reporto el mensaje.',
          correcta: true,
          retro: '¡Exacto! Revisar desde la app oficial es la forma segura de confirmar.'
        },
        {
          texto: 'Le contesto para preguntarle si es real.',
          correcta: false,
          retro: 'Contestar le confirma que tu cuenta está activa y te seguirán presionando.'
        }
      ],
      explicacion: 'Las redes sociales avisan de problemas dentro de la app (en Configuración o en el Centro de cuentas), no con un mensaje directo con prisa y un enlace raro.',
      senales: [
        'Te mete prisa: «24 horas».',
        'Te amenaza con perder tu cuenta.',
        'El enlace no es del sitio oficial.',
        'Que el nombre diga «Oficial» o tenga una palomita no prueba nada.'
      ]
    },
    {
      id: 'whatsapp-codigo',
      paquete: 'clasicos',
      canal: 'WhatsApp',
      remitente: '+52 55 •••• 0193 · Número desconocido',
      mensajes: [
        'Hola!! soy tu prima Vale, cambié de número 😅',
        'Oye, te llegó por error un código de 6 dígitos por SMS, ¿me lo pasas? Es urgente 🙏'
      ],
      opciones: [
        {
          texto: 'Se lo paso, es mi prima.',
          correcta: false,
          retro: 'Ese código sirve para abrir TU WhatsApp en otro celular. Con él te roban la cuenta y engañan a tus contactos.'
        },
        {
          texto: 'Le pido que me mande una foto para comprobar que es ella.',
          correcta: false,
          retro: 'Una foto se puede sacar de su perfil. Mejor confirma por un medio que ya conoces.'
        },
        {
          texto: 'No le paso nada y le marco a Vale a su número de siempre para confirmar.',
          correcta: true,
          retro: '¡Muy bien! Confirmar por otro medio desarma la suplantación.'
        }
      ],
      explicacion: 'El código de verificación es la llave de tu cuenta. Nadie (ni amistades ni «soporte») necesita que se lo compartas. Activa la verificación en dos pasos de WhatsApp para tener un PIN extra.',
      senales: [
        'Un número nuevo que dice ser alguien conocido.',
        'Te pide un código que te llegó a ti.',
        'Prisa y emojis para que no lo pienses.'
      ]
    },
    {
      id: 'sms-premio',
      paquete: 'clasicos',
      canal: 'SMS',
      remitente: 'PROMO-MX',
      mensajes: [
        '¡FELICIDADES! Ganaste un celular de última generación en nuestro sorteo 🎉',
        'Para enviártelo solo paga $99 de envío con tu tarjeta: [[premios-mx-entrega.ejemplo]]'
      ],
      opciones: [
        {
          texto: 'Lo borro y bloqueo el número. No participé en ningún sorteo.',
          correcta: true,
          retro: '¡Correcto! Si no participaste, no puedes ganar.'
        },
        {
          texto: 'Pago los $99; es muy poco por un celular.',
          correcta: false,
          retro: 'Perderías el dinero y además entregarías los datos de la tarjeta.'
        },
        {
          texto: 'Se lo reenvío a mis amigos para que también ganen.',
          correcta: false,
          retro: 'Así la estafa llega a más personas. Mejor avísales que es falso.'
        }
      ],
      explicacion: 'Pedir un pago pequeño para «liberar» un premio es una de las estafas más comunes. Los sorteos reales no te cobran por recibir lo que ganaste.',
      senales: [
        'Premio de algo en lo que no participaste.',
        'Te pide pagar o dar datos de tarjeta.',
        'Remitente genérico y enlace desconocido.'
      ]
    },
    {
      id: 'correo-escuela',
      paquete: 'clasicos',
      canal: 'Correo electrónico',
      remitente: 'Control Escolar <control.escolar.prepa@correo-gratis.ejemplo>',
      asunto: 'URGENTE: actualiza tus datos o perderás tu inscripción',
      mensajes: [
        'Estimado alumno: por una actualización del sistema, responde este correo con tu CURP, tu correo escolar y su contraseña antes del viernes.',
        'Si no lo haces, tu inscripción quedará cancelada.'
      ],
      opciones: [
        {
          texto: 'Respondo con mis datos; mejor no arriesgar la inscripción.',
          correcta: false,
          retro: 'Ninguna escuela necesita tu contraseña. Con ella pueden entrar a tu correo y a todo lo conectado a él.'
        },
        {
          texto: 'Mando solo la CURP, sin la contraseña.',
          correcta: false,
          retro: 'La CURP también es un dato personal que sirve para suplantar tu identidad. Primero verifica.'
        },
        {
          texto: 'No respondo y pregunto en persona en Control Escolar si el correo es real.',
          correcta: true,
          retro: '¡Bien pensado! Verificar en persona o por el canal oficial es lo más seguro.'
        }
      ],
      explicacion: 'Se hacen pasar por la escuela para que confíes. Fíjate: el correo viene de un servicio gratuito, no de la dirección oficial, y pide tu contraseña.',
      senales: [
        'Pide tu contraseña (nadie legítimo lo hace).',
        'Amenaza con una fecha límite.',
        'La dirección de correo no es de la escuela.'
      ]
    },
    {
      id: 'amigo-votar',
      paquete: 'clasicos',
      canal: 'Instagram · Mensaje directo',
      remitente: 'Diego (tu compañero de clase)',
      mensajes: [
        'Ayúdame plis!! estoy en un concurso de baile 💃',
        'Vota por mí aquí, solo tienes que entrar con tu Instagram: [[concurso-votos-baile.ejemplo]]'
      ],
      opciones: [
        {
          texto: 'No entro. Le aviso a Diego por otro medio (llamada o en persona) que su cuenta puede estar hackeada.',
          correcta: true,
          retro: '¡Eso es! Así proteges tu cuenta y ayudas a Diego a recuperar la suya.'
        },
        {
          texto: 'Entro con mi cuenta para votar; es mi amigo.',
          correcta: false,
          retro: 'Es muy probable que hayan robado la cuenta de Diego y ahora quieran la tuya con el mismo truco.'
        },
        {
          texto: 'Le doy «me gusta» al mensaje y ya.',
          correcta: false,
          retro: 'No te pasa nada por eso, pero Diego no sabe que alguien usa su cuenta. Avísale.'
        }
      ],
      explicacion: 'Cuando roban una cuenta, la usan para engañar a sus contactos, porque confías en esa persona. Un concurso que te pide iniciar sesión con tu red social es una trampa muy usada.',
      senales: [
        'Te pide iniciar sesión fuera de la app.',
        'El mensaje no suena como tu amigo.',
        'Enlace desconocido.'
      ]
    },
    {
      id: 'foto-amenaza',
      paquete: 'clasicos',
      canal: 'Instagram · Mensaje directo',
      remitente: 'cuenta_sin_foto_8821',
      mensajes: [
        'Tengo una foto tuya que no quieres que nadie vea.',
        'Si no me depositas $500 hoy, se la mando a todos tus seguidores.'
      ],
      opciones: [
        {
          texto: 'Pago para que no la publique.',
          correcta: false,
          retro: 'Pagar casi nunca detiene a quien amenaza: suele pedir más. Y tú no hiciste nada malo.'
        },
        {
          texto: 'Borro mi cuenta y no le digo a nadie.',
          correcta: false,
          retro: 'No tienes que pasar por esto sin apoyo. Borrar la cuenta también borra pruebas.'
        },
        {
          texto: 'No respondo ni pago. Guardo capturas, bloqueo y reporto la cuenta, y se lo cuento a un adulto de confianza.',
          correcta: true,
          retro: 'Así es. Guardar pruebas y pedir ayuda es lo más valiente y lo más útil.'
        }
      ],
      explicacion: 'Esto es extorsión y es un delito. La culpa siempre es de quien amenaza, nunca tuya. Muchas veces ni siquiera tienen la foto. Puedes denunciar de forma anónima al 089 y revisar la Guía de incidentes.',
      senales: [
        'Cuenta sin foto ni historial.',
        'Amenaza y exige dinero con prisa.',
        'Busca que tengas miedo para que no se lo cuentes a nadie.'
      ]
    },
    {
      id: 'tienda-falsa',
      paquete: 'avanzado',
      canal: 'Instagram · Anuncio patrocinado',
      remitente: 'SneakersMX_Oficial · 3 publicaciones',
      mensajes: [
        '🔥 Tenis originales a $399, solo HOY. Quedan 2 pares de tu talla.',
        'Paga por transferencia y te los mandamos mañana: [[sneakers-ofertas-mx.ejemplo]]'
      ],
      opciones: [
        {
          texto: 'Transfiero rápido antes de que se acaben.',
          correcta: false,
          retro: 'Una transferencia casi nunca se puede recuperar. Es justo lo que buscan las tiendas falsas.'
        },
        {
          texto: 'Busco opiniones de la tienda fuera de su perfil y, si compro, uso un método con protección al comprador.',
          correcta: true,
          retro: '¡Muy bien! Investigar antes de pagar te evita la mayoría de las estafas.'
        },
        {
          texto: 'Les pido que me manden una foto de los tenis.',
          correcta: false,
          retro: 'Una foto se puede copiar de internet. No prueba que la tienda exista.'
        }
      ],
      explicacion: 'Precio imposible, prisa («solo hoy», «quedan 2») y pago por transferencia son la fórmula típica de una tienda falsa.',
      senales: [
        'Precio demasiado bajo para ser real.',
        'Cuenta nueva con pocas publicaciones.',
        'Solo aceptan transferencia.',
        'Presión de tiempo y de pocas piezas.'
      ]
    },
    {
      id: 'qr-wifi',
      paquete: 'avanzado',
      canal: 'Cartel en la calle',
      remitente: 'Código QR pegado en un poste',
      mensajes: [
        'WIFI GRATIS 🔓 Escanea y entra con tu cuenta de Google para conectarte.',
        'El código abre: [[wifi-gratis-plaza.ejemplo/login]]'
      ],
      opciones: [
        {
          texto: 'Lo escaneo y pongo mi correo y contraseña para tener internet.',
          correcta: false,
          retro: 'Esa página imita el inicio de sesión para quedarse con tu cuenta.'
        },
        {
          texto: 'No escribo mi cuenta. Un wifi no necesita mi contraseña de Google; mejor uso mis datos.',
          correcta: true,
          retro: '¡Exacto! Ningún wifi real te pide la contraseña de tu correo.'
        },
        {
          texto: 'Le tomo foto al QR para pasárselo a mis amigos.',
          correcta: false,
          retro: 'Así la trampa llega a más personas.'
        }
      ],
      explicacion: 'Un QR es un enlace disfrazado: no puedes ver a dónde lleva hasta escanearlo. Cualquiera puede pegar uno en la calle.',
      senales: [
        'QR pegado en un lugar público sin dueño claro.',
        'Te pide iniciar sesión con otra cuenta para algo que no lo necesita.',
        'La dirección no es de ningún sitio oficial.'
      ]
    },
    {
      id: 'apk-fotos',
      paquete: 'avanzado',
      canal: 'WhatsApp · Grupo',
      remitente: 'Grupo «3°B Generación» · Número sin guardar',
      mensajes: [
        'Miren las fotos de la fiesta jajaja 📸',
        'Descarguen aquí: [[fotos-fiesta.ejemplo/album.apk]]'
      ],
      opciones: [
        {
          texto: 'No lo descargo y aviso en el grupo que puede ser un programa malicioso.',
          correcta: true,
          retro: '¡Bien! Avisar protege a todo el grupo.'
        },
        {
          texto: 'Lo instalo para ver las fotos.',
          correcta: false,
          retro: 'Un archivo .apk es una app, no fotos. Podría espiar tu celular o robar tus cuentas.'
        },
        {
          texto: 'Lo reenvío a otro grupo.',
          correcta: false,
          retro: 'Reenviarlo pone en riesgo a más personas.'
        }
      ],
      explicacion: 'Las fotos se ven directo en el chat. Si para «verlas» te piden instalar algo, es una trampa. Las apps solo se instalan desde la tienda oficial.',
      senales: [
        'El archivo termina en .apk (es una app).',
        'Lo manda un número que no tienes guardado.',
        'Usa la curiosidad («las fotos de la fiesta»).'
      ]
    },
    {
      id: 'llamada-extorsion',
      paquete: 'avanzado',
      canal: 'Llamada telefónica',
      remitente: 'Número desconocido',
      mensajes: [
        '«Tenemos a tu hermano. No cuelgues y no le digas a nadie.»',
        '«Deposita $3,000 en una tienda en los próximos 30 minutos.»'
      ],
      opciones: [
        {
          texto: 'Hago el depósito rápido sin colgar.',
          correcta: false,
          retro: 'Es lo que buscan: que no verifiques nada. Casi siempre es mentira.'
        },
        {
          texto: 'Me quedo en la llamada para averiguar más.',
          correcta: false,
          retro: 'Mientras sigas en la línea, no puedes comprobar que tu familia está bien.'
        },
        {
          texto: 'Cuelgo, llamo a mi hermano o a un adulto a su número de siempre y lo reporto al 089.',
          correcta: true,
          retro: 'Así es. Colgar y verificar rompe el engaño.'
        }
      ],
      explicacion: 'Es una extorsión telefónica. Los delincuentes inventan una emergencia y piden que no cuelgues para que no puedas confirmar. Puedes denunciar de forma anónima al 089.',
      senales: [
        'No te dejan colgar.',
        'Te piden no contarle a nadie.',
        'Exigen dinero con un tiempo límite.'
      ]
    },
    {
      id: 'meme-acoso',
      paquete: 'avanzado',
      canal: 'WhatsApp · Grupo',
      remitente: 'Grupo «Los del salón»',
      mensajes: [
        'Alguien subió una foto editada de una compañera para burlarse de ella. Ya hay 20 risas 😂.',
        '«Pásenla a los otros grupos jajaja»'
      ],
      opciones: [
        {
          texto: 'Me río y la reenvío, todos lo están haciendo.',
          correcta: false,
          retro: 'Reenviar también es participar en el acoso, aunque no la hayas hecho tú.'
        },
        {
          texto: 'No la comparto, le escribo a mi compañera para apoyarla y lo reporto a un profesor u orientación.',
          correcta: true,
          retro: '¡Eso es ser un CiberEscudo! Romper la cadena y apoyar cambia todo.'
        },
        {
          texto: 'Me salgo del grupo sin decir nada.',
          correcta: false,
          retro: 'Está bien no participar, pero tu compañera sigue sola. Avisar a un adulto puede detenerlo.'
        }
      ],
      explicacion: 'Esto es ciberacoso. Quien difunde y quien se ríe le dan fuerza. Apoyar a la persona afectada y avisar a un adulto ayuda a detenerlo.',
      senales: [
        'Una imagen editada para humillar a alguien.',
        'Invitan a reenviarla a más grupos.',
        'La persona afectada no está para defenderse.'
      ]
    },
    {
      id: 'alerta-real',
      paquete: 'avanzado',
      canal: 'Aviso dentro de la app oficial',
      remitente: 'Configuración → Seguridad',
      mensajes: [
        'Nuevo inicio de sesión en tu cuenta desde un dispositivo Android en otra ciudad.',
        '¿Fuiste tú? Toca «No fui yo» para proteger tu cuenta.'
      ],
      opciones: [
        {
          texto: 'Lo ignoro, seguro no es nada.',
          correcta: false,
          retro: 'Este aviso sí es real (está dentro de la app). Ignorarlo deja al intruso en tu cuenta.'
        },
        {
          texto: 'Toco «No fui yo», cambio la contraseña, cierro esa sesión y activo la verificación en dos pasos.',
          correcta: true,
          retro: '¡Perfecto! No todos los avisos son trampas: este viene de la app y hay que actuar.'
        },
        {
          texto: 'Borro la app para que no vuelvan a entrar.',
          correcta: false,
          retro: 'Borrar la app no cierra la sesión del intruso. La cuenta sigue abierta en su celular.'
        }
      ],
      explicacion: 'La diferencia está en el lugar: este aviso aparece dentro de la app oficial, no en un mensaje con enlace. Ahí sí conviene actuar rápido.',
      senales: [
        'Inicio de sesión que no reconoces.',
        'Dispositivo o ciudad diferentes a los tuyos.',
        'El aviso viene de la app, así que es confiable.'
      ]
    },

    // ===================== CONVIVENCIA =====================
    // Situaciones ficticias con nombres inventados. Campos extra (opcionales):
    //   paso:          'identificar' | 'prevenir' | 'actuar' (los 3 pasos de la sección Convivencia)
    //   lugar/escena:  en vez de un chat, una escena narrada (para lo que pasa en persona)
    //   pregunta:      cambia el «¿Qué harías?»
    //   recomendacion: consejo práctico que se muestra al responder
    //   ayuda:         cuándo pedir ayuda adulta o institucional
    //   delicado:      la flor reacciona con calma (sin festejo ni lágrimas)

    // ---------- Paquete 3: Chats y redes ----------
    {
      id: 'conv-insultos-grupo',
      paquete: 'conv-redes',
      paso: 'actuar',
      canal: 'WhatsApp · Grupo «3°B oficial»',
      remitente: 'Varios compañeros',
      mensajes: [
        'Otra vez le están diciendo «el bote» a Diego por su peso. Ya van tres días seguidos.',
        '«Jajaja que no coma en el recreo» · 😂😂😂 · «Mándenle el sticker»'
      ],
      pregunta: 'Estás en el grupo. ¿Qué haces?',
      opciones: [
        {
          texto: 'Mando un emoji de risa para no quedar mal con el grupo.',
          correcta: false,
          retro: 'Cada risa le dice al grupo que está bien seguir. Reaccionar también es participar.'
        },
        {
          texto: 'No reacciono, le escribo a Diego en privado para apoyarlo y le aviso a un adulto de confianza o a orientación.',
          correcta: true,
          retro: '¡Eso! Le quitas público al ataque, Diego sabe que no está solo y alguien con autoridad puede detenerlo.'
        },
        {
          texto: 'Les escribo insultos peores para que aprendan.',
          correcta: false,
          retro: 'Responder con ataques hace más grande el pleito y te pone a ti en riesgo. No ayuda a Diego.'
        },
        {
          texto: 'No hago nada: no es mi problema.',
          correcta: false,
          retro: 'Se entiende no querer meterse, pero Diego sigue solo. Avisar a un adulto es una forma segura de ayudar.'
        }
      ],
      explicacion: 'Se repite, son varios contra uno y se burlan de una característica personal: es ciberacoso. Lo que hacen los demás del grupo puede frenarlo o empeorarlo.',
      senales: [
        'Los insultos se repiten varios días.',
        'Varias personas contra una sola.',
        'Se burlan de su cuerpo.'
      ],
      recomendacion: 'Un mensaje privado como «Vi lo del grupo, no estuvo bien. ¿Quieres que vayamos a orientación?» ayuda mucho, y no te expone.',
      ayuda: 'Avisa a orientación o a un profesor si el acoso se repite o si Diego deja de ir a clases o se ve muy afectado.'
    },
    {
      id: 'conv-cuenta-rumores',
      paquete: 'conv-redes',
      paso: 'actuar',
      canal: 'Instagram · Cuenta anónima',
      remitente: '@verdades_del_salon',
      mensajes: [
        'Una cuenta nueva publica «chismes» de alumnos de tu prepa. Hoy subió un rumor sobre Fer, de tu salón.',
        'Ya tiene 300 seguidores y muchos comentan con risas.'
      ],
      pregunta: '¿Qué es lo más seguro?',
      opciones: [
        {
          texto: 'La sigo para enterarme de qué publica de los demás.',
          correcta: false,
          retro: 'Cada seguidor y cada vista le dan más alcance. Así la cuenta crece y el daño también.'
        },
        {
          texto: 'Investigo quién la maneja y publico su nombre para exhibirlo.',
          correcta: false,
          retro: 'No te toca investigar, y exhibir a alguien puede ser otra forma de acoso o equivocarte de persona.'
        },
        {
          texto: 'Reporto la cuenta, no comparto nada, le digo a Fer en privado que la apoyo y aviso a un adulto de la escuela.',
          correcta: true,
          retro: 'Correcto. Reportar y no difundir le quita fuerza, y la escuela puede actuar con más gente afectada.'
        }
      ],
      explicacion: 'Las cuentas anónimas de rumores son hostigamiento: publican información falsa o privada para humillar. Funcionan gracias al público.',
      senales: [
        'Cuenta anónima creada para hablar de otras personas.',
        'Rumores sobre alumnos con nombre.',
        'Gana seguidores con las burlas.'
      ],
      recomendacion: 'Reporta la cuenta desde el menú de la publicación (opción de acoso o información falsa). No comentes: los comentarios también la impulsan.',
      ayuda: 'Avísale a orientación: si afecta a varios alumnos, la escuela puede pedir ayuda a la plataforma o a las autoridades.'
    },
    {
      id: 'conv-amenaza-capturas',
      paquete: 'conv-redes',
      paso: 'actuar',
      canal: 'WhatsApp · Chat privado',
      remitente: 'Rodrigo (compañero)',
      mensajes: [
        'Tengo capturas de lo que me contaste de tu familia.',
        'Si no me pasas las tareas toda la semana, las publico en el grupo del salón.'
      ],
      pregunta: 'Te llega este mensaje. ¿Qué haces?',
      opciones: [
        {
          texto: 'Le paso las tareas para que no las publique.',
          correcta: false,
          retro: 'Ceder a una amenaza casi nunca la termina: suele pedir más. Y la culpa es de quien amenaza, no tuya.'
        },
        {
          texto: 'Lo amenazo también con publicar cosas de él.',
          correcta: false,
          retro: 'Responder con otra amenaza te mete en el mismo problema y lo hace más peligroso.'
        },
        {
          texto: 'Guardo captura de la amenaza con fecha y usuario, no negocio, lo bloqueo después y se lo cuento a un adulto de confianza.',
          correcta: true,
          retro: 'Así es: la evidencia de la amenaza sirve para pedir ayuda, y un adulto puede detenerlo.'
        },
        {
          texto: 'Borro todo el chat y hago como si nada.',
          correcta: false,
          retro: 'Si borras, pierdes la prueba de la amenaza, y el problema sigue ahí.'
        }
      ],
      explicacion: 'Amenazar con publicar algo privado para obtener algo es extorsión, aunque sea entre compañeros. Merece atención aunque pase una sola vez.',
      senales: [
        'Usa algo privado para presionarte.',
        'Te pone condiciones («si no…»).',
        'Amenaza con exponerte frente a otros.'
      ],
      recomendacion: 'Guarda la captura de la amenaza (con fecha, usuario y plataforma) antes de bloquear. No hace falta reenviarla a nadie más.',
      ayuda: 'Cuéntaselo hoy a tu familia u orientación. Si amenaza con dañarte o te pide dinero o fotos, también se puede denunciar.'
    },
    {
      id: 'conv-grupo-exclusion',
      paquete: 'conv-redes',
      paso: 'identificar',
      canal: 'WhatsApp',
      remitente: 'Una amiga te avisa',
      mensajes: [
        'Oye, hicieron un grupo con todo el salón menos tú. Se llama «Salón sin Andy».',
        'Ponen tus fotos y se burlan de cómo hablas.'
      ],
      pregunta: 'Eres Andy. ¿Qué haces?',
      opciones: [
        {
          texto: 'Hago mi propio grupo para burlarme de ellos.',
          correcta: false,
          retro: 'Se entiende el enojo, pero la venganza alarga el problema y te puede meter en uno.'
        },
        {
          texto: 'Le pido a mi amiga que me mande capturas de todo lo que escriban, todos los días.',
          correcta: false,
          retro: 'Pones a tu amiga en medio y te expones a leer cada burla. Mejor que un adulto atienda el caso.'
        },
        {
          texto: 'No respondo en el chat, le pido a mi amiga una captura de lo principal y se lo cuento a un adulto de confianza.',
          correcta: true,
          retro: 'Bien: con lo esencial basta para pedir ayuda, y no tienes que cargar con esto solo.'
        },
        {
          texto: 'Pienso que es normal y me aguanto: así son los grupos.',
          correcta: false,
          retro: 'No tener a alguien en un grupo puede pasar, pero hacer uno para burlarse de ti es acoso. No tienes que aguantarlo.'
        }
      ],
      explicacion: 'No toda exclusión es acoso: no estar en un grupo de amigos puede pasar. Pero crear un grupo a propósito para humillar a alguien sí lo es.',
      senales: [
        'Lo hicieron a propósito sin ti.',
        'Usan tus fotos para burlarse.',
        'Participa todo el salón.'
      ],
      recomendacion: 'No necesitas leer todo lo que dicen de ti. Una o dos capturas con fecha son suficientes para que un adulto entienda lo que pasa.',
      ayuda: 'Habla con orientación o tu familia. Si las burlas siguen en el salón, también es parte del mismo problema y se atiende.'
    },
    {
      id: 'conv-provocacion',
      paquete: 'conv-redes',
      paso: 'prevenir',
      canal: 'TikTok · Comentarios de tu video',
      remitente: '@usuario_x',
      mensajes: [
        'Subiste un video bailando. Alguien que no conoces comentó: «qué ridículo, bórralo».',
        'Es el primer comentario así que recibes.'
      ],
      pregunta: '¿Cómo respondes?',
      opciones: [
        {
          texto: 'Le contesto con un insulto peor y le pido a mis amigos que lo ataquen.',
          correcta: false,
          retro: 'Así una sola provocación se vuelve un pleito grande, y organizar un ataque también es acoso.'
        },
        {
          texto: 'No respondo, borro o filtro el comentario y, si vuelve a pasar, lo bloqueo y lo reporto.',
          correcta: true,
          retro: '¡Bien! No le das la reacción que busca y tienes herramientas para cuidarte si se repite.'
        },
        {
          texto: 'Borro mi video y dejo de publicar para siempre.',
          correcta: false,
          retro: 'Puedes hacerlo si quieres, pero no tienes que esconderte por un comentario. Tienes formas de protegerte.'
        }
      ],
      explicacion: 'Un comentario grosero aislado no siempre es acoso, pero sí una provocación. Si se repite, crece o llega de varias cuentas, ya es hostigamiento y conviene pedir ayuda.',
      senales: [
        'Busca provocarte para que respondas.',
        'Viene de una cuenta desconocida.'
      ],
      recomendacion: 'Revisa en Configuración quién puede comentar tus videos y activa los filtros de palabras ofensivas.',
      ayuda: 'Si los comentarios se repiten, llegan de varias cuentas o incluyen amenazas, guarda capturas y cuéntaselo a un adulto.'
    },
    {
      id: 'conv-suplantacion',
      paquete: 'conv-redes',
      paso: 'actuar',
      canal: 'Instagram',
      remitente: 'Perfil con tu nombre y tu foto',
      mensajes: [
        'Alguien creó un perfil con tu nombre y tu foto.',
        'Publica cosas vergonzosas como si fueras tú y les escribe a tus compañeros.'
      ],
      pregunta: '¿Qué es lo más útil?',
      opciones: [
        {
          texto: 'Creo un perfil falso de quien creo que fue, para que sienta lo mismo.',
          correcta: false,
          retro: 'Suplantar a otra persona es lo mismo que te están haciendo, y podrías equivocarte de persona.'
        },
        {
          texto: 'Guardo el enlace y capturas, lo reporto como suplantación, aviso a mis contactos por otro medio y se lo cuento a un adulto.',
          correcta: true,
          retro: 'Perfecto: las plataformas tienen una opción para cuentas que se hacen pasar por ti, y tus contactos sabrán que no eres tú.'
        },
        {
          texto: 'Le escribo al perfil falso para insultarlo.',
          correcta: false,
          retro: 'Responderle le da la reacción que busca y no hace que la plataforma lo quite.'
        },
        {
          texto: 'Lo ignoro, ya se aburrirá.',
          correcta: false,
          retro: 'Mientras siga activo puede seguir dañando tu reputación. Reportarlo es rápido.'
        }
      ],
      explicacion: 'Hacerse pasar por alguien para avergonzarlo es suplantación de identidad con fines de acoso. Se reporta en la plataforma y conviene que un adulto lo sepa.',
      senales: [
        'Usa tu nombre y tu foto sin permiso.',
        'Publica cosas para avergonzarte.',
        'Contacta a tus conocidos.'
      ],
      recomendacion: 'Pide a tus amigos que también reporten el perfil, pero que no le comenten ni le respondan.',
      ayuda: 'Si el perfil publica datos personales, amenazas o fotos íntimas, avisa a un adulto de inmediato: se puede denunciar.'
    },

    // ---------- Paquete 4: Fotos y consentimiento ----------
    {
      id: 'conv-sticker-companero',
      paquete: 'conv-fotos',
      paso: 'prevenir',
      canal: 'WhatsApp · Grupo «Los del fondo»',
      remitente: 'Grupo de amigos',
      mensajes: [
        'Alguien hizo un sticker con una foto de Luis dormido en clase, con la boca abierta.',
        '«Úsenlo cada vez que hable jajaja» · Luis no está en el grupo.'
      ],
      pregunta: '¿Qué haces?',
      opciones: [
        {
          texto: 'Lo uso, todos lo están usando y es solo un sticker.',
          correcta: false,
          retro: 'Cada vez que se usa, la burla se repite. Y Luis no aceptó que su foto se volviera sticker.'
        },
        {
          texto: 'No lo uso, escribo «esto ya no da risa, bórrenlo» y, si Luis se entera y le afecta, lo apoyo.',
          correcta: true,
          retro: 'Bien hecho: no lo amplificas y le recuerdas al grupo que hay una persona real detrás.'
        },
        {
          texto: 'Lo edito para que quede más chistoso.',
          correcta: false,
          retro: 'Editarlo agranda la humillación y te vuelve parte de quien lo creó.'
        },
        {
          texto: 'Lo guardo por si luego sirve.',
          correcta: false,
          retro: 'Guardarlo «por si acaso» deja la puerta abierta a que vuelva a circular.'
        }
      ],
      explicacion: 'Tener la foto de alguien no da permiso para convertirla en sticker. Si se usa para burlarse y la persona no lo aceptó, es una humillación que se repite.',
      senales: [
        'Foto tomada sin que Luis lo supiera.',
        'Sirve para burlarse de él.',
        'Luis no puede opinar ni pedir que lo borren.'
      ],
      recomendacion: 'Si no te sientes seguro escribiendo en el grupo, basta con no usarlo ni reenviarlo, y avisarle a un adulto si la burla crece.',
      ayuda: 'Si el sticker se difunde a otros grupos o Luis se ve afectado, cuéntaselo a orientación o a un profesor.'
    },
    {
      id: 'conv-foto-sin-permiso',
      paquete: 'conv-fotos',
      paso: 'prevenir',
      lugar: 'Después de una fiesta',
      escena: [
        'Tienes una foto del grupo de la fiesta del sábado. Todos salen bien, menos Majo, que salió con los ojos cerrados y comiendo.',
        'Quieres subirla a tus historias porque es la única donde salen todos.'
      ],
      pregunta: '¿Qué haces antes de publicarla?',
      opciones: [
        {
          texto: 'La subo y etiqueto a todos, es una foto normal.',
          correcta: false,
          retro: 'Para ti es normal, pero cada quien decide sobre su imagen. Majo podría sentirse expuesta.'
        },
        {
          texto: 'Les pregunto a quienes salen si la puedo subir. Si alguien no quiere, no la subo o uso otra.',
          correcta: true,
          retro: '¡Exacto! Preguntar toma 10 segundos y evita que alguien se sienta humillado.'
        },
        {
          texto: 'La subo sin etiquetar a Majo para que no se dé cuenta.',
          correcta: false,
          retro: 'Sin etiqueta igual la pueden ver y reconocer. El problema es el permiso, no la etiqueta.'
        },
        {
          texto: 'La subo solo a «mejores amigos».',
          correcta: false,
          retro: 'Aunque la vea menos gente, sigue siendo publicar a alguien sin preguntarle. Y cualquiera puede tomarle captura.'
        }
      ],
      explicacion: 'El consentimiento es específico: aceptar salir en una foto no es aceptar que se publique. Preguntar antes es una de las formas más sencillas de prevenir conflictos.',
      senales: [
        'Alguien sale en un momento que podría avergonzarle.',
        'Nadie dio permiso para publicarla.'
      ],
      recomendacion: 'Pregunta así: «¿Puedo subir esta foto a mis historias?». Y si alguien te pide después que la quites, quítala.',
      ayuda: 'Si alguien publica una foto tuya que no quieres y no la quita cuando se lo pides, puedes reportarla y pedir apoyo a un adulto.'
    },
    {
      id: 'conv-video-humillante',
      paquete: 'conv-fotos',
      paso: 'actuar',
      canal: 'TikTok · Te lo mandaron',
      remitente: 'Video que circula en la prepa',
      mensajes: [
        'Circula un video donde a un alumno de primero se le cae la charola en la cafetería y varios le gritan y se burlan.',
        'Ya lo compartieron en varios grupos y alguien lo subió a TikTok.'
      ],
      pregunta: 'Te llega el video. ¿Qué haces?',
      opciones: [
        {
          texto: 'Lo reenvío para que vean lo que pasó.',
          correcta: false,
          retro: 'Aunque sea «para avisar», reenviarlo hace que más gente vea la humillación.'
        },
        {
          texto: 'Le doy «me gusta» o comento con risas.',
          correcta: false,
          retro: 'Las reacciones hacen que el algoritmo lo muestre a más personas.'
        },
        {
          texto: 'No lo comparto, reporto la publicación y aviso a orientación. Si conozco al alumno, le ofrezco apoyo en privado.',
          correcta: true,
          retro: 'Así se corta la cadena: menos personas lo ven y un adulto puede pedir que lo quiten.'
        },
        {
          texto: 'Comento quién lo grabó para exhibirlo.',
          correcta: false,
          retro: 'Exhibir a alguien en los comentarios genera más ataques y no ayuda al alumno afectado.'
        }
      ],
      explicacion: 'Un video que humilla a alguien hace daño cada vez que se ve. Quien graba, quien sube, quien reenvía y quien reacciona suman al daño.',
      senales: [
        'Se grabó a alguien en un momento vergonzoso.',
        'Hay burlas de un grupo.',
        'Se está difundiendo a más lugares.'
      ],
      recomendacion: 'Reporta el video como acoso o bullying desde el menú de la publicación. Si ya lo tienes en el celular, bórralo.',
      ayuda: 'Avísale a orientación aunque no sepas quién lo grabó: la escuela puede apoyar al alumno y pedir que se elimine.'
    },
    {
      id: 'conv-imagen-intima',
      paquete: 'conv-fotos',
      paso: 'actuar',
      delicado: true,
      lugar: 'Un chat grupal',
      escena: [
        'En un grupo dicen que alguien mandó una imagen íntima de una compañera de la prepa, que es menor de edad.',
        'Varios piden que la pasen. A ti todavía no te ha llegado, pero podría llegarte.'
      ],
      pregunta: 'Si te llega, ¿qué es lo correcto?',
      opciones: [
        {
          texto: 'La guardo como prueba para enseñársela a un profesor.',
          correcta: false,
          retro: 'Aunque la intención sea buena, guardarla o enseñarla la sigue difundiendo, y también es delito. El adulto no necesita verla para ayudar.'
        },
        {
          texto: 'La reenvío al grupo para que todos sepan que circula.',
          correcta: false,
          retro: 'Reenviarla la difunde más y daña aún más a tu compañera. Además es un delito.'
        },
        {
          texto: 'No la abro ni la descargo, salgo del chat, aviso a un adulto de confianza y la reporto en la plataforma y en teprotejomexico.org.',
          correcta: true,
          retro: 'Es lo más seguro. Para ayudar basta con decir dónde circula y cuándo; no hace falta mostrarla.'
        },
        {
          texto: 'Pregunto en el grupo quién la mandó para exhibirlo.',
          correcta: false,
          retro: 'Exhibir a alguien en el grupo aumenta el escándalo alrededor de tu compañera. Eso lo atienden los adultos y las autoridades.'
        }
      ],
      explicacion: 'Difundir contenido íntimo de una persona menor de edad es un delito grave, y quien aparece en él nunca tiene la culpa. La prioridad es detener su circulación y que intervengan adultos y autoridades.',
      senales: [
        'Contenido íntimo de una persona menor de edad.',
        'Se está pidiendo que circule.'
      ],
      recomendacion: 'Para pedir ayuda solo necesitas decir en qué chat o plataforma circula y desde cuándo. No guardes ni reenvíes nada.',
      ayuda: 'Avísale hoy a un adulto de confianza o a orientación. Es un delito: los adultos pueden denunciarlo ante la Fiscalía o la policía cibernética.'
    },
    {
      id: 'conv-presion-fotos',
      paquete: 'conv-fotos',
      paso: 'actuar',
      canal: 'Instagram · Mensaje directo',
      remitente: 'Tu pareja',
      mensajes: [
        'Si de verdad me quieres, mándame una foto sin ropa.',
        'Todos lo hacen. Si no, es que no confías en mí.'
      ],
      pregunta: '¿Qué haces?',
      opciones: [
        {
          texto: 'Se la mando para que no se enoje.',
          correcta: false,
          retro: 'Nadie debe presionarte. Una vez enviada, pierdes el control de la imagen.'
        },
        {
          texto: 'Le digo que no, sin dar más explicaciones. Si insiste o amenaza, guardo los mensajes, lo bloqueo y hablo con un adulto.',
          correcta: true,
          retro: '¡Bien! Tu «no» es suficiente. Quien te quiere respeta tus límites.'
        },
        {
          texto: 'Se la mando si me promete borrarla.',
          correcta: false,
          retro: 'No hay forma de comprobar que la borre, y una promesa no evita que se difunda.'
        }
      ],
      explicacion: 'La presión («si me quieres…», «todos lo hacen») es una forma de manipulación. El consentimiento tiene que ser libre: si hay presión, no es consentimiento.',
      senales: [
        'Usa el cariño para presionarte.',
        'Dice que «todos lo hacen».',
        'Te hace sentir culpable por decir que no.'
      ],
      recomendacion: 'Puedes responder: «No, y no voy a cambiar de opinión». No tienes que justificarte.',
      ayuda: 'Si te amenaza con publicar algo o te sigue presionando, cuéntaselo a un adulto de confianza: eso ya es violencia y se puede denunciar.'
    },
    {
      id: 'conv-capturas-privadas',
      paquete: 'conv-fotos',
      paso: 'prevenir',
      canal: 'WhatsApp · Chat privado',
      remitente: 'Tu amigo Beto',
      mensajes: [
        'Mira, tengo capturas de lo que Pau le contó a su mejor amiga sobre sus papás. 😳',
        '¿Las subo al grupo? Ya nos vamos a reír un rato.'
      ],
      pregunta: '¿Qué le respondes a Beto?',
      opciones: [
        {
          texto: '«Sí, súbelas, va a estar bueno.»',
          correcta: false,
          retro: 'Publicar una conversación privada expone algo muy personal de Pau, sin su permiso.'
        },
        {
          texto: '«Mejor súbelas sin el nombre.»',
          correcta: false,
          retro: 'En el salón todos sabrán de quién se trata. Quitar el nombre no quita el daño.'
        },
        {
          texto: '«No las subas: eso es muy personal de Pau. Mejor bórralas.»',
          correcta: true,
          retro: '¡Bien! Frenar a un amigo antes de que publique es una de las formas más efectivas de prevenir.'
        }
      ],
      explicacion: 'Las capturas de conversaciones privadas, igual que los audios sacados de contexto, pueden exponer y humillar. Que alguien te las pase no te da permiso para difundirlas.',
      senales: [
        'Es información privada de otra persona.',
        'La idea es reírse de ella.'
      ],
      recomendacion: 'Si Beto las publica de todos modos, no reacciones y avísale a Pau en privado o a un adulto.',
      ayuda: 'Si las capturas ya circulan y Pau está afectada, avisa a orientación para que ayuden a detener la difusión.'
    },

    // ---------- Paquete 5: En la escuela ----------
    {
      id: 'conv-recreo-agresion',
      paquete: 'conv-escuela',
      paso: 'actuar',
      lugar: 'Patio, durante el recreo',
      escena: [
        'Ves que dos alumnos de tercero empujan contra la pared a uno de primero y le quitan su almuerzo.',
        'Es la segunda vez que lo ves esta semana. Hay un prefecto en la entrada del patio.'
      ],
      pregunta: '¿Qué es lo más seguro?',
      opciones: [
        {
          texto: 'Me meto a empujarlos para defenderlo.',
          correcta: false,
          retro: 'Son más grandes y son dos: puedes salir lastimado y la pelea puede crecer.'
        },
        {
          texto: 'Lo grabo con el celular para tener pruebas.',
          correcta: false,
          retro: 'Grabar puede humillar más al alumno si el video circula. Recuerda los detalles y díselos a un adulto.'
        },
        {
          texto: 'Voy de inmediato con el prefecto y después me acerco al alumno en privado para ver cómo está.',
          correcta: true,
          retro: '¡Eso! Llamas a quien puede detenerlo sin ponerte en riesgo, y el alumno sabe que alguien lo vio y le importa.'
        },
        {
          texto: 'Hago como que no vi nada.',
          correcta: false,
          retro: 'Es una situación que se repite y hay riesgo físico. Avisar a un adulto no te pone en peligro y puede detenerlo.'
        }
      ],
      explicacion: 'Se repite, hay desequilibrio de poder (son mayores y son dos) y hay agresión física: es bullying. La prioridad es la seguridad, la de él y la tuya.',
      senales: [
        'Agresión física.',
        'Son mayores y son varios.',
        'Ya pasó antes.'
      ],
      recomendacion: 'Para avisar sirve decir qué pasó, dónde, cuándo y quiénes estaban. No necesitas video.',
      ayuda: 'Si alguien queda lastimado o la agresión no para, busca a cualquier adulto de inmediato. En una emergencia grave, 911.'
    },
    {
      id: 'conv-pelea-grabar',
      paquete: 'conv-escuela',
      paso: 'actuar',
      lugar: 'Salida de la escuela',
      escena: [
        'Empieza una pelea afuera de la escuela. Se juntan muchos alumnos alrededor.',
        'Todos gritan «¡grábalo, grábalo!» y varios ya tienen el celular en la mano.'
      ],
      pregunta: '¿Qué haces?',
      opciones: [
        {
          texto: 'La grabo, si todos lo hacen no pasa nada.',
          correcta: false,
          retro: 'Un video de la pelea puede circular por años y humillar a los involucrados. Que todos lo hagan no lo hace correcto.'
        },
        {
          texto: 'Me acerco a animar.',
          correcta: false,
          retro: 'El público anima la pelea y la hace más violenta.'
        },
        {
          texto: 'No grabo, me alejo del círculo y aviso a un adulto de la escuela. Si alguien sale gravemente herido, llamo o pido que llamen al 911.',
          correcta: true,
          retro: 'Correcto: le quitas público, te mantienes a salvo y llega quien puede detenerla.'
        },
        {
          texto: 'Subo el video de alguien más para denunciar lo que pasa.',
          correcta: false,
          retro: 'Publicarlo para «denunciar» igual difunde la humillación. Las denuncias se hacen ante adultos y autoridades, no en redes.'
        }
      ],
      explicacion: 'Animar, rodear o grabar una pelea la empeora: le da público y el video la convierte en una humillación que se repite en línea.',
      senales: [
        'Hay violencia física.',
        'El público anima y graba.'
      ],
      recomendacion: 'Alejarte también es actuar. Puedes decirle a quien está a tu lado: «Vamos por un profe».',
      ayuda: 'Busca a personal de la escuela de inmediato. Si hay heridos graves o armas, llama al 911.'
    },
    {
      id: 'conv-apodo',
      paquete: 'conv-escuela',
      paso: 'identificar',
      lugar: 'Salón de clases',
      escena: [
        'A Toño le dicen «el ratón» por sus dientes. Todo el salón lo usa, hasta algunos profes sin saber.',
        'Él se ríe cuando se lo dicen, pero notas que después se queda callado y ya no participa en clase.'
      ],
      pregunta: '¿Es solo una broma?',
      opciones: [
        {
          texto: 'Sí, él se ríe, así que no le molesta.',
          correcta: false,
          retro: 'Reírse puede ser una forma de defenderse o de no quedar mal. Fíjate en lo que pasa después.'
        },
        {
          texto: 'Puede que no. Dejo de usar el apodo, lo llamo por su nombre y le pregunto en privado si le molesta.',
          correcta: true,
          retro: '¡Muy bien! No sacas conclusiones a la carrera: observas, preguntas en privado y cambias tu parte.'
        },
        {
          texto: 'Le digo que se aguante, a todos nos dicen algo.',
          correcta: false,
          retro: 'Minimizarlo hace que Toño sienta que no puede pedir ayuda.'
        },
        {
          texto: 'Regaño a todo el salón frente a él.',
          correcta: false,
          retro: 'La intención es buena, pero hacerlo en público puede exponerlo más. Mejor pregúntale primero.'
        }
      ],
      explicacion: 'Una broma lo es cuando todos se ríen de verdad, incluida la persona. Un apodo sobre una característica física, que todos repiten y que cambia su forma de actuar, es una señal de alerta.',
      senales: [
        'Se burla de una característica física.',
        'Lo repite todo el salón.',
        'Toño cambió: ya no participa.'
      ],
      recomendacion: 'Puedes decirle: «Oye, ¿te molesta que te digan así? Si quieres, ya no lo digo y le pido a otros que tampoco».',
      ayuda: 'Si Toño te dice que le afecta o notas que está muy triste, anímalo a hablar con orientación, o acompáñalo.'
    },
    {
      id: 'conv-represalias',
      paquete: 'conv-escuela',
      paso: 'actuar',
      lugar: 'Pasillos y chat del salón',
      escena: [
        'A Sofi le escondían la mochila casi todos los días. Se lo contó a su profesora y la regañaron a quienes lo hacían.',
        'Ahora le dicen «chismosa» en el salón y en el chat del grupo, y le dejaron de hablar.'
      ],
      pregunta: 'Sofi es tu amiga. ¿Qué le aconsejas?',
      opciones: [
        {
          texto: 'Que no vuelva a decir nada porque se pone peor.',
          correcta: false,
          retro: 'Eso es justo lo que quieren las represalias: que deje de pedir ayuda.'
        },
        {
          texto: 'Que vuelva a avisar a la profesora u orientación de las represalias, y la acompaño. Mientras, no la dejo sola.',
          correcta: true,
          retro: '¡Bien! Las represalias por pedir ayuda también se atienden, y tu compañía la protege.'
        },
        {
          texto: 'Que les esconda sus cosas para que sepan lo que se siente.',
          correcta: false,
          retro: 'La venganza alarga el conflicto y puede meter en problemas a Sofi.'
        }
      ],
      explicacion: 'Las represalias contra quien pide ayuda son otra forma de acoso, en persona y en el chat. Pedir ayuda no es «ser chismosa»: es cuidarse.',
      senales: [
        'Castigan a Sofi por haber pedido ayuda.',
        'El acoso pasó del salón al chat.',
        'La dejan sola.'
      ],
      recomendacion: 'Pueden anotar qué dicen, cuándo y dónde (también lo del chat), para que la profesora vea que sigue pasando.',
      ayuda: 'Si las represalias siguen después de volver a avisar, pueden pedir ayuda a la dirección o a la familia de Sofi.'
    },
    {
      id: 'conv-apoyar-amigo',
      paquete: 'conv-escuela',
      paso: 'actuar',
      lugar: 'Recreo',
      escena: [
        'Un grupo intimida a tu amigo Emi: lo empujan, le quitan la gorra y lo esperan a la salida.',
        'Quieres ayudarlo, pero son varios y te da miedo.'
      ],
      pregunta: '¿Cómo lo ayudas sin ponerte en peligro?',
      opciones: [
        {
          texto: 'Los enfrento solo para que lo dejen en paz.',
          correcta: false,
          retro: 'Enfrentar a un grupo solo te pone en riesgo. No es tu responsabilidad resolverlo por tu cuenta.'
        },
        {
          texto: 'Publico en redes lo que le hacen para que todos se enteren.',
          correcta: false,
          retro: 'Exponerlo en redes puede humillar más a Emi y provocar represalias. Eso se reporta con adultos.'
        },
        {
          texto: 'No lo dejo solo en el recreo ni a la salida, y vamos juntos a orientación a contar lo que pasa.',
          correcta: true,
          retro: '¡Eso! Acompañar protege y le da valor para pedir ayuda. Un adulto puede detener al grupo.'
        },
        {
          texto: 'No hago nada para no ser el siguiente.',
          correcta: false,
          retro: 'El miedo es normal. Pero hay formas seguras de ayudar, como avisar a un adulto.'
        }
      ],
      explicacion: 'Ayudar no significa pelear. Las formas más seguras de apoyar son acompañar, no dejar sola a la persona y llevar el caso a un adulto.',
      senales: [
        'Intimidación de un grupo.',
        'Lo esperan a la salida: hay riesgo.',
        'Pasa en persona.'
      ],
      recomendacion: 'Puedes decirle: «No es tu culpa. ¿Vamos juntos a orientación? Yo te acompaño».',
      ayuda: 'Si lo amenazan con golpearlo a la salida, avisa ese mismo día a un adulto de la escuela o a su familia.'
    },
    {
      id: 'conv-reparar',
      paquete: 'conv-escuela',
      paso: 'actuar',
      lugar: 'Después de compartir un meme',
      escena: [
        'La semana pasada compartiste en varios grupos un meme que se burlaba de Karla. Te pareció chistoso.',
        'Ahora te enteras de que Karla no quiere venir a la escuela por eso.'
      ],
      pregunta: '¿Qué haces?',
      opciones: [
        {
          texto: 'Nada: yo no lo creé, solo lo compartí.',
          correcta: false,
          retro: 'Compartirlo hizo que llegara a más gente. Tú también puedes ayudar a detenerlo.'
        },
        {
          texto: 'Lo borro, pido a quienes se lo mandé que lo borren, me disculpo con Karla sin excusas ni presión y pido ayuda a un adulto para reparar el daño.',
          correcta: true,
          retro: 'Reconocerlo, detenerlo y repararlo es lo más valiente que puedes hacer.'
        },
        {
          texto: 'Le pido perdón en el grupo y le exijo que me perdone.',
          correcta: false,
          retro: 'Una disculpa no obliga a perdonar, y hacerlo en el grupo vuelve a exponer a Karla.'
        },
        {
          texto: 'Le digo que fue una broma y que no exagere.',
          correcta: false,
          retro: '«Era una broma» no borra el daño. Lo importante es cómo lo vivió ella.'
        }
      ],
      explicacion: 'Haberte equivocado no te hace una mala persona. Lo que cuenta es detener el daño, asumir tu parte y no repetirlo.',
      senales: [
        'Compartiste contenido que humilla a alguien.',
        'Karla está muy afectada: no quiere ir a la escuela.'
      ],
      recomendacion: 'Una disculpa sencilla: «Perdón por compartir el meme. Ya lo borré y pedí que lo borren. No se va a repetir». Y respeta si no quiere hablar.',
      ayuda: 'Habla con orientación: pueden ayudar a reparar el daño y a que Karla reciba apoyo.'
    }
  ];


  // Separa un texto en partes normales y enlaces falsos ([[...]]).
  function partirMensaje(texto) {
    const partes = [];
    const patron = /\[\[(.+?)\]\]/g;
    let ultimo = 0;
    let encontrado;
    while ((encontrado = patron.exec(texto)) !== null) {
      if (encontrado.index > ultimo) partes.push({ tipo: 'texto', valor: texto.slice(ultimo, encontrado.index) });
      partes.push({ tipo: 'enlace', valor: encontrado[1] });
      ultimo = patron.lastIndex;
    }
    if (ultimo < texto.length) partes.push({ tipo: 'texto', valor: texto.slice(ultimo) });
    return partes;
  }

  function escenariosDePaquete(idPaquete) {
    return ESCENARIOS.filter(function (escenario) {
      return escenario.paquete === idPaquete;
    });
  }

  // ---------- Parte visual ----------
  let contenedor = null;
  let paqueteActual = null;
  let escenariosActuales = [];
  let indiceActual = 0;
  let aciertos = 0;

  function crear(etiqueta, clase, texto) {
    const elemento = document.createElement(etiqueta);
    if (clase) elemento.className = clase;
    if (texto !== undefined) elemento.textContent = texto;
    return elemento;
  }

  function dibujarChat(escenario) {
    const chat = crear('div', 'chat');
    const cabecera = crear('div', 'chat__cabecera');
    cabecera.appendChild(crear('span', 'chat__canal', escenario.canal));
    cabecera.appendChild(crear('span', 'chat__remitente', escenario.remitente));
    if (escenario.asunto) cabecera.appendChild(crear('span', 'chat__asunto', 'Asunto: ' + escenario.asunto));
    chat.appendChild(cabecera);

    escenario.mensajes.forEach(function (mensaje) {
      const burbuja = crear('p', 'chat__burbuja');
      partirMensaje(mensaje).forEach(function (parte) {
        if (parte.tipo === 'enlace') {
          const enlace = crear('span', 'enlace-falso', parte.valor);
          enlace.setAttribute('aria-label', 'Enlace falso: ' + parte.valor);
          burbuja.appendChild(enlace);
        } else {
          burbuja.appendChild(document.createTextNode(parte.valor));
        }
      });
      chat.appendChild(burbuja);
    });
    chat.appendChild(crear('p', 'chat__aviso', 'Mensaje ficticio para practicar. Los enlaces no funcionan.'));
    return chat;
  }

  // Escena narrada (para lo que pasa en persona): lugar + párrafos.
  function dibujarEscena(escenario) {
    const escena = crear('div', 'escena-caso');
    escena.appendChild(crear('p', 'escena-caso__lugar', escenario.lugar));
    escenario.escena.forEach(function (parrafo) {
      escena.appendChild(crear('p', 'escena-caso__texto', parrafo));
    });
    escena.appendChild(crear('p', 'chat__aviso', 'Situación ficticia para practicar. Los nombres son inventados.'));
    return escena;
  }

  // Pantalla para elegir paquete, con lo que llevas dominado de cada uno.
  function dibujarPaquetes() {
    paqueteActual = null;
    contenedor.textContent = '';
    contenedor.appendChild(Interfaz.selectorMisiones({
      tipo: 'escenario',
      misiones: PAQUETES.map(function (paquete) {
        const ids = escenariosDePaquete(paquete.id).map(function (escenario) {
          return escenario.id;
        });
        return Object.assign({}, paquete, { ids: ids, unidad: 'escenarios dominados' });
      }),
      alElegir: empezarPaquete
    }));
    Interfaz.animarEntrada(contenedor);
  }

  function empezarPaquete(idPaquete) {
    paqueteActual = PAQUETES.find(function (paquete) {
      return paquete.id === idPaquete;
    });
    escenariosActuales = escenariosDePaquete(idPaquete);
    indiceActual = 0;
    aciertos = 0;
    dibujarEscenario();
    Interfaz.subirAlInicio(contenedor);
  }

  function dibujarEscenario() {
    const escenario = escenariosActuales[indiceActual];
    contenedor.textContent = '';

    contenedor.appendChild(Interfaz.barraJuego(paqueteActual.nombre, dibujarPaquetes));
    contenedor.appendChild(Interfaz.barraProgreso(indiceActual, escenariosActuales.length, 'Escenario'));
    if (Progreso.estaDominado('escenario', escenario.id)) {
      contenedor.appendChild(crear('p', 'etiqueta-repaso', 'Repaso · ya lo dominas'));
    }
    contenedor.appendChild(escenario.escena ? dibujarEscena(escenario) : dibujarChat(escenario));
    if (escenario.paso) {
      contenedor.appendChild(crear('p', 'etiqueta-paso etiqueta-paso--' + escenario.paso, PASOS[escenario.paso]));
    }
    contenedor.appendChild(crear('h3', 'juego__pregunta', escenario.pregunta || '¿Qué harías?'));

    const opciones = crear('div', 'opciones');
    escenario.opciones.forEach(function (opcion, indice) {
      const boton = crear('button', 'opcion', opcion.texto);
      boton.type = 'button';
      boton.addEventListener('click', function () {
        responder(indice, opciones);
      });
      opciones.appendChild(boton);
    });
    contenedor.appendChild(opciones);
    Interfaz.animarEntrada(contenedor);
  }

  function responder(indiceElegido, opciones) {
    const escenario = escenariosActuales[indiceActual];
    const elegida = escenario.opciones[indiceElegido];
    opciones.querySelectorAll('.opcion').forEach(function (boton, indice) {
      boton.disabled = true;
      if (escenario.opciones[indice].correcta) boton.classList.add('opcion--correcta');
      else if (indice === indiceElegido) boton.classList.add('opcion--incorrecta');
    });

    if (elegida.correcta) aciertos += 1;
    const ganado = Progreso.registrarRespuesta('escenario', escenario.id, elegida.correcta, XP_POR_ACIERTO);

    const esUltimo = indiceActual === escenariosActuales.length - 1;
    // En los paquetes de convivencia se explican también las otras opciones,
    // con el consejo práctico y cuándo pedir ayuda.
    const convivencia = !!paqueteActual.convivencia;
    contenedor.appendChild(Interfaz.panelRetro({
      acerto: elegida.correcta,
      xpGanado: ganado,
      xpPosible: XP_POR_ACIERTO,
      mensaje: elegida.retro,
      explicacion: escenario.explicacion,
      senales: escenario.senales,
      tituloBien: convivencia ? '¡Buena decisión!' : null,
      tituloMal: convivencia ? 'Hay una opción más segura' : null,
      otras: convivencia ? escenario.opciones.filter(function (opcion, indice) {
        return indice !== indiceElegido && !opcion.correcta;
      }) : null,
      correcta: convivencia && !elegida.correcta ? escenario.opciones.find(function (opcion) {
        return opcion.correcta;
      }) : null,
      recomendacion: escenario.recomendacion,
      ayuda: escenario.ayuda,
      calma: !!escenario.delicado,
      textoBoton: esUltimo ? 'Ver resultados' : 'Siguiente escenario',
      alContinuar: function () {
        if (esUltimo) dibujarResultados();
        else {
          indiceActual += 1;
          dibujarEscenario();
          Interfaz.subirAlInicio(contenedor);
        }
      }
    }));
  }

  function dibujarResultados() {
    contenedor.textContent = '';
    const ids = escenariosActuales.map(function (escenario) {
      return escenario.id;
    });
    const dominados = Progreso.contarDominados('escenario', ids);
    contenedor.appendChild(Interfaz.panelResultados({
      titulo: paqueteActual.nombre,
      aciertos: aciertos,
      total: escenariosActuales.length,
      detalle: 'Dominados en este paquete: ' + dominados + ' de ' + ids.length,
      celebrar: dominados === ids.length,
      textoRepetir: 'Repetir paquete',
      alRepetir: function () {
        empezarPaquete(paqueteActual.id);
      },
      textoVolver: 'Elegir otro paquete',
      alVolver: function () {
        dibujarPaquetes();
        Interfaz.subirAlInicio(contenedor);
      }
    }));
    Interfaz.subirAlInicio(contenedor);
  }

  function iniciar() {
    contenedor = document.getElementById('simulador-juego');
    if (!contenedor) return;
    dibujarPaquetes();
    document.addEventListener('progreso-cambio', function () {
      if (!paqueteActual) dibujarPaquetes();
    });
  }

  const Simulador = {
    PAQUETES: PAQUETES,
    ESCENARIOS: ESCENARIOS,
    PASOS: PASOS,
    XP_POR_ACIERTO: XP_POR_ACIERTO,
    partirMensaje: partirMensaje,
    escenariosDePaquete: escenariosDePaquete,
    iniciar: iniciar
  };

  if (typeof module === 'object' && module.exports) module.exports = Simulador;
  else global.Simulador = Simulador;
})(this);
