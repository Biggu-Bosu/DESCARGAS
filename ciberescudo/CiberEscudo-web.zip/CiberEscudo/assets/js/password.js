// CiberEscudo · password.js
// Verificador de contraseñas 100 % local.
//
// REGLA DE SEGURIDAD: este archivo NUNCA usa localStorage, cookies ni internet.
// La contraseña solo vive en el campo de texto y en variables temporales.
// Se borra al salir de la sección, al mandar la app al fondo o al tocar "Borrar".
// Es una evaluación educativa: revisa reglas sencillas, no ataca la contraseña.

(function (global) {
  'use strict';

  // Contraseñas que aparecen en las listas de "las más usadas".
  const MUY_COMUNES = [
    '123456', '1234567', '12345678', '123456789', '1234567890', '111111',
    '000000', '123123', '654321', '666666', '121212', '112233', 'qwerty',
    'qwerty123', 'abc123', 'password', 'password1', 'contraseña', 'contrasena',
    'iloveyou', 'teamo', 'teamo123', 'admin', 'admin123', 'hola123', 'mexico',
    'america', 'futbol', 'princesa', 'dragon', 'monkey', 'superman', 'batman',
    'qwertyuiop', 'asdfghjkl', 'zxcvbnm', '1q2w3e4r', 'aaaaaa', 'abcdef'
  ];

  // Palabras que, aunque estén dentro de algo más largo, lo hacen fácil de adivinar.
  const PALABRAS_COMUNES = [
    'password', 'contraseña', 'contrasena', 'qwerty', 'admin', 'iloveyou',
    'teamo', 'futbol', 'america', 'mexico', 'chivas', 'pumas', 'cruzazul',
    'lazaro', 'cardenas', 'prepa', 'escuela', 'hola', 'amor', 'princesa',
    'usuario', 'clave'
  ];

  const SECUENCIAS = [
    'abcdefghijklmnopqrstuvwxyz',
    '01234567890',
    'qwertyuiop',
    'asdfghjkl',
    'zxcvbnm'
  ];

  const NIVELES = [
    { clave: 'muy-debil', etiqueta: 'Muy débil' },
    { clave: 'debil', etiqueta: 'Débil' },
    { clave: 'regular', etiqueta: 'Regular' },
    { clave: 'fuerte', etiqueta: 'Fuerte' },
    { clave: 'muy-fuerte', etiqueta: 'Muy fuerte' }
  ];

  // Palabras para generar frases de ejemplo (fáciles de recordar, difíciles de adivinar).
  const PALABRAS_FRASE = [
    'nopal', 'cohete', 'lluvia', 'tigre', 'volcan', 'mango', 'pixel', 'neon',
    'tortuga', 'brujula', 'galleta', 'cometa', 'jaguar', 'trompeta', 'cactus',
    'satelite', 'pinguino', 'guitarra', 'mariposa', 'tormenta', 'canica',
    'elote', 'robot', 'faro', 'ajolote', 'colibri', 'tamal', 'luna', 'oceano'
  ];

  // Busca 4 caracteres seguidos de una secuencia (por ejemplo "abcd", "4321" o "qwer").
  function tieneSecuencia(texto) {
    const minusculas = texto.toLowerCase();
    for (const secuencia of SECUENCIAS) {
      const alReves = secuencia.split('').reverse().join('');
      for (let inicio = 0; inicio + 4 <= secuencia.length; inicio += 1) {
        if (minusculas.includes(secuencia.slice(inicio, inicio + 4))) return true;
        if (minusculas.includes(alReves.slice(inicio, inicio + 4))) return true;
      }
    }
    return false;
  }

  // Analiza la contraseña y regresa un resumen. No guarda nada.
  function analizar(contrasena) {
    const texto = String(contrasena || '');
    if (texto.length === 0) return null;

    const minusculas = texto.toLowerCase();
    const sinNumerosFinales = minusculas.replace(/[0-9!.]+$/, '');
    const palabras = texto.trim().split(/[\s\-_.]+/).filter(Boolean);

    const criterios = {
      largo12: texto.length >= 12,
      minusculas: /[a-zñáéíóúü]/.test(texto),
      mayusculas: /[A-ZÑÁÉÍÓÚÜ]/.test(texto),
      numeros: /[0-9]/.test(texto),
      simbolos: /[^A-Za-z0-9ñÑáéíóúÁÉÍÓÚüÜ\s]/.test(texto),
      frase: palabras.length >= 3 && texto.length >= 16
    };

    const problemas = [];
    let puntos = 0;

    // 1. Longitud: es lo que más cuenta.
    if (texto.length >= 20) puntos = 4;
    else if (texto.length >= 16) puntos = 3;
    else if (texto.length >= 12) puntos = 2;
    else if (texto.length >= 8) puntos = 1;
    else problemas.push('Es muy corta: tiene menos de 8 caracteres.');

    // 2. Variedad: mezclar tipos de caracteres ayuda un poco.
    const tipos = [criterios.minusculas, criterios.mayusculas, criterios.numeros, criterios.simbolos]
      .filter(Boolean).length;
    if (tipos >= 3 && texto.length >= 10) puntos += 1;
    if (criterios.frase) puntos += 1;

    // 3. Patrones fáciles de adivinar: restan.
    const esMuyComun = MUY_COMUNES.includes(minusculas) || MUY_COMUNES.includes(sinNumerosFinales);
    if (esMuyComun) {
      problemas.push('Está en las listas de contraseñas más usadas. Se adivina en segundos.');
    }
    const palabraComun = PALABRAS_COMUNES.find(function (palabra) {
      return minusculas.includes(palabra);
    });
    if (palabraComun && !esMuyComun) {
      puntos -= 1;
      problemas.push('Incluye una palabra muy usada ("' + palabraComun + '").');
    }
    if (tieneSecuencia(texto)) {
      puntos -= 1;
      problemas.push('Tiene una secuencia como "1234", "abcd" o "qwer".');
    }
    if (/(.)\1\1/.test(texto)) {
      puntos -= 1;
      problemas.push('Repite el mismo caracter 3 veces o más.');
    }
    if (/(19|20)\d{2}/.test(texto) || /\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}/.test(texto)) {
      puntos -= 1;
      problemas.push('Parece tener un año o una fecha (por ejemplo, tu cumpleaños).');
    }
    if (/^\d+$/.test(texto)) {
      puntos = Math.min(puntos, 1);
      problemas.push('Solo tiene números.');
    }

    if (esMuyComun) puntos = 0;
    puntos = Math.max(0, Math.min(4, puntos));

    const consejos = [];
    if (!criterios.largo12) consejos.push('Hazla más larga: apunta a 16 caracteres o más.');
    if (!criterios.frase) {
      consejos.push('Prueba una frase de 4 palabras que no tengan relación, como "tortuga-cometa-faro-elote".');
    }
    if (tipos < 3) consejos.push('Mezcla mayúsculas, números o símbolos para hacerla más difícil.');
    consejos.push('Usa una contraseña distinta en cada cuenta importante.');
    consejos.push('Activa la verificación en dos pasos (2FA): aunque roben tu contraseña, no podrán entrar.');

    return {
      puntos: puntos,
      nivel: NIVELES[puntos],
      longitud: texto.length,
      criterios: criterios,
      problemas: problemas,
      consejos: consejos
    };
  }

  // Número al azar seguro (usa crypto si existe).
  function numeroAlAzar(maximo) {
    const cripto = global.crypto || (typeof require === 'function' ? require('crypto').webcrypto : null);
    if (cripto && cripto.getRandomValues) {
      const valores = new Uint32Array(1);
      cripto.getRandomValues(valores);
      return valores[0] % maximo;
    }
    return Math.floor(Math.random() * maximo);
  }

  function generarFrase() {
    const elegidas = [];
    while (elegidas.length < 4) {
      const palabra = PALABRAS_FRASE[numeroAlAzar(PALABRAS_FRASE.length)];
      if (!elegidas.includes(palabra)) elegidas.push(palabra);
    }
    const conMayuscula = elegidas.map(function (palabra, indice) {
      return indice === 1 ? palabra.charAt(0).toUpperCase() + palabra.slice(1) : palabra;
    });
    return conMayuscula.join('-') + '-' + (10 + numeroAlAzar(90));
  }

  // ---------- Parte visual ----------
  let elementos = null;

  const TEXTO_CRITERIOS = {
    largo12: 'Al menos 12 caracteres',
    minusculas: 'Minúsculas',
    mayusculas: 'Mayúsculas',
    numeros: 'Números',
    simbolos: 'Símbolos (! ? # - …)',
    frase: 'Frase de 3 palabras o más'
  };

  function llenarLista(lista, textos) {
    lista.textContent = '';
    textos.forEach(function (texto) {
      const elemento = document.createElement('li');
      elemento.textContent = texto;
      lista.appendChild(elemento);
    });
  }

  function mostrarResultado() {
    const resultado = analizar(elementos.campo.value);
    elementos.panel.hidden = !resultado;
    if (!resultado) {
      elementos.nivel.textContent = '';
      return;
    }
    elementos.medidor.dataset.puntos = String(resultado.puntos);
    elementos.medidor.setAttribute('aria-valuenow', String(resultado.puntos));
    elementos.medidor.setAttribute('aria-valuetext', resultado.nivel.etiqueta);
    elementos.nivel.textContent = 'Nivel: ' + resultado.nivel.etiqueta + ' · ' + resultado.longitud + ' caracteres';
    elementos.nivel.dataset.nivel = resultado.nivel.clave;

    elementos.criterios.textContent = '';
    Object.keys(TEXTO_CRITERIOS).forEach(function (clave) {
      const elemento = document.createElement('li');
      const cumple = resultado.criterios[clave];
      elemento.className = cumple ? 'criterio criterio--si' : 'criterio criterio--no';
      elemento.textContent = (cumple ? '✓ ' : '✗ ') + TEXTO_CRITERIOS[clave];
      elemento.setAttribute('aria-label', TEXTO_CRITERIOS[clave] + (cumple ? ': sí' : ': no'));
      elementos.criterios.appendChild(elemento);
    });

    elementos.bloqueProblemas.hidden = resultado.problemas.length === 0;
    llenarLista(elementos.problemas, resultado.problemas);
    llenarLista(elementos.consejos, resultado.consejos);
  }

  // Borra la contraseña de la pantalla y de la memoria de la página.
  function limpiar() {
    if (!elementos) return;
    elementos.campo.value = '';
    elementos.campo.type = 'password';
    elementos.botonMostrar.setAttribute('aria-pressed', 'false');
    elementos.botonMostrar.textContent = 'Mostrar';
    elementos.frase.textContent = '';
    elementos.bloqueFrase.hidden = true;
    mostrarResultado();
  }

  function iniciar() {
    const raiz = document.getElementById('vista-verificador');
    if (!raiz) return;
    elementos = {
      campo: document.getElementById('campo-contrasena'),
      botonMostrar: document.getElementById('boton-mostrar'),
      botonBorrar: document.getElementById('boton-borrar-contrasena'),
      botonFrase: document.getElementById('boton-frase'),
      bloqueFrase: document.getElementById('bloque-frase'),
      frase: document.getElementById('frase-ejemplo'),
      panel: document.getElementById('resultado-contrasena'),
      medidor: document.getElementById('medidor-contrasena'),
      nivel: document.getElementById('nivel-contrasena'),
      criterios: document.getElementById('criterios-contrasena'),
      bloqueProblemas: document.getElementById('bloque-problemas'),
      problemas: document.getElementById('problemas-contrasena'),
      consejos: document.getElementById('consejos-contrasena')
    };

    elementos.campo.addEventListener('input', mostrarResultado);

    elementos.botonMostrar.addEventListener('click', function () {
      const mostrar = elementos.campo.type === 'password';
      elementos.campo.type = mostrar ? 'text' : 'password';
      elementos.botonMostrar.setAttribute('aria-pressed', String(mostrar));
      elementos.botonMostrar.textContent = mostrar ? 'Ocultar' : 'Mostrar';
      elementos.campo.focus();
    });

    elementos.botonBorrar.addEventListener('click', function () {
      limpiar();
      elementos.campo.focus();
    });

    elementos.botonFrase.addEventListener('click', function () {
      elementos.frase.textContent = generarFrase();
      elementos.bloqueFrase.hidden = false;
    });

    // Si la app se va al fondo (cambias de app o apagas la pantalla), se borra.
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'hidden') limpiar();
    });
    window.addEventListener('pagehide', limpiar);

    limpiar();
  }

  const Verificador = {
    NIVELES: NIVELES,
    analizar: analizar,
    tieneSecuencia: tieneSecuencia,
    generarFrase: generarFrase,
    iniciar: iniciar,
    limpiar: limpiar
  };

  if (typeof module === 'object' && module.exports) module.exports = Verificador;
  else global.Verificador = Verificador;
})(this);
